if(!window.qxsettings)qxsettings={};
qxsettings["qx.application"]="Application";

if(!window.qxvariants)qxvariants={};
qxvariants["qx.debug"]="on";
qxvariants["qx.aspects"]="off";

if(!window.qxlibraries)qxlibraries={};qxlibraries["qx"]={"resourceUri":"./resource"};

if(!window.qxresourceinfo)qxresourceinfo={"qx/decoration/Classic/arrows/down-small-invert.gif": [5, 3, "gif", "qx"], "qx/decoration/Modern/window/captionbar-inactive-br.png": [5, 5, "png", "qx"], "qx/decoration/Classic/menu/checkbox-invert.gif": [16, 7, "gif", "qx"], "qx/decoration/Classic/cursors-combined.png": [71, 20, "png", "qx"], "qx/decoration/Modern/form/button-t.png": [4, 4, "png", "qx"], "qx/decoration/Modern/form/radiobutton-disabled.png": [14, 14, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-inactive-b.png": [5, 5, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-right-inactive-br.png": [5, 5, "png", "qx"], "qx/decoration/Modern/form/radiobutton-hovered.png": [14, 14, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-preselected-focused-l.png": [4, 52, "png", "qx", "qx/decoration/Modern/button-lr-combined.png", -16, 0], "frameworksource/resource/qx/decoration/Modern/form/radiobutton-checked-pressed.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -224, 0], "qx/decoration/Modern/scrollbar/scrollbar-bg-horizontal.png": [76, 15, "png", "qx"], "qx/decoration/Modern/cursors/nodrop.gif": [20, 20, "gif", "qx"], "qx/decoration/Modern/form/button-preselected-r.png": [4, 52, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/cursors/copy.gif": [19, 15, "gif", "qx", "qx/decoration/Modern/cursors-combined.png", -33, 0], "qx/decoration/Classic/menu/checkbox.gif": [16, 7, "gif", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-l.png": [4, 52, "png", "qx", "qx/decoration/Modern/button-lr-combined.png", -56, 0], "qx/decoration/Modern/tabview/tab-button-top-inactive-r.png": [5, 12, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-right-active-tr.png": [5, 5, "png", "qx"], "qx/decoration/Modern/window/captionbar-inactive-r.png": [5, 10, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-active-l.png": [5, 12, "png", "qx"], "qx/decoration/Classic/splitpane/knob-horizontal.png": [4, 15, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-left-inactive-r.png": [5, 37, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-focused-t.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -100], "qx/decoration/Modern/form/button-pressed-r.png": [4, 52, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/window/minimize-inactive.png": [9, 9, "png", "qx", "qx/decoration/Modern/window-combined.png", -27, 0], "frameworksource/resource/qx/decoration/Modern/form/radiobutton-focused.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -168, 0], "qx/decoration/Modern/window/statusbar-tr.png": [4, 4, "png", "qx"], "qx/icon/Oxygen/16/places/folder.png": [16, 16, "png", "qx"], "qx/decoration/Modern/form/checkbox-checked-focused.png": [14, 14, "png", "qx"], "qx/decoration/Modern/toolbar/toolbar-gradient.png": [1, 130, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/window/background-tl.png": [14, 14, "png", "qx", "qx/decoration/Modern/window-background-tb-combined.png", 0, 0], "frameworksource/resource/qx/decoration/Modern/form/button-focused-bl.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -156], "qx/decoration/Classic/menu/radiobutton.gif": [16, 5, "gif", "qx"], "frameworksource/resource/qx/decoration/Modern/window/maximize-active.png": [9, 9, "png", "qx", "qx/decoration/Modern/window-combined.png", -45, 0], "frameworksource/resource/qx/decoration/Modern/form/checkbox-hovered.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -70, 0], "frameworksource/resource/qx/decoration/Modern/form/radiobutton-checked.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -238, 0], "qx/decoration/Modern/window/captionbar-active-tr.png": [5, 5, "png", "qx"], "qx/decoration/Classic/datechooser/next-year-invert.png": [16, 16, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/radiobutton-pressed.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -196, 0], "qx/decoration/Modern/button-tb-combined.png": [4, 192, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-pressed-t.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -72], "qx/decoration/Modern/arrows/right.png": [5, 8, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-active-tl.png": [5, 5, "png", "qx"], "qx/decoration/Classic/arrows/rewind-invert.gif": [8, 7, "gif", "qx"], "qx/decoration/Modern/tabview/tab-button-top-inactive-br.png": [5, 5, "png", "qx"], "qx/decoration/Modern/tree/tree-closed-selected.png": [5, 8, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-right-active-b.png": [5, 5, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-hovered-b.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -116], "qx/decoration/Modern/pane/pane-b.png": [6, 6, "png", "qx"], "qx/decoration/Modern/form/button-hovered-br.png": [4, 4, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-checked-focused-t.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -136], "frameworksource/resource/qx/decoration/Modern/form/radiobutton-disabled.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -182, 0], "qx/decoration/Modern/window/captionbar-inactive-b.png": [5, 5, "png", "qx"], "qx/decoration/Modern/form/button-r.png": [4, 52, "png", "qx"], "qx/decoration/Classic/arrows/up-invert.gif": [7, 4, "gif", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-pressed-br.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -28], "qx/decoration/Modern/window/shadow-br.png": [14, 14, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/window/background-r.png": [14, 384, "png", "qx", "qx/decoration/Modern/window-background-lr-combined.png", -14, 0], "qx/decoration/Modern/form/button-focused-t.png": [4, 4, "png", "qx"], "qx/decoration/Modern/form/button-checked-focused-c.png": [40, 52, "png", "qx"], "qx/decoration/Classic/form/radiobutton-focused.png": [14, 14, "png", "qx"], "qx/decoration/Modern/window/minimize-inactive.png": [9, 9, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-top-active-c.png": [40, 12, "png", "qx"], "qx/decoration/Classic/arrows/right.gif": [4, 7, "gif", "qx"], "qx/decoration/Modern/form/button-checked-focused-l.png": [4, 52, "png", "qx"], "qx/decoration/Modern/window/background-bl.png": [14, 14, "png", "qx"], "qx/decoration/Modern/window/shadow-t.png": [14, 14, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/window/shadow-bl.png": [14, 14, "png", "qx", "qx/decoration/Modern/window-shadow-tb-combined.png", 0, -42], "qx/decoration/Modern/form/button-preselected-bl.png": [4, 4, "png", "qx"], "qx/decoration/Modern/scrollbar/scrollbar-bg-vertical.png": [15, 76, "png", "qx"], "qx/decoration/Modern/cursors/move.gif": [13, 9, "gif", "qx"], "qx/decoration/Modern/form/button-checked-focused-t.png": [4, 4, "png", "qx"], "qx/decoration/Modern/form/button-preselected-focused-b.png": [4, 4, "png", "qx"], "qx/decoration/Classic/arrows/left-invert.gif": [4, 7, "gif", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-preselected-bl.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -104], "qx/decoration/Modern/window/background-r.png": [14, 384, "png", "qx"], "qx/decoration/Modern/menu/checkbox-invert.gif": [16, 7, "gif", "qx"], "qx/decoration/Modern/tabview/tab-button-left-inactive-bl.png": [5, 5, "png", "qx"], "qx/decoration/Modern/form/button-checked-focused-r.png": [4, 52, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/pane/pane-tr.png": [6, 6, "png", "qx", "qx/decoration/Modern/pane-tb-combined.png", 0, -6], "frameworksource/resource/qx/decoration/Modern/form/button-preselected-t.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -56], "qx/decoration/Classic/form/checkbox-pressed.png": [14, 14, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/window/shadow-b.png": [14, 14, "png", "qx", "qx/decoration/Modern/window-shadow-tb-combined.png", 0, -56], "qx/decoration/Modern/window/captionbar-inactive-bl.png": [5, 5, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-checked-focused-tr.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -84], "qx/decoration/Modern/window/captionbar-active-t.png": [5, 5, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-right-active-tl.png": [5, 5, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-preselected-focused-b.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -96], "qx/decoration/Modern/form/button-pressed-tr.png": [4, 4, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-active-tr.png": [5, 5, "png", "qx"], "qx/decoration/Classic/colorselector/brightness-field.jpg": [19, 256, "jpeg", "qx"], "qx/decoration/Classic/arrows/right-small-invert.gif": [3, 5, "gif", "qx"], "qx/decoration/Classic/form/checkbox.png": [14, 14, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-top-inactive-t.png": [5, 5, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-right-active-bl.png": [5, 5, "png", "qx"], "qx/decoration/Modern/form/button-hovered-c.png": [40, 52, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-inactive-bl.png": [5, 5, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-checked-br.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -64], "qx/decoration/Modern/tabview/tab-button-bottom-active-c.png": [40, 12, "png", "qx"], "qx/decoration/Classic/table/boolean-false.png": [11, 11, "png", "qx"], "qx/decoration/Modern/menu/radiobutton-invert.gif": [16, 5, "gif", "qx"], "qx/decoration/Modern/tabview/tab-button-left-inactive-c.png": [17, 37, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/cursors/move.gif": [13, 9, "gif", "qx", "qx/decoration/Modern/cursors-combined.png", 0, 0], "qx/decoration/Modern/form/checkbox-pressed.png": [14, 14, "png", "qx"], "qx/decoration/Modern/window/captionbar-active-bl.png": [5, 5, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-right-active-r.png": [5, 37, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-left-active-t.png": [5, 5, "png", "qx"], "qx/decoration/Modern/window/shadow-tl.png": [14, 14, "png", "qx"], "qx/decoration/Modern/table/header-cell.png": [1, 18, "png", "qx"], "qx/decoration/Classic/form/radiobutton-checked-disabled.png": [14, 14, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/pane/pane-t.png": [6, 6, "png", "qx", "qx/decoration/Modern/pane-tb-combined.png", 0, 0], "qx/decoration/Modern/pane/pane-l.png": [6, 238, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-preselected-focused-br.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -16], "qx/decoration/Modern/window-background-lr-combined.png": [28, 384, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-preselected-focused-bl.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -44], "frameworksource/resource/qx/decoration/Modern/form/button-hovered-l.png": [4, 52, "png", "qx", "qx/decoration/Modern/button-lr-combined.png", -8, 0], "frameworksource/resource/qx/decoration/Modern/form/radiobutton-checked-disabled.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -126, 0], "qx/decoration/Modern/form/radiobutton-checked-disabled.png": [14, 14, "png", "qx"], "qx/decoration/Modern/window/statusbar-tl.png": [4, 4, "png", "qx"], "qx/decoration/Modern/window-combined.png": [54, 9, "png", "qx"], "qx/static/image/blank.gif": [1, 1, "gif", "qx"], "qx/decoration/Modern/cursors-combined.png": [71, 20, "png", "qx"], "qx/decoration/Modern/form/button-hovered-r.png": [4, 52, "png", "qx"], "qx/decoration/Modern/form/button-checked-l.png": [4, 52, "png", "qx"], "qx/decoration/Modern/arrows/down-small.png": [5, 3, "png", "qx"], "qx/decoration/Classic/tree/plus.gif": [19, 16, "gif", "qx"], "qx/decoration/Modern/scrollbar/scrollbar-up.png": [6, 4, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/cursors/alias.gif": [19, 15, "gif", "qx", "qx/decoration/Modern/cursors-combined.png", -52, 0], "qx/decoration/Modern/form/checkbox-checked-disabled.png": [14, 14, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/window/shadow-l.png": [14, 384, "png", "qx", "qx/decoration/Modern/window-shadow-lr-combined.png", -14, 0], "frameworksource/resource/qx/decoration/Modern/form/button-b.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -184], "qx/decoration/Modern/tree/tree-open.png": [8, 5, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-right-inactive-tl.png": [5, 5, "png", "qx"], "qx/decoration/Modern/window/captionbar-active-l.png": [5, 10, "png", "qx"], "qx/decoration/Modern/window/shadow-l.png": [14, 384, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-hovered-bl.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -140], "qx/decoration/Classic/arrows/up.gif": [7, 4, "gif", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-hovered-r.png": [4, 52, "png", "qx", "qx/decoration/Modern/button-lr-combined.png", -28, 0], "frameworksource/resource/qx/decoration/Modern/form/button-preselected-r.png": [4, 52, "png", "qx", "qx/decoration/Modern/button-lr-combined.png", -44, 0], "qx/decoration/Classic/arrows/previous-invert.gif": [4, 7, "gif", "qx"], "qx/decoration/Classic/datechooser/next-year.png": [16, 16, "png", "qx"], "qx/decoration/Modern/window/captionbar-inactive-tr.png": [5, 5, "png", "qx"], "qx/decoration/Modern/form/button-checked-t.png": [4, 4, "png", "qx"], "qx/decoration/Modern/form/button-hovered-bl.png": [4, 4, "png", "qx"], "qx/decoration/Classic/table/descending.png": [10, 10, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-pressed-l.png": [4, 52, "png", "qx", "qx/decoration/Modern/button-lr-combined.png", -24, 0], "qx/decoration/Modern/pane/pane-r.png": [6, 238, "png", "qx"], "qx/decoration/Modern/form/button-hovered-tr.png": [4, 4, "png", "qx"], "qx/decoration/Classic/tree/end-plus.gif": [19, 16, "gif", "qx"], "qx/decoration/Classic/splitpane/knob-vertical.png": [15, 4, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-top-inactive-tl.png": [5, 5, "png", "qx"], "qx/decoration/Modern/window/statusbar-bg.png": [1, 14, "png", "qx"], "qx/decoration/Modern/window/statusbar-l.png": [4, 8, "png", "qx"], "qx/decoration/Classic/form/checkbox-checked-hovered.png": [14, 14, "png", "qx"], "qx/decoration/Modern/scrollbar/scrollbar-down.png": [6, 4, "png", "qx"], "frameworksource/resource/qx/decoration/Classic/cursors/move.gif": [13, 9, "gif", "qx", "qx/decoration/Classic/cursors-combined.png", 0, 0], "qx/decoration/Classic/arrows/forward.gif": [8, 7, "gif", "qx"], "qx/decoration/Classic/tree/line.gif": [19, 16, "gif", "qx"], "qx/decoration/Modern/tabview/tab-button-top-active-b.png": [5, 5, "png", "qx"], "qx/decoration/Modern/window/statusbar-r.png": [4, 8, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-hovered-t.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -124], "frameworksource/resource/qx/decoration/Modern/pane/pane-br.png": [6, 6, "png", "qx", "qx/decoration/Modern/pane-tb-combined.png", 0, -18], "qx/decoration/Modern/window/background-t.png": [14, 14, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-top-inactive-l.png": [5, 12, "png", "qx"], "qx/decoration/Modern/window/captionbar-inactive-l.png": [5, 10, "png", "qx"], "qx/decoration/Modern/form/button-preselected-c.png": [40, 52, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-left-active-tl.png": [5, 5, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-top-active-r.png": [5, 12, "png", "qx"], "qx/icon/Oxygen/16/places/folder-open.png": [16, 16, "png", "qx"], "qx/decoration/Classic/menu/radiobutton-invert.gif": [16, 5, "gif", "qx"], "qx/decoration/Modern/form/button-preselected-focused-bl.png": [4, 4, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-preselected-tr.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -88], "frameworksource/resource/qx/decoration/Modern/window/background-bl.png": [14, 14, "png", "qx", "qx/decoration/Modern/window-background-tb-combined.png", 0, -56], "qx/decoration/Modern/arrows/left.png": [5, 8, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-checked-focused-br.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -24], "qx/decoration/Modern/form/button-focused-l.png": [4, 52, "png", "qx"], "qx/decoration/Classic/datechooser/next-month.png": [16, 16, "png", "qx"], "qx/decoration/Modern/window/background-b.png": [14, 14, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-right-active-br.png": [5, 5, "png", "qx"], "qx/decoration/Modern/pane/pane-tl.png": [6, 6, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/window/background-b.png": [14, 14, "png", "qx", "qx/decoration/Modern/window-background-tb-combined.png", 0, -70], "frameworksource/resource/qx/decoration/Modern/form/button-checked-focused-tl.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -40], "qx/decoration/Modern/tabview/tab-button-right-inactive-bl.png": [5, 5, "png", "qx"], "qx/decoration/Modern/scrollbar/scrollbar-left.png": [4, 6, "png", "qx"], "qx/decoration/Modern/pane-tb-combined.png": [6, 36, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-right-inactive-b.png": [5, 5, "png", "qx"], "qx/decoration/Classic/table/select-column-order.png": [10, 9, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-r.png": [4, 52, "png", "qx", "qx/decoration/Modern/button-lr-combined.png", -60, 0], "qx/decoration/Modern/pane/pane-c.png": [40, 238, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/window/shadow-r.png": [14, 384, "png", "qx", "qx/decoration/Modern/window-shadow-lr-combined.png", 0, 0], "qx/decoration/Modern/form/button-preselected-focused-tl.png": [4, 4, "png", "qx"], "qx/decoration/Modern/selection.png": [110, 20, "png", "qx"], "qx/decoration/Modern/table/select-column-order.png": [10, 9, "png", "qx"], "qx/decoration/Classic/arrows/down-invert.gif": [7, 4, "gif", "qx"], "qx/decoration/Modern/tree/tree-closed.png": [5, 8, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-inactive-tr.png": [5, 5, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-pressed-b.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -120], "qx/decoration/Modern/arrows/up.png": [8, 5, "png", "qx"], "qx/decoration/Modern/form/button-tr.png": [4, 4, "png", "qx"], "qx/decoration/Modern/form/button-pressed-b.png": [4, 4, "png", "qx"], "qx/decoration/Classic/window/close.gif": [10, 9, "gif", "qx"], "qx/decoration/Modern/window/maximize-active.png": [9, 9, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-top-active-t.png": [5, 5, "png", "qx"], "qx/decoration/Modern/form/button-preselected-l.png": [4, 52, "png", "qx"], "qx/decoration/Classic/tree/start-minus.gif": [19, 16, "gif", "qx"], "frameworksource/resource/qx/decoration/Modern/form/radiobutton-checked-hovered.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -140, 0], "qx/decoration/Modern/form/button-checked-focused-bl.png": [4, 4, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/checkbox-focused.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -112, 0], "qx/decoration/Modern/form/button-pressed-br.png": [4, 4, "png", "qx"], "qx/decoration/Modern/window/background-tr.png": [14, 14, "png", "qx"], "qx/decoration/Modern/window/captionbar-active-c.png": [40, 10, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-right-inactive-c.png": [17, 37, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-top-inactive-c.png": [40, 12, "png", "qx"], "qx/decoration/Classic/datechooser/last-month.png": [16, 16, "png", "qx"], "qx/decoration/Classic/window/minimize.gif": [9, 9, "gif", "qx"], "frameworksource/resource/qx/decoration/Modern/form/checkbox-pressed.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -14, 0], "qx/decoration/Modern/menu/radiobutton.gif": [16, 5, "gif", "qx"], "qx/decoration/Modern/form/button-checked-tl.png": [4, 4, "png", "qx"], "qx/decoration/Modern/form/button-preselected-tl.png": [4, 4, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-inactive-tl.png": [5, 5, "png", "qx"], "qx/decoration/Modern/form/button-focused-c.png": [40, 52, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-preselected-l.png": [4, 52, "png", "qx", "qx/decoration/Modern/button-lr-combined.png", -20, 0], "frameworksource/resource/qx/decoration/Modern/window/background-t.png": [14, 14, "png", "qx", "qx/decoration/Modern/window-background-tb-combined.png", 0, -14], "frameworksource/resource/qx/decoration/Modern/form/button-focused-br.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -128], "frameworksource/resource/qx/decoration/Modern/window/background-l.png": [14, 384, "png", "qx", "qx/decoration/Modern/window-background-lr-combined.png", 0, 0], "qx/decoration/Modern/window/captionbar-inactive-bg.png": [1, 19, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/window/shadow-tl.png": [14, 14, "png", "qx", "qx/decoration/Modern/window-shadow-tb-combined.png", 0, -28], "qx/decoration/Classic/arrows/left-small.gif": [3, 5, "gif", "qx"], "qx/decoration/Classic/colorselector/huesaturation-field.jpg": [256, 256, "jpeg", "qx"], "qx/decoration/Modern/tabview/tab-button-left-active-c.png": [17, 37, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/pane/pane-r.png": [6, 238, "png", "qx", "qx/decoration/Modern/pane-lr-combined.png", 0, 0], "qx/decoration/Classic/form/radiobutton-checked-focused.png": [14, 14, "png", "qx"], "qx/decoration/Modern/window/captionbar-inactive-t.png": [5, 5, "png", "qx"], "qx/decoration/Modern/window/captionbar-active-tl.png": [5, 5, "png", "qx"], "qx/decoration/Modern/arrows/right-invert.png": [5, 8, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-checked-r.png": [4, 52, "png", "qx", "qx/decoration/Modern/button-lr-combined.png", -12, 0], "qx/decoration/Classic/cursors/nodrop.gif": [20, 20, "gif", "qx"], "qx/decoration/Classic/form/radiobutton-disabled.png": [14, 14, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-hovered-br.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -148], "qx/decoration/Modern/arrows/left-invert.png": [5, 8, "png", "qx"], "qx/decoration/Modern/form/button-pressed-bl.png": [4, 4, "png", "qx"], "qx/decoration/Modern/form/button-preselected-focused-r.png": [4, 52, "png", "qx"], "qx/decoration/Modern/window/background-l.png": [14, 384, "png", "qx"], "qx/decoration/Classic/form/checkbox-checked-focused.png": [14, 14, "png", "qx"], "qx/decoration/Classic/arrows/rewind.gif": [8, 7, "gif", "qx"], "qx/decoration/Modern/toolbar/toolbar-divider.png": [2, 26, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-focused-tl.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -144], "frameworksource/resource/qx/decoration/Modern/pane/pane-tl.png": [6, 6, "png", "qx", "qx/decoration/Modern/pane-tb-combined.png", 0, -12], "qx/decoration/Modern/tabview/tab-button-left-inactive-tl.png": [5, 5, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-top-active-l.png": [5, 12, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-checked-l.png": [4, 52, "png", "qx", "qx/decoration/Modern/button-lr-combined.png", 0, 0], "qx/decoration/Modern/tree/tree-open-selected.png": [8, 5, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/window/minimize-active.png": [9, 9, "png", "qx", "qx/decoration/Modern/window-combined.png", -18, 0], "qx/decoration/Classic/arrows/next.gif": [4, 7, "gif", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-checked-tl.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, 0], "frameworksource/resource/qx/decoration/Modern/form/button-checked-focused-l.png": [4, 52, "png", "qx", "qx/decoration/Modern/button-lr-combined.png", -36, 0], "qx/decoration/Modern/tabview/tab-button-left-active-tr.png": [5, 5, "png", "qx"], "qx/decoration/Modern/window/statusbar-bl.png": [4, 4, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-preselected-b.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -20], "qx/decoration/Classic/colorselector/huesaturation-handle.gif": [11, 11, "gif", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-active-bl.png": [5, 5, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-checked-t.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -32], "qx/decoration/Modern/tabview/tab-button-left-active-l.png": [5, 37, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-pressed-r.png": [4, 52, "png", "qx", "qx/decoration/Modern/button-lr-combined.png", -32, 0], "frameworksource/resource/qx/decoration/Modern/form/button-preselected-focused-tl.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -68], "qx/decoration/Modern/form/checkbox-checked.png": [14, 14, "png", "qx"], "qx/decoration/Modern/checkradio-combined.png": [252, 14, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-preselected-br.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -152], "qx/decoration/Modern/form/button-preselected-focused-l.png": [4, 52, "png", "qx"], "qx/decoration/Modern/window/shadow-tr.png": [14, 14, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-left-inactive-b.png": [5, 5, "png", "qx"], "qx/decoration/Classic/datechooser/last-year.png": [16, 16, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-top-active-br.png": [5, 5, "png", "qx"], "qx/decoration/Modern/form/radiobutton-focused.png": [14, 14, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/cursors/nodrop.gif": [20, 20, "gif", "qx", "qx/decoration/Modern/cursors-combined.png", -13, 0], "qx/decoration/Classic/arrows/left.gif": [4, 7, "gif", "qx"], "qx/decoration/Modern/tabview/tab-button-right-inactive-l.png": [5, 37, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/radiobutton-checked-focused.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -154, 0], "qx/decoration/Classic/cursors/alias.gif": [19, 15, "gif", "qx"], "qx/decoration/Classic/arrows/up-small-invert.gif": [5, 3, "gif", "qx"], "qx/decoration/Modern/form/button-focused-bl.png": [4, 4, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-left-inactive-tr.png": [5, 5, "png", "qx"], "qx/decoration/Modern/arrows/down.png": [8, 5, "png", "qx"], "qx/decoration/Modern/arrows/up-invert.png": [8, 5, "png", "qx"], "qx/decoration/Modern/form/button-preselected-br.png": [4, 4, "png", "qx"], "qx/decoration/Modern/window/minimize-active.png": [9, 9, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-br.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -172], "qx/decoration/Classic/tree/end.gif": [19, 16, "gif", "qx"], "qx/decoration/Modern/form/input.png": [84, 12, "png", "qx"], "qx/decoration/Modern/window/statusbar-c.png": [40, 8, "png", "qx"], "qx/icon/Tango/16/mimetypes/text-plain.png": [16, 16, "png", "qx"], "qx/decoration/Modern/arrows/down-invert.png": [8, 5, "png", "qx"], "qx/decoration/Classic/table/ascending-invert.png": [10, 10, "png", "qx"], "qx/decoration/Modern/table/ascending.png": [8, 5, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/window/shadow-br.png": [14, 14, "png", "qx", "qx/decoration/Modern/window-shadow-tb-combined.png", 0, -70], "qx/decoration/Modern/form/radiobutton-checked-hovered.png": [14, 14, "png", "qx"], "qx/decoration/Classic/arrows/up-small.gif": [5, 3, "gif", "qx"], "qx/decoration/Modern/menu/checkbox.gif": [16, 7, "gif", "qx"], "qx/decoration/Classic/arrows/right-invert.gif": [4, 7, "gif", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-t.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -176], "qx/decoration/Modern/window/statusbar-b.png": [4, 4, "png", "qx"], "qx/decoration/Modern/form/button-hovered-t.png": [4, 4, "png", "qx"], "qx/decoration/Modern/window/close-active.png": [9, 9, "png", "qx"], "qx/decoration/Modern/splitpane/knob-horizontal.png": [4, 15, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-checked-focused-bl.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -12], "qx/decoration/Modern/tabview/tab-button-right-active-c.png": [17, 37, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/window/shadow-tr.png": [14, 14, "png", "qx", "qx/decoration/Modern/window-shadow-tb-combined.png", 0, 0], "qx/decoration/Modern/form/button-preselected-focused-c.png": [40, 52, "png", "qx"], "qx/decoration/Modern/form/radiobutton-checked-focused.png": [14, 14, "png", "qx"], "qx/decoration/Modern/window/background-br.png": [14, 14, "png", "qx"], "qx/decoration/Modern/menu/background.png": [1, 49, "png", "qx"], "qx/decoration/Modern/toolbar/toolbar-handle.png": [7, 40, "png", "qx"], "qx/decoration/Modern/form/button-checked-c.png": [40, 52, "png", "qx"], "qx/decoration/Classic/arrows/previous.gif": [4, 7, "gif", "qx"], "qx/decoration/Classic/form/radiobutton-checked-hovered.png": [14, 14, "png", "qx"], "qx/decoration/Classic/arrows/forward-invert.gif": [8, 7, "gif", "qx"], "qx/decoration/Modern/window/captionbar-inactive-tl.png": [5, 5, "png", "qx"], "frameworksource/resource/qx/decoration/Classic/cursors/copy.gif": [19, 15, "gif", "qx", "qx/decoration/Classic/cursors-combined.png", -33, 0], "qx/decoration/Classic/window/restore.gif": [8, 9, "gif", "qx"], "qx/decoration/Classic/colorselector/brightness-handle.gif": [35, 11, "gif", "qx"], "qx/decoration/Modern/tabview/tab-button-left-active-br.png": [5, 5, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-inactive-c.png": [40, 12, "png", "qx"], "qx/decoration/Modern/pane/pane-tr.png": [6, 6, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/window/background-tr.png": [14, 14, "png", "qx", "qx/decoration/Modern/window-background-tb-combined.png", 0, -28], "frameworksource/resource/qx/decoration/Modern/window/background-br.png": [14, 14, "png", "qx", "qx/decoration/Modern/window-background-tb-combined.png", 0, -42], "frameworksource/resource/qx/decoration/Modern/form/button-checked-focused-b.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -160], "qx/decoration/Modern/scrollbar/slider-knob-bg-vertical.png": [10, 12, "png", "qx"], "qx/decoration/Classic/arrows/next-invert.gif": [4, 7, "gif", "qx"], "qx/decoration/Modern/window/captionbar-active-br.png": [5, 5, "png", "qx"], "qx/decoration/Classic/arrows/down.gif": [7, 4, "gif", "qx"], "frameworksource/resource/qx/decoration/Modern/window/maximize-inactive.png": [9, 9, "png", "qx", "qx/decoration/Modern/window-combined.png", -36, 0], "qx/decoration/Modern/form/checkbox-checked-hovered.png": [14, 14, "png", "qx"], "qx/decoration/Modern/form/button-preselected-focused-tr.png": [4, 4, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-right-active-l.png": [5, 37, "png", "qx"], "qx/decoration/Classic/form/radiobutton-hovered.png": [14, 14, "png", "qx"], "qx/decoration/Classic/tree/cross.gif": [19, 16, "gif", "qx"], "qx/decoration/Modern/window/shadow-c.png": [40, 384, "png", "qx"], "qx/decoration/Modern/form/button-focused-r.png": [4, 52, "png", "qx"], "qx/decoration/Modern/window/captionbar-active-bg.png": [1, 19, "png", "qx"], "qx/decoration/Classic/tree/only-minus.gif": [19, 16, "gif", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-focused-r.png": [4, 52, "png", "qx", "qx/decoration/Modern/button-lr-combined.png", -52, 0], "qx/decoration/Modern/tabview/tab-button-top-active-tr.png": [5, 5, "png", "qx"], "qx/decoration/Classic/form/checkbox-checked.png": [14, 14, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-top-active-bl.png": [5, 5, "png", "qx"], "qx/decoration/Classic/tree/cross-plus.gif": [19, 16, "gif", "qx"], "qx/decoration/Modern/form/button-preselected-tr.png": [4, 4, "png", "qx"], "qx/decoration/Modern/form/button-pressed-c.png": [40, 52, "png", "qx"], "qx/decoration/Modern/cursors/alias.gif": [19, 15, "gif", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-hovered-tr.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -8], "frameworksource/resource/qx/decoration/Modern/form/button-preselected-focused-tr.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -4], "qx/decoration/Modern/scrollbar/scrollbar-bg-pressed-vertical.png": [10, 19, "png", "qx"], "qx/decoration/Classic/form/checkbox-focused.png": [14, 14, "png", "qx"], "qx/icon/Tango/16/places/folder.png": [16, 16, "png", "qx"], "qx/decoration/Modern/form/button-bl.png": [4, 4, "png", "qx"], "qx/decoration/Classic/form/checkbox-checked-disabled.png": [14, 14, "png", "qx"], "qx/decoration/Modern/form/button-tl.png": [4, 4, "png", "qx"], "qx/decoration/Modern/form/button-checked-focused-tr.png": [4, 4, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-right-inactive-tr.png": [5, 5, "png", "qx"], "qx/icon/Oxygen/16/mimetypes/text-plain.png": [16, 16, "png", "qx"], "qx/decoration/Modern/window-shadow-tb-combined.png": [14, 84, "png", "qx"], "qx/decoration/Modern/pane-lr-combined.png": [12, 238, "png", "qx"], "qx/decoration/Classic/table/boolean-true.png": [11, 11, "png", "qx"], "qx/decoration/Classic/core/dotted-white.gif": [2, 2, "gif", "qx"], "frameworksource/resource/qx/decoration/Modern/form/checkbox-checked-focused.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", 0, 0], "qx/decoration/Classic/form/checkbox-checked-pressed.png": [14, 14, "png", "qx"], "qx/decoration/Classic/arrows/down-small.gif": [5, 3, "gif", "qx"], "qx/decoration/Modern/form/button-checked-r.png": [4, 52, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/checkbox-disabled.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -28, 0], "qx/decoration/Classic/table/ascending.png": [10, 10, "png", "qx"], "qx/decoration/Modern/form/button-pressed-tl.png": [4, 4, "png", "qx"], "qx/decoration/Modern/form/radiobutton.png": [14, 14, "png", "qx"], "qx/decoration/Modern/form/button-checked-focused-b.png": [4, 4, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-tl.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -168], "frameworksource/resource/qx/decoration/Modern/form/button-preselected-focused-r.png": [4, 52, "png", "qx", "qx/decoration/Modern/button-lr-combined.png", -40, 0], "qx/decoration/Modern/form/checkbox-hovered.png": [14, 14, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/checkbox-checked-pressed.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -42, 0], "qx/decoration/Modern/form/button-focused-tr.png": [4, 4, "png", "qx"], "qx/decoration/Classic/form/checkbox-disabled.png": [14, 14, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-active-t.png": [5, 5, "png", "qx"], "qx/decoration/Classic/arrows/left-small-invert.gif": [3, 5, "gif", "qx"], "qx/decoration/Classic/datechooser/next-month-invert.png": [16, 16, "png", "qx"], "qx/decoration/Modern/form/button-focused-b.png": [4, 4, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-checked-bl.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -76], "qx/decoration/Modern/arrows/up-small.png": [5, 3, "png", "qx"], "qx/decoration/Modern/form/button-preselected-t.png": [4, 4, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-left-inactive-br.png": [5, 5, "png", "qx"], "qx/decoration/Modern/window-background-tb-combined.png": [14, 84, "png", "qx"], "qx/decoration/Modern/form/checkbox-checked-pressed.png": [14, 14, "png", "qx"], "qx/decoration/Modern/window/background-tl.png": [14, 14, "png", "qx"], "qx/decoration/Classic/datechooser/last-month-invert.png": [16, 16, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-right-inactive-r.png": [5, 37, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-pressed-tr.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -80], "qx/decoration/Modern/form/button-br.png": [4, 4, "png", "qx"], "qx/decoration/Modern/pane/pane-bl.png": [6, 6, "png", "qx"], "qx/decoration/Classic/table/descending-invert.png": [10, 10, "png", "qx"], "qx/decoration/Classic/tree/minus.gif": [19, 16, "gif", "qx"], "qx/decoration/Modern/form/radiobutton-checked.png": [14, 14, "png", "qx"], "qx/decoration/Modern/button-lr-combined.png": [64, 52, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-checked-tr.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -108], "frameworksource/resource/qx/decoration/Modern/window/close-active.png": [9, 9, "png", "qx", "qx/decoration/Modern/window-combined.png", 0, 0], "qx/decoration/Classic/window/maximize.gif": [9, 9, "gif", "qx"], "qx/decoration/Modern/window/statusbar-br.png": [4, 4, "png", "qx"], "qx/decoration/Modern/form/checkbox-focused.png": [14, 14, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-inactive-t.png": [5, 5, "png", "qx"], "qx/decoration/Modern/form/button-pressed-l.png": [4, 52, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-left-active-r.png": [5, 37, "png", "qx"], "qx/decoration/Classic/cursors/copy.gif": [19, 15, "gif", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-active-r.png": [5, 12, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-checked-b.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -132], "qx/decoration/Classic/arrows/right-small.gif": [3, 5, "gif", "qx"], "qx/icon/Tango/16/places/folder-open.png": [16, 16, "png", "qx"], "qx/decoration/Modern/form/button-checked-focused-br.png": [4, 4, "png", "qx"], "frameworksource/resource/qx/decoration/Classic/cursors/nodrop.gif": [20, 20, "gif", "qx", "qx/decoration/Classic/cursors-combined.png", -13, 0], "qx/icon/Oxygen/16/apps/office-calendar.png": [16, 16, "png", "qx"], "qx/decoration/Classic/cursors/move.gif": [13, 9, "gif", "qx"], "qx/decoration/Modern/form/button-focused-tl.png": [4, 4, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-hovered-tl.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -48], "qx/decoration/Modern/form/button-focused-br.png": [4, 4, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-inactive-l.png": [5, 12, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-top-inactive-b.png": [5, 5, "png", "qx"], "qx/decoration/Modern/scrollbar/slider-knob-bg-horizontal.png": [12, 10, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-top-active-tl.png": [5, 5, "png", "qx"], "qx/decoration/Modern/form/checkbox-disabled.png": [14, 14, "png", "qx"], "qx/decoration/Modern/form/button-b.png": [4, 4, "png", "qx"], "qx/decoration/Modern/window/close-inactive.png": [9, 9, "png", "qx"], "qx/decoration/Modern/form/button-checked-focused-tl.png": [4, 4, "png", "qx"], "qx/decoration/Classic/form/checkbox-hovered.png": [14, 14, "png", "qx"], "qx/decoration/Modern/form/button-checked-bl.png": [4, 4, "png", "qx"], "qx/decoration/Modern/form/radiobutton-checked-pressed.png": [14, 14, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/pane/pane-b.png": [6, 6, "png", "qx", "qx/decoration/Modern/pane-tb-combined.png", 0, -24], "qx/decoration/Classic/tree/end-minus.gif": [19, 16, "gif", "qx"], "qx/decoration/Modern/pane/pane-br.png": [6, 6, "png", "qx"], "qx/decoration/Classic/datechooser/last-year-invert.png": [16, 16, "png", "qx"], "qx/decoration/Modern/splitpane/knob-vertical.png": [15, 4, "png", "qx"], "qx/decoration/Modern/scrollbar/scrollbar-right.png": [4, 6, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-inactive-br.png": [5, 5, "png", "qx"], "qx/decoration/Modern/window-shadow-lr-combined.png": [28, 384, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-right-active-t.png": [5, 5, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/radiobutton-hovered.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -210, 0], "frameworksource/resource/qx/decoration/Modern/pane/pane-l.png": [6, 238, "png", "qx", "qx/decoration/Modern/pane-lr-combined.png", -6, 0], "qx/decoration/Modern/window/background-c.png": [40, 384, "png", "qx"], "qx/decoration/Modern/form/button-hovered-l.png": [4, 52, "png", "qx"], "qx/decoration/Classic/tree/cross-minus.gif": [19, 16, "gif", "qx"], "qx/decoration/Modern/toolbar/toolbar-handle-38.png": [7, 40, "png", "qx"], "qx/icon/Oxygen/16/actions/view-refresh.png": [16, 16, "png", "qx"], "qx/decoration/Classic/tree/only-plus.gif": [19, 16, "gif", "qx"], "qx/decoration/Classic/tree/start-plus.gif": [19, 16, "gif", "qx"], "qx/decoration/Modern/window/captionbar-active-b.png": [5, 5, "png", "qx"], "qx/decoration/Modern/form/button-checked-br.png": [4, 4, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-focused-l.png": [4, 52, "png", "qx", "qx/decoration/Modern/button-lr-combined.png", -4, 0], "frameworksource/resource/qx/decoration/Modern/form/button-pressed-bl.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -36], "qx/decoration/Modern/pane/pane-t.png": [6, 6, "png", "qx"], "qx/decoration/Classic/form/radiobutton-checked-pressed.png": [14, 14, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-inactive-r.png": [5, 12, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-active-b.png": [5, 5, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-left-inactive-l.png": [5, 37, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-top-inactive-tr.png": [5, 5, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/checkbox-checked.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -98, 0], "frameworksource/resource/qx/decoration/Modern/form/button-pressed-tl.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -164], "frameworksource/resource/qx/decoration/Modern/form/button-focused-tr.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -60], "frameworksource/resource/qx/decoration/Modern/form/checkbox-checked-hovered.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -84, 0], "qx/decoration/Modern/form/radiobutton-pressed.png": [14, 14, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-tr.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -180], "qx/decoration/Modern/window/statusbar-t.png": [4, 4, "png", "qx"], "qx/decoration/Modern/window/maximize-inactive.png": [9, 9, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-checked-focused-r.png": [4, 52, "png", "qx", "qx/decoration/Modern/button-lr-combined.png", -48, 0], "qx/decoration/Modern/form/button-hovered-b.png": [4, 4, "png", "qx"], "qx/decoration/Modern/form/button-preselected-focused-t.png": [4, 4, "png", "qx"], "frameworksource/resource/qx/decoration/Classic/cursors/alias.gif": [19, 15, "gif", "qx", "qx/decoration/Classic/cursors-combined.png", -52, 0], "qx/decoration/Modern/tabview/tab-button-left-active-b.png": [5, 5, "png", "qx"], "qx/decoration/Modern/window/captionbar-active-r.png": [5, 10, "png", "qx"], "qx/decoration/Modern/table/descending.png": [8, 5, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/window/close-inactive.png": [9, 9, "png", "qx", "qx/decoration/Modern/window-combined.png", -9, 0], "qx/decoration/Modern/form/button-checked-tr.png": [4, 4, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-left-active-bl.png": [5, 5, "png", "qx"], "qx/decoration/Classic/form/radiobutton-checked.png": [14, 14, "png", "qx"], "qx/decoration/Modern/arrows/down-small-invert.png": [5, 3, "png", "qx"], "qx/decoration/Modern/window/shadow-b.png": [14, 14, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-bottom-active-br.png": [5, 5, "png", "qx"], "qx/decoration/Modern/form/button-checked-b.png": [4, 4, "png", "qx"], "qx/decoration/Modern/form/button-pressed-t.png": [4, 4, "png", "qx"], "qx/decoration/Modern/window/shadow-r.png": [14, 384, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-preselected-focused-t.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -112], "frameworksource/resource/qx/decoration/Modern/form/checkbox-checked-disabled.png": [14, 14, "png", "qx", "qx/decoration/Modern/checkradio-combined.png", -56, 0], "qx/decoration/Modern/form/button-preselected-focused-br.png": [4, 4, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-bl.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -188], "qx/decoration/Modern/form/button-c.png": [40, 52, "png", "qx"], "qx/decoration/Modern/form/button-l.png": [4, 52, "png", "qx"], "qx/decoration/Modern/form/button-hovered-tl.png": [4, 4, "png", "qx"], "qx/decoration/Modern/window/shadow-bl.png": [14, 14, "png", "qx"], "qx/decoration/Classic/form/radiobutton-pressed.png": [14, 14, "png", "qx"], "qx/decoration/Classic/form/radiobutton.png": [14, 14, "png", "qx"], "qx/decoration/Modern/form/button-preselected-b.png": [4, 4, "png", "qx"], "qx/decoration/Modern/tabview/tab-button-top-inactive-bl.png": [5, 5, "png", "qx"], "qx/decoration/Modern/scrollbar/scrollbar-bg-pressed-horizontal.png": [19, 10, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/window/shadow-t.png": [14, 14, "png", "qx", "qx/decoration/Modern/window-shadow-tb-combined.png", 0, -14], "frameworksource/resource/qx/decoration/Modern/pane/pane-bl.png": [6, 6, "png", "qx", "qx/decoration/Modern/pane-tb-combined.png", 0, -30], "qx/decoration/Modern/window/captionbar-inactive-c.png": [40, 10, "png", "qx"], "qx/decoration/Modern/form/checkbox.png": [14, 14, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-focused-b.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -52], "qx/decoration/Modern/tabview/tab-button-right-inactive-t.png": [5, 5, "png", "qx"], "qx/decoration/Modern/cursors/copy.gif": [19, 15, "gif", "qx"], "qx/decoration/Modern/tabview/tab-button-left-inactive-t.png": [5, 5, "png", "qx"], "frameworksource/resource/qx/decoration/Modern/form/button-preselected-tl.png": [4, 4, "png", "qx", "qx/decoration/Modern/button-tb-combined.png", 0, -92]};

if(!window.qxlocales)qxlocales={};
qxlocales["C"]={"cldr_date_format_long": "MMMM d, yyyy", "cldr_month_abbreviated_11": "Nov", "cldr_month_abbreviated_10": "Oct", "cldr_month_abbreviated_12": "Dec", "cldr_date_time_format_MMMMdd": "dd MMMM", "cldr_date_time_format_mmss": "mm:ss", "cldr_day_abbreviated_tue": "Tue", "cldr_date_time_format_MMd": "d\/MM", "cldr_day_wide_fri": "Friday", "cldr_date_time_format_HHmm": "HH:mm", "cldr_day_wide_tue": "Tuesday", "cldr_day_wide_thu": "Thursday", "cldr_date_time_format_MMMdd": "dd MMM", "cldr_day_abbreviated_fri": "Fri", "cldr_day_wide_sun": "Sunday", "cldr_date_time_format_yyyyMMM": "MMM yyyy", "cldr_day_wide_mon": "Monday", "cldr_day_abbreviated_mon": "Mon", "cldr_pm": "PM", "cldr_day_narrow_sun": "S", "cldr_month_narrow_12": "D", "cldr_month_narrow_5": "M", "cldr_day_narrow_sat": "S", "cldr_date_time_format_yyQ": "Q yy", "cldr_date_time_format_Md": "M\/d", "cldr_month_narrow_7": "J", "cldr_date_format_full": "EEEE, MMMM d, yyyy", "cldr_month_abbreviated_9": "Sep", "cldr_month_abbreviated_8": "Aug", "cldr_month_narrow_10": "O", "cldr_month_narrow_11": "N", "cldr_date_format_medium": "MMM d, yyyy", "cldr_month_abbreviated_1": "Jan", "cldr_month_abbreviated_3": "Mar", "cldr_month_abbreviated_2": "Feb", "cldr_month_abbreviated_5": "May", "cldr_month_abbreviated_4": "Apr", "cldr_month_abbreviated_7": "Jul", "cldr_month_abbreviated_6": "Jun", "cldr_date_time_format_MMMd": "d-MMM", "cldr_day_wide_sat": "Saturday", "cldr_day_abbreviated_wed": "Wed", "cldr_day_narrow_wed": "W", "cldr_number_group_separator": ",", "cldr_date_time_format_hhmmss": "hh:mm:ss a", "cldr_month_wide_2": "February", "cldr_month_wide_3": "March", "cldr_month_wide_1": "January", "cldr_month_wide_6": "June", "cldr_month_wide_7": "July", "cldr_month_wide_4": "April", "cldr_month_wide_5": "May", "cldr_month_wide_8": "August", "cldr_month_wide_9": "September", "cldr_month_wide_10": "October", "cldr_month_wide_11": "November", "cldr_month_wide_12": "December", "cldr_number_decimal_separator": ".", "cldr_day_narrow_fri": "F", "cldr_day_narrow_tue": "T", "cldr_day_narrow_thu": "T", "cldr_time_format_short": "h:mm a", "cldr_time_format_medium": "h:mm:ss a", "cldr_day_abbreviated_sun": "Sun", "cldr_day_abbreviated_thu": "Thu", "cldr_date_format_short": "M\/d\/yy", "cldr_time_format_long": "h:mm:ss a z", "cldr_date_time_format_HHmmss": "HH:mm:ss", "cldr_day_wide_wed": "Wednesday", "cldr_day_narrow_mon": "M", "cldr_date_time_format_hhmm": "hh:mm a", "cldr_month_narrow_1": "J", "cldr_month_narrow_2": "F", "cldr_month_narrow_3": "M", "cldr_month_narrow_4": "A", "cldr_date_time_format_MMMMd": "MMMM d", "cldr_month_narrow_6": "J", "cldr_date_time_format_yyyyM": "M\/yyyy", "cldr_month_narrow_8": "A", "cldr_month_narrow_9": "S", "cldr_day_abbreviated_sat": "Sat", "cldr_date_time_format_yyMM": "MM\/yy", "cldr_am": "AM", "cldr_time_format_full": "h:mm:ss a v", "cldr_date_time_format_yyQQQQ": "QQQQ yy"};

window.qxloader =
{
  parts : {"boot":[0]},
  uris : [["script/qx-0.js"]],
  boot : "boot",

  runningParts : {},
  loadedParts : {},
  runningPackages : {},
  loadedPackages : {},
  runningScripts : {},
  loadedScripts : {},

  callbackList : [],

  scriptQueue : [],
  inFlushQueue : false,


  // Simple log wrapper
  _log : function(msg, type)
  {
    if (!type) {
      type = "debug";
    }

    if (window.qx && qx.core && qx.log.Logger) {
      qx.log.Logger[type](msg);
    }
  },


  // Main method to manage part loading
  loadPart : function(name, callback, self)
  {
    if (callback && !self) {
      self = window;
    }

    if (this.parts[name]==null)
    {
      this._log("No such part: " + name, "warn");

      if (callback) {
        callback.call(self);
      }

      return;
    }

    if (this.loadedParts[name])
    {
      // this._log("Part " + name + " is already loaded...");
      if (callback) {
        callback.call(self);
      }

      return;
    }

    if (this.runningParts[name])
    {
      this._log("The part " + name + " is already in loading state... checking callback");

      if (callback)
      {
        for (var i=0, a=this.callbackList, l=a.length; i<l; i++)
        {
          if (a[i].callback == callback && a[i].self == self)
          {
            this._log("Callback is already registered.");
            return;
          }
        }

        // this._log("Registering callback");
        this.callbackList.push({
          callback : callback,
          self : self || null
        });
      }

      return;
    }

    this.runningParts[name] = true;

    this._log("Loading part " + name + "...");

    var pkgs = this.parts[name];
    var pkg;
    var uris;
    var scripts = [];

    for (var i=0; i<pkgs.length; i++)
    {
      pkg = pkgs[i];

      if (this.loadedPackages[pkg])
      {
        // this._log("Package: " + pkg + " is already loaded...");
        continue;
      }

      if (this.runningPackages[pkg]) {
        continue;
      }

      // this._log("Loading package: " + pkg);
      this.runningPackages[pkg] = true;

      uris = this.uris[pkg];
      // this._log("Queueing " + uris.length + " files");
      this.scriptQueue.push.apply(this.scriptQueue, uris);
    }



    if (this.scriptQueue.length == 0)
    {
      this.loadedParts[name] = true;

      if (callback) {
        self ? callback.call(self) : callback();
      }

      return;
    }

    if (callback)
    {
      // this._log("Registering callback");
      this.callbackList.push({
        callback : callback,
        self : self || null
      });
    }

    if (!this.inFlushQueue) {
      this._flushQueue();
    }
  },


  _isWebkit : /AppleWebKit\/([^ ]+)/.test(navigator.userAgent),

  _flushQueue : function()
  {
    this.inFlushQueue = true;

    var queue = this.scriptQueue;

    // Queue empty?
    if (queue.length == 0)
    {
      // this._log("Queue flushed successfully!");

      // Move running packages to loaded packages
      for (var pkg in this.runningPackages)
      {
        // this._log("Package " + pkg + " successfully loaded");
        this.loadedPackages[pkg] = true;
      }
      this.runningPackages = {};

      for (var part in this.runningParts)
      {
        this._log("Part " + part + " successfully loaded");
        this.loadedParts[part] = true;
      }
      this.runningParts = {};

      // Clear flag
      this.inFlushQueue = false;

      // Execute callbacks
      var callbacks = this.callbackList.concat();
      this.callbackList.length = 0;
      for (var i=0, l=callbacks.length; i<l; i++) {
        callbacks[i].callback.call(callbacks[i].self);
      }

      // Is this the boot module? => start init process
      if (part == this.boot)
      {
        this._bootLoaded = true;
        this._fireReady();
      }

      // Finally return
      return;
    }

    // Load next script
    var next = queue.shift();

    if (this._isWebkit)
    {
      // force asynchronous load
      // Safari fails with an "maximum recursion depth exceeded" error if it is
      // called sync.
      var self = this;
      window.setTimeout(function() {
        self.loadScript(next, self._flushQueue, self);
      }, 0);
    } else {
      this.loadScript(next, this._flushQueue, this);
    }
  },


  _fireReady : function()
  {
    if (this._bootLoaded && this._pageLoaded && window.qx && qx.event && qx.event.handler && qx.event.handler.Application) {
      qx.event.handler.Application.ready();
    }
  },


  loadScript : function(uri, callback, self)
  {
    if (callback && !self) {
      self = window;
    }

    if (this.loadedScripts[uri])
    {
      // this._log("Script is already loaded: " + uri);

      if (callback) {
        callback.call(self);
      }

      return;
    }

    // This needs a better implementation!
    if (this.runningScripts[uri]) {
      throw new Error("Script is already loading.");
    }

    this.runningScripts[uri] = true;

    var head = document.getElementsByTagName("head")[0];
    var elem = document.createElement("script");

    elem.charset = "utf-8";
    elem.src = uri;

    // Assign listener
    elem.onreadystatechange = elem.onload = function()
    {
      if (!this.readyState || this.readyState == "loaded" || this.readyState == "complete")
      {
        // Remove listeners (mem leak prevention)
        elem.onreadystatechange = elem.onload = null;

        // Remember
        delete qxloader.runningScripts[uri];
        qxloader.loadedScripts[uri] = true;

        // Execute callback
        if (callback) {
          callback.call(self);
        }
      }
    };

    head.appendChild(elem);
  },


  _pageLoad : function()
  {
    if (window.addEventListener) {
      window.removeEventListener("load", qxloader._pageLoad, false);
    } else {
      window.detachEvent("onload", qxloader._pageLoad);
    }

    qxloader._pageLoaded = true;
    qxloader._fireReady();
  },


  init : function() {
    this.loadPart(this.boot);
  }
};

if (window.addEventListener) {
  window.addEventListener("load", qxloader._pageLoad, false);
} else {
  window.attachEvent("onload", qxloader._pageLoad);
}

qxloader.init();
