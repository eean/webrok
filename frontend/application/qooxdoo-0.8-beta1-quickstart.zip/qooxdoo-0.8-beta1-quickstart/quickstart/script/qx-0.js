qx={Bootstrap:{genericToString:function(){return "[Class "+this.classname+"]";
},
createNamespace:function(a,
b){var c=a.split(".");
var d=window;
var e=c[0];
for(var f=0,
g=c.length-1;f<g;f++,
e=c[f]){if(!d[e]){d=d[e]={};
}else{d=d[e];
}}d[e]=b;
return e;
},
define:function(a,
b){if(!b){var b={statics:{}};
}var c;
var d=null;
if(b.members){c=b.construct||new Function;
var e=b.statics;
for(var f in e){c[f]=e[f];
}d=c.prototype;
var g=b.members;
for(var f in g){d[f]=g[f];
}}else{c=b.statics||{};
}var h=this.createNamespace(a,
c);
c.name=c.classname=a;
c.basename=h;
c.$$type="Class";
if(!c.hasOwnProperty("toString")){c.toString=this.genericToString;
}if(b.defer){b.defer(c,
d);
}qx.Bootstrap.$$registry[a]=b.statics;
}}};
qx.Bootstrap.define("qx.Bootstrap",
{statics:{LOADSTART:new Date,
createNamespace:qx.Bootstrap.createNamespace,
define:qx.Bootstrap.define,
genericToString:qx.Bootstrap.genericToString,
getByName:function(a){return this.$$registry[a];
},
$$registry:{}}});
qx.Bootstrap.define("qx.core.Setting",
{statics:{__a:{},
define:function(a,
b){if(b===undefined){throw new Error('Default value of setting "'+a+'" must be defined!');
}
if(!this.__a[a]){this.__a[a]={};
}else if(this.__a[a].defaultValue!==undefined){throw new Error('Setting "'+a+'" is already defined!');
}this.__a[a].defaultValue=b;
},
get:function(a){var b=this.__a[a];
if(b===undefined){throw new Error('Setting "'+a+'" is not defined.');
}
if(b.value!==undefined){return b.value;
}return b.defaultValue;
},
__b:function(){if(window.qxsettings){for(var a in qxsettings){if((a.split(".")).length<2){throw new Error('Malformed settings key "'+a+'". Must be following the schema "namespace.key".');
}
if(!this.__a[a]){this.__a[a]={};
}this.__a[a].value=qxsettings[a];
}window.qxsettings=undefined;
try{delete window.qxsettings;
}catch(ex){}this.__c();
}},
__c:function(){if(this.get("qx.allowUrlSettings")!=true){return;
}var a=document.location.search.slice(1).split("&");
for(var b=0;b<a.length;b++){var c=a[b].split(":");
if(c.length!=3||c[0]!="qxsetting"){continue;
}var d=c[1];
if(!this.__a[d]){this.__a[d]={};
}this.__a[d].value=decodeURIComponent(c[2]);
}}},
defer:function(a){a.define("qx.allowUrlSettings",
false);
a.define("qx.allowUrlVariants",
false);
a.__b();
}});
qx.Bootstrap.define("qx.bom.client.Engine",
{statics:{NAME:"",
FULLVERSION:"0.0.0",
VERSION:0.0,
OPERA:false,
WEBKIT:false,
GECKO:false,
MSHTML:false,
__d:function(){var a="unknown";
var b="0.0.0";
var c=navigator.userAgent;
if(window.opera){a="opera";
this.OPERA=true;
if(/Opera[\s\/]([0-9\.]*)/.test(c)){b=RegExp.$1.substring(0,
3)+"."+RegExp.$1.substring(3);
}else{throw new Error("Could not detect Opera version: "+c+"!");
}}else if(navigator.vendor&&(navigator.vendor==="Apple Computer, Inc."||navigator.vendor==="Adobe Systems Incorporated")){a="webkit";
this.WEBKIT=true;
if(/AppleWebKit\/([^ ]+)/.test(c)){b=RegExp.$1;
var d=RegExp("[^\\.0-9]").exec(b);
if(d){b=b.slice(0,
d.index);
}}else{throw new Error("Could not detect Webkit version: "+c+"!");
}}else if(window.controllers&&navigator.product==="Gecko"){a="gecko";
this.GECKO=true;
if(/rv\:([^\);]+)(\)|;)/.test(c)){b=RegExp.$1;
}else{throw new Error("Could not detect Gecko version: "+c+"!");
}}else if(navigator.cpuClass&&/MSIE\s+([^\);]+)(\)|;)/.test(c)){a="mshtml";
b=RegExp.$1;
this.MSHTML=true;
}else{throw new Error("Unsupported client: "+c+"!");
}this.NAME=a;
this.FULLVERSION=b;
this.VERSION=parseFloat(b);
}},
defer:function(a){a.__d();
}});
qx.Bootstrap.define("qx.core.Variant",
{statics:{__e:{},
__f:{},
compilerIsSet:function(){return true;
},
define:function(a,
b,
c){{if(!this.__i(b)){throw new Error('Allowed values of variant "'+a+'" must be defined!');
}
if(c===undefined){throw new Error('Default value of variant "'+a+'" must be defined!');
}};
if(!this.__e[a]){this.__e[a]={};
}else{if(this.__e[a].defaultValue!==undefined){throw new Error('Variant "'+a+'" is already defined!');
}}this.__e[a].allowedValues=b;
this.__e[a].defaultValue=c;
},
get:function(a){var b=this.__e[a];
{if(b===undefined){throw new Error('Variant "'+a+'" is not defined.');
}};
if(b.value!==undefined){return b.value;
}return b.defaultValue;
},
__g:function(){if(window.qxvariants){for(var a in qxvariants){{if((a.split(".")).length<2){throw new Error('Malformed settings key "'+a+'". Must be following the schema "namespace.key".');
}};
if(!this.__e[a]){this.__e[a]={};
}this.__e[a].value=qxvariants[a];
}window.qxvariants=undefined;
try{delete window.qxvariants;
}catch(ex){}this.__h(this.__e);
}},
__h:function(){if(qx.core.Setting.get("qx.allowUrlVariants")!=true){return;
}var a=document.location.search.slice(1).split("&");
for(var b=0;b<a.length;b++){var c=a[b].split(":");
if(c.length!=3||c[0]!="qxvariant"){continue;
}var d=c[1];
if(!this.__e[d]){this.__e[d]={};
}this.__e[d].value=decodeURIComponent(c[2]);
}},
select:function(a,
b){{if(!this.__j(this.__e[a])){throw new Error("Variant \""+a+"\" is not defined");
}
if(!this.__j(b)){throw new Error("the second parameter must be a map!");
}};
for(var c in b){if(this.isSet(a,
c)){return b[c];
}}
if(b["default"]!==undefined){return b["default"];
}{throw new Error('No match for variant "'+a+'" in variants ['+qx.lang.Object.getKeysAsString(b)+'] found, and no default ("default") given');
};
},
isSet:function(a,
b){var c=a+"$"+b;
if(this.__f[c]!==undefined){return this.__f[c];
}var d=false;
if(b.indexOf("|")<0){d=this.get(a)===b;
}else{var e=b.split("|");
for(var f=0,
g=e.length;f<g;f++){if(this.get(a)===e[f]){d=true;
break;
}}}this.__f[c]=d;
return d;
},
__i:function(a){return typeof a==="object"&&a!==null&&a instanceof Array;
},
__j:function(a){return typeof a==="object"&&a!==null&&!(a instanceof Array);
},
__k:function(a,
b){for(var c=0,
d=a.length;c<d;c++){if(a[c]==b){return true;
}}return false;
}},
defer:function(a){a.define("qx.client",
["gecko",
"mshtml",
"opera",
"webkit"],
qx.bom.client.Engine.NAME);
a.define("qx.debug",
["on",
"off"],
"on");
a.define("qx.compatibility",
["on",
"off"],
"on");
a.define("qx.eventMonitorNoListeners",
["on",
"off"],
"off");
a.define("qx.aspects",
["on",
"off"],
"off");
a.define("qx.deprecationWarnings",
["on",
"off"],
"on");
a.define("qx.dynamicLocaleSwitch",
["on",
"off"],
"on");
a.__g();
}});
qx.Bootstrap.define("qx.lang.Object",
{statics:{isEmpty:function(a){for(var b in a){return false;
}return true;
},
hasMinLength:function(a,
b){var c=0;
for(var d in a){if((++c)>=b){return true;
}}return false;
},
getLength:function(a){var b=0;
for(var c in a){b++;
}return b;
},
_shadowedKeys:["isPrototypeOf",
"hasOwnProperty",
"toLocaleString",
"toString",
"valueOf"],
getKeys:qx.core.Variant.select("qx.client",
{"mshtml":function(b){var c=[];
for(var d in b){c.push(d);
}for(var e=0,
f=this._shadowedKeys,
g=f.length;e<g;e++){if(b.hasOwnProperty(f[e])){c.push(f[e]);
}}return c;
},
"default":function(a){var b=[];
for(var c in a){b.push(c);
}return b;
}}),
getKeysAsString:function(a){var b=qx.lang.Object.getKeys(a);
if(b.length==0){return "";
}return '"'+b.join('\", "')+'"';
},
getValues:function(a){var b=[];
for(var c in a){b.push(a[c]);
}return b;
},
mergeWith:function(a,
b,
c){if(c===undefined){c=true;
}
for(var d in b){if(c||a[d]===undefined){a[d]=b[d];
}}return a;
},
carefullyMergeWith:function(a,
b){return qx.lang.Object.mergeWith(a,
b,
false);
},
merge:function(a,
b){var c=arguments.length;
for(var d=1;d<c;d++){qx.lang.Object.mergeWith(a,
arguments[d]);
}return a;
},
copy:function(a){var b={};
for(var c in a){b[c]=a[c];
}return b;
},
invert:function(a){var b={};
for(var c in a){b[a[c].toString()]=c;
}return b;
},
getKeyFromValue:function(a,
b){for(var c in a){if(a[c]===b){return c;
}}return null;
},
select:function(a,
b){return b[a];
},
fromArray:function(a){var b={};
for(var c=0,
d=a.length;c<d;c++){{switch(typeof a[c]){case "object":case "function":case "undefined":throw new Error("Could not convert complex objects like "+a[c]+" at array index "+c+" to map syntax");
}};
b[a[c].toString()]=true;
}return b;
}}});
qx.Bootstrap.define("qx.core.Aspect",
{statics:{__l:[],
wrap:function(a,
b,
c){var d=[];
var e=[];
var f=this.__l;
var g;
for(var h=0;h<f.length;h++){g=f[h];
if((g.type==null||c==g.type||g.type=="*")&&(g.name==null||a.match(g.name))){g.pos==-1?d.push(g.fcn):e.push(g.fcn);
}}
if(d.length===0&&e.length===0){return b;
}var j=function(){for(var h=0;h<d.length;h++){d[h].call(this,
a,
b,
c,
arguments);
}var k=b.apply(this,
arguments);
for(var h=0;h<e.length;h++){e[h].call(this,
a,
b,
c,
arguments,
k);
}return k;
};
if(c!=="static"){j.self=b.self;
j.base=b.base;
}b.wrapper=j;
j.original=b;
return j;
},
addAdvice:function(a,
b,
c,
d){this.__l.push({fcn:a,
pos:b==="before"?-1:1,
type:c,
name:d});
}}});
qx.Bootstrap.define("qx.Class",
{statics:{define:function(a,
b){if(!b){var b={};
}if(b.include&&!(b.include instanceof Array)){b.include=[b.include];
}if(b.implement&&!(b.implement instanceof Array)){b.implement=[b.implement];
}if(!b.hasOwnProperty("extend")&&!b.type){b.type="static";
}{this.__o(a,
b);
};
var c=this.__q(a,
b.type,
b.extend,
b.statics,
b.construct,
b.destruct);
if(b.extend){if(b.properties){this.__s(c,
b.properties,
true);
}if(b.members){this.__u(c,
b.members,
true,
true,
false);
}if(b.events){this.__r(c,
b.events,
true);
}if(b.include){for(var d=0,
e=b.include.length;d<e;d++){this.__x(c,
b.include[d],
false);
}}}if(b.settings){for(var f in b.settings){qx.core.Setting.define(f,
b.settings[f]);
}}if(b.variants){for(var f in b.variants){qx.core.Variant.define(f,
b.variants[f].allowedValues,
b.variants[f].defaultValue);
}}if(b.implement){for(var d=0,
e=b.implement.length;d<e;d++){this.__w(c,
b.implement[d]);
}}{this.__p(c);
};
if(b.defer){b.defer.self=c;
b.defer(c,
c.prototype,
{add:function(a,
b){var g={};
g[a]=b;
qx.Class.__s(c,
g,
true);
}});
}},
isDefined:function(a){return this.getByName(a)!==undefined;
},
getTotalNumber:function(){return qx.lang.Object.getLength(this.$$registry);
},
getByName:function(a){return this.$$registry[a];
},
include:function(a,
b){{if(!b){throw new Error("Includes of mixins must be mixins. A dynamic mixin of class '"+a.classname+"' is undefined/null!");
}qx.Mixin.isCompatible(b,
a);
};
qx.Class.__x(a,
b,
false);
},
patch:function(a,
b){{if(!b){throw new Error("Includes of mixins must be mixins. A dynamic mixin of class '"+a.classname+"' is undefined/null!");
}qx.Mixin.isCompatible(b,
a);
};
qx.Class.__x(a,
b,
true);
},
isSubClassOf:function(a,
b){if(!a){return false;
}
if(a==b){return true;
}
if(a.prototype instanceof b){return true;
}return false;
},
getPropertyDefinition:function(a,
b){while(a){if(a.$$properties&&a.$$properties[b]){return a.$$properties[b];
}a=a.superclass;
}return null;
},
getProperties:function(a){var b=[];
while(a){if(a.$$properties){b.push.apply(b,
qx.lang.Object.getKeys(a.$$properties));
}a=a.superclass;
}return b;
},
getByProperty:function(a,
b){while(a){if(a.$$properties&&a.$$properties[b]){return a;
}a=a.superclass;
}return null;
},
hasProperty:function(a,
b){return !!this.getPropertyDefinition(a,
b);
},
getEventType:function(a,
b){var a=a.constructor;
while(a.superclass){if(a.$$events&&a.$$events[b]!==undefined){return a.$$events[b];
}a=a.superclass;
}return null;
},
supportsEvent:function(a,
b){return !!this.getEventType(a,
b);
},
hasOwnMixin:function(a,
b){return a.$$includes&&a.$$includes.indexOf(b)!==-1;
},
getByMixin:function(a,
b){var c,
d,
e;
while(a){if(a.$$includes){c=a.$$flatIncludes;
for(d=0,
e=c.length;d<e;d++){if(c[d]===b){return a;
}}}a=a.superclass;
}return null;
},
getMixins:function(a){var b=[];
while(a){if(a.$$includes){b.push.apply(b,
a.$$flatIncludes);
}a=a.superclass;
}return b;
},
hasMixin:function(a,
b){return !!this.getByMixin(a,
b);
},
hasOwnInterface:function(a,
b){return a.$$implements&&a.$$implements.indexOf(b)!==-1;
},
getByInterface:function(a,
b){var c,
d,
e;
while(a){if(a.$$implements){c=a.$$flatImplements;
for(d=0,
e=c.length;d<e;d++){if(c[d]===b){return a;
}}}a=a.superclass;
}return null;
},
getInterfaces:function(a){var b=[];
while(a){if(a.$$implements){b.push.apply(b,
a.$$flatImplements);
}a=a.superclass;
}return b;
},
hasInterface:function(a,
b){return !!this.getByInterface(a,
b);
},
implementsInterface:function(a,
b){if(this.hasInterface(a,
b)){return true;
}
try{qx.Interface.assert(a,
b,
false);
return true;
}catch(ex){}return false;
},
getInstance:function(){if(!this.$$instance){this.$$allowconstruct=true;
this.$$instance=new this;
delete this.$$allowconstruct;
}return this.$$instance;
},
genericToString:function(){return "[Class "+this.classname+"]";
},
$$registry:qx.Bootstrap.$$registry,
__m:{"type":"string",
"extend":"function",
"implement":"object",
"include":"object",
"construct":"function",
"statics":"object",
"properties":"object",
"members":"object",
"settings":"object",
"variants":"object",
"events":"object",
"defer":"function",
"destruct":"function"},
__n:{"type":"string",
"statics":"object",
"settings":"object",
"variants":"object",
"defer":"function"},
__o:function(b,
c){if(c.type&&!(c.type==="static"||c.type==="abstract"||c.type==="singleton")){throw new Error('Invalid type "'+c.type+'" definition for class "'+b+'"!');
}var d=c.type==="static"?this.__n:this.__m;
for(var e in c){if(!d[e]){throw new Error('The configuration key "'+e+'" in class "'+b+'" is not allowed!');
}
if(c[e]==null){throw new Error('Invalid key "'+e+'" in class "'+b+'"! The value is undefined/null!');
}
if(typeof c[e]!==d[e]){throw new Error('Invalid type of key "'+e+'" in class "'+b+'"! The type of the key must be "'+d[e]+'"!');
}}var f=["statics",
"properties",
"members",
"settings",
"variants",
"events"];
for(var g=0,
h=f.length;g<h;g++){var e=f[g];
if(c[e]!==undefined&&(c[e] instanceof Array||c[e] instanceof RegExp||c[e] instanceof Date||c[e].classname!==undefined)){throw new Error('Invalid key "'+e+'" in class "'+b+'"! The value needs to be a map!');
}}if(c.include){if(c.include instanceof Array){for(var g=0,
j=c.include,
h=j.length;g<h;g++){if(j[g]==null||j[g].$$type!=="Mixin"){throw new Error('The include definition in class "'+b+'" contains an invalid mixin at position '+g+': '+j[g]);
}}}else{throw new Error('Invalid include definition in class "'+b+'"! Only mixins and arrays of mixins are allowed!');
}}if(c.implement){if(c.implement instanceof Array){for(var g=0,
j=c.implement,
h=j.length;g<h;g++){if(j[g]==null||j[g].$$type!=="Interface"){throw new Error('The implement definition in class "'+b+'" contains an invalid interface at position '+g+': '+j[g]);
}}}else{throw new Error('Invalid implement definition in class "'+b+'"! Only interfaces and arrays of interfaces are allowed!');
}}if(c.include){try{qx.Mixin.checkCompatibility(c.include);
}catch(ex){throw new Error('Error in include definition of class "'+b+'"! '+ex.message);
}}if(c.settings){for(var e in c.settings){if(e.substr(0,
e.indexOf("."))!=b.substr(0,
b.indexOf("."))){throw new Error('Forbidden setting "'+e+'" found in "'+b+'". It is forbidden to define a default setting for an external namespace!');
}}}if(c.variants){for(var e in c.variants){if(e.substr(0,
e.indexOf("."))!=b.substr(0,
b.indexOf("."))){throw new Error('Forbidden variant "'+e+'" found in "'+b+'". It is forbidden to define a variant for an external namespace!');
}}}},
__p:function(a){var b=a.superclass;
while(b){if(b.$$classtype!=="abstract"){break;
}var c=b.$$implements;
if(c){for(var d=0;d<c.length;d++){qx.Interface.assert(a,
c[d],
true);
}}b=b.superclass;
}},
__q:function(b,
c,
d,
e,
f,
g){var h;
if(!d&&true){h=e||{};
}else{h={};
if(d){if(!f){f=this.__y();
}h=this.__A(f,
b,
c);
}if(e){var j;
for(var k=0,
m=qx.lang.Object.getKeys(e),
n=m.length;k<n;k++){j=m[k];
{h[j]=e[j];
};
var o;
}}}var p=qx.Bootstrap.createNamespace(b,
h,
false);
h.name=h.classname=b;
h.basename=p;
h.$$type="Class";
if(c){h.$$classtype=c;
}if(!h.hasOwnProperty("toString")){h.toString=this.genericToString;
}
if(d){var q=d.prototype;
var r=this.__z();
r.prototype=q;
var s=new r;
h.prototype=s;
s.name=s.classname=b;
s.basename=p;
f.base=h.superclass=d;
f.self=h.constructor=s.constructor=h;
if(g){{};
h.$$destructor=g;
}}this.$$registry[b]=h;
return h;
},
__r:function(a,
b,
c){{if(typeof b!=="object"||b instanceof Array){throw new Error(a.classname+": the events must be defined as map!");
}
for(var d in b){if(typeof b[d]!=="string"){throw new Error(a.classname+"/"+d+": the event value needs to be a string with the class name of the event object which will be fired.");
}}if(a.$$events&&c!==true){for(var d in b){if(a.$$events[d]!==undefined&&a.$$events[d]!==b[d]){throw new Error(a.classname+"/"+d+": the event value/type cannot be changed from "+a.$$events[d]+" to "+b[d]);
}}}};
if(a.$$events){for(var d in b){a.$$events[d]=b[d];
}}else{a.$$events=b;
}},
__s:function(a,
b,
c){var d;
if(c===undefined){c=false;
}var e=!!a.$$propertiesAttached;
for(var f in b){d=b[f];
{this.__t(a,
f,
d,
c);
};
d.name=f;
if(!d.refine){if(a.$$properties===undefined){a.$$properties={};
}a.$$properties[f]=d;
}if(d.init!==undefined){a.prototype["$$init_"+f]=d.init;
}if(d.event!==undefined){var g={};
g[d.event]="qx.event.type.Data";
this.__r(a,
g,
c);
}if(d.inheritable){qx.core.Property.$$inheritable[f]=true;
}if(e){qx.core.Property.attachMethods(a,
f,
d);
}}},
__t:function(a,
b,
c,
d){var e=this.hasProperty(a,
b);
if(e){var f=this.getPropertyDefinition(a,
b);
if(c.refine&&f.init===undefined){throw new Error("Could not refine a init value if there was previously no init value defined. Property '"+b+"' of class '"+a.classname+"'.");
}}
if(!e&&c.refine){throw new Error("Could not refine non-existent property: "+b+"!");
}
if(e&&!d){throw new Error("Class "+a.classname+" already has a property: "+b+"!");
}
if(e&&d){if(!c.refine){throw new Error('Could not refine property "'+b+'" without a "refine" flag in the property definition! This class: '+a.classname+', original class: '+this.getByProperty(a,
b).classname+'.');
}
for(var g in c){if(g!=="init"&&g!=="refine"){throw new Error("Class "+a.classname+" could not refine property: "+b+"! Key: "+g+" could not be refined!");
}}}var h=c.group?qx.core.Property.$$allowedGroupKeys:qx.core.Property.$$allowedKeys;
for(var g in c){if(h[g]===undefined){throw new Error('The configuration key "'+g+'" of property "'+b+'" in class "'+a.classname+'" is not allowed!');
}
if(c[g]===undefined){throw new Error('Invalid key "'+g+'" of property "'+b+'" in class "'+a.classname+'"! The value is undefined: '+c[g]);
}
if(h[g]!==null&&typeof c[g]!==h[g]){throw new Error('Invalid type of key "'+g+'" of property "'+b+'" in class "'+a.classname+'"! The type of the key must be "'+h[g]+'"!');
}}
if(c.transform!=null){if(!(typeof c.transform=="string")){throw new Error('Invalid transform definition of property "'+b+'" in class "'+a.classname+'"! Needs to be a String.');
}}
if(c.check!=null){if(!(typeof c.check=="string"||c.check instanceof Array||c.check instanceof Function)){throw new Error('Invalid check definition of property "'+b+'" in class "'+a.classname+'"! Needs to be a String, Array or Function.');
}}},
__u:function(b,
c,
d,
e,
f){var g=b.prototype;
var h,
j;
for(var k=0,
m=qx.lang.Object.getKeys(c),
n=m.length;k<n;k++){h=m[k];
j=c[h];
{if(g[h]!==undefined&&h.charAt(0)=="_"&&h.charAt(1)=="_"){throw new Error('Overwriting private member "'+h+'" of Class "'+b.classname+'" is not allowed!');
}
if(d!==true&&g.hasOwnProperty(h)){throw new Error('Overwriting member "'+h+'" of Class "'+b.classname+'" is not allowed!');
}};
if(e!==false&&j instanceof Function&&j.$$type==null){if(f==true){j=this.__v(j,
g[h]);
}else{if(g[h]){j.base=g[h];
}j.self=b;
}{};
}g[h]=j;
}},
__v:function(a,
b){if(b){return function(){var c=a.base;
a.base=b;
var d=a.apply(this,
arguments);
a.base=c;
return d;
};
}else{return a;
}},
__w:function(a,
b){{if(!a||!b){throw new Error("Incomplete parameters!");
}if(this.hasOwnInterface(a,
b)){throw new Error('Interface "'+b.name+'" is already used by Class "'+a.classname+'!');
}if(a.$$classtype!=="abstract"){qx.Interface.assert(a,
b,
true);
}};
var c=qx.Interface.flatten([b]);
if(a.$$implements){a.$$implements.push(b);
a.$$flatImplements.push.apply(a.$$flatImplements,
c);
}else{a.$$implements=[b];
a.$$flatImplements=c;
}},
__x:function(a,
b,
c){{if(!a||!b){throw new Error("Incomplete parameters!");
}};
if(this.hasMixin(a,
b)){qx.log.Logger.warn('Mixin "'+b.name+'" is already included into Class "'+a.classname+'" by class: '+this.getByMixin(a,
b).classname+'!');
return;
}var d=qx.Mixin.flatten([b]);
var e;
for(var f=0,
g=d.length;f<g;f++){e=d[f];
if(e.$$events){this.__r(a,
e.$$events,
c);
}if(e.$$properties){this.__s(a,
e.$$properties,
c);
}if(e.$$members){this.__u(a,
e.$$members,
c,
c,
c);
}}if(a.$$includes){a.$$includes.push(b);
a.$$flatIncludes.push.apply(a.$$flatIncludes,
d);
}else{a.$$includes=[b];
a.$$flatIncludes=d;
}},
__y:function(){function a(){arguments.callee.base.apply(this,
arguments);
}return a;
},
__z:function(){return function(){};
},
__A:function(a,
b,
c){var d=function(){var e=arguments.callee.constructor;
{if(!(this instanceof e)){throw new Error("Please initialize '"+b+"' objects using the new keyword!");
}if(c==="abstract"){if(this.classname===b){throw new Error("The class ',"+b+"' is abstract! It is not possible to instantiate it.");
}}else if(c==="singleton"){if(!e.$$allowconstruct){throw new Error("The class '"+b+"' is a singleton! It is not possible to instantiate it directly. Use the static getInstance() method instead.");
}}};
if(!e.$$propertiesAttached){qx.core.Property.attach(e);
}var f=e.$$original.apply(this,
arguments);
if(e.$$includes){var g=e.$$flatIncludes;
for(var h=0,
j=g.length;h<j;h++){if(g[h].$$constructor){g[h].$$constructor.apply(this,
arguments);
}}}if(this.classname===b.classname){this.$$initialized=true;
}return f;
};
var k;
if(c==="singleton"){d.getInstance=this.getInstance;
}d.$$original=a;
a.wrapper=d;
return d;
}},
defer:function(a){for(var b in qx.Bootstrap.$$registry){var a=qx.Bootstrap.$$registry[b];
for(var c in a){if(a[c] instanceof Function){a[c]=qx.core.Aspect.wrap(b+"."+c,
a[c],
"static");
}}}}});
qx.Bootstrap.define("qx.lang.Core");
if(!Error.prototype.toString||Error.prototype.toString()=="[object Error]"){Error.prototype.toString=function(){return this.message;
};
}if(!Array.prototype.indexOf){Array.prototype.indexOf=function(a,
b){if(b==null){b=0;
}else if(b<0){b=Math.max(0,
this.length+b);
}
for(var c=b;c<this.length;c++){if(this[c]===a){return c;
}}return -1;
};
}
if(!Array.prototype.lastIndexOf){Array.prototype.lastIndexOf=function(a,
b){if(b==null){b=this.length-1;
}else if(b<0){b=Math.max(0,
this.length+b);
}
for(var c=b;c>=0;c--){if(this[c]===a){return c;
}}return -1;
};
}
if(!Array.prototype.forEach){Array.prototype.forEach=function(a,
b){var c=this.length;
for(var d=0;d<c;d++){a.call(b,
this[d],
d,
this);
}};
}
if(!Array.prototype.filter){Array.prototype.filter=function(a,
b){var c=this.length;
var d=[];
for(var e=0;e<c;e++){if(a.call(b,
this[e],
e,
this)){d.push(this[e]);
}}return d;
};
}
if(!Array.prototype.map){Array.prototype.map=function(a,
b){var c=this.length;
var d=[];
for(var e=0;e<c;e++){d.push(a.call(b,
this[e],
e,
this));
}return d;
};
}
if(!Array.prototype.some){Array.prototype.some=function(a,
b){var c=this.length;
for(var d=0;d<c;d++){if(a.call(b,
this[d],
d,
this)){return true;
}}return false;
};
}
if(!Array.prototype.every){Array.prototype.every=function(a,
b){var c=this.length;
for(var d=0;d<c;d++){if(!a.call(b,
this[d],
d,
this)){return false;
}}return true;
};
}if(!String.prototype.quote){String.prototype.quote=function(){return '"'+this.replace(/\\/g,
"\\\\").replace(/\"/g,
"\\\"")+'"';
};
}qx.Bootstrap.define("qx.lang.Generics",
{statics:{__B:{"Array":["join",
"reverse",
"sort",
"push",
"pop",
"shift",
"unshift",
"splice",
"concat",
"slice",
"indexOf",
"lastIndexOf",
"forEach",
"map",
"filter",
"some",
"every"],
"String":["quote",
"substring",
"toLowerCase",
"toUpperCase",
"charAt",
"charCodeAt",
"indexOf",
"lastIndexOf",
"toLocaleLowerCase",
"toLocaleUpperCase",
"localeCompare",
"match",
"search",
"replace",
"split",
"substr",
"concat",
"slice"]},
__C:function(a,
b){return function(c){return a.prototype[b].apply(c,
Array.prototype.slice.call(arguments,
1));
};
},
__D:function(){var a=qx.lang.Generics.__B;
for(var b in a){var c=window[b];
var d=a[b];
for(var e=0,
f=d.length;e<f;e++){var g=d[e];
if(!c[g]){c[g]=qx.lang.Generics.__C(c,
g);
}}}}},
defer:function(a){a.__D();
}});
qx.Bootstrap.define("qx.log.Logger",
{statics:{__E:50,
__F:"debug",
setLevel:function(a){this.__F=a;
},
getLevel:function(){return this.__F;
},
setTreshold:function(a){this.__E=a;
},
getTreshold:function(){return this.__E;
},
__G:{},
__H:0,
register:function(a){if(a.$$id){return;
}var b=this.__H++;
this.__G[b]=a;
a.$$id=b;
var c=this.__I;
for(var d=0,
e=c.length;d<e;d++){a.process(c[d]);
}},
unregister:function(a){var b=a.$$id;
if(b==null){return;
}delete this.__G[b];
delete a.$$id;
},
debug:function(a,
b){this.__K("debug",
arguments);
},
info:function(a,
b){this.__K("info",
arguments);
},
warn:function(a,
b){this.__K("warn",
arguments);
},
error:function(a,
b){this.__K("error",
arguments);
},
trace:function(a){this.__K("info",
[a,
qx.dev.StackTrace.getStackTrace().join("\n")]);
},
deprecatedMethodWarning:function(a,
b){if(qx.core.Variant.isSet("qx.deprecationWarnings",
"on")){var c=qx.lang.Function.getName(a);
var d=a.self?a.self.classname:"unknown";
this.warn("The method '"+c+"' of class '"+d+"' is deprecated: "+b||"Please consult the API documentation of this method for alternatives.");
this.trace();
}},
deprecatedClassWarning:function(a,
b){if(qx.core.Variant.isSet("qx.deprecationWarnings",
"on")){var c=a.self?a.self.classname:"unknown";
this.warn("The method class '"+c+"' is deprecated: "+b||"Please consult the API documentation of this class for alternatives.");
this.trace();
}},
clear:function(){this.__I=[];
},
__I:[],
__J:{debug:0,
info:1,
warn:2,
error:3},
__K:function(a,
b){var c=this.__J;
if(c[a]<c[this.__F]){return;
}var d=b.length<2?null:b[0];
var e=d?1:0;
var f=[];
for(var g=e,
h=b.length;g<h;g++){f.push(this.__M(b[g],
true));
}var j=new Date;
var k={time:j,
offset:j-qx.Bootstrap.LOADSTART,
level:a,
items:f};
if(d){if(d instanceof qx.core.Object){k.object=d.$$hash;
}else if(d.$$type){k.clazz=d;
}}var m=this.__I;
m.push(k);
if(m.length>(this.__E+10)){m.splice(this.__E,
m.length);
}var n=this.__G;
for(var o in n){n[o].process(k);
}},
__L:function(a){if(a===undefined){return "undefined";
}else if(a===null){return "null";
}
if(a.$$type){return "class";
}var b=typeof a;
if(b==="function"||b=="string"||b==="number"||b==="boolean"){return b;
}else if(b==="object"){if(a.nodeType){return "node";
}else if(a.classname){return "instance";
}else if(a instanceof Array){return "array";
}else if(a instanceof Error){return "error";
}else{return "map";
}}
if(a.toString){return "stringify";
}return "unknown";
},
__M:function(a,
b){var c=this.__L(a);
var d="unknown";
switch(c){case "null":case "undefined":d=c;
break;
case "string":case "number":case "boolean":d=a;
break;
case "node":if(a.nodeType===9){d="document";
}else if(a.nodeType===3){d="text["+a.nodeValue+"]";
}else if(a.nodeType===1){d=a.nodeName.toLowerCase();
if(a.id){d+="#"+a.id;
}}else{d="node";
}break;
case "function":d=qx.lang.Function.getName(a)||c;
break;
case "instance":d=a.basename+"["+a.$$hash+"]";
break;
case "class":case "stringify":case "error":d=a.toString();
break;
case "array":if(b){d=[];
for(var e=0,
f=a.length;e<f;e++){if(d.length>20){d.push("...(+"+(f-e)+")");
break;
}d.push(this.__M(a[e],
false));
}}else{d="[...("+a.length+")]";
}break;
case "map":if(b){var g;
var h=[];
for(var j in a){h.push(j);
}h.sort();
d=[];
for(var e=0,
f=h.length;e<f;e++){if(d.length>20){d.push("...(+"+(f-e)+")");
break;
}j=h[e];
g=this.__M(a[j],
false);
g.key=j;
d.push(g);
}}else{var k=0;
for(var j in a){k++;
}d="{...("+k+")}";
}break;
}return {type:c,
text:d};
}}});
qx.Class.define("qx.dev.StackTrace",
{statics:{getStackTrace:qx.core.Variant.select("qx.client",
{"gecko":function(){try{throw new Error();
}catch(e){var a=this.getStackTraceFromError(e);
qx.lang.Array.removeAt(a,
0);
var b=this.getStackTraceFromCaller(arguments);
var c=b.length>a.length?b:a;
for(var d=0;d<Math.min(b.length,
a.length);d++){var e=b[d];
if(e.indexOf("anonymous")>=0){continue;
}var f=e.split(":");
if(f.length!=2){continue;
}var g=f[0];
var h=f[1];
var j=a[d];
var k=j.split(":");
var l=k[0];
var m=k[1];
if(qx.Class.getByName(l)){var n=l;
}else{n=g;
}var o=n+":";
if(h){o+=h+":";
}o+=m;
c[d]=o;
}return c;
}},
"mshtml|webkit":function(){return this.getStackTraceFromCaller(arguments);
},
"opera":function(){var a;
try{a.bar();
}catch(e){var b=this.getStackTraceFromError(e);
qx.lang.Array.removeAt(b,
0);
return b;
}return [];
}}),
getStackTraceFromCaller:qx.core.Variant.select("qx.client",
{"opera":function(a){return [];
},
"default":function(a){var b=[];
var c=qx.lang.Function.getCaller(a);
var d={};
while(c){var e=qx.lang.Function.getName(c);
b.push(e);
try{c=c.caller;
}catch(e){break;
}
if(!c){break;
}var f=qx.core.ObjectRegistry.toHashCode(c);
if(d[f]){b.push("...");
break;
}d[f]=c;
}return b;
}}),
getStackTraceFromError:qx.core.Variant.select("qx.client",
{"gecko":function(a){if(!a.stack){return [];
}var b=/@(.+):(\d+)$/gm;
var c;
var d=[];
while((c=b.exec(a.stack))!=null){var e=c[1];
var f=c[2];
var g=this.__N(e);
d.push(g+":"+f);
}return d;
},
"webkit":function(a){if(a.sourceURL&&a.line){return [this.__N(a.sourceURL)+":"+a.line];
}else{return [];
}},
"opera":function(a){if(a.message.indexOf("Backtrace:")<0){return [];
}var b=[];
var c=qx.lang.String.trim(a.message.split("Backtrace:")[1]);
var d=c.split("\n");
for(var e=0;e<d.length;e++){var f=d[e].match(/\s*Line ([0-9]+) of.* (\S.*)/);
if(f&&f.length>=2){var g=f[1];
var h=this.__N(f[2]);
b.push(h+":"+g);
}}return b;
},
"default":function(){return [];
}}),
__N:function(a){var b="/source/class/";
var c=a.indexOf(b);
var d=(c==-1)?a:a.substring(c+b.length).replace(/\//g,
".").replace(/\.js$/,
"");
return d;
}}});
qx.Bootstrap.define("qx.lang.Array",
{statics:{fromArguments:function(a,
b){return Array.prototype.slice.call(a,
b||0);
},
fromCollection:function(a){if(qx.core.Variant.isSet("qx.client",
"mshtml")){if(a.item){var b=[];
for(var c=0,
d=a.length;c<d;c++){b[c]=a[c];
}return b;
}}return Array.prototype.slice.call(a,
0);
},
fromShortHand:function(a){var b=a.length;
var c=qx.lang.Array.copy(a);
switch(b){case 1:c[1]=c[2]=c[3]=c[0];
break;
case 2:c[2]=c[0];
case 3:c[3]=c[1];
}return c;
},
copy:function(a){return a.concat();
},
clone:function(a){return a.concat();
},
getLast:function(a){return a[a.length-1];
},
getFirst:function(a){return a[0];
},
insertAt:function(a,
b,
c){a.splice(c,
0,
b);
return a;
},
insertBefore:function(a,
b,
c){var d=a.indexOf(c);
if(d==-1){a.push(b);
}else{a.splice(d,
0,
b);
}return a;
},
insertAfter:function(a,
b,
c){var d=a.indexOf(c);
if(d==-1||d==(a.length-1)){a.push(b);
}else{a.splice(d+1,
0,
b);
}return a;
},
removeAt:function(a,
b){return a.splice(b,
1)[0];
},
removeAll:function(a){return a.length=0;
},
append:function(b,
c){{qx.core.Assert.assertArray(c,
"The second parameter must be an array.");
};
Array.prototype.push.apply(b,
c);
return b;
},
remove:function(a,
b){var c=a.indexOf(b);
if(c!=-1){a.splice(c,
1);
return b;
}},
contains:function(a,
b){return a.indexOf(b)!==-1;
},
equals:function(a,
b){var c=a.length;
if(c!==b.length){return false;
}
for(var d=0;d<c;d++){if(a[d]!==b[d]){return false;
}}return true;
},
sum:function(a){var b=0;
for(var c=0,
d=a.length;c<d;c++){b+=a[c];
}return b;
},
max:function(a){var b=Number.MIN_VALUE;
for(var c=0,
d=a.length;c<d;c++){if(a[c]>b){b=a[c];
}}return b;
},
min:function(a){var b=Number.MAX_VALUE;
for(var c=0,
d=a.length;c<d;c++){if(a[c]<b){b=a[c];
}}return b;
}}});
qx.Class.define("qx.core.Assert",
{statics:{__O:function(a,
b,
c){if(!a){var d="Assertion error! "+b+": "+c;
qx.log.Logger.error(d);
if(qx.Class.isDefined("qx.core.AssertionError")){var e=new qx.core.AssertionError(b,
c);
qx.log.Logger.error("Stack trace: \n"+e.getStackTrace());
throw e;
}else{throw new Error(d);
}}},
assert:function(a,
b){this.__O(a==true,
b||"",
"Called assert with 'false'");
},
fail:function(a){this.__O(false,
a||"",
"Called fail().");
},
assertTrue:function(a,
b){this.__O(a===true,
b||"",
"Called assertTrue with 'false'");
},
assertFalse:function(a,
b){this.__O(a===false,
b||"",
"Called assertFalse with 'true'");
},
assertEquals:function(a,
b,
c){this.__O(a==b,
c||"",
"Expected '"+a+"' but found '"+b+"'!");
},
assertIdentical:function(a,
b,
c){this.__O(a===b,
c||"",
"Expected '"+a+"' (identical) but found '"+b+"'!");
},
assertNotIdentical:function(a,
b,
c){this.__O(a!==b,
c||"",
"Expected '"+a+"' to be not identical with '"+b+"'!");
},
assertNotUndefined:function(a,
b){this.__O(a!==undefined,
b||"",
"Expected value not to be undefined but found "+a+"!");
},
assertUndefined:function(a,
b){this.__O(a===undefined,
b||"",
"Expected value to be undefined but found "+a+"!");
},
assertNotNull:function(a,
b){this.__O(a!==null,
b||"",
"Expected value not to be null but found "+a+"!");
},
assertNull:function(a,
b){this.__O(a===null,
b||"",
"Expected value to be null but found "+a+"!");
},
assertJsonEquals:function(a,
b,
c){this.assertEquals(qx.util.Json.stringify(a),
qx.util.Json.stringify(b),
c);
},
assertMatch:function(a,
b,
c){this.assertString(a);
this.__O(a.search(b)>=0?true:false,
c||"",
"The String '"+a+"' does not match the regular expression '"+b.toString()+"'!");
},
assertArgumentsCount:function(a,
b,
c,
d){var e=a.length;
this.__O((e>=b&&e<=c),
d||"",
"Wrong number of arguments given. Expected '"+b+"' to '"+c+"' arguments but found '"+arguments.length+"' arguments.");
},
assertException:function(a,
b,
c,
d){var b=b||Error;
var e;
try{a();
}catch(e){e=e;
}
if(e==null){this.__O(false,
d||"",
"The function did not raise an exception!");
}this.__O(e instanceof b,
d||"",
"The raised exception does not have the expected type!");
if(c){this.assertMatch(e.toString(),
c,
d);
}},
assertInArray:function(a,
b,
c){this.__O(b.indexOf(a)>-1,
c||"",
"The value '"+a+"' must have any of the values defined in the array '"+qx.util.Json.stringify(b)+"'");
},
assertKeyInMap:function(a,
b,
c){this.__O(b[a],
c||"",
"The value '"+a+"' must must be a key of the map '"+qx.util.Json.stringify(b)+"'");
},
assertFunction:function(a,
b){this.__O(typeof a==="function",
b||"",
"Expected value to be typeof function but found "+a+"!");
},
assertString:function(a,
b){this.__O(typeof a==="string"||a instanceof String,
b||"",
"Expected value to be a string but found "+a+"!");
},
assertBoolean:function(a,
b){this.__O(typeof a==="boolean"||a instanceof Boolean,
b||"",
"Expected value to be a boolean but found "+a+"!");
},
assertNumber:function(a,
b){this.__O((typeof a==="number"||a instanceof Number)&&isFinite(a),
b||"",
"Expected value to be a number but found "+a+"!");
},
assertPositiveNumber:function(a,
b){this.__O((typeof a==="number"||a instanceof Number)&&isFinite(a)&&a>=0,
b||"",
"Expected value to be a number >= 0 but found "+a+"!");
},
assertInteger:function(a,
b){this.__O(((typeof a==="number"||a instanceof Number)&&isFinite(a)&&a%1===0),
b||"",
"Expected value to be an integer but found "+a+"!");
},
assertPositiveInteger:function(a,
b){this.__O(((typeof a==="number"||a instanceof Number)&&isFinite(a)&&a%1===0&&a>=0),
b||"",
"Expected value to be an integer >= 0 but found "+a+"!");
},
assertInRange:function(a,
b,
c,
d){this.__O(a>=b&&a<=c,
d||"",
qx.lang.String.format("Expected value '%1' to be in the range '%2'..'%3'!",
[a,
b,
c]));
},
assertObject:function(a,
b){this.__O(typeof a==="object"&&a!==null,
b||"",
"Expected value to be typeof object but found "+a+"!");
},
assertArray:function(a,
b){this.__O(a instanceof Array,
b||"",
"Expected value to be an array but found "+a+"!");
},
assertMap:function(a,
b){var c=({}).constructor;
this.__O(a&&a.constructor===c,
b||"",
"Expected value to be a map but found "+a+"!");
},
assertType:function(a,
b,
c){this.__O(typeof (a)===b,
c||"",
"Expected value to be typeof '"+b+"' but found "+a+"!");
},
assertInstance:function(a,
b,
c){var d=b.classname||b+"";
this.__O(a instanceof b,
c||"",
"Expected value to be instanceof '"+d+"' but found "+a+"!");
},
assertInterface:function(a,
b,
c){this.__O(qx.Class.implementsInterface(a.constructor,
b),
c||"",
"Expected object '"+a+"' to implement the interface '"+b+"'!");
},
assertCssColor:function(a,
b,
c){var d=qx.util.ColorUtil;
var e=d.stringToRgb(a);
try{var f=d.stringToRgb(b);
}catch(e){this.__O(false,
c||"",
qx.lang.String.format("Expected value to be the CSS color '%1' (rgb(%2)), but found value '%3', which cannot be converted to a CSS color!",
[a,
e.join(","),
b]));
}this.__O(e[0]==f[0]&&e[1]==f[1]&&e[2]==f[2],
c||"",
qx.lang.String.format("Expected value to be the CSS color '%1' (rgb(%2)), but found value '%3' (rgb(%4))!",
[a,
e.join(","),
b,
f.join(",")]));
},
assertElement:function(a,
b){this.__O(qx.dom.Node.isElement(a),
b||"",
qx.lang.String.format("Expected value to be a DOM element but found  '%1'!",
[a]));
},
assertQxObject:function(a,
b){this.__O(a instanceof qx.core.Object,
b||"",
"Expected value to be a qooxdoo object but found "+a+"!");
},
assertQxWidget:function(a,
b){this.__O(a instanceof qx.ui.core.Widget,
b||"",
"Expected value to be a qooxdoo widget but found "+a+"!");
}}});
qx.Class.define("qx.core.AssertionError",
{extend:Error,
construct:function(a,
b){Error.call(this,
b);
this._comment=a||"";
this._msg=b||"";
this._trace=qx.dev.StackTrace.getStackTrace();
},
members:{getComment:function(){return this._comment;
},
message:function(){return this._msg;
},
toString:function(){return this._comment+": "+this._msg;
},
getStackTrace:function(){return this._trace;
}}});
qx.Class.define("qx.util.Json",
{statics:{BEAUTIFYING_INDENT:"  ",
BEAUTIFYING_LINE_END:"\n",
__P:{"function":"__Q",
"boolean":"__R",
"number":"__S",
"string":"__T",
"object":"__ba",
"undefined":"__bb"},
__Q:function(a){return String(a);
},
__R:function(a){return String(a);
},
__S:function(a){return isFinite(a)?String(a):"null";
},
__T:function(a){var b;
if(/["\\\x00-\x1f]/.test(a)){b=a.replace(/([\x00-\x1f\\"])/g,
qx.util.Json.__V);
}else{b=a;
}return '"'+b+'"';
},
__U:{'\b':'\\b',
'\t':'\\t',
'\n':'\\n',
'\f':'\\f',
'\r':'\\r',
'"':'\\"',
'\\':'\\\\'},
__V:function(c,
d){var e=qx.util.Json.__U[d];
if(e){return e;
}e=d.charCodeAt();
return '\\u00'+Math.floor(e/16).toString(16)+(e%16).toString(16);
},
__W:function(a){var b=[],
c=true,
d,
e;
var f=qx.util.Json.__beautify;
b.push("[");
if(f){qx.util.Json.__indent+=qx.util.Json.BEAUTIFYING_INDENT;
b.push(qx.util.Json.__indent);
}
for(var g=0,
h=a.length;g<h;g++){e=a[g];
d=this.__P[typeof e];
if(d){e=this[d](e);
if(typeof e=="string"){if(!c){b.push(",");
if(f){b.push(qx.util.Json.__indent);
}}b.push(e);
c=false;
}}}
if(f){qx.util.Json.__indent=qx.util.Json.__indent.substring(0,
qx.util.Json.__indent.length-qx.util.Json.BEAUTIFYING_INDENT.length);
b.push(qx.util.Json.__indent);
}b.push("]");
return b.join("");
},
__X:function(a){var b=a.getUTCFullYear()+","+a.getUTCMonth()+","+a.getUTCDate()+","+a.getUTCHours()+","+a.getUTCMinutes()+","+a.getUTCSeconds()+","+a.getUTCMilliseconds();
return "new Date(Date.UTC("+b+"))";
},
__Y:function(a){var b=[],
c=true,
d,
e;
var f=qx.util.Json.__beautify;
b.push("{");
if(f){qx.util.Json.__indent+=qx.util.Json.BEAUTIFYING_INDENT;
b.push(qx.util.Json.__indent);
}
for(var g in a){e=a[g];
d=this.__P[typeof e];
if(d){e=this[d](e);
if(typeof e=="string"){if(!c){b.push(",");
if(f){b.push(qx.util.Json.__indent);
}}b.push(this.__T(g),
":",
e);
c=false;
}}}
if(f){qx.util.Json.__indent=qx.util.Json.__indent.substring(0,
qx.util.Json.__indent.length-qx.util.Json.BEAUTIFYING_INDENT.length);
b.push(qx.util.Json.__indent);
}b.push("}");
return b.join("");
},
__ba:function(a){if(a){var b=a.constructor.name;
if(a instanceof Array||b=="Array"){return this.__W(a);
}else if(a instanceof Date||b=="Date"){return this.__X(a);
}else if(a instanceof Object||b=="Object"){return this.__Y(a);
}return "";
}return "null";
},
__bb:function(a){if(qx.core.Setting.get("qx.jsonEncodeUndefined")){return "null";
}},
stringify:function(a,
b){this.__beautify=b;
this.__indent=this.BEAUTIFYING_LINE_END;
var c=this[this.__P[typeof a]](a);
if(typeof c!="string"){c=null;
}if(qx.core.Setting.get("qx.jsonDebugging")){qx.log.Logger.debug(this,
"JSON request: "+c);
}return c;
},
parse:function(a){if(/[^,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t]/.test(a.replace(/"(\\.|[^"\\])*"/g,
""))){throw new Error("Could not parse JSON string!");
}
try{return eval("("+a+")");
}catch(ex){throw new Error("Could not evaluate JSON string: "+ex.message);
}},
parseQx:function(a){if(qx.core.Setting.get("qx.jsonDebugging")){qx.log.Logger.debug(this,
"JSON response: "+a);
}var b=(a&&a.length>0)?eval('('+a+')'):null;
return b;
}},
settings:{"qx.jsonEncodeUndefined":true,
"qx.jsonDebugging":false}});
qx.Bootstrap.define("qx.lang.String",
{statics:{camelCase:function(a){return a.replace(/\-([a-z])/g,
function(b,
c){return c.toUpperCase();
});
},
hyphenate:function(a){return a.replace(/[A-Z]/g,
function(b){return ('-'+b.charAt(0).toLowerCase());
});
},
capitalize:function(a){return a.replace(/\b[a-z]/g,
function(b){return b.toUpperCase();
});
},
trimLeft:function(a){return a.replace(/^\s+/,
"");
},
trimRight:function(a){return a.replace(/\s+$/,
"");
},
trim:function(a){return a.replace(/^\s+|\s+$/g,
"");
},
startsWith:function(a,
b){return a.substring(0,
b.length)===b;
},
endsWith:function(a,
b){return a.substring(a.length-b.length,
a.length)===b;
},
pad:function(a,
b,
c){if(typeof c==="undefined"){c="0";
}var d="";
for(var e=a.length;e<b;e++){d+=c;
}return d+a;
},
firstUp:function(a){return a.charAt(0).toUpperCase()+a.substr(1);
},
firstLow:function(a){return a.charAt(0).toLowerCase()+a.substr(1);
},
contains:function(a,
b){return a.indexOf(b)!=-1;
},
format:function(a,
b){var c=a;
for(var d=0;d<b.length;d++){c=c.replace(new RegExp("%"+(d+1),
"g"),
b[d]);
}return c;
},
escapeRegexpChars:function(a){return a.replace(/([.*+?^${}()|[\]\/\\])/g,
'\\$1');
},
toArray:function(a){return a.split(/\B|\b/g);
},
stripTags:function(a){return a.replace(/<\/?[^>]+>/gi,
"");
}}});
qx.Class.define("qx.util.ColorUtil",
{statics:{REGEXP:{hex3:/^#([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
hex6:/^#([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
rgb:/^rgb\(\s*([0-9]{1,3}\.{0,1}[0-9]*)\s*,\s*([0-9]{1,3}\.{0,1}[0-9]*)\s*,\s*([0-9]{1,3}\.{0,1}[0-9]*)\s*\)$/},
SYSTEM:{activeborder:true,
activecaption:true,
appworkspace:true,
background:true,
buttonface:true,
buttonhighlight:true,
buttonshadow:true,
buttontext:true,
captiontext:true,
graytext:true,
highlight:true,
highlighttext:true,
inactiveborder:true,
inactivecaption:true,
inactivecaptiontext:true,
infobackground:true,
infotext:true,
menu:true,
menutext:true,
scrollbar:true,
threeddarkshadow:true,
threedface:true,
threedhighlight:true,
threedlightshadow:true,
threedshadow:true,
window:true,
windowframe:true,
windowtext:true},
NAMED:{black:[0,
0,
0],
silver:[192,
192,
192],
gray:[128,
128,
128],
white:[255,
255,
255],
maroon:[128,
0,
0],
red:[255,
0,
0],
purple:[128,
0,
128],
fuchsia:[255,
0,
255],
green:[0,
128,
0],
lime:[0,
255,
0],
olive:[128,
128,
0],
yellow:[255,
255,
0],
navy:[0,
0,
128],
blue:[0,
0,
255],
teal:[0,
128,
128],
aqua:[0,
255,
255],
transparent:[-1,
-1,
-1],
grey:[128,
128,
128],
magenta:[255,
0,
255],
orange:[255,
165,
0],
brown:[165,
42,
42]},
isNamedColor:function(a){return this.NAMED[a]!==undefined;
},
isSystemColor:function(a){return this.SYSTEM[a]!==undefined;
},
supportsThemes:function(){return qx.Class.isDefined("qx.theme.manager.Color");
},
isThemedColor:function(a){if(!this.supportsThemes()){return false;
}return qx.theme.manager.Color.getInstance().isDynamic(a);
},
stringToRgb:function(a){if(this.supportsThemes()&&this.isThemedColor(a)){var a=qx.theme.manager.Color.getInstance().resolveDynamic(a);
}
if(this.isNamedColor(a)){return this.NAMED[a];
}else if(this.isSystemColor(a)){throw new Error("Could not convert system colors to RGB: "+a);
}else if(this.isRgbString(a)){return this.__bc();
}else if(this.isHex3String(a)){return this.__bd();
}else if(this.isHex6String(a)){return this.__be();
}throw new Error("Could not parse color: "+a);
},
cssStringToRgb:function(a){if(this.isNamedColor(a)){return this.NAMED[a];
}else if(this.isSystemColor(a)){throw new Error("Could not convert system colors to RGB: "+a);
}else if(this.isRgbString(a)){return this.__bc();
}else if(this.isHex3String(a)){return this.__bd();
}else if(this.isHex6String(a)){return this.__be();
}throw new Error("Could not parse color: "+a);
},
stringToRgbString:function(a){return this.rgbToRgbString(this.stringToRgb(a));
},
rgbToRgbString:function(a){return "rgb("+a[0]+","+a[1]+","+a[2]+")";
},
rgbToHexString:function(a){return (qx.lang.String.pad(a[0].toString(16).toUpperCase(),
2)+qx.lang.String.pad(a[1].toString(16).toUpperCase(),
2)+qx.lang.String.pad(a[2].toString(16).toUpperCase(),
2));
},
isValid:function(a){return this.isThemedColor(a)||this.isCssString(a);
},
isCssString:function(a){return this.isSystemColor(a)||this.isNamedColor(a)||this.isHex3String(a)||this.isHex6String(a)||this.isRgbString(a);
},
isHex3String:function(a){return this.REGEXP.hex3.test(a);
},
isHex6String:function(a){return this.REGEXP.hex6.test(a);
},
isRgbString:function(a){return this.REGEXP.rgb.test(a);
},
__bc:function(){var a=parseInt(RegExp.$1,
10);
var b=parseInt(RegExp.$2,
10);
var c=parseInt(RegExp.$3,
10);
return [a,
b,
c];
},
__bd:function(){var a=parseInt(RegExp.$1,
16)*17;
var b=parseInt(RegExp.$2,
16)*17;
var c=parseInt(RegExp.$3,
16)*17;
return [a,
b,
c];
},
__be:function(){var a=(parseInt(RegExp.$1,
16)*16)+parseInt(RegExp.$2,
16);
var b=(parseInt(RegExp.$3,
16)*16)+parseInt(RegExp.$4,
16);
var c=(parseInt(RegExp.$5,
16)*16)+parseInt(RegExp.$6,
16);
return [a,
b,
c];
},
hex3StringToRgb:function(a){if(this.isHex3String(a)){return this.__bd(a);
}throw new Error("Invalid hex3 value: "+a);
},
hex6StringToRgb:function(a){if(this.isHex6String(a)){return this.__be(a);
}throw new Error("Invalid hex6 value: "+a);
},
hexStringToRgb:function(a){if(this.isHex3String(a)){return this.__bd(a);
}
if(this.isHex6String(a)){return this.__be(a);
}throw new Error("Invalid hex value: "+a);
},
rgbToHsb:function(a){var b,
c,
d;
var e=a[0];
var f=a[1];
var g=a[2];
var h=(e>f)?e:f;
if(g>h){h=g;
}var i=(e<f)?e:f;
if(g<i){i=g;
}d=h/255.0;
if(h!=0){c=(h-i)/h;
}else{c=0;
}
if(c==0){b=0;
}else{var j=(h-e)/(h-i);
var k=(h-f)/(h-i);
var l=(h-g)/(h-i);
if(e==h){b=l-k;
}else if(f==h){b=2.0+j-l;
}else{b=4.0+k-j;
}b=b/6.0;
if(b<0){b=b+1.0;
}}return [Math.round(b*360),
Math.round(c*100),
Math.round(d*100)];
},
hsbToRgb:function(a){var b,
c,
d,
e,
g;
var h=a[0]/360;
var j=a[1]/100;
var k=a[2]/100;
if(h>=1.0){h%=1.0;
}
if(j>1.0){j=1.0;
}
if(k>1.0){k=1.0;
}var l=Math.floor(255*k);
var m={};
if(j==0.0){m.red=m.green=m.blue=l;
}else{h*=6.0;
b=Math.floor(h);
c=h-b;
d=Math.floor(l*(1.0-j));
e=Math.floor(l*(1.0-(j*c)));
g=Math.floor(l*(1.0-(j*(1.0-c))));
switch(b){case 0:m.red=l;
m.green=g;
m.blue=d;
break;
case 1:m.red=e;
m.green=l;
m.blue=d;
break;
case 2:m.red=d;
m.green=l;
m.blue=g;
break;
case 3:m.red=d;
m.green=e;
m.blue=l;
break;
case 4:m.red=g;
m.green=d;
m.blue=l;
break;
case 5:m.red=l;
m.green=d;
m.blue=e;
break;
}}return m;
},
randomColor:function(){var a=Math.round(Math.random()*255);
var c=Math.round(Math.random()*255);
var d=Math.round(Math.random()*255);
return this.rgbToRgbString([a,
c,
d]);
}}});
qx.Class.define("qx.dom.Node",
{statics:{ELEMENT:1,
ATTRIBUTE:2,
TEXT:3,
CDATA_SECTION:4,
ENTITY_REFERENCE:5,
ENTITY:6,
PROCESSING_INSTRUCTION:7,
COMMENT:8,
DOCUMENT:9,
DOCUMENT_TYPE:10,
DOCUMENT_FRAGMENT:11,
NOTATION:12,
getDocument:function(a){if(this.isDocument(a)){return a;
}return a.ownerDocument||a.document||null;
},
getWindow:qx.core.Variant.select("qx.client",
{"mshtml":function(a){return this.getDocument(a).parentWindow;
},
"default":function(a){return this.getDocument(a).defaultView;
}}),
getDocumentElement:function(a){return this.getDocument(a).documentElement;
},
getBodyElement:function(a){return this.getDocument(a).body;
},
isElement:function(a){return !!(a&&a.nodeType===qx.dom.Node.ELEMENT);
},
isDocument:function(a){return !!(a&&a.nodeType===qx.dom.Node.DOCUMENT);
},
isText:function(a){return !!(a&&a.nodeType===qx.dom.Node.TEXT);
},
isWindow:function(a){return !!(typeof a==="object"&&a&&a.Array);
},
getText:function(b){if(!b||!b.nodeType){return null;
}
switch(b.nodeType){case 1:var c,
d=[],
e=b.childNodes,
f=e.length;
for(c=0;c<f;c++){d[c]=this.getText(e[c]);
}return d.join("");
case 2:return b.nodeValue;
break;
case 3:return b.nodeValue;
break;
}return null;
}}});
qx.Class.define("qx.core.Property",
{statics:{__bf:{"Boolean":'qx.core.Assert.assertBoolean(value, msg) || true',
"String":'qx.core.Assert.assertString(value, msg) || true',
"Number":'qx.core.Assert.assertNumber(value, msg) || true',
"Integer":'qx.core.Assert.assertInteger(value, msg) || true',
"PositiveNumber":'qx.core.Assert.assertPositiveNumber(value, msg) || true',
"PositiveInteger":'qx.core.Assert.assertPositiveInteger(value, msg) || true',
"Error":'qx.core.Assert.assertInstance(value, Error, msg) || true',
"RegExp":'qx.core.Assert.assertInstance(value, RegExp, msg) || true',
"Object":'qx.core.Assert.assertObject(value, msg) || true',
"Array":'qx.core.Assert.assertArray(value, msg) || true',
"Map":'qx.core.Assert.assertMap(value, msg) || true',
"Function":'qx.core.Assert.assertFunction(value, msg) || true',
"Date":'qx.core.Assert.assertInstance(value, Date, msg) || true',
"Node":'value !== null && value.nodeType !== undefined',
"Element":'value !== null && value.nodeType === 1 && value.attributes',
"Document":'value !== null && value.nodeType === 9 && value.documentElement',
"Window":'value !== null && value.document',
"Event":'value !== null && value.type !== undefined',
"Class":'value !== null && value.$$type === "Class"',
"Mixin":'value !== null && value.$$type === "Mixin"',
"Interface":'value !== null && value.$$type === "Interface"',
"Theme":'value !== null && value.$$type === "Theme"',
"Color":'(typeof value === "string" || value instanceof String) && qx.util.ColorUtil.isValid(value)',
"Decorator":'value !== null && qx.theme.manager.Decoration.getInstance().isDynamic(value)',
"Font":'value !== null && qx.theme.manager.Font.getInstance().isDynamic(value)'},
__bg:{"Object":true,
"Array":true,
"Map":true,
"Function":true,
"Date":true,
"Node":true,
"Element":true,
"Document":true,
"Window":true,
"Event":true,
"Class":true,
"Mixin":true,
"Interface":true,
"Theme":true},
$$inherit:"inherit",
$$idcounter:0,
$$store:{user:{},
theme:{},
inherit:{},
init:{},
useinit:{}},
$$method:{get:{},
set:{},
reset:{},
init:{},
refresh:{},
style:{},
unstyle:{}},
$$allowedKeys:{name:"string",
dispose:"boolean",
inheritable:"boolean",
nullable:"boolean",
themeable:"boolean",
refine:"boolean",
init:null,
apply:"string",
event:"string",
check:null,
transform:"string",
deferredInit:"boolean"},
$$allowedGroupKeys:{name:"string",
group:"object",
mode:"string",
themeable:"boolean"},
$$inheritable:{},
refresh:function(a){var b=a.getLayoutParent();
if(b){var c=a.constructor;
var d=this.$$store.inherit;
var e=this.$$store.init;
var f=this.$$method.refresh;
var g;
var h;
{if(qx.core.Setting.get("qx.propertyDebugLevel")>1){a.debug("Update widget: "+a);
}};
while(c){g=c.$$properties;
if(g){for(var i in this.$$inheritable){if(g[i]&&a[f[i]]){h=b[d[i]];
if(h===undefined){h=b[e[i]];
}{if(qx.core.Setting.get("qx.propertyDebugLevel")>2){a.debug("Updating property: "+i+" to '"+h+"'");
}};
a[f[i]](h);
}}}c=c.superclass;
}}},
attach:function(a){var b=a.$$properties;
if(b){for(var c in b){this.attachMethods(a,
c,
b[c]);
}}a.$$propertiesAttached=true;
},
attachMethods:function(a,
b,
c){c.group?this.__bh(a,
c,
b):this.__bi(a,
c,
b);
},
__bh:function(b,
c,
d){var e=qx.lang.String.firstUp(d);
var f=b.prototype;
var g=c.themeable===true;
{if(qx.core.Setting.get("qx.propertyDebugLevel")>1){qx.log.Logger.debug("Generating property group: "+d);
}};
var h=[];
var j=[];
if(g){var k=[];
var m=[];
}var n="var a=arguments[0] instanceof Array?arguments[0]:arguments;";
h.push(n);
if(g){k.push(n);
}
if(c.mode=="shorthand"){var o="a=qx.lang.Array.fromShortHand(qx.lang.Array.fromArguments(a));";
h.push(o);
if(g){k.push(o);
}}
for(var p=0,
q=c.group,
r=q.length;p<r;p++){{if(!this.$$method.set[q[p]]||!this.$$method.reset[q[p]]){throw new Error("Cannot create property group '"+d+"' including non-existing property '"+q[p]+"'!");
}};
h.push("this.",
this.$$method.set[q[p]],
"(a[",
p,
"]);");
j.push("this.",
this.$$method.reset[q[p]],
"();");
if(g){{if(!this.$$method.style[q[p]]){throw new Error("Cannot add the non themable property '"+q[p]+"' to the themable property group '"+d+"'");
}};
k.push("this.",
this.$$method.style[q[p]],
"(a[",
p,
"]);");
m.push("this.",
this.$$method.unstyle[q[p]],
"();");
}}this.$$method.set[d]="set"+e;
f[this.$$method.set[d]]=new Function(h.join(""));
this.$$method.reset[d]="reset"+e;
f[this.$$method.reset[d]]=new Function(j.join(""));
if(g){this.$$method.style[d]="style"+e;
f[this.$$method.style[d]]=new Function(k.join(""));
this.$$method.unstyle[d]="unstyle"+e;
f[this.$$method.unstyle[d]]=new Function(m.join(""));
}},
__bi:function(a,
b,
c){var d=qx.lang.String.firstUp(c);
var e=a.prototype;
{if(qx.core.Setting.get("qx.propertyDebugLevel")>1){qx.log.Logger.debug("Generating property wrappers: "+c);
}};
if(b.dispose===undefined&&typeof b.check==="string"){b.dispose=this.__bg[b.check]||qx.Class.isDefined(b.check)||qx.Interface.isDefined(b.check);
}var f=this.$$method;
var g=this.$$store;
g.user[c]="$$user_"+c;
g.theme[c]="$$theme_"+c;
g.init[c]="$$init_"+c;
g.inherit[c]="$$inherit_"+c;
g.useinit[c]="$$useinit_"+c;
f.get[c]="get"+d;
e[f.get[c]]=function(){return qx.core.Property.executeOptimizedGetter(this,
a,
c,
"get");
};
f.set[c]="set"+d;
e[f.set[c]]=function(h){return qx.core.Property.executeOptimizedSetter(this,
a,
c,
"set",
arguments);
};
f.reset[c]="reset"+d;
e[f.reset[c]]=function(){return qx.core.Property.executeOptimizedSetter(this,
a,
c,
"reset");
};
if(b.inheritable||b.apply||b.event||b.deferredInit){f.init[c]="init"+d;
e[f.init[c]]=function(h){return qx.core.Property.executeOptimizedSetter(this,
a,
c,
"init",
arguments);
};
}
if(b.inheritable){f.refresh[c]="refresh"+d;
e[f.refresh[c]]=function(h){return qx.core.Property.executeOptimizedSetter(this,
a,
c,
"refresh",
arguments);
};
}
if(b.themeable){f.style[c]="style"+d;
e[f.style[c]]=function(h){return qx.core.Property.executeOptimizedSetter(this,
a,
c,
"style",
arguments);
};
f.unstyle[c]="unstyle"+d;
e[f.unstyle[c]]=function(){return qx.core.Property.executeOptimizedSetter(this,
a,
c,
"unstyle");
};
}
if(b.check==="Boolean"){e["toggle"+d]=new Function("return this."+f.set[c]+"(!this."+f.get[c]+"())");
e["is"+d]=new Function("return this."+f.get[c]+"()");
}},
__bj:{0:'Could not change or apply init value after constructing phase!',
1:'Requires exactly one argument!',
2:'Undefined value is not allowed!',
3:'Does not allow any arguments!',
4:'Null value is not allowed!',
5:'Is invalid!'},
error:function(a,
b,
c,
d,
e){var f=a.constructor.classname;
var g="Error in property "+c+" of class "+f+" in method "+this.$$method[d][c]+" with incoming value '"+e+"': ";
throw new Error(g+(this.__bj[b]||"Unknown reason: "+b));
},
__bk:function(a,
b,
c,
d,
e,
f){var g=this.$$method[d][c];
{if(qx.core.Setting.get("qx.propertyDebugLevel")>1){qx.log.Logger.debug("Code["+this.$$method[d][c]+"]: "+e.join(""));
}try{b[g]=new Function("value",
e.join(""));
}catch(ex){alert("Malformed generated code to unwrap method: "+this.$$method[d][c]+"\n"+e.join(""));
}};
{};
if(f===undefined){return a[g]();
}else{return a[g].apply(a,
f);
}},
executeOptimizedGetter:function(a,
b,
c,
d){var e=b.$$properties[c];
var f=b.prototype;
var g=[];
var h=this.$$store;
if(e.inheritable){g.push('if(this.',
h.inherit[c],
'!==undefined)');
g.push('return this.',
h.inherit[c],
';');
g.push('else ');
}g.push('if(this.',
h.user[c],
'!==undefined)');
g.push('return this.',
h.user[c],
';');
if(e.themeable){g.push('else if(this.',
h.theme[c],
'!==undefined)');
g.push('return this.',
h.theme[c],
';');
}
if(e.deferredInit&&e.init===undefined){g.push('else if(this.',
h.init[c],
'!==undefined)');
g.push('return this.',
h.init[c],
';');
}g.push('else ');
if(e.init!==undefined){g.push('return this.',
h.init[c],
';');
}else if(e.inheritable||e.nullable){g.push('return null;');
}else{g.push('throw new Error("Property ',
c,
' of an instance of ',
b.classname,
' is not (yet) ready!");');
}return this.__bk(a,
f,
c,
d,
g);
},
executeOptimizedSetter:function(a,
b,
c,
d,
e){var f=b.$$properties[c];
var g=b.prototype;
var h=[];
var i=d==="set"||d==="style"||(d==="init"&&f.init===undefined);
var j=d==="reset"||d==="unstyle";
var k=f.apply||f.event||f.inheritable;
if(d==="style"||d==="unstyle"){var l=this.$$store.theme[c];
}else if(d==="init"){var l=this.$$store.init[c];
}else{var l=this.$$store.user[c];
}{h.push('var prop=qx.core.Property;');
if(d==="init"){h.push('if(this.$$initialized)prop.error(this,0,"',
c,
'","',
d,
'",value);');
}
if(d==="refresh"){}else if(i){h.push('if(arguments.length!==1)prop.error(this,1,"',
c,
'","',
d,
'",value);');
h.push('if(value===undefined)prop.error(this,2,"',
c,
'","',
d,
'",value);');
}else{h.push('if(arguments.length!==0)prop.error(this,3,"',
c,
'","',
d,
'",value);');
}};
if(i){if(f.transform){h.push('value=this.',
f.transform,
'(value);');
}}if(k){if(i){h.push('if(this.',
l,
'===value)return value;');
}else if(j){h.push('if(this.',
l,
'===undefined)return;');
}}if(f.inheritable){h.push('var inherit=prop.$$inherit;');
}{if(i){if(!f.nullable){h.push('if(value===null)prop.error(this,4,"',
c,
'","',
d,
'",value);');
}if(f.check!==undefined){h.push('var msg = "Invalid incoming value for property \''+c+'\' of class \''+b.classname+'\'";');
if(f.nullable){h.push('if(value!==null)');
}if(f.inheritable){h.push('if(value!==inherit)');
}h.push('if(');
if(this.__bf[f.check]!==undefined){h.push('!(',
this.__bf[f.check],
')');
}else if(qx.Class.isDefined(f.check)){h.push('qx.core.Assert.assertInstance(value, qx.Class.getByName("',
f.check,
'"), msg)');
}else if(qx.Interface&&qx.Interface.isDefined(f.check)){h.push('qx.core.Assert.assertInterface(value, qx.Interface.getByName("',
f.check,
'"), msg)');
}else if(typeof f.check==="function"){h.push('!',
b.classname,
'.$$properties.',
c);
h.push('.check.call(this, value)');
}else if(typeof f.check==="string"){h.push('!(',
f.check,
')');
}else if(f.check instanceof Array){f.checkMap=qx.lang.Object.fromArray(f.check);
h.push('qx.core.Assert.assertKeyInMap(value, ',
b.classname,
'.$$properties.',
c,
'.checkMap, msg)');
}else{throw new Error("Could not add check to property "+c+" of class "+b.classname);
}h.push(')prop.error(this,5,"',
c,
'","',
d,
'",value);');
}}};
if(!k){if(d==="set"){h.push('this.',
this.$$store.user[c],
'=value;');
}else if(d==="reset"){h.push('if(this.',
this.$$store.user[c],
'!==undefined)');
h.push('delete this.',
this.$$store.user[c],
';');
}else if(d==="style"){h.push('this.',
this.$$store.theme[c],
'=value;');
}else if(d==="unstyle"){h.push('if(this.',
this.$$store.theme[c],
'!==undefined)');
h.push('delete this.',
this.$$store.theme[c],
';');
}else if(d==="init"&&i){h.push('this.',
this.$$store.init[c],
'=value;');
}}else{if(f.inheritable){h.push('var computed, old=this.',
this.$$store.inherit[c],
';');
}else{h.push('var computed, old;');
}h.push('if(this.',
this.$$store.user[c],
'!==undefined){');
if(d==="set"){if(!f.inheritable){h.push('old=this.',
this.$$store.user[c],
';');
}h.push('computed=this.',
this.$$store.user[c],
'=value;');
}else if(d==="reset"){if(!f.inheritable){h.push('old=this.',
this.$$store.user[c],
';');
}h.push('delete this.',
this.$$store.user[c],
';');
h.push('if(this.',
this.$$store.theme[c],
'!==undefined)');
h.push('computed=this.',
this.$$store.theme[c],
';');
h.push('else if(this.',
this.$$store.init[c],
'!==undefined){');
h.push('computed=this.',
this.$$store.init[c],
';');
h.push('this.',
this.$$store.useinit[c],
'=true;');
h.push('}');
}else{if(f.inheritable){h.push('computed=this.',
this.$$store.user[c],
';');
}else{h.push('old=computed=this.',
this.$$store.user[c],
';');
}if(d==="style"){h.push('this.',
this.$$store.theme[c],
'=value;');
}else if(d==="unstyle"){h.push('delete this.',
this.$$store.theme[c],
';');
}else if(d==="init"&&i){h.push('this.',
this.$$store.init[c],
'=value;');
}}h.push('}');
if(f.themeable){h.push('else if(this.',
this.$$store.theme[c],
'!==undefined){');
if(!f.inheritable){h.push('old=this.',
this.$$store.theme[c],
';');
}
if(d==="set"){h.push('computed=this.',
this.$$store.user[c],
'=value;');
}else if(d==="style"){h.push('computed=this.',
this.$$store.theme[c],
'=value;');
}else if(d==="unstyle"){h.push('delete this.',
this.$$store.theme[c],
';');
h.push('if(this.',
this.$$store.init[c],
'!==undefined){');
h.push('computed=this.',
this.$$store.init[c],
';');
h.push('this.',
this.$$store.useinit[c],
'=true;');
h.push('}');
}else if(d==="init"){if(i){h.push('this.',
this.$$store.init[c],
'=value;');
}h.push('computed=this.',
this.$$store.theme[c],
';');
}else if(d==="refresh"){h.push('computed=this.',
this.$$store.theme[c],
';');
}h.push('}');
}h.push('else if(this.',
this.$$store.useinit[c],
'){');
if(!f.inheritable){h.push('old=this.',
this.$$store.init[c],
';');
}
if(d==="init"){if(i){h.push('computed=this.',
this.$$store.init[c],
'=value;');
}else{h.push('computed=this.',
this.$$store.init[c],
';');
}}else if(d==="set"||d==="style"||d==="refresh"){h.push('delete this.',
this.$$store.useinit[c],
';');
if(d==="set"){h.push('computed=this.',
this.$$store.user[c],
'=value;');
}else if(d==="style"){h.push('computed=this.',
this.$$store.theme[c],
'=value;');
}else if(d==="refresh"){h.push('computed=this.',
this.$$store.init[c],
';');
}}h.push('}');
if(d==="set"||d==="style"||d==="init"){h.push('else{');
if(d==="set"){h.push('computed=this.',
this.$$store.user[c],
'=value;');
}else if(d==="style"){h.push('computed=this.',
this.$$store.theme[c],
'=value;');
}else if(d==="init"){if(i){h.push('computed=this.',
this.$$store.init[c],
'=value;');
}else{h.push('computed=this.',
this.$$store.init[c],
';');
}h.push('this.',
this.$$store.useinit[c],
'=true;');
}h.push('}');
}}
if(f.inheritable){h.push('if(computed===undefined||computed===inherit){');
if(d==="refresh"){h.push('computed=value;');
}else{h.push('var pa=this.getLayoutParent();if(pa)computed=pa.',
this.$$store.inherit[c],
';');
}h.push('if((computed===undefined||computed===inherit)&&');
h.push('this.',
this.$$store.init[c],
'!==undefined&&');
h.push('this.',
this.$$store.init[c],
'!==inherit){');
h.push('computed=this.',
this.$$store.init[c],
';');
h.push('this.',
this.$$store.useinit[c],
'=true;');
h.push('}else{');
h.push('delete this.',
this.$$store.useinit[c],
';}');
h.push('}');
h.push('if(old===computed)return value;');
h.push('if(computed===inherit){');
h.push('computed=undefined;delete this.',
this.$$store.inherit[c],
';');
h.push('}');
h.push('else if(computed===undefined)');
h.push('delete this.',
this.$$store.inherit[c],
';');
h.push('else this.',
this.$$store.inherit[c],
'=computed;');
h.push('var backup=computed;');
h.push('if(old===undefined)old=null;');
h.push('if(computed===undefined)computed=null;');
}else if(k){if(d!=="set"&&d!=="style"){h.push('if(computed===undefined)computed=null;');
}h.push('if(old===computed)return value;');
h.push('if(old===undefined)old=null;');
}if(k){if(f.apply){h.push('this.',
f.apply,
'(computed, old, "',
c,
'");');
}if(f.event){h.push("reg = qx.event.Registration;",
"if(reg.hasListener(this, '",
f.event,
"')){",
"reg.fireEvent(this, '",
f.event,
"', qx.event.type.Data, [computed, old]",
")}");
}if(f.inheritable&&g._getChildren){h.push('var a=this._getChildren();if(a)for(var i=0,l=a.length;i<l;i++){');
h.push('if(a[i].',
this.$$method.refresh[c],
')a[i].',
this.$$method.refresh[c],
'(backup);');
h.push('}');
}}if(i){h.push('return value;');
}return this.__bk(a,
g,
c,
d,
h,
e);
}},
settings:{"qx.propertyDebugLevel":0}});
qx.Bootstrap.define("qx.core.ObjectRegistry",
{statics:{__bl:{},
__bm:0,
register:function(a){var b=this.__bl;
if(!b){return;
}var c=a.$$hash;
if(c==null){c=a.$$hash=(this.__bm++).toString(36);
}
if(!a.dispose){throw new Error("Invalid object: "+a);
}b[c]=a;
},
unregister:function(a){var b=a.$$hash;
if(b==null){return;
}var c=this.__bl;
if(c&&c[b]){delete c[b];
}},
toHashCode:function(a){{if(a==null){qx.log.Logger.trace(this);
throw new Error("Invalid object: "+a);
}};
if(a.$$hash!=null){return a.$$hash;
}return a.$$hash=(this.__bm++).toString(36);
},
fromHashCode:function(a){return this.__bl[a]||null;
},
shutdown:function(){var c=this.__bl;
var d=[];
for(var e in c){d.push(e);
}d.sort(function(f,
g){return parseInt(g,
36)-parseInt(f,
36);
});
var h,
j=0,
k=d.length;
while(true){try{for(;j<k;j++){e=d[j];
h=c[e];
if(h&&h.dispose){h.dispose();
}}}catch(ex){qx.log.Logger.error(this,
"Could not dispose object "+h.toString()+": "+ex);
if(j!==0){continue;
}}break;
}qx.log.Logger.debug(this,
"Disposed "+k+" objects");
delete this.__bl;
},
getRegistry:function(){return this.__bl;
}}});
qx.Class.define("qx.Mixin",
{statics:{define:function(a,
b){if(b){if(b.include&&!(b.include instanceof Array)){b.include=[b.include];
}{this.__bo(a,
b);
};
var c=b.statics?b.statics:{};
for(var d in c){c[d].mixin=c;
}if(b.construct){c.$$constructor=b.construct;
}
if(b.include){c.$$includes=b.include;
}
if(b.properties){c.$$properties=b.properties;
}
if(b.members){c.$$members=b.members;
}
for(var d in c.$$members){if(c.$$members[d] instanceof Function){c.$$members[d].mixin=c;
}}
if(b.events){c.$$events=b.events;
}
if(b.destruct){c.$$destructor=b.destruct;
}}else{var c={};
}c.$$type="Mixin";
c.name=a;
c.toString=this.genericToString;
c.basename=qx.Bootstrap.createNamespace(a,
c);
this.$$registry[a]=c;
return c;
},
checkCompatibility:function(a){var b=this.flatten(a);
var c=b.length;
if(c<2){return true;
}var d={};
var e={};
var f={};
var g;
for(var h=0;h<c;h++){g=b[h];
for(var j in g.events){if(f[j]){throw new Error('Conflict between mixin "'+g.name+'" and "'+f[j]+'" in member "'+j+'"!');
}f[j]=g.name;
}
for(var j in g.properties){if(d[j]){throw new Error('Conflict between mixin "'+g.name+'" and "'+d[j]+'" in property "'+j+'"!');
}d[j]=g.name;
}
for(var j in g.members){if(e[j]){throw new Error('Conflict between mixin "'+g.name+'" and "'+e[j]+'" in member "'+j+'"!');
}e[j]=g.name;
}}return true;
},
isCompatible:function(a,
b){var c=qx.Class.getMixins(b);
c.push(a);
return qx.Mixin.checkCompatibility(c);
},
getByName:function(a){return this.$$registry[a];
},
isDefined:function(a){return this.getByName(a)!==undefined;
},
getTotalNumber:function(){return qx.lang.Object.getLength(this.$$registry);
},
flatten:function(a){if(!a){return [];
}var b=a.concat();
for(var c=0,
d=a.length;c<d;c++){if(a[c].$$includes){b.push.apply(b,
this.flatten(a[c].$$includes));
}}return b;
},
genericToString:function(){return "[Mixin "+this.name+"]";
},
$$registry:{},
__bn:{"include":"object",
"statics":"object",
"members":"object",
"properties":"object",
"events":"object",
"destruct":"function",
"construct":"function"},
__bo:function(b,
c){var d=this.__bn;
for(var e in c){if(!d[e]){throw new Error('The configuration key "'+e+'" in mixin "'+b+'" is not allowed!');
}
if(c[e]==null){throw new Error('Invalid key "'+e+'" in mixin "'+b+'"! The value is undefined/null!');
}
if(d[e]!==null&&typeof c[e]!==d[e]){throw new Error('Invalid type of key "'+e+'" in mixin "'+b+'"! The type of the key must be "'+d[e]+'"!');
}}var f=["statics",
"members",
"properties",
"events"];
for(var g=0,
h=f.length;g<h;g++){var e=f[g];
if(c[e]!==undefined&&(c[e] instanceof Array||c[e] instanceof RegExp||c[e] instanceof Date||c[e].classname!==undefined)){throw new Error('Invalid key "'+e+'" in mixin "'+b+'"! The value needs to be a map!');
}}if(c.include){for(var g=0,
j=c.include,
h=j.length;g<h;g++){if(j[g]==null){throw new Error("Includes of mixins must be mixins. The include number '"+(g+1)+"' in mixin '"+b+"'is undefined/null!");
}
if(j[g].$$type!=="Mixin"){throw new Error("Includes of mixins must be mixins. The include number '"+(g+1)+"' in mixin '"+b+"'is not a mixin!");
}}this.checkCompatibility(c.include);
}}}});
qx.Mixin.define("qx.core.MAssert",
{members:{assert:function(a,
b){qx.core.Assert.assert(a,
b);
},
fail:function(a){qx.core.Assert.fail(a);
},
assertTrue:function(a,
b){qx.core.Assert.assertTrue(a,
b);
},
assertFalse:function(a,
b){qx.core.Assert.assertFalse(a,
b);
},
assertEquals:function(a,
b,
c){qx.core.Assert.assertEquals(a,
b,
c);
},
assertIdentical:function(a,
b,
c){qx.core.Assert.assertIdentical(a,
b,
c);
},
assertNotIdentical:function(a,
b,
c){qx.core.Assert.assertNotIdentical(a,
b,
c);
},
assertNotUndefined:function(a,
b){qx.core.Assert.assertNotUndefined(a,
b);
},
assertUndefined:function(a,
b){qx.core.Assert.assertUndefined(a,
b);
},
assertNotNull:function(a,
b){qx.core.Assert.assertNotNull(a,
b);
},
assertNull:function(a,
b){qx.core.Assert.assertNull(a,
b);
},
assertJsonEquals:function(a,
b,
c){qx.core.Assert.assertJsonEquals(a,
b,
c);
},
assertMatch:function(a,
b,
c){qx.core.Assert.assertMatch(a,
b,
c);
},
assertArgumentsCount:function(a,
b,
c,
d){qx.core.Assert.assertArgumentsCount(a,
b,
c,
d);
},
assertException:function(a,
b,
c,
d){qx.core.Assert.assertException(a,
b,
c,
d);
},
assertInArray:function(a,
b,
c){qx.core.Assert.assertInArray(a,
b,
c);
},
assertKeyInMap:function(a,
b,
c){qx.core.Assert.assertKeyInMap(a,
b,
c);
},
assertFunction:function(a,
b){qx.core.Assert.assertFunction(a,
b);
},
assertString:function(a,
b){qx.core.Assert.assertString(a,
b);
},
assertBoolean:function(a,
b){qx.core.Assert.assertBoolean(a,
b);
},
assertNumber:function(a,
b){qx.core.Assert.assertNumber(a,
b);
},
assertPositiveNumber:function(a,
b){qx.core.Assert.assertPositiveNumber(a,
b);
},
assertInteger:function(a,
b){qx.core.Assert.assertInteger(a,
b);
},
assertPositiveInteger:function(a,
b){qx.core.Assert.assertPositiveInteger(a,
b);
},
assertInRange:function(a,
b,
c,
d){qx.core.Assert.assertInRange(a,
b,
c,
d);
},
assertObject:function(a,
b){qx.core.Assert.assertObject(a,
b);
},
assertArray:function(a,
b){qx.core.Assert.assertArray(a,
b);
},
assertMap:function(a,
b){qx.core.Assert.assertMap(a,
b);
},
assertType:function(a,
b,
c){qx.core.Assert.assertType(a,
b,
c);
},
assertInstance:function(a,
b,
c){qx.core.Assert.assertInstance(a,
b,
c);
},
assertInterface:function(a,
b,
c){qx.core.Assert.assertInterface(a,
b,
c);
},
assertCssColor:function(a,
b,
c){qx.core.Assert.assertCssColor(a,
b,
c);
},
assertElement:function(a,
b){qx.core.Assert.assertElement(a,
b);
},
assertQxObject:function(a,
b){qx.core.Assert.assertQxObject(a,
b);
},
assertQxWidget:function(a,
b){qx.core.Assert.assertQxWidget(a,
b);
}}});
qx.Bootstrap.define("qx.bom.Event",
{statics:{addNativeListener:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b,
c){a.attachEvent("on"+b,
c);
},
"default":function(a,
b,
c){a.addEventListener(b,
c,
false);
}}),
removeNativeListener:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b,
c){a.detachEvent("on"+b,
c);
},
"default":function(a,
b,
c){a.removeEventListener(b,
c,
false);
}}),
getTarget:function(a){return a.target||a.srcElement;
},
getRelatedTarget:qx.core.Variant.select("qx.client",
{"mshtml":function(a){if(a.type==="mouseover"){return a.fromEvent;
}else{return a.toElement;
}},
"default":function(a){return a.relatedTarget;
}}),
preventDefault:function(a){if(a.preventDefault){a.preventDefault();
}
try{a.keyCode=0;
}catch(a){}a.returnValue=false;
},
stopPropagation:function(a){if(a.stopPropagation){a.stopPropagation();
}a.cancelBubble=true;
}}});
qx.Bootstrap.define("qx.event.Manager",
{construct:function(a){this.__window=a;
this.__disposeWrapper=qx.lang.Function.bind(this.dispose,
this);
qx.bom.Event.addNativeListener(a,
"unload",
this.__disposeWrapper);
this.__listeners={};
this.__handlers={};
this.__dispatchers={};
this.__handlerCache={};
},
members:{dispose:function(){qx.bom.Event.removeNativeListener(this.__window,
"unload",
this.__disposeWrapper);
qx.event.Registration.removeManager(this);
this.__listeners=this.__window=this.__handlers=this.__dispatchers=this.__disposeWrapper=this.__handlerCache=null;
},
getWindow:function(){return this.__window;
},
getHandler:function(a){var b=this.__handlers[a.classname];
if(b){return b;
}return this.__handlers[a.classname]=new a(this);
},
getDispatcher:function(a){var b=this.__dispatchers[a.classname];
if(b){return b;
}return this.__dispatchers[a.classname]=new a(this);
},
getListeners:function(a,
b,
c){var d=qx.core.ObjectRegistry.toHashCode(a);
var e=this.__listeners[d];
if(!e){return null;
}var f=b+(c?"|capture":"|bubble");
var g=e[f];
return g?g.concat():null;
},
hasListener:function(a,
b,
c){{if(a==null){qx.log.Logger.trace(this);
throw new Error("Invalid object: "+a);
}};
var d=qx.core.ObjectRegistry.toHashCode(a);
var e=this.__listeners[d];
if(!e){return false;
}var f=b+(c?"|capture":"|bubble");
var g=e[f];
if(!g){return false;
}return g.length>0;
},
importListeners:function(a,
b){{if(a==null){qx.log.Logger.trace(this);
throw new Error("Invalid object: "+a);
}};
var c=qx.core.ObjectRegistry.toHashCode(a);
var d=this.__listeners[c]={};
for(var e in b){var f=b[e];
var g=f.type+(f.capture?"|capture":"|bubble");
var h=d[g];
if(!h){h=d[g]=[];
this.__bp(a,
f.type,
f.capture);
}h.push({handler:f.listener,
context:f.self});
}},
addListener:function(a,
b,
c,
d,
e){{var f="Failed to add event listener for type '"+b+"'"+" to the target '"+a+"': ";
qx.core.Assert.assertObject(a,
f+"Invalid Target.");
qx.core.Assert.assertString(b,
f+"Invalid event type.");
qx.core.Assert.assertFunction(c,
f+"Invalid callback function");
if(d!==undefined){qx.core.Assert.assertObject(d,
"Invalid context for callback.");
}
if(e!==undefined){qx.core.Assert.assertBoolean(e,
"Invalid capture falg.");
}};
var g=qx.core.ObjectRegistry.toHashCode(a);
var h=this.__listeners[g];
if(!h){h=this.__listeners[g]={};
}var i=b+(e?"|capture":"|bubble");
var j=h[i];
if(!j){j=h[i]=[];
}if(j.length===0){this.__bp(a,
b,
e);
}j.push({handler:c,
context:d});
},
_findHandler:function(a,
b){var c;
var d=false;
var e=false;
var f=false;
if(a.nodeType===1){d=true;
c="DOM_"+a.tagName.toLowerCase()+"_"+b;
}else if(a==this.__window){e=true;
c="WIN_"+b;
}else if(a.classname){f=true;
c="QX_"+a.classname+"_"+b;
}else{c="UNKNOWN_"+a+"_"+b;
}var g=this.__handlerCache;
if(g[c]){return g[c];
}var h=qx.event.Registration.getHandlers();
var j;
for(var k=0,
m=h.length;k<m;k++){var n=h[k];
var o=n.SUPPORTED_TYPES;
if(o&&!o[b]){continue;
}var p=qx.event.IEventHandler;
var q=n.TARGET_CHECK;
if(q){if(q===p.TARGET_DOMNODE&&!d){continue;
}else if(q===p.TARGET_WINDOW&&!e){continue;
}else if(q===p.TARGET_OBJECT&&!f){continue;
}}j=this.getHandler(h[k]);
if(n.IGNORE_CAN_HANDLE||j.canHandleEvent(a,
b)){g[c]=j;
return j;
}}return null;
},
__bp:function(a,
b,
c){var d=this._findHandler(a,
b);
if(d){d.registerEvent(a,
b,
c);
return;
}{qx.log.Logger.warn(this,
"There is no event handler for the event '"+b+"' on target '"+a+"'!");
};
},
removeListener:function(a,
b,
c,
d,
e){{var f="Failed to dd event listener for type '"+b+"'"+" to the target '"+a+"': ";
qx.core.Assert.assertObject(a,
f+"Invalid Target.");
qx.core.Assert.assertString(b,
f+"Invalid event type.");
qx.core.Assert.assertFunction(c,
f+"Invalid callback function");
if(d!==undefined){qx.core.Assert.assertObject(d,
"Invalid context for callback.");
}
if(e!==undefined){qx.core.Assert.assertBoolean(e,
"Invalid capture falg.");
}};
var g=qx.core.ObjectRegistry.toHashCode(a);
var h=this.__listeners[g];
if(!h){return false;
}var j=b+(e?"|capture":"|bubble");
var k=h[j];
if(!k){return false;
}
for(var m=0,
n=k.length;m<n;m++){var o=k[m];
if(o.handler===c&&o.context===d){qx.lang.Array.removeAt(k,
m);
if(k.length==0){this.__bq(a,
b,
e);
}return true;
}}return false;
},
removeAllListeners:function(a){var b=qx.core.ObjectRegistry.toHashCode(a);
var c=this.__listeners[b];
if(!c){return false;
}var d,
e,
f;
for(var g in c){if(c[g].length>0){d=g.split('|');
e=d[0];
f=d[1]==="capture";
this.__bq(a,
e,
f);
}}delete this.__listeners[b];
return true;
},
__bq:function(a,
b,
c){var d=this._findHandler(a,
b);
if(d){d.unregisterEvent(a,
b,
c);
return;
}{qx.log.Logger.warn(this,
"There is no event handler for the event '"+b+"' on target '"+a+"'!");
};
},
dispatchEvent:function(a,
b){{var c="Could not dispatch event '"+b+"' on target '"+a+"': ";
qx.core.Assert.assertNotUndefined(a,
c+"Invalid event target.");
qx.core.Assert.assertInstance(b,
qx.event.type.Event,
c+"Invalid event object.");
};
var d=b.getType();
if(!b.getBubbles()&&!this.hasListener(a,
d)){qx.event.Pool.getInstance().poolObject(b);
return true;
}
if(!b.getTarget()){b.setTarget(a);
}var e=qx.event.Registration.getDispatchers();
var f;
var g=false;
for(var h=0,
j=e.length;h<j;h++){f=this.getDispatcher(e[h]);
if(f.canDispatchEvent(a,
b,
d)){f.dispatchEvent(a,
b,
d);
g=true;
break;
}}
if(!g){qx.log.Logger.error(this,
"No dispatcher can handle event of type "+d+" on "+a);
return true;
}var k=b.getDefaultPrevented();
qx.event.Pool.getInstance().poolObject(b);
return !k;
}}});
qx.Bootstrap.define("qx.lang.Function",
{statics:{getCaller:function(a){return a.caller?a.caller.callee:a.callee.caller;
},
getName:function(a){if(a.$$original){return a.classname+":constructor wrapper";
}
if(a.wrapper){return a.wrapper.classname+":constructor";
}
if(a.classname){return a.classname+":constructor";
}
if(a.mixin){for(var b in a.mixin.$$members){if(a.mixin.$$members[b]==a){return a.mixin.name+":"+b;
}}for(var b in a.mixin){if(a.mixin[b]==a){return a.mixin.name+":"+b;
}}}
if(a.self){var c=a.self.constructor;
if(c){for(var b in c.prototype){if(c.prototype[b]==a){return c.classname+":"+b;
}}for(var b in c){if(c[b]==a){return c.classname+":"+b;
}}}}var d=a.toString().match(/(function\s*\w*\(.*?\))/);
if(d&&d.length>=1&&d[1]){return d[1];
}var d=a.toString().match(/(function\s*\(.*?\))/);
if(d&&d.length>=1&&d[1]){return "anonymous: "+d[1];
}return 'anonymous';
},
globalEval:function(a){if(window.execScript){return window.execScript(a);
}else{return eval.call(window,
a);
}},
returnTrue:function(){return true;
},
returnFalse:function(){return false;
},
returnNull:function(){return null;
},
returnThis:function(){return this;
},
returnZero:function(){return 0;
},
create:function(a,
b){{qx.core.Assert.assertFunction(a,
"Invalid parameter 'func'.");
};
if(!b){return a;
}if(!(b.self||b.args||b.delay!=null||b.periodical!=null||b.attempt)){return a;
}return function(c){var d=qx.lang.Array.fromArguments(arguments);
if(b.args){d=b.args.concat(d);
}
if(b.delay||b.periodical){var e=function(){return a.apply(b.self||this,
d);
};
if(b.delay){return setTimeout(e,
b.delay);
}
if(b.periodical){return setInterval(e,
b.periodical);
}}else if(b.attempt){var f=false;
try{f=a.apply(b.self||this,
d);
}catch(ex){}return f;
}else{return a.apply(b.self||this,
d);
}};
},
bind:function(a,
b,
c){return this.create(a,
{self:b,
args:c!==undefined?qx.lang.Array.fromArguments(arguments,
2):null});
},
curry:function(a,
b){return this.create(a,
{args:b!==undefined?qx.lang.Array.fromArguments(arguments,
1):null});
},
listener:function(a,
b,
c){if(c===undefined){return function(d){return a.call(b||this,
d||window.event);
};
}else{var e=qx.lang.Array.fromArguments(arguments,
2);
return function(d){var f=[d||window.event];
f.push.apply(f,
e);
a.apply(b||this,
f);
};
}},
attempt:function(a,
b,
c){return this.create(a,
{self:b,
attempt:true,
args:c!==undefined?qx.lang.Array.fromArguments(arguments,
2):null})();
},
delay:function(a,
b,
c,
d){return this.create(a,
{delay:b,
self:c,
args:d!==undefined?qx.lang.Array.fromArguments(arguments,
3):null})();
},
periodical:function(a,
b,
c,
d){return this.create(a,
{periodical:b,
self:c,
args:d!==undefined?qx.lang.Array.fromArguments(arguments,
3):null})();
}}});
qx.Bootstrap.define("qx.event.Registration",
{statics:{__br:{},
getManager:function(a){if(qx.dom.Node.isWindow(a)){var b=a;
}else if(qx.dom.Node.isElement(a)){var b=qx.dom.Node.getWindow(a);
}else{var b=window;
}var c=qx.core.ObjectRegistry.toHashCode(b);
var d=this.__br[c];
if(!d){d=new qx.event.Manager(b);
this.__br[c]=d;
}return d;
},
removeManager:function(a){var b=qx.core.ObjectRegistry.toHashCode(a.getWindow());
delete this.__br[b];
},
addListener:function(a,
b,
c,
d,
e){this.getManager(a).addListener(a,
b,
c,
d,
e);
},
removeListener:function(a,
b,
c,
d,
e){this.getManager(a).removeListener(a,
b,
c,
d,
e);
},
removeAllListeners:function(a){this.getManager(a).removeAllListeners(a);
},
hasListener:function(a,
b,
c){return this.getManager(a).hasListener(a,
b,
c);
},
createEvent:function(a,
b,
c){{if(arguments.length>1&&b===undefined){throw new Error("Create event of type "+a+" with undefined class. Please use null to explicit fallback to default event type!");
}};
if(b==null){b=qx.event.type.Event;
}var d=qx.event.Pool.getInstance().getObject(b);
if(!d){return;
}c?d.init.apply(d,
c):d.init();
if(a){d.setType(a);
}return d;
},
dispatchEvent:function(a,
b){return this.getManager(a).dispatchEvent(a,
b);
},
fireEvent:function(a,
b,
c,
d){{if(arguments.length>2&&c===undefined&&d!==undefined){throw new Error("Create event of type "+b+" with undefined class. Please use null to explicit fallback to default event type!");
}};
var e=this.createEvent(b,
c||null,
d);
return this.getManager(a).dispatchEvent(a,
e);
},
fireNonBubblingEvent:function(a,
b,
c,
d){{if(arguments.length>2&&c===undefined&&d!==undefined){throw new Error("Create event of type "+b+" with undefined class. Please use null to explicit fallback to default event type!");
}};
var e=this.getManager(a);
if(!e.hasListener(a,
b,
false)){return true;
}var f=this.createEvent(b,
c||null,
d);
return e.dispatchEvent(a,
f);
},
PRIORITY_FIRST:-32000,
PRIORITY_NORMAL:0,
PRIORITY_LAST:32000,
__bs:[],
addHandler:function(c){{qx.core.Assert.assertInterface(c,
qx.event.IEventHandler,
"Invalid event handler.");
};
this.__bs.push(c);
this.__bs.sort(function(d,
e){return d.PRIORITY-e.PRIORITY;
});
},
getHandlers:function(){return this.__bs;
},
__bt:[],
addDispatcher:function(c,
d){{qx.core.Assert.assertInterface(c,
qx.event.IEventDispatcher,
"Invalid event dispatcher!");
};
this.__bt.push(c);
this.__bt.sort(function(e,
f){return e.PRIORITY-f.PRIORITY;
});
},
getDispatchers:function(){return this.__bt;
}}});
qx.Class.define("qx.core.Object",
{extend:Object,
construct:function(){qx.core.ObjectRegistry.register(this);
},
statics:{$$type:"Object"},
members:{toHashCode:function(){return this.$$hash;
},
toString:function(){return this.classname+"["+this.$$hash+"]";
},
base:function(a,
b){if(arguments.length===1){return a.callee.base.call(this);
}else{return a.callee.base.apply(this,
Array.prototype.slice.call(arguments,
1));
}},
self:function(a){return a.callee.self;
},
clone:function(){var a=this.constructor;
var b=new a;
var c=qx.Class.getProperties(a);
var d=qx.core.Property.$$store.user;
var e=qx.core.Property.$$method.set;
var f;
for(var g=0,
h=c.length;g<h;g++){f=c[g];
if(this.hasOwnProperty(d[f])){b[e[f]](this[d[f]]);
}}return b;
},
serialize:function(){var a=this.constructor;
var b=qx.Class.getProperties(a);
var c=qx.core.Property.$$store.user;
var d=qx.core.Property.$$method.set;
var e;
var f={classname:a.classname,
properties:{}};
for(var g=0,
h=b.length;g<h;g++){e=b[g];
if(this.hasOwnProperty(c[e])){value=this[c[e]];
if(value instanceof qx.core.Object){f.properties[e]={$$hash:value.$$hash};
}else{f.properties[e]=value;
}}}return f;
},
set:function(a,
b){var c=qx.core.Property.$$method.set;
if(typeof a==="string"){{if(!this[c[a]]){this.warn("No such property: "+a);
return this;
}};
return this[c[a]](b);
}else{for(var d in a){{if(!this[c[d]]){this.warn("No such property: "+d);
continue;
}};
this[c[d]](a[d]);
}return this;
}},
get:function(a){var b=qx.core.Property.$$method.get;
{if(!this[b[a]]){this.warn("No such property: "+a);
return;
}};
return this[b[a]]();
},
reset:function(a){var b=qx.core.Property.$$method.reset;
{if(!this[b[a]]){this.warn("No such property: "+a);
return;
}};
this[b[a]]();
},
__bu:qx.event.Registration,
addListener:function(a,
b,
c,
d){if(!this.$$disposed){this.__bu.addListener(this,
a,
b,
c,
d);
}},
addListenerOnce:function(a,
b,
c,
d){var f=function(g){b.call(c||this,
g);
this.removeListener(a,
f,
this,
d);
};
this.addListener(a,
f,
this,
d);
},
removeListener:function(a,
b,
c,
d){if(!this.$$disposed){this.__bu.removeListener(this,
a,
b,
c,
d);
}},
hasListener:function(a,
b){return this.__bu.hasListener(this,
a,
b);
},
dispatchEvent:function(a){if(!this.$$disposed){return this.__bu.dispatchEvent(this,
a);
}return true;
},
fireEvent:function(a,
b,
c){if(!this.$$disposed){return this.__bu.fireEvent(this,
a,
b,
c);
}return true;
},
fireNonBubblingEvent:function(a,
b,
c){if(!this.$$disposed){return this.__bu.fireNonBubblingEvent(this,
a,
b,
c);
}return true;
},
fireDataEvent:function(a,
b,
c,
d){if(!this.$$disposed){return this.__bu.fireNonBubblingEvent(this,
a,
qx.event.type.Data,
[b,
c||null,
!!d]);
}return true;
},
setUserData:function(a,
b){if(!this.__userData){this.__userData={};
}this.__userData[a]=b;
},
getUserData:function(a){if(!this.__userData){return null;
}return this.__userData[a];
},
__bv:qx.log.Logger,
debug:function(a){this.__bv.debug(this,
a);
},
info:function(a){this.__bv.info(this,
a);
},
warn:function(a){this.__bv.warn(this,
a);
},
error:function(a){this.__bv.error(this,
a);
},
trace:function(){this.__bv.trace(this);
},
isDisposed:function(){return this.$$disposed||false;
},
dispose:function(){if(this.$$disposed){return;
}this.$$disposed=true;
{if(qx.core.Setting.get("qx.disposerDebugLevel")>1){qx.log.Logger.debug(this,
"Disposing "+this.classname+"["+this.toHashCode()+"]");
}};
var a=this.constructor;
var b;
while(a.superclass){if(a.$$destructor){a.$$destructor.call(this);
}if(a.$$includes){b=a.$$flatIncludes;
for(var c=0,
d=b.length;c<d;c++){if(b[c].$$destructor){b[c].$$destructor.call(this);
}}}a=a.superclass;
}{if(qx.core.Setting.get("qx.disposerDebugLevel")>0){var e,
f;
for(e in this){f=this[e];
if(f!==null&&typeof f==="object"){if(this.constructor.prototype[e]!=null){continue;
}qx.log.Logger.warn(this,
"Missing destruct definition for '"+e+"' in "+this.classname+"["+this.toHashCode()+"]: "+f);
delete this[e];
}}}};
},
_disposeFields:function(a){qx.util.DisposeUtil.disposeFields(this,
arguments);
},
_disposeObjects:function(a){qx.util.DisposeUtil.disposeObjects(this,
arguments);
},
_disposeArray:function(a){qx.util.DisposeUtil.disposeArray(this,
a);
},
_disposeMap:function(a){qx.util.DisposeUtil.disposeMap(this,
a);
}},
settings:{"qx.disposerDebugLevel":0},
defer:function(a){{qx.Class.include(a,
qx.core.MAssert);
};
},
destruct:function(){qx.event.Registration.removeAllListeners(this);
qx.core.ObjectRegistry.unregister(this);
this._disposeFields("__userData");
var a=this.constructor;
var b;
var c=qx.core.Property.$$store;
var d=c.user;
var e=c.theme;
var f=c.inherit;
var g=c.useinit;
var h=c.init;
while(a){b=a.$$properties;
if(b){for(var i in b){if(b[i].dispose){this[d[i]]=this[e[i]]=this[f[i]]=this[g[i]]=this[h[i]]=undefined;
}}}a=a.superclass;
}}});
qx.Class.define("qx.event.type.Event",
{extend:qx.core.Object,
statics:{CAPTURING_PHASE:1,
AT_TARGET:2,
BUBBLING_PHASE:3},
members:{init:function(a,
b){{if(a!==undefined){qx.core.Assert.assertBoolean(a,
"Invalid argument value 'canBubble'.");
}
if(b!==undefined){qx.core.Assert.assertBoolean(b,
"Invalid argument value 'cancelable'.");
}};
this._type=null;
this._target=null;
this._currentTarget=null;
this._relatedTarget=null;
this._originalTarget=null;
this._stopPropagation=false;
this._preventDefault=false;
this._bubbles=!!a;
this._cancelable=!!b;
this._timeStamp=(new Date()).getTime();
this._eventPhase=null;
return this;
},
clone:function(a){if(a){var b=a;
}else{var b=qx.event.Pool.getInstance().getObject(this.constructor);
}b._type=this._type;
b._target=this._target;
b._currentTarget=this._currentTarget;
b._relatedTarget=this._relatedTarget;
b._originalTarget=this._originalTarget;
b._stopPropagation=this._stopPropagation;
b._bubbles=this._bubbles;
b._preventDefault=this._preventDefault;
b._cancelable=this._cancelable;
return b;
},
stopPropagation:function(){{this.assertTrue(this._bubbles,
"Cannot stop propagation on a non bubbling event: "+this.getType());
};
this._stopPropagation=true;
},
getPropagationStopped:function(){return !!this._stopPropagation;
},
preventDefault:function(){{this.assertTrue(this._cancelable,
"Cannot prevent default action on a non cancelable event: "+this.getType());
};
this._preventDefault=true;
},
getDefaultPrevented:function(){return !!this._preventDefault;
},
getType:function(){return this._type;
},
setType:function(a){this._type=a;
},
getEventPhase:function(){return this._eventPhase;
},
setEventPhase:function(a){this._eventPhase=a;
},
getTimeStamp:function(){return this._timeStamp;
},
getTarget:function(){return this._target;
},
setTarget:function(a){this._target=a;
},
getCurrentTarget:function(){return this._currentTarget||this._target;
},
setCurrentTarget:function(a){this._currentTarget=a;
},
getRelatedTarget:function(){return this._relatedTarget;
},
setRelatedTarget:function(a){this._relatedTarget=a;
},
getOriginalTarget:function(){return this._originalTarget;
},
setOriginalTarget:function(a){this._originalTarget=a;
},
getBubbles:function(){return this._bubbles;
},
setBubbles:function(a){this._bubbles=a;
},
isCancelable:function(){return this._cancelable;
},
setCancelable:function(a){this._cancelable=a;
}},
destruct:function(){this._disposeFields("_target",
"_currentTarget",
"_relatedTarget",
"_originalTarget");
}});
qx.Class.define("qx.event.type.Data",
{extend:qx.event.type.Event,
members:{init:function(a,
b,
c){arguments.callee.base.call(this,
false,
c);
this.__data=a;
this.__old=b;
return this;
},
clone:function(a){var b=arguments.callee.base.call(this,
a);
b.__data=this.__data;
b.__old=this.__old;
return b;
},
getData:function(){return this.__data;
},
getOldData:function(){return this.__old;
},
getValue:function(){qx.log.Logger.deprecatedMethodWarning(arguments.callee,
"Better use 'getData'");
return this.__data;
},
getOldValue:function(){qx.log.Logger.deprecatedMethodWarning(arguments.callee,
"Better use 'getOldData'");
return this.__old;
}},
destruct:function(){this._disposeFields("__data",
"__old");
}});
qx.Class.define("qx.Interface",
{statics:{define:function(a,
b){if(b){if(b.extend&&!(b.extend instanceof Array)){b.extend=[b.extend];
}{this.__by(a,
b);
};
var c=b.statics?b.statics:{};
if(b.extend){c.$$extends=b.extend;
}
if(b.properties){c.$$properties=b.properties;
}
if(b.members){c.$$members=b.members;
}
if(b.events){c.$$events=b.events;
}}else{var c={};
}c.$$type="Interface";
c.name=a;
c.toString=this.genericToString;
c.basename=qx.Bootstrap.createNamespace(a,
c);
qx.Interface.$$registry[a]=c;
return c;
},
getByName:function(a){return this.$$registry[a];
},
isDefined:function(a){return this.getByName(a)!==undefined;
},
getTotalNumber:function(){return qx.lang.Object.getLength(this.$$registry);
},
flatten:function(a){if(!a){return [];
}var b=a.concat();
for(var c=0,
d=a.length;c<d;c++){if(a[c].$$extends){b.push.apply(b,
this.flatten(a[c].$$extends));
}}return b;
},
assert:function(a,
b,
c){var d=b.$$members;
if(d){var e=a.prototype;
for(var f in d){if(typeof d[f]==="function"){if(typeof e[f]==="function"){if(c===true&&!qx.Class.hasInterface(a,
b)){e[f]=this.__bw(b,
e[f],
f,
d[f]);
}}else{var g=f.match(/^(get|set|reset)(.*)$/);
if(!g||!qx.Class.hasProperty(a,
qx.lang.String.firstLow(g[2]))){throw new Error('Implementation of method "'+f+'" is missing in class "'+a.classname+'" required by interface "'+b.name+'"');
}}}else{if(typeof e[f]===undefined){if(typeof e[f]!=="function"){throw new Error('Implementation of member "'+f+'" is missing in class "'+a.classname+'" required by interface "'+b.name+'"');
}}}}}if(b.$$properties){for(var f in b.$$properties){if(!qx.Class.hasProperty(a,
f)){throw new Error('The property "'+f+'" is not supported by Class "'+a.classname+'"!');
}}}if(b.$$events){for(var f in b.$$events){if(!qx.Class.supportsEvent(a,
f)){throw new Error('The event "'+f+'" is not supported by Class "'+a.classname+'"!');
}}}var h=b.$$extends;
if(h){for(var j=0,
k=h.length;j<k;j++){this.assert(a,
h[j],
c);
}}},
genericToString:function(){return "[Interface "+this.name+"]";
},
$$registry:{},
__bw:function(a,
b,
c,
d){function e(){d.apply(this,
arguments);
return b.apply(this,
arguments);
}b.wrapper=e;
return e;
},
__bx:{"extend":"object",
"statics":"object",
"members":"object",
"properties":"object",
"events":"object"},
__by:function(b,
c){{var d=this.__bx;
for(var e in c){if(d[e]===undefined){throw new Error('The configuration key "'+e+'" in class "'+b+'" is not allowed!');
}
if(c[e]==null){throw new Error("Invalid key '"+e+"' in interface '"+b+"'! The value is undefined/null!");
}
if(d[e]!==null&&typeof c[e]!==d[e]){throw new Error('Invalid type of key "'+e+'" in interface "'+b+'"! The type of the key must be "'+d[e]+'"!');
}}var f=["statics",
"members",
"properties",
"events"];
for(var g=0,
h=f.length;g<h;g++){var e=f[g];
if(c[e]!==undefined&&(c[e] instanceof Array||c[e] instanceof RegExp||c[e] instanceof Date||c[e].classname!==undefined)){throw new Error('Invalid key "'+e+'" in interface "'+b+'"! The value needs to be a map!');
}}if(c.extend){for(var g=0,
j=c.extend,
h=j.length;g<h;g++){if(j[g]==null){throw new Error("Extends of interfaces must be interfaces. The extend number '"+g+1+"' in interface '"+b+"' is undefined/null!");
}
if(j[g].$$type!=="Interface"){throw new Error("Extends of interfaces must be interfaces. The extend number '"+g+1+"' in interface '"+b+"' is not an interface!");
}}}if(c.statics){for(var e in c.statics){if(e.toUpperCase()!==e){throw new Error('Invalid key "'+e+'" in interface "'+b+'"! Static constants must be all uppercase.');
}
switch(typeof c.statics[e]){case "boolean":case "string":case "number":break;
default:throw new Error('Invalid key "'+e+'" in interface "'+b+'"! Static constants must be all of a primitive type.');
}}}};
}}});
qx.Interface.define("qx.event.IEventHandler",
{statics:{TARGET_DOMNODE:1,
TARGET_WINDOW:2,
TARGET_OBJECT:3},
members:{canHandleEvent:function(a,
b){},
registerEvent:function(a,
b,
c){},
unregisterEvent:function(a,
b,
c){}}});
qx.Class.define("qx.event.handler.Application",
{extend:qx.core.Object,
implement:qx.event.IEventHandler,
construct:function(a){arguments.callee.base.call(this);
this._window=a.getWindow();
this._initObserver();
qx.event.handler.Application.$$instance=this;
},
statics:{PRIORITY:qx.event.Registration.PRIORITY_NORMAL,
SUPPORTED_TYPES:{ready:1,
shutdown:1},
TARGET_CHECK:qx.event.IEventHandler.TARGET_WINDOW,
IGNORE_CAN_HANDLE:true,
ready:function(){var a=qx.event.handler.Application.$$instance;
if(a){a.__bz();
}}},
members:{canHandleEvent:function(a,
b){},
registerEvent:function(a,
b,
c){},
unregisterEvent:function(a,
b,
c){},
__bz:function(){if(!this.__isReady){this.__isReady=true;
qx.event.Registration.fireEvent(window,
"ready");
}},
_initObserver:function(){this._onNativeLoadWrapped=qx.lang.Function.bind(this._onNativeLoad,
this);
this._onNativeUnloadWrapped=qx.lang.Function.bind(this._onNativeUnload,
this);
qx.bom.Event.addNativeListener(window,
"load",
this._onNativeLoadWrapped);
qx.bom.Event.addNativeListener(window,
"unload",
this._onNativeUnloadWrapped);
},
_stopObserver:function(){qx.bom.Event.removeNativeListener(window,
"load",
this._onNativeLoadWrapped);
qx.bom.Event.removeNativeListener(window,
"unload",
this._onNativeUnloadWrapped);
this._onNativeLoadWrapped=null;
this._onNativeUnloadWrapped=null;
},
_onNativeLoad:function(a){if(!window.qxloader){this.__bz();
}},
_onNativeUnload:function(a){if(!this.__isUnloaded){this.__isUnloaded=true;
qx.event.Registration.fireEvent(window,
"shutdown");
qx.core.ObjectRegistry.shutdown();
}}},
destruct:function(){this._stopObserver();
this._disposeFields("_window");
},
defer:function(a){qx.event.Registration.addHandler(a);
}});
qx.Class.define("qx.util.ObjectPool",
{extend:qx.core.Object,
construct:function(a){arguments.callee.base.call(this);
this.__pool={};
if(a!==undefined){this.setSize(a);
}},
properties:{size:{check:"Integer",
init:null,
nullable:true}},
members:{getObject:function(a){if(this.$$disposed){return;
}
if(!a){throw new Error("Class needs to be defined!");
}var b=null;
var c=this.__pool[a.classname];
if(c){b=c.pop();
}
if(b){b.$$pooled=false;
}else{b=new a;
}return b;
},
poolObject:function(a){var b=a.classname;
var c=this.__pool[b];
if(a.$$pooled){throw new Error("Object is already pooled: "+a);
}
if(!c){this.__pool[b]=c=[];
}var d=this.getSize()||Infinity;
if(c.length>d){this.warn("Cannot pool "+a+" because the pool is already full.");
a.dispose();
return;
}a.$$pooled=true;
c.push(a);
}},
destruct:function(){var a=this.__pool;
var b,
c,
d,
e;
for(b in a){c=a[b];
for(d=0,
e=c.length;d<e;d++){c[d].dispose();
}}delete this.__pool;
}});
qx.Class.define("qx.event.Pool",
{extend:qx.util.ObjectPool,
type:"singleton",
construct:function(){arguments.callee.base.call(this,
30);
},
members:{__bA:{"qx.legacy.event.type.DragEvent":1,
"qx.legacy.event.type.MouseEvent":1,
"qx.legacy.event.type.KeyEvent":1},
poolObject:function(a){if(this.__bA[a.classname]){return;
}arguments.callee.base.call(this,
a);
}}});
qx.Interface.define("qx.event.IEventDispatcher",
{members:{canDispatchEvent:function(a,
b,
c){this.assertInstance(b,
qx.event.type.Event);
this.assertString(c);
},
dispatchEvent:function(a,
b,
c){this.assertInstance(b,
qx.event.type.Event);
this.assertString(c);
}}});
qx.Class.define("qx.event.dispatch.Direct",
{extend:qx.core.Object,
implement:qx.event.IEventDispatcher,
construct:function(a){this._manager=a;
},
statics:{PRIORITY:qx.event.Registration.PRIORITY_LAST},
members:{canDispatchEvent:function(a,
b,
c){return !b.getBubbles();
},
dispatchEvent:function(a,
b,
c){b.setEventPhase(qx.event.type.Event.AT_TARGET);
var d=this._manager.getListeners(a,
c,
false);
if(d){for(var e=0,
f=d.length;e<f;e++){var g=d[e].context||a;
d[e].handler.call(g,
b);
}}}},
defer:function(a){qx.event.Registration.addDispatcher(a);
}});
qx.Class.define("qx.event.handler.Object",
{extend:qx.core.Object,
implement:qx.event.IEventHandler,
statics:{PRIORITY:qx.event.Registration.PRIORITY_LAST,
SUPPORTED_TYPES:null,
TARGET_CHECK:qx.event.IEventHandler.TARGET_OBJECT,
IGNORE_CAN_HANDLE:false},
members:{canHandleEvent:function(a,
b){return qx.Class.supportsEvent(a.constructor,
b);
},
registerEvent:function(a,
b,
c){},
unregisterEvent:function(a,
b,
c){}},
defer:function(a){qx.event.Registration.addHandler(a);
}});
qx.Class.define("qx.util.DisposeUtil",
{statics:{disposeFields:function(a,
b){var c;
for(var d=0,
e=b.length;d<e;d++){var c=b[d];
if(a[c]==null||!a.hasOwnProperty(c)){continue;
}a[c]=null;
}},
disposeObjects:function(a,
b){var c;
for(var d=0,
e=b.length;d<e;d++){var c=b[d];
if(a[c]==null||!this.hasOwnProperty(c)){continue;
}a[c].dispose();
a[c]=null;
}},
disposeArray:function(a,
b){var c=a[b];
if(!c){return;
}try{var d;
for(var e=c.length-1;e>=0;e--){d=c[e];
if(d){d.dispose();
}}}catch(ex){throw new Error("The array field: "+b+" of object: "+a+" has non disposable entries: "+ex);
}c.length=0;
a[b]=null;
},
disposeMap:function(a,
b){var c=a[b];
if(!c){return;
}try{for(var d in c){if(c.hasOwnProperty(d)){c[d].dispose();
}}}catch(ex){throw new Error("The map field: "+b+" of object: "+a+" has non disposable entries: "+ex);
}a[b]=null;
}}});
qx.Interface.define("qx.ui.form.IFormElement",
{events:{"changeValue":"qx.event.type.Data",
"changeName":"qx.event.type.Data",
"changeEnabled":"qx.event.type.Data"},
members:{setEnabled:function(a){this.assertType(a,
"boolean");
},
getEnabled:function(){},
setName:function(a){this.assertType(a,
"string");
},
getName:function(){},
setValue:function(a){this.assertType(a,
"string");
},
getValue:function(){}}});
qx.Class.define("qx.ui.form.RadioGroup",
{extend:qx.core.Object,
implement:qx.ui.form.IFormElement,
construct:function(a){arguments.callee.base.call(this);
this.__items=[];
if(a!=null){this.add.apply(this,
arguments);
}this.addListener("changeSelected",
this._onChangeSelected);
},
properties:{enabled:{check:"Boolean",
apply:"_applyEnabled",
event:"changeEnabled"},
selected:{nullable:true,
apply:"_applySelected",
event:"changeSelected",
check:"qx.ui.form.IRadioItem"},
name:{check:"String",
nullable:true,
apply:"_applyName",
event:"changeName"},
wrap:{check:"Boolean",
init:true}},
events:{"changeValue":"qx.event.type.Data"},
members:{getItems:function(){return this.__items;
},
select:function(a){this.setSelected(a);
},
setValue:function(a){var b=this.__items;
var c;
for(var d=0,
e=b.length;d<e;d++){c=b[d];
if(c.getValue()==a){this.setSelected(c);
break;
}}},
getValue:function(){var a=this.getSelected();
return a?a.getValue():null;
},
add:function(a){var b=this.__items;
var c;
for(var d=0,
e=arguments.length;d<e;d++){c=arguments[d];
if(c.getGroup()===this){continue;
}c.addListener("changeChecked",
this._onItemChangeChecked,
this);
b.push(c);
c.setGroup(this);
if(c.getChecked()){this.setSelected(c);
}}if(b.length>0&&!this.getSelected()){this.setSelected(b[0]);
}},
remove:function(a){if(a.getGroup()===this){qx.lang.Array.remove(this.__items,
a);
a.resetGroup();
a.removeListener("changeChecked",
this._onItemChangeChecked,
this);
if(a.getChecked()){this.resetSelected();
}}},
_onItemChangeChecked:function(a){var b=a.getTarget();
if(b.getChecked()){this.setSelected(b);
}else if(this.getSelected()==b){this.resetSelected();
}},
_onChangeSelected:function(a){var b=a.getData();
var c=null;
if(b){c=b.getValue();
if(c==null){c=b.getLabel();
}}this.fireDataEvent("changeValue",
c);
},
_applySelected:function(a,
b){if(b){b.setChecked(false);
}
if(a){a.setChecked(true);
if(b&&b.hasState("focused")){a.focus();
}}var c=b?b.getValue():null;
var d=a?a.getValue():null;
if(c!=d){this.fireNonBubblingEvent("changeValue",
qx.event.type.Data,
[d,
c]);
}},
_applyEnabled:function(a,
b){var c=this.__items;
if(a==null){for(var d=0,
e=c.length;d<e;d++){c[d].resetEnabled();
}}else{for(var d=0,
e=c.length;d<e;d++){c[d].setEnabled(true);
}}},
_applyName:function(a,
b){var c=this.__items;
if(a==null){for(var d=0,
e=c.length;d<e;d++){c[d].resetName();
}}else{for(var d=0,
e=c.length;d<e;d++){c[d].setName(a);
}}},
selectNext:function(a){var b=this.__items;
var c=b.indexOf(a);
if(c==-1){return;
}var d=0;
var e=b.length;
if(this.getWrap()){c=(c+1)%e;
}else{c=Math.min(c+1,
e-1);
}
while(d<e&&!b[c].getEnabled()){c=(c+1)%e;
d++;
}this.setSelected(b[c]);
},
selectPrevious:function(a){var b=this.__items;
var c=b.indexOf(a);
if(c==-1){return;
}var d=0;
var e=b.length;
if(this.getWrap()){c=(c-1+e)%e;
}else{c=Math.max(c-1,
0);
}
while(d<e&&!b[c].getEnabled()){c=(c-1+e)%e;
d++;
}this.setSelected(b[c]);
}},
destruct:function(){this._disposeArray("__items");
}});
qx.Class.define("qx.bom.String",
{statics:{TO_CHARCODE:{"quot":34,
"amp":38,
"lt":60,
"gt":62,
"nbsp":160,
"iexcl":161,
"cent":162,
"pound":163,
"curren":164,
"yen":165,
"brvbar":166,
"sect":167,
"uml":168,
"copy":169,
"ordf":170,
"laquo":171,
"not":172,
"shy":173,
"reg":174,
"macr":175,
"deg":176,
"plusmn":177,
"sup2":178,
"sup3":179,
"acute":180,
"micro":181,
"para":182,
"middot":183,
"cedil":184,
"sup1":185,
"ordm":186,
"raquo":187,
"frac14":188,
"frac12":189,
"frac34":190,
"iquest":191,
"Agrave":192,
"Aacute":193,
"Acirc":194,
"Atilde":195,
"Auml":196,
"Aring":197,
"AElig":198,
"Ccedil":199,
"Egrave":200,
"Eacute":201,
"Ecirc":202,
"Euml":203,
"Igrave":204,
"Iacute":205,
"Icirc":206,
"Iuml":207,
"ETH":208,
"Ntilde":209,
"Ograve":210,
"Oacute":211,
"Ocirc":212,
"Otilde":213,
"Ouml":214,
"times":215,
"Oslash":216,
"Ugrave":217,
"Uacute":218,
"Ucirc":219,
"Uuml":220,
"Yacute":221,
"THORN":222,
"szlig":223,
"agrave":224,
"aacute":225,
"acirc":226,
"atilde":227,
"auml":228,
"aring":229,
"aelig":230,
"ccedil":231,
"egrave":232,
"eacute":233,
"ecirc":234,
"euml":235,
"igrave":236,
"iacute":237,
"icirc":238,
"iuml":239,
"eth":240,
"ntilde":241,
"ograve":242,
"oacute":243,
"ocirc":244,
"otilde":245,
"ouml":246,
"divide":247,
"oslash":248,
"ugrave":249,
"uacute":250,
"ucirc":251,
"uuml":252,
"yacute":253,
"thorn":254,
"yuml":255,
"fnof":402,
"Alpha":913,
"Beta":914,
"Gamma":915,
"Delta":916,
"Epsilon":917,
"Zeta":918,
"Eta":919,
"Theta":920,
"Iota":921,
"Kappa":922,
"Lambda":923,
"Mu":924,
"Nu":925,
"Xi":926,
"Omicron":927,
"Pi":928,
"Rho":929,
"Sigma":931,
"Tau":932,
"Upsilon":933,
"Phi":934,
"Chi":935,
"Psi":936,
"Omega":937,
"alpha":945,
"beta":946,
"gamma":947,
"delta":948,
"epsilon":949,
"zeta":950,
"eta":951,
"theta":952,
"iota":953,
"kappa":954,
"lambda":955,
"mu":956,
"nu":957,
"xi":958,
"omicron":959,
"pi":960,
"rho":961,
"sigmaf":962,
"sigma":963,
"tau":964,
"upsilon":965,
"phi":966,
"chi":967,
"psi":968,
"omega":969,
"thetasym":977,
"upsih":978,
"piv":982,
"bull":8226,
"hellip":8230,
"prime":8242,
"Prime":8243,
"oline":8254,
"frasl":8260,
"weierp":8472,
"image":8465,
"real":8476,
"trade":8482,
"alefsym":8501,
"larr":8592,
"uarr":8593,
"rarr":8594,
"darr":8595,
"harr":8596,
"crarr":8629,
"lArr":8656,
"uArr":8657,
"rArr":8658,
"dArr":8659,
"hArr":8660,
"forall":8704,
"part":8706,
"exist":8707,
"empty":8709,
"nabla":8711,
"isin":8712,
"notin":8713,
"ni":8715,
"prod":8719,
"sum":8721,
"minus":8722,
"lowast":8727,
"radic":8730,
"prop":8733,
"infin":8734,
"ang":8736,
"and":8743,
"or":8744,
"cap":8745,
"cup":8746,
"int":8747,
"there4":8756,
"sim":8764,
"cong":8773,
"asymp":8776,
"ne":8800,
"equiv":8801,
"le":8804,
"ge":8805,
"sub":8834,
"sup":8835,
"sube":8838,
"supe":8839,
"oplus":8853,
"otimes":8855,
"perp":8869,
"sdot":8901,
"lceil":8968,
"rceil":8969,
"lfloor":8970,
"rfloor":8971,
"lang":9001,
"rang":9002,
"loz":9674,
"spades":9824,
"clubs":9827,
"hearts":9829,
"diams":9830,
"OElig":338,
"oelig":339,
"Scaron":352,
"scaron":353,
"Yuml":376,
"circ":710,
"tilde":732,
"ensp":8194,
"emsp":8195,
"thinsp":8201,
"zwnj":8204,
"zwj":8205,
"lrm":8206,
"rlm":8207,
"ndash":8211,
"mdash":8212,
"lsquo":8216,
"rsquo":8217,
"sbquo":8218,
"ldquo":8220,
"rdquo":8221,
"bdquo":8222,
"dagger":8224,
"Dagger":8225,
"permil":8240,
"lsaquo":8249,
"rsaquo":8250,
"euro":8364},
escape:function(a){return qx.util.StringEscape.escape(a,
qx.bom.String.FROM_CHARCODE);
},
unescape:function(a){return qx.util.StringEscape.unescape(a,
qx.bom.String.TO_CHARCODE);
},
fromText:function(a){return qx.bom.String.escape(a).replace(/(  |\n)/g,
function(b){var c={"  ":" &nbsp;",
"\n":"<br>"};
return c[b]||b;
});
},
toText:function(a){return qx.bom.String.unescape(a.replace(/\s+|<([^>])+>/gi,
function(b){if(/\s+/.test(b)){return " ";
}else if(/^<BR|^<br/gi.test(b)){return "\n";
}else{return "";
}}));
}},
defer:function(a,
b,
c){a.FROM_CHARCODE=qx.lang.Object.invert(a.TO_CHARCODE);
}});
qx.Bootstrap.define("qx.util.StringEscape",
{statics:{escape:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b){var c,
d=[];
for(var e=0,
f=a.length;e<f;e++){var g=a.charAt(e);
var h=g.charCodeAt(0);
if(b[h]){c="&"+b[h]+";";
}else{if(h>0x7F){c="&#"+h+";";
}else{c=g;
}}d[d.length]=c;
}return d.join("");
},
"default":function(a,
b){var c,
d="";
for(var e=0,
f=a.length;e<f;e++){var g=a.charAt(e);
var h=g.charCodeAt(0);
if(b[h]){c="&"+b[h]+";";
}else{if(h>0x7F){c="&#"+h+";";
}else{c=g;
}}d+=c;
}return d;
}}),
unescape:function(a,
b){return a.replace(/&[#\w]+;/gi,
function(c){var d=c;
var c=c.substring(1,
c.length-1);
var e=b[c];
if(e){d=String.fromCharCode(e);
}else{if(c.charAt(0)=='#'){if(c.charAt(1).toUpperCase()=='X'){e=c.substring(2);
if(e.match(/^[0-9A-Fa-f]+$/gi)){d=String.fromCharCode(parseInt(e,
16));
}}else{e=c.substring(1);
if(e.match(/^\d+$/gi)){d=String.fromCharCode(parseInt(e,
10));
}}}}return d;
});
}}});
qx.Interface.define("qx.util.format.IFormat",
{members:{format:function(a){},
parse:function(a){}}});
qx.Class.define("qx.util.format.NumberFormat",
{extend:qx.core.Object,
implement:qx.util.format.IFormat,
construct:function(a){arguments.callee.base.call(this);
this._locale=a;
},
statics:{getIntegerInstance:function(){var a=qx.util.format.NumberFormat;
if(a._integerInstance==null){a._integerInstance=new a();
a._integerInstance.setMaximumFractionDigits(0);
}return a._integerInstance;
},
getInstance:function(){if(!this._instance){this._instance=new this;
}return this._instance;
}},
properties:{minimumIntegerDigits:{check:"Number",
init:0},
maximumIntegerDigits:{check:"Number",
nullable:true},
minimumFractionDigits:{check:"Number",
init:0},
maximumFractionDigits:{check:"Number",
nullable:true},
groupingUsed:{check:"Boolean",
init:true},
prefix:{check:"String",
init:""},
postfix:{check:"String",
init:""}},
members:{format:function(a){switch(a){case Infinity:return "Infinity";
case -Infinity:return "-Infinity";
case NaN:return "NaN";
}var b=(a<0);
if(b){a=-a;
}
if(this.getMaximumFractionDigits()!=null){var c=Math.pow(10,
this.getMaximumFractionDigits());
a=Math.round(a*c)/c;
}var d=String(Math.floor(a)).length;
var e=""+a;
var f=e.substring(0,
d);
while(f.length<this.getMinimumIntegerDigits()){f="0"+f;
}
if(this.getMaximumIntegerDigits()!=null&&f.length>this.getMaximumIntegerDigits()){f=f.substring(f.length-this.getMaximumIntegerDigits());
}var g=e.substring(d+1);
while(g.length<this.getMinimumFractionDigits()){g+="0";
}
if(this.getMaximumFractionDigits()!=null&&g.length>this.getMaximumFractionDigits()){g=g.substring(0,
this.getMaximumFractionDigits());
}if(this.getGroupingUsed()){var h=f;
f="";
var i;
for(i=h.length;i>3;i-=3){f=""+qx.locale.Number.getGroupSeparator(this._locale)+h.substring(i-3,
i)+f;
}f=h.substring(0,
i)+f;
}var j=this.getPrefix()?this.getPrefix():"";
var k=this.getPostfix()?this.getPostfix():"";
var l=j+(b?"-":"")+f;
if(g.length>0){l+=""+qx.locale.Number.getDecimalSeparator(this._locale)+g;
}l+=k;
return l;
},
parse:function(a){var b=qx.lang.String.escapeRegexpChars(qx.locale.Number.getGroupSeparator(this._locale)+"");
var c=qx.lang.String.escapeRegexpChars(qx.locale.Number.getDecimalSeparator(this._locale)+"");
var d=new RegExp("^"+qx.lang.String.escapeRegexpChars(this.getPrefix())+'([-+]){0,1}'+'([0-9]{1,3}(?:'+b+'{0,1}[0-9]{3}){0,})'+'('+c+'\\d+){0,1}'+qx.lang.String.escapeRegexpChars(this.getPostfix())+"$");
var e=d.exec(a);
if(e==null){throw new Error("Number string '"+a+"' does not match the number format");
}var f=(e[1]=="-");
var g=e[2];
var h=e[3];
g=g.replace(new RegExp(b,
"g"),
"");
var i=(f?"-":"")+g;
if(h!=null&&h.length!=0){h=h.replace(new RegExp(c),
"");
i+="."+h;
}return parseFloat(i);
}}});
qx.Class.define("qx.locale.Number",
{statics:{getDecimalSeparator:function(a){return qx.locale.Manager.getInstance().translate("cldr_number_decimal_separator",
[],
a);
},
getGroupSeparator:function(a){return qx.locale.Manager.getInstance().translate("cldr_number_group_separator",
[],
a);
},
getPercentFormat:function(a){return qx.locale.Manager.getInstance().translate("cldr_number_percent_format",
[],
a);
}}});
qx.Bootstrap.define("qx.bom.client.Locale",
{statics:{LOCALE:"",
VARIANT:"",
__bB:function(){var a=(qx.bom.client.Engine.MSHTML?navigator.userLanguage:navigator.language).toLowerCase();
var b="";
var c=a.indexOf("-");
if(c!=-1){b=a.substr(c+1);
a=a.substr(0,
c);
}this.LOCALE=a;
this.VARIANT=b;
}},
defer:function(a){a.__bB();
}});
qx.Class.define("qx.lang.BaseString",
{extend:String,
construct:function(a){{this.assertType(a,
"string",
"Invalid argument 'txt'.");
};
this._txt=a;
},
members:{toString:function(){return this._txt;
},
valueOf:function(){return this._txt;
},
toHashCode:function(){return qx.core.ObjectRegistry.toHashCode(this);
},
base:function(a,
b){return qx.core.Object.prototype.base.apply(this,
arguments);
}},
defer:function(a){{qx.Class.include(a,
qx.core.MAssert);
};
}});
qx.Class.define("qx.locale.LocalizedString",
{extend:qx.lang.BaseString,
construct:function(a,
b,
c){arguments.callee.base.call(this,
a);
this.__messageId=b;
this.__args=c;
},
members:{translate:function(){return qx.locale.Manager.getInstance().translate(this.__messageId,
this.__args);
}}});
qx.Class.define("qx.locale.Manager",
{type:"singleton",
extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
this._translationCatalog=window.qxlocales||{};
var a=qx.bom.client.Locale;
var b=a.LOCALE;
var c=a.VARIANT;
if(c!==""){b+="_"+c;
}this.setLocale(b||this._defaultLocale);
},
statics:{tr:function(a,
b){var c=qx.lang.Array.fromArguments(arguments);
c.splice(0,
1);
return qx.locale.Manager.getInstance().translate(a,
c);
},
trn:function(a,
b,
c,
d){var e=qx.lang.Array.fromArguments(arguments);
e.splice(0,
3);
if(c!=1){return qx.locale.Manager.getInstance().translate(b,
e);
}else{return qx.locale.Manager.getInstance().translate(a,
e);
}},
trc:function(a,
b,
c){var d=qx.lang.Array.fromArguments(arguments);
d.splice(0,
2);
return qx.locale.Manager.getInstance().translate(b,
d);
},
marktr:function(a){return a;
}},
properties:{locale:{check:"String",
nullable:true,
apply:"_applyLocale",
event:"changeLocale"}},
members:{_defaultLocale:"C",
getLanguage:function(){return this._language;
},
getTerritory:function(){return this.getLocale().split("_")[1]||"";
},
getAvailableLocales:function(){var a=[];
for(var b in this._translationCatalog){if(b!=this._defaultLocale){a.push(b);
}}return a;
},
__bC:function(a){var b;
var c=a.indexOf("_");
if(c==-1){b=a;
}else{b=a.substring(0,
c);
}return b;
},
_applyLocale:function(a,
b){this._locale=a;
this._language=this.__bC(a);
},
addTranslation:function(a,
b){if(this._translationCatalog[a]){for(var c in b){this._translationCatalog[a][c]=b[c];
}}else{this._translationCatalog[a]=b;
}},
translate:function(a,
b,
c){var d;
if(c){var e=this.__bC(c);
}else{c=this._locale;
e=this._language;
}
if(!d&&this._translationCatalog[c]){d=this._translationCatalog[c][a];
}
if(!d&&this._translationCatalog[e]){d=this._translationCatalog[e][a];
}
if(!d&&this._translationCatalog[this._defaultLocale]){d=this._translationCatalog[this._defaultLocale][a];
}
if(!d){d=a;
}
if(b.length>0){var f=[];
for(var g=0;g<b.length;g++){var h=b[g];
if(h.translate){f[g]=h.translate();
}else{f[g]=h;
}}d=qx.lang.String.format(d,
f);
}
if(qx.core.Variant.isSet("qx.dynamicLocaleSwitch",
"on")){d=new qx.locale.LocalizedString(d,
a,
b);
}return d;
}},
destruct:function(){this._disposeFields("_translationCatalog");
}});
qx.Class.define("qx.util.format.DateFormat",
{extend:qx.core.Object,
implement:qx.util.format.IFormat,
construct:function(a,
b){arguments.callee.base.call(this);
if(!b){this._locale=qx.locale.Manager.getInstance().getLocale();
}else{this._locale=b;
}
if(a!=null){this._format=a.toString();
}else{this._format=qx.locale.Date.getDateFormat("long",
this._locale)+" "+qx.locale.Date.getDateTimeFormat("HHmmss",
"HH:mm:ss",
this._locale);
}},
statics:{getDateTimeInstance:function(){var a=qx.util.format.DateFormat;
var b=qx.locale.Date.getDateFormat("long")+" "+qx.locale.Date.getDateTimeFormat("HHmmss",
"HH:mm:ss");
if(a._dateInstance==null||a._format!=b){a._dateTimeInstance=new a();
}return a._dateTimeInstance;
},
getDateInstance:function(){var a=qx.util.format.DateFormat;
var b=qx.locale.Date.getDateFormat("short")+"";
if(a._dateInstance==null||a._format!=b){a._dateInstance=new a(b);
}return a._dateInstance;
},
ASSUME_YEAR_2000_THRESHOLD:30,
LOGGING_DATE_TIME_FORMAT:"yyyy-MM-dd HH:mm:ss",
AM_MARKER:"am",
PM_MARKER:"pm",
MEDIUM_TIMEZONE_NAMES:["GMT"],
FULL_TIMEZONE_NAMES:["Greenwich Mean Time"]},
members:{__bD:function(a,
b){var c=""+a;
while(c.length<b){c="0"+c;
}return c;
},
__bE:function(a){var b=new Date(a.getTime());
var c=b.getDate();
while(b.getMonth()!=0){b.setDate(-1);
c+=b.getDate()+1;
}return c;
},
__bF:function(a){return new Date(a.getTime()+(3-((a.getDay()+6)%7))*86400000);
},
__bG:function(a){var b=this.__bF(a);
var c=b.getFullYear();
var d=this.__bF(new Date(c,
0,
4));
return Math.floor(1.5+(b.getTime()-d.getTime())/86400000/7);
},
format:function(a){var b=qx.util.format.DateFormat;
var c=this._locale;
var d=a.getFullYear();
var e=a.getMonth();
var f=a.getDate();
var g=a.getDay();
var h=a.getHours();
var j=a.getMinutes();
var k=a.getSeconds();
var l=a.getMilliseconds();
var m=a.getTimezoneOffset()/60;
this.__bH();
var n="";
for(var o=0;o<this.__formatTree.length;o++){var p=this.__formatTree[o];
if(p.type=="literal"){n+=p.text;
}else{var q=p.character;
var r=p.size;
var s="?";
switch(q){case 'y':if(r==2){s=this.__bD(d%100,
2);
}else if(r==4){s=d;
}break;
case 'D':s=this.__bD(this.__bE(a),
r);
break;
case 'd':s=this.__bD(f,
r);
break;
case 'w':s=this.__bD(this.__bG(a),
r);
break;
case 'E':if(r==2){s=qx.locale.Date.getDayName("narrow",
g,
c);
}else if(r==3){s=qx.locale.Date.getDayName("abbreviated",
g,
c);
}else if(r==4){s=qx.locale.Date.getDayName("wide",
g,
c);
}break;
case 'M':if(r==1||r==2){s=this.__bD(e+1,
r);
}else if(r==3){s=qx.locale.Date.getMonthName("abbreviated",
e,
c);
}else if(r==4){s=qx.locale.Date.getMonthName("wide",
e,
c);
}break;
case 'a':s=(h<12)?qx.locale.Date.getAmMarker(c):qx.locale.Date.getPmMarker(c);
break;
case 'H':s=this.__bD(h,
r);
break;
case 'k':s=this.__bD((h==0)?24:h,
r);
break;
case 'K':s=this.__bD(h%12,
r);
break;
case 'h':s=this.__bD(((h%12)==0)?12:(h%12),
r);
break;
case 'm':s=this.__bD(j,
r);
break;
case 's':s=this.__bD(k,
r);
break;
case 'S':s=this.__bD(l,
r);
break;
case 'z':if(r==1){s="GMT"+((m<0)?"-":"+")+this.__bD(m)+":00";
}else if(r==2){s=b.MEDIUM_TIMEZONE_NAMES[m];
}else if(r==3){s=b.FULL_TIMEZONE_NAMES[m];
}break;
case 'Z':s=((m<0)?"-":"+")+this.__bD(m,
2)+"00";
}n+=s;
}}return n;
},
parse:function(a){this.__bI();
var b=this._parseFeed.regex.exec(a);
if(b==null){throw new Error("Date string '"+a+"' does not match the date format: "+this._format);
}var c={year:1970,
month:0,
day:1,
hour:0,
ispm:false,
min:0,
sec:0,
ms:0};
var d=1;
for(var e=0;e<this._parseFeed.usedRules.length;e++){var f=this._parseFeed.usedRules[e];
var g=b[d];
if(f.field!=null){c[f.field]=parseInt(g,
10);
}else{f.manipulator(c,
g);
}d+=(f.groups==null)?1:f.groups;
}var h=new Date(c.year,
c.month,
c.day,
(c.ispm)?(c.hour+12):c.hour,
c.min,
c.sec,
c.ms);
if(c.month!=h.getMonth()||c.year!=h.getFullYear()){throw new Error("Error parsing date '"+a+"': the value for day or month is too large");
}return h;
},
__bH:function(){if(this.__formatTree!=null){return;
}this.__formatTree=[];
var a;
var b=0;
var c="";
var d=this._format;
var e="default";
var f=0;
while(f<d.length){var g=d.charAt(f);
switch(e){case "quoted_literal":if(g=="'"){if(f+1>=d.length){f++;
break;
}var h=d.charAt(f+1);
if(h=="'"){c+=g;
f++;
}else{f++;
e="unkown";
}}else{c+=g;
f++;
}break;
case "wildcard":if(g==a){b++;
f++;
}else{this.__formatTree.push({type:"wildcard",
character:a,
size:b});
a=null;
b=0;
e="default";
}break;
default:if((g>='a'&&g<='z')||(g>='A'&&g<='Z')){a=g;
e="wildcard";
}else if(g=="'"){if(f+1>=d.length){c+=g;
f++;
break;
}var h=d.charAt(f+1);
if(h=="'"){c+=g;
f++;
}f++;
e="quoted_literal";
}else{e="default";
}
if(e!="default"){if(c.length>0){this.__formatTree.push({type:"literal",
text:c});
c="";
}}else{c+=g;
f++;
}break;
}}if(a!=null){this.__formatTree.push({type:"wildcard",
character:a,
size:b});
}else if(c.length>0){this.__formatTree.push({type:"literal",
text:c});
}},
__bI:function(){if(this._parseFeed!=null){return ;
}var a=this._format;
this.__bJ();
this.__bH();
var b=[];
var c="^";
for(var d=0;d<this.__formatTree.length;d++){var e=this.__formatTree[d];
if(e.type=="literal"){c+=qx.lang.String.escapeRegexpChars(e.text);
}else{var f=e.character;
var g=e.size;
var h;
for(var j=0;j<this._parseRules.length;j++){var k=this._parseRules[j];
if(f==k.pattern.charAt(0)&&g==k.pattern.length){h=k;
break;
}}if(h==null){var l="";
for(var m=0;m<g;m++){l+=f;
}throw new Error("Malformed date format: "+a+". Wildcard "+l+" is not supported");
}else{b.push(h);
c+=h.regex;
}}}c+="$";
var n;
try{n=new RegExp(c);
}catch(exc){throw new Error("Malformed date format: "+a);
}this._parseFeed={regex:n,
"usedRules":b,
pattern:c};
},
__bJ:function(){var a=qx.util.format.DateFormat;
if(this._parseRules!=null){return ;
}this._parseRules=[];
var b=function(c,
d){d=parseInt(d,
10);
if(d<a.ASSUME_YEAR_2000_THRESHOLD){d+=2000;
}else if(d<100){d+=1900;
}c.year=d;
};
var e=function(c,
d){c.month=parseInt(d,
10)-1;
};
var f=function(c,
d){c.ispm=(d==a.PM_MARKER);
};
var g=function(c,
d){c.hour=parseInt(d,
10)%24;
};
var h=function(c,
d){c.hour=parseInt(d,
10)%12;
};
var j=function(c,
d){return;
};
var k=qx.locale.Date.getMonthNames("abbreviated",
this._locale);
for(var l=0;l<k.length;l++){k[l]=qx.lang.String.escapeRegexpChars(k[l].toString());
}var m=function(c,
d){d=qx.lang.String.escapeRegexpChars(d);
c.month=k.indexOf(d);
};
var n=qx.locale.Date.getMonthNames("wide",
this._locale);
for(var l=0;l<n.length;l++){n[l]=qx.lang.String.escapeRegexpChars(n[l].toString());
}var o=function(c,
d){d=qx.lang.String.escapeRegexpChars(d);
c.month=n.indexOf(d);
};
var p=qx.locale.Date.getDayNames("narrow",
this._locale);
for(var l=0;l<p.length;l++){p[l]=qx.lang.String.escapeRegexpChars(p[l].toString());
}var q=function(c,
d){d=qx.lang.String.escapeRegexpChars(d);
c.month=p.indexOf(d);
};
var r=qx.locale.Date.getDayNames("abbreviated",
this._locale);
for(var l=0;l<r.length;l++){r[l]=qx.lang.String.escapeRegexpChars(r[l].toString());
}var s=function(c,
d){d=qx.lang.String.escapeRegexpChars(d);
c.month=r.indexOf(d);
};
var t=qx.locale.Date.getDayNames("wide",
this._locale);
for(var l=0;l<t.length;l++){t[l]=qx.lang.String.escapeRegexpChars(t[l].toString());
}var u=function(c,
d){d=qx.lang.String.escapeRegexpChars(d);
c.month=t.indexOf(d);
};
this._parseRules.push({pattern:"yyyy",
regex:"(\\d\\d(\\d\\d)?)",
groups:2,
manipulator:b});
this._parseRules.push({pattern:"yy",
regex:"(\\d\\d)",
manipulator:b});
this._parseRules.push({pattern:"M",
regex:"(\\d\\d?)",
manipulator:e});
this._parseRules.push({pattern:"MM",
regex:"(\\d\\d?)",
manipulator:e});
this._parseRules.push({pattern:"MMM",
regex:"("+k.join("|")+")",
manipulator:m});
this._parseRules.push({pattern:"MMMM",
regex:"("+n.join("|")+")",
manipulator:o});
this._parseRules.push({pattern:"dd",
regex:"(\\d\\d?)",
field:"day"});
this._parseRules.push({pattern:"d",
regex:"(\\d\\d?)",
field:"day"});
this._parseRules.push({pattern:"EE",
regex:"("+p.join("|")+")",
manipulator:q});
this._parseRules.push({pattern:"EEE",
regex:"("+r.join("|")+")",
manipulator:s});
this._parseRules.push({pattern:"EEEE",
regex:"("+t.join("|")+")",
manipulator:u});
this._parseRules.push({pattern:"a",
regex:"("+a.AM_MARKER+"|"+a.PM_MARKER+")",
manipulator:f});
this._parseRules.push({pattern:"HH",
regex:"(\\d\\d?)",
field:"hour"});
this._parseRules.push({pattern:"H",
regex:"(\\d\\d?)",
field:"hour"});
this._parseRules.push({pattern:"kk",
regex:"(\\d\\d?)",
manipulator:g});
this._parseRules.push({pattern:"k",
regex:"(\\d\\d?)",
manipulator:g});
this._parseRules.push({pattern:"KK",
regex:"(\\d\\d?)",
field:"hour"});
this._parseRules.push({pattern:"K",
regex:"(\\d\\d?)",
field:"hour"});
this._parseRules.push({pattern:"hh",
regex:"(\\d\\d?)",
manipulator:h});
this._parseRules.push({pattern:"h",
regex:"(\\d\\d?)",
manipulator:h});
this._parseRules.push({pattern:"mm",
regex:"(\\d\\d?)",
field:"min"});
this._parseRules.push({pattern:"m",
regex:"(\\d\\d?)",
field:"min"});
this._parseRules.push({pattern:"ss",
regex:"(\\d\\d?)",
field:"sec"});
this._parseRules.push({pattern:"s",
regex:"(\\d\\d?)",
field:"sec"});
this._parseRules.push({pattern:"SSS",
regex:"(\\d\\d?\\d?)",
field:"ms"});
this._parseRules.push({pattern:"SS",
regex:"(\\d\\d?\\d?)",
field:"ms"});
this._parseRules.push({pattern:"S",
regex:"(\\d\\d?\\d?)",
field:"ms"});
this._parseRules.push({pattern:"Z",
regex:"((\\+|\\-)\\d\\d:?\\d\\d)",
manipulator:j});
this._parseRules.push({pattern:"z",
regex:"([a-zA-Z]+)",
manipulator:j});
}},
destruct:function(){this._disposeFields("_format",
"_locale",
"__formatTree",
"_parseFeed",
"_parseRules");
}});
qx.Class.define("qx.locale.Date",
{statics:{__bK:qx.locale.Manager.getInstance(),
getAmMarker:function(a){return this.__bK.translate("cldr_am",
[],
a);
},
getPmMarker:function(a){return this.__bK.translate("cldr_pm",
[],
a);
},
getDayNames:function(a,
b){{qx.core.Assert.assertInArray(a,
["abbreviated",
"narrow",
"wide"]);
};
var c=["sun",
"mon",
"tue",
"wed",
"thu",
"fri",
"sat"];
var d=[];
for(var e=0;e<c.length;e++){var f="cldr_day_"+a+"_"+c[e];
d.push(this.__bK.translate(f,
[],
b));
}return d;
},
getDayName:function(a,
b,
c){{qx.core.Assert.assertInArray(a,
["abbreviated",
"narrow",
"wide"]);
qx.core.Assert.assertInteger(b);
qx.core.Assert.assertInRange(b,
0,
6);
};
var d=["sun",
"mon",
"tue",
"wed",
"thu",
"fri",
"sat"];
var e="cldr_day_"+a+"_"+d[b];
return this.__bK.translate(e,
[],
c);
},
getMonthNames:function(a,
b){{qx.core.Assert.assertInArray(a,
["abbreviated",
"narrow",
"wide"]);
};
var c=[];
for(var d=0;d<12;d++){var e="cldr_month_"+a+"_"+(d+1);
c.push(this.__bK.translate(e,
[],
b));
}return c;
},
getMonthName:function(a,
b,
c){{qx.core.Assert.assertInArray(a,
["abbreviated",
"narrow",
"wide"]);
};
var d="cldr_month_"+a+"_"+(b+1);
return this.__bK.translate(d,
[],
c);
},
getDateFormat:function(a,
b){{qx.core.Assert.assertInArray(a,
["short",
"medium",
"long",
"full"]);
};
var c="cldr_date_format_"+a;
return this.__bK.translate(c,
[],
b);
},
getDateTimeFormat:function(a,
b,
c){var d="cldr_date_time_format_"+a;
var e=this.__bK.translate(d,
[],
c);
if(e==d){e=b;
}return e;
},
getTimeFormat:function(a,
b){{qx.core.Assert.assertInArray(a,
["short",
"medium",
"long",
"full"]);
};
var c="cldr_time_format_"+a;
var d=this.__bK.translate(c,
[],
b);
if(d!=c){return d;
}
switch(a){case "short":case "medium":return qx.locale.Date.getDateTimeFormat("HHmm",
"HH:mm");
case "long":return qx.locale.Date.getDateTimeFormat("HHmmss",
"HH:mm:ss");
case "full":return qx.locale.Date.getDateTimeFormat("HHmmsszz",
"HH:mm:ss zz");
default:throw new Error("This case should never happen.");
}},
getWeekStart:function(a){var b={"MV":5,
"AE":6,
"AF":6,
"BH":6,
"DJ":6,
"DZ":6,
"EG":6,
"ER":6,
"ET":6,
"IQ":6,
"IR":6,
"JO":6,
"KE":6,
"KW":6,
"LB":6,
"LY":6,
"MA":6,
"OM":6,
"QA":6,
"SA":6,
"SD":6,
"SO":6,
"TN":6,
"YE":6,
"AS":0,
"AU":0,
"AZ":0,
"BW":0,
"CA":0,
"CN":0,
"FO":0,
"GE":0,
"GL":0,
"GU":0,
"HK":0,
"IE":0,
"IL":0,
"IS":0,
"JM":0,
"JP":0,
"KG":0,
"KR":0,
"LA":0,
"MH":0,
"MN":0,
"MO":0,
"MP":0,
"MT":0,
"NZ":0,
"PH":0,
"PK":0,
"SG":0,
"TH":0,
"TT":0,
"TW":0,
"UM":0,
"US":0,
"UZ":0,
"VI":0,
"ZA":0,
"ZW":0,
"MW":0,
"NG":0,
"TJ":0};
var c=qx.locale.Date._getTerritory(a);
return b[c]!=null?b[c]:1;
},
getWeekendStart:function(a){var b={"EG":5,
"IL":5,
"SY":5,
"IN":0,
"AE":4,
"BH":4,
"DZ":4,
"IQ":4,
"JO":4,
"KW":4,
"LB":4,
"LY":4,
"MA":4,
"OM":4,
"QA":4,
"SA":4,
"SD":4,
"TN":4,
"YE":4};
var c=qx.locale.Date._getTerritory(a);
return b[c]!=null?b[c]:6;
},
getWeekendEnd:function(a){var b={"AE":5,
"BH":5,
"DZ":5,
"IQ":5,
"JO":5,
"KW":5,
"LB":5,
"LY":5,
"MA":5,
"OM":5,
"QA":5,
"SA":5,
"SD":5,
"TN":5,
"YE":5,
"AF":5,
"IR":5,
"EG":6,
"IL":6,
"SY":6};
var c=qx.locale.Date._getTerritory(a);
return b[c]!=null?b[c]:0;
},
isWeekend:function(a,
b){var c=qx.locale.Date.getWeekendStart(b);
var d=qx.locale.Date.getWeekendEnd(b);
if(d>c){return ((a>=c)&&(a<=d));
}else{return ((a>=c)||(a<=d));
}},
_getTerritory:function(a){if(a){var b=a.split("_")[1]||a;
}else{b=this.__bK.getTerritory()||this.__bK.getLanguage();
}return b.toUpperCase();
}}});
qx.Class.define("qx.event.dispatch.AbstractBubbling",
{extend:qx.core.Object,
implement:qx.event.IEventDispatcher,
type:"abstract",
construct:function(a){this._manager=a;
},
members:{_getParent:function(a){throw new Error("Missing implementation");
},
canDispatchEvent:function(a,
b,
c){return b.getBubbles();
},
dispatchEvent:function(a,
b,
c){var d=a;
var e=this._manager;
var f,
g;
var h;
var k,
l;
var m;
var n=[];
f=e.getListeners(a,
c,
true);
g=e.getListeners(a,
c,
false);
if(f){n.push(f);
}
if(g){n.push(g);
}var d=this._getParent(a);
var o=[];
var p=[];
var q=[];
var r=[];
while(d!=null){f=e.getListeners(d,
c,
true);
if(f){q.push(f);
r.push(d);
}g=e.getListeners(d,
c,
false);
if(g){o.push(g);
p.push(d);
}d=this._getParent(d);
}b.setEventPhase(qx.event.type.Event.CAPTURING_PHASE);
for(var s=q.length-1;s>=0;s--){m=r[s];
b.setCurrentTarget(m);
h=q[s];
for(var t=0,
u=h.length;t<u;t++){k=h[t];
l=k.context||m;
k.handler.call(l,
b);
}
if(b.getPropagationStopped()){return;
}}b.setEventPhase(qx.event.type.Event.AT_TARGET);
b.setCurrentTarget(a);
for(var s=0,
v=n.length;s<v;s++){h=n[s];
for(var t=0,
u=h.length;t<u;t++){k=h[t];
l=k.context||a;
k.handler.call(l,
b);
}
if(b.getPropagationStopped()){return;
}}b.setEventPhase(qx.event.type.Event.BUBBLING_PHASE);
for(var s=0,
v=o.length;s<v;s++){m=p[s];
b.setCurrentTarget(m);
h=o[s];
for(var t=0,
u=h.length;t<u;t++){k=h[t];
l=k.context||m;
k.handler.call(l,
b);
}
if(b.getPropagationStopped()){return;
}}}}});
qx.Class.define("qx.util.DeferredCallManager",
{extend:qx.core.Object,
type:"singleton",
construct:function(){this.__calls={};
this.__timeoutWrapper=qx.lang.Function.bind(this.__bL,
this);
this.__hasCalls=false;
},
members:{schedule:function(a){if(this.__timeoutId==null){this.__timeoutId=window.setTimeout(this.__timeoutWrapper,
0);
}var b=a.toHashCode();
if(this.__currentQueue&&this.__currentQueue[b]){return;
}this.__calls[b]=a;
this.__hasCalls=true;
},
cancel:function(a){var b=a.toHashCode();
if(this.__currentQueue&&this.__currentQueue[b]){this.__currentQueue[b]=null;
return;
}delete this.__calls[b];
if(qx.lang.Object.isEmpty(this.__calls)&&this.__timeoutId!=null){window.clearTimeout(this.__timeoutId);
this.__timeoutId=null;
}},
__bL:function(){this.__timeoutId=null;
while(this.__hasCalls){this.__currentQueue=qx.lang.Object.copy(this.__calls);
this.__calls={};
this.__hasCalls=false;
for(var a in this.__currentQueue){var b=this.__currentQueue[a];
if(b){this.__currentQueue[a]=null;
b.call();
}}}this.__currentQueue=null;
}},
destruct:function(){if(this.__timeoutId!=null){window.clearTimeout(this.__timeoutId);
}this._disposeFields("__timeoutWrapper",
"__calls");
}});
qx.Class.define("qx.util.DeferredCall",
{extend:qx.core.Object,
construct:function(a,
b){arguments.callee.base.call(this);
this.__callback=a;
this.__context=b||null;
this.__manager=qx.util.DeferredCallManager.getInstance();
},
members:{cancel:function(){this.__manager.cancel(this);
},
schedule:function(){this.__manager.schedule(this);
},
call:function(){this.__context?this.__callback.apply(this.__context):this.__callback();
}},
destruct:function(a,
b){this.cancel();
this._disposeFields("__context",
"__callback",
"__manager");
}});
qx.Mixin.define("qx.locale.MTranslation",
{members:{tr:function(a,
b){var c=qx.locale.Manager;
if(c){return c.tr.apply(c,
arguments);
}throw new Error("To enable localization please include qx.locale.Manager into your build!");
},
trn:function(a,
b,
c,
d){var e=qx.locale.Manager;
if(e){return e.trn.apply(e,
arguments);
}throw new Error("To enable localization please include qx.locale.Manager into your build!");
},
marktr:function(a){var b=qx.locale.Manager;
if(b){return b.marktr.apply(b,
arguments);
}throw new Error("To enable localization please include qx.locale.Manager into your build!");
}}});
qx.Class.define("qx.bom.Viewport",
{statics:{getWidth:qx.core.Variant.select("qx.client",
{"opera":function(a){return (a||window).document.body.clientWidth;
},
"webkit":function(a){return (a||window).innerWidth;
},
"default":function(a){var b=(a||window).document;
return b.compatMode==="CSS1Compat"?b.documentElement.clientWidth:b.body.clientWidth;
}}),
getHeight:qx.core.Variant.select("qx.client",
{"opera":function(a){return (a||window).document.body.clientHeight;
},
"webkit":function(a){return (a||window).innerHeight;
},
"default":function(a){var b=(a||window).document;
return b.compatMode==="CSS1Compat"?b.documentElement.clientHeight:b.body.clientHeight;
}}),
getScrollLeft:qx.core.Variant.select("qx.client",
{"mshtml":function(a){var b=(a||window).document;
return b.documentElement.scrollLeft||b.body.scrollLeft;
},
"default":function(a){return (a||window).pageXOffset;
}}),
getScrollTop:qx.core.Variant.select("qx.client",
{"mshtml":function(a){var b=(a||window).document;
return b.documentElement.scrollTop||b.body.scrollTop;
},
"default":function(a){return (a||window).pageYOffset;
}})}});
qx.Bootstrap.define("qx.lang.Number",
{statics:{isInRange:function(a,
b,
c){return a>=b&&a<=c;
},
isBetweenRange:function(a,
b,
c){return a>b&&a<c;
},
limit:function(a,
b,
c){if(c!=null&&a>c){return c;
}else if(b!=null&&a<b){return b;
}else{return a;
}}}});
qx.Class.define("qx.bom.Stylesheet",
{statics:{includeFile:function(a,
b){if(!b){b=document;
}var c=b.createElement("link");
c.type="text/css";
c.rel="stylesheet";
c.href=qx.util.ResourceManager.toUri(a);
var d=b.getElementsByTagName("head")[0];
d.appendChild(c);
},
createElement:qx.core.Variant.select("qx.client",
{"mshtml":function(a){var b=document.createStyleSheet();
if(a){b.cssText=a;
}return b;
},
"default":function(a){var b=document.createElement("style");
b.type="text/css";
if(a){b.appendChild(document.createTextNode(a));
}document.getElementsByTagName("head")[0].appendChild(b);
return b.sheet;
}}),
addRule:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b,
c){a.addRule(b,
c);
},
"default":function(a,
b,
c){a.insertRule(b+"{"+c+"}",
a.cssRules.length);
}}),
removeRule:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b){var c=a.rules;
var d=c.length;
for(var e=d-1;e>=0;--e){if(c[e].selectorText==b){a.removeRule(e);
}}},
"default":function(a,
b){var c=a.cssRules;
var d=c.length;
for(var e=d-1;e>=0;--e){if(c[e].selectorText==b){a.deleteRule(e);
}}}}),
removeAllRules:qx.core.Variant.select("qx.client",
{"mshtml":function(a){var b=a.rules;
var c=b.length;
for(var d=c-1;d>=0;d--){a.removeRule(d);
}},
"default":function(a){var b=a.cssRules;
var c=b.length;
for(var d=c-1;d>=0;d--){a.deleteRule(d);
}}}),
addImport:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b){a.addImport(b);
},
"default":function(a,
b){a.insertRule('@import "'+b+'";',
a.cssRules.length);
}}),
removeImport:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b){var c=a.imports;
var d=c.length;
for(var e=d-1;e>=0;e--){if(c[e].href==b){a.removeImport(e);
}}},
"default":function(a,
b){var c=a.cssRules;
var d=c.length;
for(var e=d-1;e>=0;e--){if(c[e].href==b){a.deleteRule(e);
}}}}),
removeAllImports:qx.core.Variant.select("qx.client",
{"mshtml":function(a){var b=a.imports;
var c=b.length;
for(var d=c-1;d>=0;d--){a.removeImport(d);
}},
"default":function(a){var b=a.cssRules;
var c=b.length;
for(var d=c-1;d>=0;d--){if(b[d].type==b[d].IMPORT_RULE){a.deleteRule(d);
}}}})}});
qx.Bootstrap.define("qx.util.ResourceManager",
{statics:{__bM:window.qxresourceinfo||{},
registerImage:function(a,
b,
c){if(this.__bM[a]){return;
}qx.log.Logger.debug("Dynamically registering: "+a);
this.__bM[a]=[b,
c];
},
has:function(a){return !!this.__bM[a];
},
getData:function(a){return this.__bM[a]||null;
},
getClipped:function(a){var b=this.__bM[a];
if(!b){return null;
}var c=b[0];
var d=b[1];
var e=b[2];
if(b.length<5){var f=0;
var g=0;
}else{a=b[4];
var f=b[5];
var g=b[6];
}return [a,
f,
g,
c,
d,
e];
},
toUri:function(a){if(a==null){return a;
}var b=this.__bM[a];
if(!b){return a;
}
if(typeof b==="string"){var c=b;
}else{var c=b[3];
if(!c){return a;
}}return window.qxlibraries[c].resourceUri+"/"+a;
}}});
qx.Class.define("qx.Theme",
{statics:{define:function(b,
c){if(!c){var c={};
}
if(c.include&&!(c.include instanceof Array)){c.include=[c.include];
}{this.__bS(b,
c);
};
var d={$$type:"Theme",
name:b,
title:c.title,
toString:this.genericToString};
if(c.extend){d.supertheme=c.extend;
}if(c.resource){d.resource=c.resource;
}d.basename=qx.Bootstrap.createNamespace(b,
d);
this.__bO(d,
c);
this.$$registry[b]=d;
if(c.include){for(var e=0,
f=c.include,
g=f.length;e<g;e++){this.include(d,
f[e]);
}}},
getAll:function(){return this.$$registry;
},
getByName:function(a){return this.$$registry[a];
},
isDefined:function(a){return this.getByName(a)!==undefined;
},
getTotalNumber:function(){return qx.lang.Object.getLength(this.$$registry);
},
genericToString:function(){return "[Theme "+this.name+"]";
},
__bN:function(a){for(var b=0,
c=this.__bP,
d=c.length;b<d;b++){if(a[c[b]]){return c[b];
}}},
__bO:function(a,
b){var c=this.__bN(b);
if(b.extend&&!c){c=b.extend.type;
}a.type=c||"other";
if(!c){return;
}var d=function(){};
if(b.extend){d.prototype=new b.extend.$$clazz;
}var e=d.prototype;
var f=b[c];
for(var g in f){e[g]=f[g];
if(e[g].base){{if(!b.extend){throw new Error("Found base flag in entry '"+g+"' of theme '"+b.name+"'. Base flags are not allowed for themes without a valid super theme!");
}};
e[g].base=b.extend;
}}a.$$clazz=d;
a[c]=new d;
},
$$registry:{},
__bP:["colors",
"borders",
"decorations",
"fonts",
"icons",
"widgets",
"appearances",
"meta"],
__bQ:{"title":"string",
"resource":"string",
"type":"string",
"extend":"object",
"colors":"object",
"borders":"object",
"decorations":"object",
"fonts":"object",
"icons":"object",
"widgets":"object",
"appearances":"object",
"meta":"object",
"include":"object"},
__bR:{"color":"object",
"border":"object",
"decoration":"object",
"font":"object",
"icon":"object",
"appearance":"object",
"widget":"object"},
__bS:function(a,
b){var c=this.__bQ;
for(var d in b){if(c[d]===undefined){throw new Error('The configuration key "'+d+'" in theme "'+a+'" is not allowed!');
}
if(b[d]==null){throw new Error('Invalid key "'+d+'" in theme "'+a+'"! The value is undefined/null!');
}
if(c[d]!==null&&typeof b[d]!==c[d]){throw new Error('Invalid type of key "'+d+'" in theme "'+a+'"! The type of the key must be "'+c[d]+'"!');
}}if(b.title===undefined){throw new Error("Missing title definition in theme: "+a);
}var e=["colors",
"borders",
"decorations",
"fonts",
"icons",
"widgets",
"appearances",
"meta"];
for(var f=0,
g=e.length;f<g;f++){var d=e[f];
if(b[d]!==undefined&&(b[d] instanceof Array||b[d] instanceof RegExp||b[d] instanceof Date||b[d].classname!==undefined)){throw new Error('Invalid key "'+d+'" in theme "'+a+'"! The value needs to be a map!');
}}var h=0;
for(var f=0,
g=e.length;f<g;f++){var d=e[f];
if(b[d]){h++;
}
if(h>1){throw new Error("You can only define one theme category per file! Invalid theme: "+a);
}}if(!b.extend&&h===0){throw new Error("You must define at least one entry in your theme configuration :"+a);
}if(b.meta){var j;
for(var d in b.meta){j=b.meta[d];
if(this.__bR[d]===undefined){throw new Error('The key "'+d+'" is not allowed inside a meta theme block.');
}
if(typeof j!==this.__bR[d]){throw new Error('The type of the key "'+d+'" inside the meta block is wrong.');
}
if(!(typeof j==="object"&&j!==null&&j.$$type==="Theme")){throw new Error('The content of a meta theme must reference to other themes. The value for "'+d+'" in theme "'+a+'" is invalid: '+j);
}}}if(b.extend&&b.extend.$$type!=="Theme"){throw new Error('Invalid extend in theme "'+a+'": '+b.extend);
}},
patch:function(a,
b){var c=this.__bN(b);
if(c!==this.__bN(a)){throw new Error("The mixins '"+a.name+"' are not compatible '"+b.name+"'!");
}var d=b[c];
var e=a[c];
for(var f in d){e[f]=d[f];
}},
include:function(a,
b){var c=b.type;
if(c!==a.type){throw new Error("The mixins '"+a.name+"' are not compatible '"+b.name+"'!");
}var d=b[c];
var e=a[c];
for(var f in d){if(e[f]!==undefined){throw new Error("It is not allowed to overwrite the key '"+f+"' of theme '"+a.name+"' by mixin theme '"+b.name+"'.");
}e[f]=d[f];
}}}});
qx.Class.define("qx.bom.element.Location",
{statics:{__bT:function(a,
b){return qx.bom.element.Style.get(a,
b,
qx.bom.element.Style.COMPUTED_MODE,
false);
},
__bU:function(a,
b){return parseInt(qx.bom.element.Style.get(a,
b,
qx.bom.element.Style.COMPUTED_MODE,
false),
10)||0;
},
__bV:function(a){var b=0,
c=0;
if(a.getBoundingClientRect){var d=qx.dom.Node.getWindow(a);
b-=qx.bom.Viewport.getScrollLeft(d);
c-=qx.bom.Viewport.getScrollTop(d);
}else{var e=qx.dom.Node.getDocument(a).body;
a=a.parentNode;
while(a&&a!=e){b+=a.scrollLeft;
c+=a.scrollTop;
a=a.parentNode;
}}return {left:b,
top:c};
},
__bW:qx.core.Variant.select("qx.client",
{"mshtml":function(a){var b=qx.dom.Node.getDocument(a);
var c=b.body;
var d=c.offsetLeft;
var e=c.offsetTop;
d-=c.parentNode.clientLeft;
e-=c.parentNode.clientTop;
if(b.compatMode==="CSS1Compat"){d+=this.__bU(c,
"marginLeft");
e+=this.__bU(c,
"marginTop");
}return {left:d,
top:e};
},
"webkit":function(a){var b=qx.dom.Node.getDocument(a);
var c=b.body;
var d=c.offsetLeft;
var e=c.offsetTop;
d+=this.__bU(c,
"borderLeftWidth");
e+=this.__bU(c,
"borderTopWidth");
if(b.compatMode==="CSS1Compat"){d+=this.__bU(c,
"marginLeft");
e+=this.__bU(c,
"marginTop");
}return {left:d,
top:e};
},
"gecko":function(a){var b=qx.dom.Node.getDocument(a).body;
var c=b.offsetLeft;
var d=b.offsetTop;
if(qx.bom.element.BoxSizing.get(b)!=="border-box"){c+=this.__bU(b,
"borderLeftWidth");
d+=this.__bU(b,
"borderTopWidth");
if(!a.getBoundingClientRect){var e;
while(a){if(this.__bT(a,
"position")==="absolute"||this.__bT(a,
"position")==="fixed"){e=true;
break;
}a=a.offsetParent;
}
if(!e){c+=this.__bU(b,
"borderLeftWidth");
d+=this.__bU(b,
"borderTopWidth");
}}}return {left:c,
top:d};
},
"default":function(a){var b=qx.dom.Node.getDocument(a).body;
var c=b.offsetLeft;
var d=b.offsetTop;
return {left:c,
top:d};
}}),
__bX:qx.core.Variant.select("qx.client",
{"mshtml|webkit":function(a){var b=qx.dom.Node.getDocument(a);
if(a.getBoundingClientRect){var c=a.getBoundingClientRect();
var d=c.left;
var e=c.top;
if(b.compatMode==="CSS1Compat"){d-=this.__bU(a,
"borderLeftWidth");
e-=this.__bU(a,
"borderTopWidth");
}}else{var d=a.offsetLeft;
var e=a.offsetTop;
a=a.offsetParent;
var f=b.body;
while(a&&a!=f){d+=a.offsetLeft;
e+=a.offsetTop;
d+=this.__bU(a,
"borderLeftWidth");
e+=this.__bU(a,
"borderTopWidth");
a=a.offsetParent;
}}return {left:d,
top:e};
},
"gecko":function(a){if(a.getBoundingClientRect){var b=a.getBoundingClientRect();
var c=Math.round(b.left);
var d=Math.round(b.top);
}else{var c=0;
var d=0;
var e=qx.dom.Node.getDocument(a).body;
var f=qx.bom.element.BoxSizing;
if(f.get(a)!=="border-box"){c-=this.__bU(a,
"borderLeftWidth");
d-=this.__bU(a,
"borderTopWidth");
}
while(a&&a!==e){c+=a.offsetLeft;
d+=a.offsetTop;
if(f.get(a)!=="border-box"){c+=this.__bU(a,
"borderLeftWidth");
d+=this.__bU(a,
"borderTopWidth");
}if(a.parentNode&&this.__bT(a.parentNode,
"overflow")!="visible"){c+=this.__bU(a.parentNode,
"borderLeftWidth");
d+=this.__bU(a.parentNode,
"borderTopWidth");
}a=a.offsetParent;
}}return {left:c,
top:d};
},
"default":function(a){var b=0;
var c=0;
var d=qx.dom.Node.getDocument(a).body;
while(a&&a!==d){b+=a.offsetLeft;
c+=a.offsetTop;
a=a.offsetParent;
}return {left:b,
top:c};
}}),
get:function(a,
b){var c=this.__bW(a);
if(a.tagName=="BODY"){var d=c.left;
var e=c.top;
}else{var f=this.__bX(a);
var g=this.__bV(a);
var d=f.left+c.left-g.left;
var e=f.top+c.top-g.top;
}var h=d+a.offsetWidth;
var i=e+a.offsetHeight;
if(b){if(b=="padding"||b=="scroll"){var j=qx.bom.element.Overflow.getX(a);
if(j=="scroll"||j=="auto"){h+=a.scrollWidth-a.offsetWidth+this.__bU(a,
"borderLeftWidth")+this.__bU(a,
"borderRightWidth");
}var k=qx.bom.element.Overflow.getY(a);
if(k=="scroll"||k=="auto"){i+=a.scrollHeight-a.offsetHeight+this.__bU(a,
"borderTopWidth")+this.__bU(a,
"borderBottomWidth");
}}
switch(b){case "padding":d+=this.__bU(a,
"paddingLeft");
e+=this.__bU(a,
"paddingTop");
h-=this.__bU(a,
"paddingRight");
i-=this.__bU(a,
"paddingBottom");
case "scroll":d-=a.scrollLeft;
e-=a.scrollTop;
h-=a.scrollLeft;
i-=a.scrollTop;
case "border":d+=this.__bU(a,
"borderLeftWidth");
e+=this.__bU(a,
"borderTopWidth");
h-=this.__bU(a,
"borderRightWidth");
i-=this.__bU(a,
"borderBottomWidth");
break;
case "margin":d-=this.__bU(a,
"marginLeft");
e-=this.__bU(a,
"marginTop");
h+=this.__bU(a,
"marginRight");
i+=this.__bU(a,
"marginBottom");
break;
}}return {left:d,
top:e,
right:h,
bottom:i};
},
getLeft:function(a,
b){return this.get(a,
b).left;
},
getTop:function(a,
b){return this.get(a,
b).top;
},
getRight:function(a,
b){return this.get(a,
b).right;
},
getBottom:function(a,
b){return this.get(a,
b).bottom;
},
getRelative:function(a,
b,
c,
d){var e=this.get(a,
c);
var f=this.get(b,
d);
return {left:e.left-f.left,
top:e.top-f.top,
right:e.right-f.right,
bottom:e.bottom-f.bottom};
}}});
qx.Class.define("qx.bom.element.Style",
{statics:{__bY:{styleNames:{"float":qx.core.Variant.select("qx.client",
{"mshtml":"styleFloat",
"default":"cssFloat"}),
"appearance":qx.core.Variant.select("qx.client",
{"gecko":"MozAppearance",
"webkit":"WebkitAppearance",
"default":"appearance"}),
"userSelect":qx.core.Variant.select("qx.client",
{"gecko":"MozUserSelect",
"webkit":"WebkitUserSelect",
"default":"userSelect"})},
cssNames:{"appearance":qx.core.Variant.select("qx.client",
{"gecko":"-moz-appearance",
"webkit":"-webkit-appearance",
"default":"appearance"}),
"userSelect":qx.core.Variant.select("qx.client",
{"gecko":"-moz-user-select",
"webkit":"-webkit-user-select",
"default":"user-select"}),
"textOverflow":qx.core.Variant.select("qx.client",
{"opera":"-o-text-overflow",
"default":"text-overflow"})},
mshtmlPixel:{width:"pixelWidth",
height:"pixelHeight",
left:"pixelLeft",
right:"pixelRight",
top:"pixelTop",
bottom:"pixelBottom"},
special:{clip:1,
cursor:1,
opacity:1,
boxSizing:1,
overflowX:1,
overflowY:1}},
__ca:{},
compile:function(a){var b=[];
var c=this.__bY;
var d=c.special;
var e=c.cssNames;
var f=this.__ca;
var g=qx.lang.String;
var h,
i,
j;
for(h in a){j=a[h];
h=e[h]||h;
if(d[h]){switch(h){case "clip":b.push(qx.bom.element.Clip.compile(j));
break;
case "cursor":b.push(qx.bom.element.Cursor.compile(j));
break;
case "opacity":b.push(qx.bom.element.Opacity.compile(j));
break;
case "boxSizing":b.push(qx.bom.element.BoxSizing.compile(j));
break;
case "overflowX":b.push(qx.bom.element.Overflow.compileX(j));
break;
case "overflowY":b.push(qx.bom.element.Overflow.compileY(j));
break;
}}else{i=f[h];
if(!i){i=f[h]=g.hyphenate(h);
}b.push(i,
":",
j,
";");
}}return b.join("");
},
setCss:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b){a.style.cssText=b;
},
"default":function(a,
b){a.setAttribute("style",
b);
}}),
getCss:qx.core.Variant.select("qx.client",
{"mshtml":function(a){return a.style.cssText.toLowerCase();
},
"default":function(a){return a.getAttribute("style");
}}),
COMPUTED_MODE:1,
CASCADED_MODE:2,
LOCAL_MODE:3,
set:function(a,
b,
c,
d){{qx.core.Assert.assertElement(a,
"Invalid argument 'element'");
qx.core.Assert.assertString(b,
"Invalid argument 'name'");
if(d!==undefined){qx.core.Assert.assertBoolean(d,
"Invalid argument 'smart'");
}};
var e=this.__bY;
b=e.styleNames[b]||b;
if(d!==false&&e.special[b]){switch(b){case "clip":return qx.bom.element.Clip.set(a,
c);
case "cursor":return qx.bom.element.Cursor.set(a,
c);
case "opacity":return qx.bom.element.Opacity.set(a,
c);
case "boxSizing":return qx.bom.element.BoxSizing.set(a,
c);
case "overflowX":return qx.bom.element.Overflow.setX(a,
c);
case "overflowY":return qx.bom.element.Overflow.setY(a,
c);
}}a.style[b]=c!==null?c:"";
},
setStyles:function(a,
b,
c){{qx.core.Assert.assertElement(a,
"Invalid argument 'element'");
qx.core.Assert.assertMap(b,
"Invalid argument 'styles'");
if(c!==undefined){qx.core.Assert.assertBoolean(c,
"Invalid argument 'smart'");
}};
for(var d in b){this.set(a,
d,
b[d],
c);
}},
reset:function(a,
b,
c){var d=this.__bY;
b=d.styleNames[b]||b;
if(c!==false&&d.special[b]){switch(b){case "clip":return qx.bom.element.Clip.reset(a);
case "cursor":return qx.bom.element.Cursor.reset(a);
case "opacity":return qx.bom.element.Opacity.reset(a);
case "boxSizing":return qx.bom.element.BoxSizing.reset(a);
case "overflowX":return qx.bom.element.Overflow.resetX(a);
case "overflowY":return qx.bom.element.Overflow.resetY(a);
}}a.style[b]="";
},
get:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b,
c,
d){var e=this.__bY;
b=e.styleNames[b]||b;
if(d!==false&&e.special[b]){switch(b){case "clip":return qx.bom.element.Clip.get(a,
c);
case "cursor":return qx.bom.element.Cursor.get(a,
c);
case "opacity":return qx.bom.element.Opacity.get(a,
c);
case "boxSizing":return qx.bom.element.BoxSizing.get(a,
c);
case "overflowX":return qx.bom.element.Overflow.getX(a,
c);
case "overflowY":return qx.bom.element.Overflow.getY(a,
c);
}}if(!a.currentStyle){return a.style[b]||"";
}switch(c){case this.LOCAL_MODE:return a.style[b]||"";
case this.CASCADED_MODE:return a.currentStyle[b]||"";
default:var f=a.currentStyle[b]||"";
if(/^-?[\.\d]+(px)?$/i.test(f)){return f;
}var g=e.mshtmlPixel[b];
if(g){var h=a.style[b];
a.style[b]=f||0;
var i=a.style[g]+"px";
a.style[b]=h;
return i;
}if(/^-?[\.\d]+(em|pt|%)?$/i.test(f)){throw new Error("Untranslated computed property value: "+b+". Only pixel values work well across different clients.");
}return f;
}},
"default":function(a,
b,
c,
d){var e=this.__bY;
b=e.styleNames[b]||b;
if(d!==false&&e.special[b]){switch(b){case "clip":return qx.bom.element.Clip.get(a,
c);
case "cursor":return qx.bom.element.Cursor.get(a,
c);
case "opacity":return qx.bom.element.Opacity.get(a,
c);
case "boxSizing":return qx.bom.element.BoxSizing.get(a,
c);
case "overflowX":return qx.bom.element.Overflow.getX(a,
c);
case "overflowY":return qx.bom.element.Overflow.getY(a,
c);
}}switch(c){case this.LOCAL_MODE:return a.style[b]||"";
case this.CASCADED_MODE:if(a.currentStyle){return a.currentStyle[b]||"";
}throw new Error("Cascaded styles are not supported in this browser!");
default:var f=qx.dom.Node.getDocument(a);
var g=f.defaultView.getComputedStyle(a,
null);
return g?g[b]:"";
}}})}});
qx.Class.define("qx.bom.element.Clip",
{statics:{compile:function(a){var b=a.left;
var c=a.top;
var d=a.width;
var e=a.height;
var f,
g;
if(b==null){f=(d==null?"auto":d+"px");
b="auto";
}else{f=(d==null?"auto":b+d+"px");
b=b+"px";
}
if(c==null){g=(e==null?"auto":e+"px");
c="auto";
}else{g=(e==null?"auto":c+e+"px");
c=c+"px";
}return "clip:rect("+c+","+f+","+g+","+b+");";
},
get:function(a,
b){var c=qx.bom.element.Style.get(a,
"clip",
b,
false);
var d,
e,
f,
g;
var h,
i;
if(typeof c==="string"&&c!=="auto"&&c!==""){c=qx.lang.String.trim(c);
if(/\((.*)\)/.test(c)){var j=RegExp.$1.split(",");
e=qx.lang.String.trim(j[0]);
h=qx.lang.String.trim(j[1]);
i=qx.lang.String.trim(j[2]);
d=qx.lang.String.trim(j[3]);
if(d==="auto"){d=null;
}
if(e==="auto"){e=null;
}
if(h==="auto"){h=null;
}
if(i==="auto"){i=null;
}if(e!=null){e=parseInt(e,
10);
}
if(h!=null){h=parseInt(h,
10);
}
if(i!=null){i=parseInt(i,
10);
}
if(d!=null){d=parseInt(d,
10);
}if(h!=null&&d!=null){f=h-d;
}else if(h!=null){f=h;
}
if(i!=null&&e!=null){g=i-e;
}else if(i!=null){g=i;
}}else{throw new Error("Could not parse clip string: "+c);
}}return {left:d||null,
top:e||null,
width:f||null,
height:g||null};
},
set:function(a,
b){var c=b.left;
var d=b.top;
var e=b.width;
var f=b.height;
var g,
h;
if(c==null){g=(e==null?"auto":e+"px");
c="auto";
}else{g=(e==null?"auto":c+e+"px");
c=c+"px";
}
if(d==null){h=(f==null?"auto":f+"px");
d="auto";
}else{h=(f==null?"auto":d+f+"px");
d=d+"px";
}a.style.clip="rect("+d+","+g+","+h+","+c+")";
},
reset:function(a){a.style.clip="";
}}});
qx.Class.define("qx.bom.element.Cursor",
{statics:{__cb:qx.core.Variant.select("qx.client",
{"mshtml":{"cursor":"hand",
"ew-resize":"e-resize",
"ns-resize":"n-resize",
"nesw-resize":"ne-resize",
"nwse-resize":"nw-resize"},
"opera":{"col-resize":"e-resize",
"row-resize":"n-resize",
"ew-resize":"e-resize",
"ns-resize":"n-resize",
"nesw-resize":"ne-resize",
"nwse-resize":"nw-resize"},
"default":{}}),
compile:function(a){return "cursor:"+(this.__cb[a]||a)+";";
},
get:function(a,
b){return qx.bom.element.Style.get(a,
"cursor",
b,
false);
},
set:function(a,
b){a.style.cursor=this.__cb[b]||b;
},
reset:function(a){a.style.cursor="";
}}});
qx.Class.define("qx.bom.element.Opacity",
{statics:{compile:qx.core.Variant.select("qx.client",
{"mshtml":function(a){if(a>=1){return "";
}
if(a<0.00001){a=0;
}return "zoom:1;filter:alpha(opacity="+(a*100)+");";
},
"gecko":function(a){if(a==1){a=0.999999;
}
if(qx.bom.client.Engine.VERSION<1.7){return "-moz-opacity:"+a+";";
}else{return "opacity:"+a+";";
}},
"default":function(a){if(a==1){return "";
}return "opacity:"+a+";";
}}),
set:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b){var c=qx.bom.element.Style.get(a,
"filter",
qx.bom.element.Style.COMPUTED_MODE,
false);
if(b>=1){a.style.filter=c.replace(/alpha\([^\)]*\)/gi,
"");
return;
}
if(b<0.00001){b=0;
}if(!a.currentStyle.hasLayout){a.style.zoom=1;
}a.style.filter=c.replace(/alpha\([^\)]*\)/gi,
"")+"alpha(opacity="+b*100+")";
},
"gecko":function(a,
b){if(b==1){b=0.999999;
}
if(qx.bom.client.Engine.VERSION<1.7){a.style.MozOpacity=b;
}else{a.style.opacity=b;
}},
"default":function(a,
b){if(b==1){b="";
}a.style.opacity=b;
}}),
reset:qx.core.Variant.select("qx.client",
{"mshtml":function(a){var b=qx.bom.element.Style.get(a,
"filter",
qx.bom.element.Style.COMPUTED_MODE,
false);
a.style.filter=b.replace(/alpha\([^\)]*\)/gi,
"");
},
"gecko":function(a){if(qx.bom.client.Engine.VERSION<1.7){a.style.MozOpacity="";
}else{a.style.opacity="";
}},
"default":function(a){a.style.opacity="";
}}),
get:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b){var c=qx.bom.element.Style.get(a,
"filter",
b,
false);
if(c){var d=c.match(/alpha\(opacity=(.*)\)/);
if(d&&d[1]){return parseFloat(d[1])/100;
}}return 1.0;
},
"gecko":function(a,
b){var c=qx.bom.element.Style.get(a,
qx.bom.client.Engine.VERSION<1.7?"MozOpacity":"opacity",
b,
false);
if(c==0.999999){c=1.0;
}
if(c!=null){return parseFloat(c);
}return 1.0;
},
"default":function(a,
b){var c=qx.bom.element.Style.get(a,
"opacity",
b,
false);
if(c!=null){return parseFloat(c);
}return 1.0;
}})}});
qx.Class.define("qx.bom.element.BoxSizing",
{statics:{__cc:qx.core.Variant.select("qx.client",
{"mshtml":null,
"webkit":["boxSizing",
"KhtmlBoxSizing",
"WebkitBoxSizing"],
"gecko":["MozBoxSizing",
"boxSizing"],
"opera":["boxSizing"]}),
__cd:qx.core.Variant.select("qx.client",
{"mshtml":null,
"webkit":["box-sizing",
"-khtml-box-sizing",
"-webkit-box-sizing"],
"gecko":["-moz-box-sizing",
"box-sizing"],
"opera":["box-sizing"]}),
__ce:{tags:{button:true,
select:true},
types:{search:true,
button:true,
submit:true,
reset:true,
checkbox:true,
radio:true}},
__cf:function(a){var b=this.__ce;
return b.tags[a.tagName.toLowerCase()]||b.types[a.type];
},
compile:qx.core.Variant.select("qx.client",
{"mshtml":function(a){{qx.log.Logger.warn(this,
"This client do not support the dynamic modification of the box-sizing property.");
};
},
"default":function(a){var b=this.__cd;
var c="";
if(b){for(var d=0,
e=b.length;d<e;d++){c+=b[d]+":"+a+";";
}}return c;
}}),
get:qx.core.Variant.select("qx.client",
{"mshtml":function(a){if(qx.bom.Document.isStandardMode(qx.dom.Node.getDocument(a))){if(!this.__cf(a)){return "content-box";
}}return "border-box";
},
"default":function(a){var b=this.__cc;
var c;
if(b){for(var d=0,
e=b.length;d<e;d++){c=qx.bom.element.Style.get(a,
b[d],
null,
false);
if(c!=null&&c!==""){return c;
}}}return "";
}}),
set:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b){{qx.log.Logger.warn(this,
"This client do not support the dynamic modification of the box-sizing property.");
};
},
"default":function(a,
b){var c=this.__cc;
if(c){for(var d=0,
e=c.length;d<e;d++){a.style[c[d]]=b;
}}}}),
reset:function(a){this.set(a,
"");
}}});
qx.Class.define("qx.bom.Document",
{statics:{isQuirksMode:function(a){return (a||window).document.compatMode!=="CSS1Compat";
},
isStandardMode:function(a){return (a||window).document.compatMode==="CSS1Compat";
},
getWidth:function(a){var b=(a||window).document;
var c=qx.bom.Viewport.getWidth(a);
var d=b.compatMode==="CSS1Compat"?b.documentElement.scrollWidth:b.body.scrollWidth;
return Math.max(d,
c);
},
getHeight:function(a){var b=(a||window).document;
var c=qx.bom.Viewport.getHeight(a);
var d=b.compatMode==="CSS1Compat"?b.documentElement.scrollHeight:b.body.scrollHeight;
return Math.max(d,
c);
}}});
qx.Class.define("qx.bom.element.Overflow",
{statics:{__cg:null,
getScrollbarWidth:function(){if(this.__cg!==null){return this.__cg;
}var a=qx.bom.Style.get;
var b=function(d){return (a(d,
"borderRightStyle")=="none"?0:getStyleSize(d,
"borderRightWidth"));
};
var e=function(d){return (a(d,
"borderLeftStyle")=="none"?0:getStyleSize(d,
"borderLeftWidth"));
};
var f=qx.core.Variant.select("qx.client",
{"mshtml":function(d){if(a(d,
"overflowY")=="hidden"||d.clientWidth==0){return b(d);
}return Math.max(0,
d.offsetWidth-d.clientLeft-d.clientWidth);
},
"default":function(d){if(d.clientWidth==0){var g=a(d,
"overflow");
var h=(g=="scroll"||g=="-moz-scrollbars-vertical"?16:0);
return Math.max(0,
b(d)+h);
}return Math.max(0,
(d.offsetWidth-d.clientWidth-e(d)));
}});
var i=function(d){return f(d)-b(d);
};
var j=document.createElement("div");
var k=j.style;
k.height=k.width="100px";
k.overflow="scroll";
document.body.appendChild(j);
var l=i(j);
this.__cg=l?l:16;
document.body.removeChild(j);
return this.__cg;
},
_compile:qx.core.Variant.select("qx.client",
{"gecko":qx.bom.client.Engine.VERSION<
1.8?
function(a,
b){if(b=="hidden"){b="-moz-scrollbars-none";
}return "overflow:"+b+";";
}:
function(a,
b){return a+":"+b+";";
},
"opera":qx.bom.client.Engine.VERSION<
9.5?
function(a,
b){return "overflow:"+b+";";
}:
function(a,
b){return a+":"+b+";";
},
"default":function(a,
b){return a+":"+b+";";
}}),
compileX:function(a){return this._compile("overflow-x",
a);
},
compileY:function(a){return this._compile("overflow-y",
a);
},
getX:qx.core.Variant.select("qx.client",
{"gecko":qx.bom.client.Engine.VERSION<
1.8?
function(a,
b){var c=qx.bom.element.Style.get(a,
"overflow",
b,
false);
if(c==="-moz-scrollbars-none"){c="hidden";
}return c;
}:
function(a,
b){return qx.bom.element.Style.get(a,
"overflowX",
b,
false);
},
"opera":qx.bom.client.Engine.VERSION<
9.5?
function(a,
b){return qx.bom.element.Style.get(a,
"overflow",
b,
false);
}:
function(a,
b){return qx.bom.element.Style.get(a,
"overflowX",
b,
false);
},
"default":function(a,
b){return qx.bom.element.Style.get(a,
"overflowX",
b,
false);
}}),
setX:qx.core.Variant.select("qx.client",
{"gecko":qx.bom.client.Engine.VERSION<
1.8?
function(a,
b){if(b=="hidden"){b="-moz-scrollbars-none";
}a.style.overflow=b;
}:
function(a,
b){a.style.overflowX=b;
},
"opera":qx.bom.client.Engine.VERSION<
9.5?
function(a,
b){a.style.overflow=b;
}:
function(a,
b){a.style.overflowX=b;
},
"default":function(a,
b){a.style.overflowX=b;
}}),
resetX:qx.core.Variant.select("qx.client",
{"gecko":qx.bom.client.Engine.VERSION<
1.8?
function(a){a.style.overflow="";
}:
function(a){a.style.overflowX="";
},
"opera":qx.bom.client.Engine.VERSION<
9.5?
function(a,
b){a.style.overflow="";
}:
function(a,
b){a.style.overflowX="";
},
"default":function(a){a.style.overflowX="";
}}),
getY:qx.core.Variant.select("qx.client",
{"gecko":qx.bom.client.Engine.VERSION<
1.8?
function(a,
b){var c=qx.bom.element.Style.get(a,
"overflow",
b,
false);
if(c==="-moz-scrollbars-none"){c="hidden";
}return c;
}:
function(a,
b){return qx.bom.element.Style.get(a,
"overflowY",
b,
false);
},
"opera":qx.bom.client.Engine.VERSION<
9.5?
function(a,
b){return qx.bom.element.Style.get(a,
"overflow",
b,
false);
}:
function(a,
b){return qx.bom.element.Style.get(a,
"overflowY",
b,
false);
},
"default":function(a,
b){return qx.bom.element.Style.get(a,
"overflowY",
b,
false);
}}),
setY:qx.core.Variant.select("qx.client",
{"gecko":qx.bom.client.Engine.VERSION<
1.8?
function(a,
b){if(b==="hidden"){b="-moz-scrollbars-none";
}a.style.overflow=b;
}:
function(a,
b){a.style.overflowY=b;
},
"opera":qx.bom.client.Engine.VERSION<
9.5?
function(a,
b){a.style.overflow=b;
}:
function(a,
b){a.style.overflowY=b;
},
"default":function(a,
b){a.style.overflowY=b;
}}),
resetY:qx.core.Variant.select("qx.client",
{"gecko":qx.bom.client.Engine.VERSION<
1.8?
function(a){a.style.overflow="";
}:
function(a){a.style.overflowY="";
},
"opera":qx.bom.client.Engine.VERSION<
9.5?
function(a,
b){a.style.overflow="";
}:
function(a,
b){a.style.overflowY="";
},
"default":function(a){a.style.overflowY="";
}})}});
qx.Class.define("qx.ui.core.LayoutItem",
{type:"abstract",
extend:qx.core.Object,
properties:{minWidth:{check:"Integer",
nullable:true,
apply:"_applyDimension",
init:null,
themeable:true},
width:{check:"Integer",
nullable:true,
apply:"_applyDimension",
init:null,
themeable:true},
maxWidth:{check:"Integer",
nullable:true,
apply:"_applyDimension",
init:null,
themeable:true},
minHeight:{check:"Integer",
nullable:true,
apply:"_applyDimension",
init:null,
themeable:true},
height:{check:"Integer",
nullable:true,
apply:"_applyDimension",
init:null,
themeable:true},
maxHeight:{check:"Integer",
nullable:true,
apply:"_applyDimension",
init:null,
themeable:true},
allowGrowX:{check:"Boolean",
apply:"_applyStretching",
init:true,
themeable:true},
allowShrinkX:{check:"Boolean",
apply:"_applyStretching",
init:true,
themeable:true},
allowGrowY:{check:"Boolean",
apply:"_applyStretching",
init:true,
themeable:true},
allowShrinkY:{check:"Boolean",
apply:"_applyStretching",
init:true,
themeable:true},
allowStretchX:{group:["allowGrowX",
"allowShrinkX"],
mode:"shorthand",
themeable:true},
allowStretchY:{group:["allowGrowY",
"allowShrinkY"],
mode:"shorthand",
themeable:true},
marginTop:{check:"Integer",
init:0,
apply:"_applyMargin",
themeable:true},
marginRight:{check:"Integer",
init:0,
apply:"_applyMargin",
themeable:true},
marginBottom:{check:"Integer",
init:0,
apply:"_applyMargin",
themeable:true},
marginLeft:{check:"Integer",
init:0,
apply:"_applyMargin",
themeable:true},
margin:{group:["marginTop",
"marginRight",
"marginBottom",
"marginLeft"],
mode:"shorthand",
themeable:true},
alignX:{check:["left",
"center",
"right"],
nullable:true,
apply:"_applyAlign",
themeable:true},
alignY:{check:["top",
"middle",
"bottom",
"baseline"],
nullable:true,
apply:"_applyAlign",
themeable:true}},
members:{getBounds:function(){return this.__userBounds||this.__computedLayout||null;
},
renderLayout:function(a,
b,
c,
d){{var e="Something went wrong with the layout of "+this.toString()+"!";
this.assertInteger(a,
"Wrong 'left' argument. "+e);
this.assertInteger(b,
"Wrong 'top' argument. "+e);
this.assertInteger(c,
"Wrong 'width' argument. "+e);
this.assertInteger(d,
"Wrong 'height' argument. "+e);
};
var f=null;
if(this.getHeight()==null&&this._hasHeightForWidth()){var f=this._getHeightForWidth(c);
}
if(f!=null&&f!==this.__computedHeightForWidth){this.__computedHeightForWidth=f;
qx.ui.core.queue.Layout.add(this);
return null;
}else{var g=this.__computedLayout;
if(!g){g=this.__computedLayout={};
}var h={};
if(a!==g.left||b!==g.top){h.position=true;
g.left=a;
g.top=b;
}
if(c!==g.width||d!==g.height){h.size=true;
g.width=c;
g.height=d;
}if(this.__hasInvalidLayout){h.local=true;
delete this.__hasInvalidLayout;
}}return h;
},
shouldBeLayouted:function(){return true;
},
hasValidLayout:function(){return !this.__hasInvalidLayout;
},
scheduleLayoutUpdate:function(){qx.ui.core.queue.Layout.add(this);
},
invalidateLayoutCache:function(){this.__hasInvalidLayout=true;
this.__sizeHint=null;
},
getSizeHint:function(a){var b=this.__sizeHint;
if(b){return b;
}
if(a===false){return null;
}var b=this.__sizeHint=this._computeSizeHint();
if(this.__computedHeightForWidth&&this.getHeight()==null){b.height=this.__computedHeightForWidth;
}if(!this.getAllowShrinkX()){b.minWidth=b.width;
}else if(b.minWidth>b.width){b.width=b.minWidth;
}
if(!this.getAllowShrinkY()){b.minHeight=b.height;
}else if(b.minHeight>b.height){b.height=b.minHeight;
}if(!this.getAllowGrowX()){b.maxWidth=b.width;
}else if(b.width>b.maxWidth){b.width=b.maxWidth;
}
if(!this.getAllowGrowY()){b.maxHeight=b.height;
}else if(b.height>b.maxHeight){b.height=b.maxHeight;
}return b;
},
_computeSizeHint:function(){var a=this.getMinWidth()||0;
var b=this.getMinHeight()||0;
var c=this.getWidth()||a;
var d=this.getHeight()||b;
var e=this.getMaxWidth()||Infinity;
var f=this.getMaxHeight()||Infinity;
return {minWidth:a,
width:c,
maxWidth:e,
minHeight:b,
height:d,
maxHeight:f};
},
_hasHeightForWidth:function(){return false;
},
_getHeightForWidth:function(a){return null;
},
_applyMargin:function(){this.__updateMargin=true;
var a=this._parent;
if(a){a.updateLayoutProperties();
}},
_applyAlign:function(){var a=this._parent;
if(a){a.updateLayoutProperties();
}},
_applyDimension:function(){qx.ui.core.queue.Layout.add(this);
},
_applyStretching:function(){qx.ui.core.queue.Layout.add(this);
},
hasUserBounds:function(){return !!this.__userBounds;
},
setUserBounds:function(a,
b,
c,
d){this.__userBounds={left:a,
top:b,
width:c,
height:d};
qx.ui.core.queue.Layout.add(this);
},
resetUserBounds:function(){delete this.__userBounds;
qx.ui.core.queue.Layout.add(this);
},
__ch:{},
setLayoutProperties:function(a){if(a==null){return;
}var b=this.__layoutProperties;
if(!b){b=this.__layoutProperties={};
}var c=this.getLayoutParent();
if(c){c.updateLayoutProperties(a);
}for(var d in a){if(a[d]==null){delete b[d];
}else{b[d]=a[d];
}}},
getLayoutProperties:function(){return this.__layoutProperties||this.__ch;
},
clearLayoutProperties:function(){delete this.__layoutProperties;
},
updateLayoutProperties:function(a){var b=this._getLayout();
if(b){{if(a){for(var c in a){if(a[c]!==null){b.verifyLayoutProperty(this,
c,
a[c]);
}}}};
b.invalidateChildrenCache();
}qx.ui.core.queue.Layout.add(this);
},
getApplicationRoot:function(){return qx.core.Init.getApplication().getRoot();
},
getLayoutParent:function(){return this._parent||null;
},
setLayoutParent:function(a){this._parent=a;
},
isRootWidget:function(){return false;
},
_getRoot:function(){var a=this;
while(a){if(a.isRootWidget()){return a;
}a=a._parent;
}return null;
},
clone:function(){var a=arguments.callee.base.call(this);
var b=this.__layoutProperties;
if(b){a.__layoutProperties=qx.lang.Object.copy(b);
}return a;
},
serialize:function(){var a=arguments.callee.base.call(this);
var b=this.__layoutProperties;
if(b){a.layoutProperties=qx.lang.Object.copy(b);
}return a;
}}});
qx.Class.define("qx.ui.core.Widget",
{extend:qx.ui.core.LayoutItem,
include:[qx.locale.MTranslation],
construct:function(){arguments.callee.base.call(this);
this._containerElement=this._createContainerElement();
this._contentElement=this.__cj();
this._containerElement.add(this._contentElement);
this._containerElement.setAttribute("$$widget",
this.toHashCode());
{this._containerElement.setAttribute("qxClass",
this.classname);
};
this.__children=[];
qx.ui.core.queue.Appearance.add(this);
this.initFocusable();
this.initSelectable();
this.initCursor();
this.initKeepFocus();
this.initKeepActive();
},
events:{appear:"qx.event.type.Event",
disappear:"qx.event.type.Event",
resize:"qx.event.type.Data",
move:"qx.event.type.Data",
mousemove:"qx.event.type.Mouse",
mouseover:"qx.event.type.Mouse",
mouseout:"qx.event.type.Mouse",
mousedown:"qx.event.type.Mouse",
mouseup:"qx.event.type.Mouse",
click:"qx.event.type.Mouse",
dblclick:"qx.event.type.Mouse",
contextmenu:"qx.event.type.Mouse",
mousewheel:"qx.event.type.Mouse",
keyup:"qx.event.type.KeySequence",
keydown:"qx.event.type.KeySequence",
keypress:"qx.event.type.KeySequence",
keyinput:"qx.event.type.KeyInput",
focus:"qx.event.type.Focus",
blur:"qx.event.type.Focus",
focusin:"qx.event.type.Focus",
focusout:"qx.event.type.Focus",
activate:"qx.event.type.Focus",
deactivate:"qx.event.type.Focus",
capture:"qx.event.type.Event",
losecapture:"qx.event.type.Event",
drop:"qx.event.type.Drag",
dragleave:"qx.event.type.Drag",
dragover:"qx.event.type.Drag",
drag:"qx.event.type.Drag",
dragstart:"qx.event.type.Drag",
dragend:"qx.event.type.Drag",
dragchange:"qx.event.type.Drag",
droprequest:"qx.event.type.Drag"},
properties:{paddingTop:{check:"Integer",
init:0,
apply:"_applyPadding",
themeable:true},
paddingRight:{check:"Integer",
init:0,
apply:"_applyPadding",
themeable:true},
paddingBottom:{check:"Integer",
init:0,
apply:"_applyPadding",
themeable:true},
paddingLeft:{check:"Integer",
init:0,
apply:"_applyPadding",
themeable:true},
padding:{group:["paddingTop",
"paddingRight",
"paddingBottom",
"paddingLeft"],
mode:"shorthand",
themeable:true},
zIndex:{nullable:true,
init:null,
apply:"_applyZIndex",
event:"changeZIndex",
check:"Integer",
themeable:true},
decorator:{nullable:true,
init:null,
apply:"_applyDecorator",
event:"changeDecorator",
check:"Decorator",
themeable:true},
backgroundColor:{nullable:true,
check:"Color",
apply:"_applyBackgroundColor",
event:"changeBackgroundColor",
themeable:true},
textColor:{nullable:true,
init:"inherit",
check:"Color",
apply:"_applyTextColor",
event:"changeTextColor",
themeable:true,
inheritable:true},
font:{nullable:true,
init:"inherit",
apply:"_applyFont",
check:"Font",
event:"changeFont",
themeable:true,
inheritable:true},
opacity:{check:"Number",
apply:"_applyOpacity",
themeable:true,
nullable:true,
init:null},
cursor:{check:"String",
apply:"_applyCursor",
themeable:true,
inheritable:true,
nullable:true,
init:null},
toolTip:{check:"qx.ui.tooltip.ToolTip",
nullable:true},
visibility:{check:["visible",
"hidden",
"excluded"],
init:"visible",
apply:"_applyVisibility",
event:"changeVisibility"},
enabled:{init:"inherit",
check:"Boolean",
inheritable:true,
apply:"_applyEnabled",
event:"changeEnabled"},
anonymous:{init:false,
check:"Boolean"},
tabIndex:{check:"Integer",
nullable:true,
apply:"_applyTabIndex"},
focusable:{check:"Boolean",
init:false,
apply:"_applyFocusable"},
keepFocus:{check:"Boolean",
init:false,
apply:"_applyKeepFocus"},
keepActive:{check:"Boolean",
init:false,
apply:"_applyKeepActive"},
draggable:{check:"Boolean",
init:false,
apply:"_applyDraggable"},
droppable:{check:"Boolean",
init:false,
apply:"_applyDroppable"},
selectable:{check:"Boolean",
init:false,
apply:"_applySelectable"},
appearance:{check:"String",
init:"widget",
apply:"_applyAppearance",
event:"changeAppearance"}},
statics:{getWidgetByElement:function(a){try{while(a){var b=a.$$widget;
if(b!=null){return qx.core.ObjectRegistry.fromHashCode(b);
}a=a.parentNode;
}}catch(ex){}return null;
},
contains:function(a,
b){while(b){if(a==b){return true;
}b=b.getLayoutParent();
}return false;
}},
members:{_getLayout:function(){return this.__layout;
},
_setLayout:function(a){{if(a){this.assertInstance(a,
qx.ui.layout.Abstract);
}};
if(this.__layout){this.__layout.connectToWidget(null);
}
if(a){a.connectToWidget(this);
}this.__layout=a;
qx.ui.core.queue.Layout.add(this);
},
setLayoutParent:function(a){if(this._parent===a){return;
}
if(this._parent){this._parent.getContentElement().remove(this._containerElement);
}this._parent=a||null;
if(this._parent){this._parent.getContentElement().add(this._containerElement);
}qx.core.Property.refresh(this);
},
configureSeparators:function(a){var b=this._separators;
var c=this.getContentElement();
var d;
if(!b){b=this._separators=[];
for(var e=0;e<a;e++){d=new qx.html.Element;
d.setStyle("position",
"absolute");
b.push(d);
c.add(d);
}}else{var f=b.length;
if(f<a){for(var e=f;e<a;e++){d=new qx.html.Element;
d.setStyle("position",
"absolute");
b.push(d);
c.add(d);
}}else if(f>a){for(var e=f-1;e>a-1;e--){b[e].dispose();
}b.length=a;
}}},
renderHorizontalSeparator:function(a,
b,
c,
d){var e=this._separators[b];
var f=qx.theme.manager.Color.getInstance();
e.setStyle("left",
c+"px");
e.setStyle("width",
"0px");
e.setStyle("top",
"0px");
e.setStyle("height",
d+"px");
e.setStyle("borderLeft",
a[0]?"1px solid "+f.resolve(a[0]):null);
e.setStyle("borderRight",
a[1]?"1px solid "+f.resolve(a[1]):null);
},
renderVerticalSeparator:function(a,
b,
c,
d){var e=this._separators[b];
var f=qx.theme.manager.Color.getInstance();
e.setStyle("left",
"0px");
e.setStyle("width",
d+"px");
e.setStyle("top",
c+"px");
e.setStyle("height",
"0px");
e.setStyle("borderTop",
a[0]?"1px solid "+f.resolve(a[0]):null);
e.setStyle("borderBottom",
a[1]?"1px solid "+f.resolve(a[1]):null);
},
renderLayout:function(a,
b,
c,
d){var e=arguments.callee.base.call(this,
a,
b,
c,
d);
if(!e){return;
}var f=this._containerElement;
var g=this._contentElement;
var h=e.size||this.__updateInsets;
var i="px";
if(e.position){f.setStyle("left",
a+i);
f.setStyle("top",
b+i);
}if(e.size){f.setStyle("width",
c+i);
f.setStyle("height",
d+i);
}
if(h||e.local||this.__updateMargin){var j=this.getInsets();
var k=c-j.left-j.right;
var l=d-j.top-j.bottom;
}
if(this.__updateInsets){g.setStyle("left",
j.left+i);
g.setStyle("top",
j.top+i);
}
if(h){g.setStyle("width",
k+i);
g.setStyle("height",
l+i);
}
if(e.size||this.__styleDecorator||this.__initDecorator){if(this._decorator){var m=this.getBackgroundColor();
var n=this._decorationElement;
var o={size:e.size,
style:this.__styleDecorator,
init:this.__initDecorator,
bgcolor:this.__styleBackgroundColor};
this._decorator.render(n,
c,
d,
m,
o);
}delete this.__styleDecorator;
delete this.__styleBackgroundColor;
delete this.__initDecorator;
}
if(h||e.local||this.__updateMargin){if(this.__layout&&this.hasLayoutChildren()){this.__layout.renderLayout(k,
l);
}else if(this.hasLayoutChildren()){throw new Error("At least one child in control "+this._findTopControl()+" requires a layout, but no one was defined!");
}}if(e.position&&this.hasListener("move")){this.fireDataEvent("move",
this.getBounds());
}
if(e.size&&this.hasListener("resize")){this.fireDataEvent("resize",
this.getBounds());
}delete this.__updateInsets;
delete this.__updateMargin;
},
_computeSizeHint:function(){var a=this.getWidth();
var b=this.getMinWidth();
var c=this.getMaxWidth();
var d=this.getHeight();
var e=this.getMinHeight();
var f=this.getMaxHeight();
var g=this._getContentHint();
var h=this.getInsets();
var i=h.left+h.right;
var j=h.top+h.bottom;
if(a==null){a=g.width+i;
}
if(d==null){d=g.height+j;
}
if(b==null){b=i;
if(g.minWidth!=null){b+=g.minWidth;
}}
if(e==null){e=j;
if(g.minHeight!=null){e+=g.minHeight;
}}
if(c==null){if(g.maxWidth==null){c=Infinity;
}else{c=g.maxWidth+i;
}}
if(f==null){if(g.maxHeight==null){f=Infinity;
}else{f=g.maxHeight+j;
}}return {width:a,
minWidth:b,
maxWidth:c,
height:d,
minHeight:e,
maxHeight:f};
},
invalidateLayoutCache:function(){arguments.callee.base.call(this);
if(this.__layout){this.__layout.invalidateLayoutCache();
}},
_getContentHint:function(){var a=this.__layout;
if(a){if(this.hasLayoutChildren()){var b=a.getSizeHint();
{var c="The layout of the widget"+this.toString()+" returned an invalid size hint!";
this.assertInteger(b.width,
"Wrong 'left' argument. "+c);
this.assertInteger(b.height,
"Wrong 'top' argument. "+c);
};
return b;
}else{return {width:0,
height:0};
}}else{return {width:100,
height:50};
}},
_getHeightForWidth:function(a){var b=this.getInsets();
var c=b.left+b.right;
var d=b.top+b.bottom;
var e=a-c;
var f=this._getContentHeightForWidth(e);
var g=f+d;
return g;
},
_getContentHeightForWidth:function(a){throw new Error("Abstract method call: _getContentHeightForWidth()!");
},
getInsets:function(){if(this._getStyleTarget&&this._getStyleTarget()!==this){var a=0;
var b=0;
var c=0;
var d=0;
}else{var a=this.getPaddingTop();
var b=this.getPaddingRight();
var c=this.getPaddingBottom();
var d=this.getPaddingLeft();
}
if(this._decorator){var e=this._decorator.getInsets();
a+=e.top;
b+=e.right;
c+=e.bottom;
d+=e.left;
}return {"top":a,
"right":b,
"bottom":c,
"left":d};
},
getInnerSize:function(){var a=this.getBounds();
if(!a){return null;
}var b=this.getInsets();
return {width:a.width-b.left-b.right,
height:a.height-b.top-b.bottom};
},
show:function(){this.setVisibility("visible");
},
hide:function(){this.setVisibility("hidden");
},
exclude:function(){this.setVisibility("excluded");
},
isVisible:function(){return this.getVisibility()==="visible";
},
isHidden:function(){return this.getVisibility()!=="visible";
},
isExcluded:function(){return this.getVisibility()==="excluded";
},
_createContainerElement:function(){var a=new qx.html.Element("div");
a.setStyle("position",
"absolute");
a.setStyle("zIndex",
0);
return a;
},
__ci:function(){var a=new qx.html.Element("div");
a.setStyle("zIndex",
5);
a.setStyle("position",
"absolute");
a.setStyle("left",
0);
a.setStyle("top",
0);
return a;
},
__cj:function(){var a=this._createContentElement();
a.setStyle("position",
"absolute");
a.setStyle("zIndex",
10);
return a;
},
_createContentElement:function(){var a=new qx.html.Element("div");
a.setStyle("overflowX",
"hidden");
a.setStyle("overflowY",
"hidden");
return a;
},
getContainerElement:function(){return this._containerElement;
},
getContentElement:function(){return this._contentElement;
},
getLayoutChildren:function(){if(this.__layoutChildren){return this.__layoutChildren;
}var a=[];
for(var b=0,
c=this.__children.length;b<c;b++){var d=this.__children[b];
if(!d.hasUserBounds()&&d.shouldBeLayouted()){a.push(d);
}}this.__layoutChildren=a;
return a;
},
scheduleLayoutUpdate:function(){qx.ui.core.queue.Layout.add(this);
},
invalidateLayoutChildren:function(){var a=this.__layout;
if(a){a.invalidateChildrenCache();
}this.__layoutChildren=null;
qx.ui.core.queue.Layout.add(this);
},
shouldBeLayouted:function(){return this.getVisibility()!=="excluded";
},
hasLayoutChildren:function(){return this.getLayoutChildren().length>0;
},
getChildrenContainer:function(){return this;
},
_getChildren:function(){return this.__children;
},
_indexOf:function(a){return this.__children.indexOf(a);
},
_hasChildren:function(){return !!this.__children[0];
},
_add:function(a,
b){this.__ck(a,
b);
this.__children.push(a);
},
_addAt:function(a,
b,
c){var d=this.__children[b];
if(d===a){return a.setLayoutProperties(c);
}this.__ck(a,
c);
if(d){qx.lang.Array.insertBefore(this.__children,
a,
d);
}else{this.__children.push(a);
}},
_addBefore:function(a,
b,
c){{this.assertNotIdentical(a,
b,
"Invalid parameters for _addBefore!");
};
this.__ck(a,
c);
qx.lang.Array.insertBefore(this.__children,
a,
b);
},
_addAfter:function(a,
b,
c){{this.assertNotIdentical(a,
b,
"Invalid parameters for _addAfter!");
};
this.__ck(a,
c);
qx.lang.Array.insertAfter(this.__children,
a,
b);
},
_remove:function(a){this.__cl(a);
qx.lang.Array.remove(this.__children,
a);
},
_removeAt:function(a){var b=this.__children[a];
this.__cl(b);
qx.lang.Array.removeAt(this.__children,
a);
},
_removeAll:function(){var a=this.__children;
for(var b=a.length-1;b>=0;b--){a[b].setLayoutParent(null);
}a.length=0;
qx.ui.core.queue.Layout.add(this);
},
_afterAddChild:null,
_afterRemoveChild:null,
__ck:function(a,
b){{this.assertInstance(a,
qx.ui.core.LayoutItem,
"Invalid widget to add: "+a);
this.assertNotIdentical(a,
this,
"Could not add widget to itself: "+a);
if(b!=null){this.assertType(b,
"object",
"Invalid layout data: "+b);
}};
var c=a.getLayoutParent();
if(c){c._remove(a);
}a.setLayoutParent(this);
if(b){a.setLayoutProperties(b);
}else{this.updateLayoutProperties();
}this.__layoutChildren=null;
if(this._afterAddChild){this._afterAddChild(a);
}},
__cl:function(a){{this.assertNotUndefined(a);
this.assertNotIdentical(a.getLayoutParent,
this,
"Remove Error: "+a+" is not a child of this widget!");
};
a.setLayoutParent(null);
if(this.__layout){this.__layout.invalidateChildrenCache();
}this.__layoutChildren=null;
qx.ui.core.queue.Layout.add(this);
if(this._afterRemoveChild){this._afterRemoveChild(a);
}},
capture:function(){this._containerElement.capture();
},
releaseCapture:function(){this._containerElement.releaseCapture();
},
_getStyleTarget:null,
_applyPadding:function(a,
b,
c){if(this._getStyleTarget&&this._getStyleTarget()!==this){var d={};
d[c]=a;
this._getStyleTarget().set(d);
}else{this.__updateInsets=true;
qx.ui.core.queue.Layout.add(this);
}},
_applyDecorator:function(a,
b){var c=this.__oldInsets;
var d;
if(a){this._decorator=qx.theme.manager.Decoration.getInstance().resolve(a);
d=this._decorator.getInsets();
this.__oldInsets=qx.lang.Object.copy(d);
}else{this._decorator=null;
d=null;
}var e=this._containerElement;
var f=this._decorationElement;
if(b&&a){var g=b.classname!==a.classname;
var h=c.top!==d.top||c.right!==d.right||c.bottom!==d.bottom||c.left!==d.left;
}else{var g=true;
var h=true;
var i=this.getBackgroundColor();
if(a){if(!f){f=this._decorationElement=this.__ci();
e.add(f);
}if(i){e.removeStyle("backgroundColor");
}}else if(i){e.setStyle("backgroundColor",
qx.theme.manager.Color.getInstance().resolve(i)||null);
}}if(b&&g){var j=qx.theme.manager.Decoration.getInstance().resolve(b);
j.reset(f);
}
if(a){if(h){if(g&&!this.__initDecorator){this.__initDecorator=true;
}this.__updateInsets=true;
this.__styleDecorator=true;
qx.ui.core.queue.Layout.add(this);
}else if(!this.__styleDecorator){var k=this.getBounds();
this._decorator.render(f,
k.width,
k.height,
i,
{init:g,
style:true});
}}else{this.__updateInsets=true;
qx.ui.core.queue.Layout.add(this);
}},
_applyTextColor:function(a,
b){if(this._getStyleTarget&&this._getStyleTarget()!==this){var c=this._getStyleTarget();
if(a){c.setTextColor(a);
}else{c.resetTextColor();
}return;
}},
_applyZIndex:function(a,
b){this._containerElement.setStyle("zIndex",
a==null?0:a);
},
_applyVisibility:function(a,
b){if(a==="visible"){this._containerElement.show();
}else{this._containerElement.hide();
}var c=this._parent;
if(c&&(b==null||a==null||b==="excluded"||a==="excluded")){c.invalidateLayoutChildren();
}},
_applyOpacity:function(a,
b){this._containerElement.setStyle("opacity",
a);
},
_applyCursor:function(a,
b){if(a==null&&!this.isSelectable()){a="default";
}this._containerElement.setStyle("cursor",
a);
},
_applyBackgroundColor:function(a,
b){if(this._decorator){if(!this.__styleDecorator){var c=this.getBounds();
this._decorator.render(this._decorationElement,
c.width,
c.height,
a,
{bgcolor:true});
}else{this.__styleBackgroundColor=true;
}}else{this._containerElement.setStyle("backgroundColor",
qx.theme.manager.Color.getInstance().resolve(a)||null);
}},
_applyFont:function(a,
b){if(this._getStyleTarget&&this._getStyleTarget()!==this){var c=this._getStyleTarget();
if(a){c.setFont(a);
}else{c.resetFont();
}}},
hasState:function(a){var b=this.__states;
return b&&b[a];
},
addState:function(a){var b=this.__states;
if(!b){b=this.__states={};
}
if(b[a]){return;
}this.__states[a]=true;
qx.ui.core.queue.Appearance.add(this);
var c=this._forwardStates;
var d=this.__childControls;
if(c&&c[a]&&d){var e;
for(var f in d){e=d[f];
if(e instanceof qx.ui.core.Widget){d[f].addState(a);
}}}},
removeState:function(a){var b=this.__states;
if(!b||!b[a]){return;
}delete this.__states[a];
qx.ui.core.queue.Appearance.add(this);
var c=this._forwardStates;
var d=this.__childControls;
if(c&&c[a]&&d){for(var e in d){var f=d[e];
if(f instanceof qx.ui.core.Widget){f.removeState(a);
}}}},
replaceState:function(a,
b){var c=this.__states;
if(!c){c=this.__states={};
}
if(!c[b]){c[b]=true;
}
if(c[a]){delete c[a];
}qx.ui.core.queue.Appearance.add(this);
var d=this._forwardStates;
var e=this.__childControls;
if(d&&d[b]&&e){for(var f in e){var g=e[f];
if(g instanceof qx.ui.core.Widget){g.replaceState(a,
b);
}}}},
syncAppearance:function(){var a=this.__states;
var b=this.__selector;
var c=qx.theme.manager.Appearance.getInstance();
var d=qx.core.Property.$$method.style;
var e=qx.core.Property.$$method.unstyle;
if(this.__updateSelector){delete this.__updateSelector;
if(b){var f=c.styleFrom(b,
a);
if(f){b=null;
}}}if(!b){var g=this;
var h=[];
do{h.push(g.$$subcontrol||g.getAppearance());
}while(g=g.$$subparent);
b=this.__selector=h.reverse().join("/");
}var i=c.styleFrom(b,
a);
if(i){if(f){for(var j in f){if(i[j]===undefined){this[e[j]]();
}}}{for(var j in i){if(!this[d[j]]){throw new Error(this.classname+' has no themeable property "'+j+'"');
}}};
var k;
var l="undefined";
for(var j in i){k=i[j];
k===l?this[e[j]]():this[d[j]](k);
}}else if(f){for(var j in f){this[e[j]]();
}}},
_applyAppearance:function(a,
b){this.updateAppearance();
},
updateAppearance:function(){this.__updateSelector=true;
qx.ui.core.queue.Appearance.add(this);
var a=this.__childControls;
if(a){var b;
for(var c in a){b=a[c];
if(b instanceof qx.ui.core.Widget){b.updateAppearance();
}}}},
syncWidget:function(){},
getEventTarget:function(){var a=this;
while(a.getAnonymous()){a=a.getLayoutParent();
if(!a){return null;
}}return a;
},
getFocusTarget:function(){var a=this;
if(!a.getEnabled()){return null;
}
while(a.getAnonymous()||!a.getFocusable()){a=a.getLayoutParent();
if(!a||!a.getEnabled()){return null;
}}return a;
},
getFocusElement:function(){return this._containerElement;
},
isTabable:function(){return this.isFocusable();
},
_applyFocusable:function(a,
b){var c=this.getFocusElement();
if(a){var d=this.getTabIndex();
if(d==null){d=1;
}c.setAttribute("tabIndex",
d);
if(qx.core.Variant.isSet("qx.client",
"mshtml")){c.setAttribute("hideFocus",
"true");
}else{c.setStyle("outline",
"none");
}}else{if(c.isNativelyFocusable()){c.setAttribute("tabIndex",
-1);
}else if(b){c.setAttribute("tabIndex",
null);
}}},
_applyKeepFocus:function(a){var b=this.getFocusElement();
b.setAttribute("qxKeepFocus",
a?"on":null);
},
_applyKeepActive:function(a){var b=this.getContainerElement();
b.setAttribute("qxKeepActive",
a?"on":null);
},
_applyTabIndex:function(a){if(a==null){a=1;
}else if(a<1||a>32000){throw new Error("TabIndex property must be between 1 and 32000");
}
if(this.getFocusable()&&a!=null){this.getFocusElement().setAttribute("tabIndex",
a);
}},
_applySelectable:function(a){this._applyCursor(this.getCursor());
this._containerElement.setAttribute("qxSelectable",
a?"on":"off");
if(qx.core.Variant.isSet("qx.client",
"webkit")){this._containerElement.setStyle("userSelect",
a?"normal":"none");
}},
_applyEnabled:function(a,
b){if(a===false){this.addState("disabled");
this.removeState("hovered");
if(this.isFocusable()){this.blur();
this._applyFocusable(false,
true);
}}else{this.removeState("disabled");
if(this.isFocusable()){this._applyFocusable(true,
false);
}}},
_applyDraggable:function(a,
b){qx.ui.core.DragDropCursor.getInstance();
if(a){this.addListener("dragstart",
this._onDragStart);
this.addListener("drag",
this._onDrag);
this.addListener("dragend",
this._onDragEnd);
this.addListener("dragchange",
this._onDragChange);
}else{this.removeListener("dragstart",
this._onDragStart);
this.removeListener("drag",
this._onDrag);
this.removeListener("dragend",
this._onDragEnd);
this.removeListener("dragchange",
this._onDragChange);
}this._containerElement.setAttribute("qxDraggable",
a?"on":null);
},
_applyDroppable:function(a,
b){this._containerElement.setAttribute("qxDroppable",
a?"on":null);
},
_onDragStart:function(a){qx.ui.core.DragDropCursor.getInstance().alignToMouse(a);
this.getApplicationRoot().setGlobalCursor("default");
},
_onDrag:function(a){qx.ui.core.DragDropCursor.getInstance().alignToMouse(a);
},
_onDragEnd:function(a){qx.ui.core.DragDropCursor.getInstance().moveTo(-1000,
-1000);
this.getApplicationRoot().resetGlobalCursor();
},
_onDragChange:function(a){var b=qx.ui.core.DragDropCursor.getInstance();
var c=a.getCurrentAction();
c?b.setAction(c):b.resetAction();
},
visualizeFocus:function(){this.addState("focused");
},
visualizeBlur:function(){this.removeState("focused");
},
scrollChildIntoView:function(a,
b,
c){this.scrollChildIntoViewX(a,
b);
this.scrollChildIntoViewY(a,
c);
},
scrollChildIntoViewX:function(a,
b){this._contentElement.scrollChildIntoViewX(a.getContainerElement(),
b);
},
scrollChildIntoViewY:function(a,
b){this._contentElement.scrollChildIntoViewY(a.getContainerElement(),
b);
},
supportsDrop:function(a){var b=this.getSupportsDropMethod();
if(b!==null){return b.call(this,
a);
}return (this!=a.sourceWidget);
},
focus:function(){if(this.isFocusable()){this.getFocusElement().focus();
}else{throw new Error("Widget is not focusable!");
}},
blur:function(){if(this.isFocusable()){this.getFocusElement().blur();
}else{throw new Error("Widget is not focusable!");
}},
activate:function(){this._containerElement.activate();
},
deactivate:function(){this._containerElement.deactivate();
},
tabFocus:function(){this.getFocusElement().focus();
},
_hasChildControl:function(a){if(!this.__childControls){return false;
}return !!this.__childControls[a];
},
_getChildControl:function(a,
b){if(!this.__childControls){if(b){return null;
}this.__childControls={};
}var c=this.__childControls[a];
if(c){return c;
}
if(b===true){return null;
}return this._createChildControl(a);
},
_showChildControl:function(a){var b=this._getChildControl(a);
b.show();
return b;
},
_excludeChildControl:function(a){var b=this._getChildControl(a,
true);
if(b){b.exclude();
}},
_isChildControlVisible:function(a){var b=this._getChildControl(a,
true);
if(b){return b.isVisible();
}return false;
},
_createChildControl:function(a){if(!this.__childControls){this.__childControls={};
}else if(this.__childControls[a]){throw new Error("Child control '"+a+"' already created!");
}var b=this._createChildControlImpl(a);
if(!b){throw new Error("Unsupported control: "+a);
}b.$$subcontrol=a;
b.$$subparent=this;
var c=this.__states;
var d=this._forwardStates;
if(c&&d&&b instanceof qx.ui.core.Widget){for(var e in c){if(d[e]){b.addState(e);
}}}return this.__childControls[a]=b;
},
_createChildControlImpl:function(a){return null;
},
_disposeChildControls:function(){var a=this.__childControls;
if(!a){return;
}
for(var b in a){a[b].dispose();
}delete this.__childControls;
},
_findTopControl:function(){var a=this;
while(a){if(!a.$$subparent){return a;
}a=a.$$subparent;
}return null;
},
getContainerLocation:function(a){var b=this.getContainerElement().getDomElement();
return b?qx.bom.element.Location.get(b,
a):null;
},
getContentLocation:function(a){var b=this.getContainerElement().getDomElement();
return b?qx.bom.element.Location.get(b,
a):null;
},
setDomLeft:function(a){var b=this.getContainerElement().getDomElement();
if(b){b.style.left=a+"px";
}else{throw new Error("DOM element is not yet created!");
}},
setDomTop:function(a){var b=this.getContainerElement().getDomElement();
if(b){b.style.top=a+"px";
}else{throw new Error("DOM element is not yet created!");
}},
setDomPosition:function(a,
b){var c=this.getContainerElement().getDomElement();
if(c){c.style.left=a+"px";
c.style.top=b+"px";
}else{throw new Error("DOM element is not yet created!");
}},
destroy:function(){var a=this.getLayoutParent();
if(a){a.remove(this);
}qx.ui.core.queue.Dispose.add(this);
},
clone:function(){var a=arguments.callee.base.call(this);
if(this.getChildren){var b=this.getChildren();
for(var c=0,
d=b.length;c<d;c++){a.add(b[c].clone());
}}return a;
},
serialize:function(){var a=arguments.callee.base.call(this);
if(this.getChildren){var b=this.getChildren();
if(b.length>0){a.children=[];
for(var c=0,
d=b.length;c<d;c++){a.children.push(b[c].serialize());
}}}
if(this.getLayout){var e=this.getLayout();
if(e){a.layout=e.serialize();
}}return a;
}},
destruct:function(){this._disposeChildControls();
this._disposeArray("__children");
this._disposeObjects("__states",
"_containerElement",
"_contentElement",
"_decorationElement");
}});
qx.Class.define("qx.ui.splitpane.Pane",
{extend:qx.ui.core.Widget,
construct:function(a){arguments.callee.base.call(this);
if(a){this.setOrientation(a);
}else{this.initOrientation();
}this.addListener("mousedown",
this._onMouseDown);
this.addListener("mouseup",
this._onMouseUp);
this.addListener("mousemove",
this._onMouseMove);
this.addListener("mouseout",
this._onMouseOut);
this.addListener("losecapture",
this._onMouseUp);
},
properties:{appearance:{refine:true,
init:"splitpane"},
orientation:{check:["horizontal",
"vertical"],
apply:"_applyOrientation"}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "slider":b=new qx.ui.splitpane.Slider(this);
b.exclude();
this._add(b,
{type:a});
break;
case "splitter":b=new qx.ui.splitpane.Splitter(this);
this._add(b,
{type:a});
b.addListener("move",
this._onSplitterMove,
this);
break;
}return b||arguments.callee.base.call(this,
a);
},
_applyOrientation:function(a,
b){var c=this._getChildControl("slider");
var d=this._getChildControl("splitter");
this._isHorizontal=a==="horizontal";
var e=this._getLayout();
if(e){e.dispose();
}var f=a==="vertical"?new qx.ui.layout.VSplit:new qx.ui.layout.HSplit;
this._setLayout(f);
d.replaceState(b,
a);
d._getChildControl("knob").replaceState(b,
a);
c.replaceState(b,
a);
},
add:function(a,
b){if(b==null){this._add(a);
}else{this._add(a,
{flex:b});
}},
remove:function(a){this._remove(a);
},
_onMouseDown:function(a){if(!a.isLeftPressed()){return;
}var b=this._getChildControl("splitter");
if(!b.hasState("active")){return;
}var c=b.getContainerLocation();
var d=this.getContentLocation();
this.__splitterOffset=this._isHorizontal?a.getDocumentLeft()-c.left+d.left:a.getDocumentTop()-c.top+d.top;
var f=this._getChildControl("slider");
var g=b.getBounds();
f.setUserBounds(g.left,
g.top,
g.width,
g.height);
f.setZIndex(b.getZIndex()+1);
f.show();
this.__activeDragSession=true;
this.capture();
},
_onMouseMove:function(a){this.__lastMouseX=a.getDocumentLeft();
this.__lastMouseY=a.getDocumentTop();
if(this.__activeDragSession){this.__cp();
var b=this._getChildControl("slider");
if(this._isHorizontal){b.setDomLeft(this._beginSize);
}else{b.setDomTop(this._beginSize);
}}else{this.__co();
}},
_onMouseOut:function(a){return;
this.__lastMouseX=-1;
this.__lastMouseY=-1;
this.__co();
},
_onMouseUp:function(a){if(!this.__activeDragSession){return;
}this.__cm();
var b=this._getChildControl("slider");
b.exclude();
delete this.__activeDragSession;
this.releaseCapture();
this.__co();
},
_onSplitterMove:function(){this.__co();
},
__cm:function(){var a=this._beginSize;
var b=this._endSize;
if(a==null){return;
}var c=this._getChildren();
var d=c[2];
var e=c[3];
var f=d.getLayoutProperties().flex;
var g=e.getLayoutProperties().flex;
if((f!=0)&&(g!=0)){d.setLayoutProperties({flex:a});
e.setLayoutProperties({flex:b});
}else{if(this._isHorizontal){d.setWidth(a);
e.setWidth(b);
}else{d.setHeight(a);
e.setHeight(b);
}}},
__cn:function(){var a=this._getChildControl("splitter");
var b=a.getBounds();
var c=this.getContentLocation();
if(!c){return;
}var d=this.__lastMouseX;
var e=b.width;
var f=c.left+b.left;
if(e<5){f-=Math.floor((5-e)/2);
}
if(d<f||d>(f+e)){return false;
}var d=this.__lastMouseY;
var e=b.height;
var f=c.top+b.top;
if(e<5){f-=Math.floor((5-e)/2);
}
if(d<f||d>(f+e)){return false;
}return true;
},
__co:function(){var a=this._getChildControl("splitter");
var b=this.getApplicationRoot();
if(this.__activeDragSession||this.__cn()){var c=this._isHorizontal?"col-resize":"row-resize";
this.setCursor(c);
b.setGlobalCursor(c);
a.addState("active");
}else if(a.hasState("active")){this.resetCursor();
b.resetGlobalCursor();
a.removeState("active");
}},
__cp:function(){if(this._isHorizontal){var a="minWidth",
b="width",
c="maxWidth",
d=this.__lastMouseX;
}else{var a="minHeight",
b="height",
c="maxHeight",
d=this.__lastMouseY;
}var e=this._getChildren();
var f=e[2].getSizeHint();
var g=e[3].getSizeHint();
var h=e[2].getBounds()[b]+e[3].getBounds()[b];
var i=d-this.__splitterOffset;
var j=h-i;
if(i<f[a]){j-=f[a]-i;
i=f[a];
}else if(j<g[a]){i-=g[a]-j;
j=g[a];
}if(i>f[c]){j+=i-f[c];
i=f[c];
}else if(j>g[c]){i+=j-g[c];
j=g[c];
}this._beginSize=i;
this._endSize=j;
}}});
qx.Class.define("qx.ui.core.queue.Layout",
{statics:{__cq:{},
add:function(a){this.__cq[a.$$hash]=a;
qx.ui.core.queue.Manager.scheduleFlush("layout");
},
flush:function(){var a=this.__cs();
for(var b=a.length-1;b>=0;b--){var c=a[b];
if(c.hasValidLayout()){continue;
}if(c.isRootWidget()&&!c.hasUserBounds()){var d=c.getSizeHint();
c.renderLayout(0,
0,
d.width,
d.height);
}else{var e=c.getBounds();
c.renderLayout(e.left,
e.top,
e.width,
e.height);
}}},
getNestingLevel:function(a){var b=this.__nesting;
var c=0;
var d=a;
while(true){if(b[d.$$hash]!=null){c+=b[d.$$hash];
break;
}
if(!d._parent){break;
}d=d._parent;
c+=1;
}var e=c;
while(a&&a!==d){b[a.$$hash]=e--;
a=a._parent;
}return c;
},
isWidgetVisible:function(a){var b=this.__visibility;
var c=a;
var d=false;
while(c){if(b[c.$$hash]!=null){d=b[c.$$hash];
break;
}if(c.isRootWidget()){d=true;
break;
}if(!c.shouldBeLayouted()){break;
}c=c._parent;
}while(a&&a!==c){b[a.$$hash]=d;
a=a._parent;
}return d;
},
__cr:function(){this.__visibility={};
this.__nesting={};
var a=[];
var b=this.__cq;
var c,
d;
for(var e in b){c=b[e];
if(this.isWidgetVisible(c)){d=this.getNestingLevel(c);
if(!a[d]){a[d]={};
}a[d][e]=c;
delete b[e];
}}return a;
},
__cs:function(){var a=[];
var b=this.__cr();
for(var c=b.length-1;c>=0;c--){if(!b[c]){continue;
}
for(var d in b[c]){var e=b[c][d];
if(c==0||e.isRootWidget()||e.hasUserBounds()){a.push(e);
e.invalidateLayoutCache();
continue;
}var f=e.getSizeHint(false);
if(f){e.invalidateLayoutCache();
var g=e.getSizeHint();
var h=(!e.getBounds()||f.minWidth!==g.minWidth||f.width!==g.width||f.maxWidth!==g.maxWidth||f.minHeight!==g.minHeight||f.height!==g.height||f.maxHeight!==g.maxHeight);
}else{h=true;
}
if(h){var i=e.getLayoutParent();
if(!b[c-1]){b[c-1]={};
}b[c-1][i.$$hash]=i;
}else{a.push(e);
}}}return a;
}}});
qx.Class.define("qx.event.handler.UserAction",
{extend:qx.core.Object,
implement:qx.event.IEventHandler,
construct:function(a){arguments.callee.base.call(this);
this._manager=a;
this._window=a.getWindow();
},
statics:{PRIORITY:qx.event.Registration.PRIORITY_NORMAL,
SUPPORTED_TYPES:{useraction:1},
TARGET_CHECK:qx.event.IEventHandler.TARGET_WINDOW,
IGNORE_CAN_HANDLE:true},
members:{canHandleEvent:function(a,
b){},
registerEvent:function(a,
b,
c){},
unregisterEvent:function(a,
b,
c){}},
destruct:function(){this._disposeFields("_manager",
"_window");
},
defer:function(a){qx.event.Registration.addHandler(a);
}});
qx.Class.define("qx.html.Element",
{extend:qx.core.Object,
construct:function(a){arguments.callee.base.call(this);
this._nodeName=a||"div";
this._children=[];
},
statics:{_debug:false,
_modified:{},
_visibility:{},
_scroll:{},
_actions:{},
_supportedActions:["activate",
"focus",
"capture"],
_scheduleFlush:function(a){qx.html.Element.__deferredCall.schedule();
},
_mshtmlVisibilitySort:qx.core.Variant.select("qx.client",
{"mshtml":function(c,
d){var e=c._element;
var f=d._element;
if(e.contains(f)){return 1;
}
if(f.contains(e)){return -1;
}return 0;
},
"default":null}),
flush:function(){var a;
{if(this._debug){qx.log.Logger.debug(this,
"Flushing elements...");
}};
var b=[];
var c=this._modified;
for(var d in c){a=c[d];
if(a.__cu()){if(a._element&&qx.dom.Hierarchy.isRendered(a._element)){b.push(a);
}else{{if(this._debug){a.debug("Flush invisible element");
}};
a.__ct();
}delete c[d];
}}
for(var e=0,
f=b.length;e<f;e++){a=b[e];
{if(this._debug){a.debug("Flush rendered element");
}};
a.__ct();
}var g=this._visibility;
if(qx.core.Variant.isSet("qx.client",
"mshtml")){var h=[];
for(var d in g){h.push(g[d]);
}if(h.length>1){h.sort(this._mshtmlVisibilitySort);
g=this._visibility={};
for(var e=0;e<h.length;e++){a=h[e];
g[a.$$hash]=a;
}}}
for(var d in g){a=g[d];
{if(this._debug){qx.log.Logger.debug(this,
"Switching visibility to: "+a._visible);
}};
a._element.style.display=a._visible?"":"none";
delete g[d];
}var j=this._scroll;
for(var d in j){a=j[d];
var k=a._element;
if(k&&k.offsetWidth){var m=true;
if(a.__lazyScrollX!=null){a._element.scrollLeft=a.__lazyScrollX;
delete a.__lazyScrollX;
}if(a.__lazyScrollY!=null){a._element.scrollTop=a.__lazyScrollY;
delete a.__lazyScrollY;
}var n=a.__lazyScrollIntoViewX;
if(n!=null){var o=n.element.getDomElement();
if(o&&o.offsetWidth){qx.bom.element.Scroll.intoViewX(o,
k,
n.align);
delete a.__lazyScrollIntoViewX;
}else{m=false;
}}var p=a.__lazyScrollIntoViewY;
if(p!=null){var o=p.element.getDomElement();
if(o&&o.offsetWidth){qx.bom.element.Scroll.intoViewY(o,
k,
p.align);
delete a.__lazyScrollIntoViewY;
}else{m=false;
}}if(m){delete j[d];
}}}var q=this._actions;
var r=this._supportedActions;
var s,
t;
for(var e=0,
f=r.length;e<f;e++){s=r[e];
if(q[s]){t=q[s]._element;
if(t){qx.bom.Element[s](t);
}delete q[s];
}}qx.event.handler.Appear.refresh();
}},
members:{_element:null,
_root:false,
_included:true,
_visible:true,
_scheduleChildrenUpdate:function(){if(this._modifiedChildren){return;
}this._modifiedChildren=true;
qx.html.Element._modified[this.$$hash]=this;
qx.html.Element._scheduleFlush("element");
},
_createDomElement:function(){return qx.bom.Element.create(this._nodeName);
},
__ct:function(){{if(this._debug){this.debug("Flush: "+this.getAttribute("id"));
}};
var a=this._children;
var b=a.length;
var c;
for(var d=0;d<b;d++){c=a[d];
if(c._visible&&c._included&&!c._element){c.__ct();
}}
if(!this._element){this._element=this._createDomElement();
this._element.$$hash=this.$$hash;
this._copyData();
if(b>0){this._insertChildren();
}}else{this._syncData();
if(this._modifiedChildren){this._syncChildren();
}}delete this._modifiedChildren;
},
_insertChildren:function(){var a=this._children;
var b=a.length;
var c;
if(b>2){var d=document.createDocumentFragment();
for(var e=0;e<b;e++){c=a[e];
if(c._element&&c._included){d.appendChild(c._element);
}}this._element.appendChild(d);
}else{var d=this._element;
for(var e=0;e<b;e++){c=a[e];
if(c._element&&c._included){d.appendChild(c._element);
}}}},
_syncChildren:function(){var a=qx.core.ObjectRegistry;
var b=this._children;
var c=b.length;
var d;
var e;
var f=this._element;
var g=f.childNodes;
var h=0;
var j;
{var k=0;
};
for(var l=g.length-1;l>=0;l--){j=g[l];
e=a.fromHashCode(j.$$hash);
if(!e||!e._included||e._parent!==this){f.removeChild(j);
{k++;
};
}}for(var l=0;l<c;l++){d=b[l];
if(d._included){e=d._element;
j=g[h];
if(!e){continue;
}if(e!=j){if(j){f.insertBefore(e,
j);
}else{f.appendChild(e);
}{k++;
};
}h++;
}}{if(qx.html.Element._debug){this.debug("Synced DOM with "+k+" operations");
}};
},
_copyData:function(){var a=this._element;
var b=this.__attribValues;
if(b){var c=qx.bom.element.Attribute;
for(var d in b){c.set(a,
d,
b[d]);
}}var b=this.__styleValues;
if(b){var e=qx.bom.element.Style;
e.setCss(a,
e.compile(b));
}var b=this.__propertyValues;
if(b){for(var d in b){this._applyProperty(d,
b[d]);
}}var b=this.__eventValues;
if(b){qx.event.Registration.getManager(a).importListeners(a,
b);
delete this.__eventValues;
}},
_syncData:function(){var a=this._element;
var b=qx.bom.element.Attribute;
var c=qx.bom.element.Style;
var d=this.__attribJobs;
if(d){var e=this.__attribValues;
if(e){var f;
for(var g in d){f=e[g];
if(f!==undefined){b.set(a,
g,
f);
}else{b.reset(a,
g);
}}}this.__attribJobs=null;
}var d=this.__styleJobs;
if(d){var e=this.__styleValues;
if(e){var f;
for(var g in d){f=e[g];
if(f!==undefined){c.set(a,
g,
f);
}else{c.reset(a,
g);
}}}this.__styleJobs=null;
}var d=this.__propertyJobs;
if(d){var e=this.__propertyValues;
if(e){var f;
for(var g in d){this._applyProperty(g,
e[g]);
}}this.__propertyJobs=null;
}},
__cu:function(){var a=this;
while(a){if(a._root){return true;
}
if(!a._included||!a._visible){return false;
}a=a._parent;
}return false;
},
__cv:function(a,
b,
c,
d){var e=qx.core.ObjectRegistry;
var f="evt-"+a+"-"+e.toHashCode(b);
if(c){f+="-"+e.toHashCode(c);
}
if(d){f+="-capture";
}return f;
},
__cw:function(a){if(a._parent===this){throw new Error("Child is already in: "+a);
}
if(a._root){throw new Error("Root elements could not be inserted into other ones.");
}if(a._parent){a._parent.remove(a);
}a._parent=this;
if(this._element){this._scheduleChildrenUpdate();
}},
__cx:function(a){if(a._parent!==this){throw new Error("Has no child: "+a);
}if(this._element){this._scheduleChildrenUpdate();
}delete a._parent;
},
__cy:function(a){if(a._parent!==this){throw new Error("Has no child: "+a);
}if(this._element){this._scheduleChildrenUpdate();
}},
getChildren:function(){return qx.lang.Array.copy(this._children);
},
getChild:function(a){return this._children[a]||null;
},
hasChildren:function(){return this._children[0]==undefined;
},
indexOf:function(a){return this._children.indexOf(a);
},
hasChild:function(a){return this._children.indexOf(a)!==-1;
},
add:function(a){var b=this._children;
if(arguments[1]){for(var c=0,
d=arguments.length;c<d;c++){this.__cw(arguments[c]);
}b.push.apply(b,
arguments);
}else{this.__cw(a);
b.push(a);
}return this;
},
addAt:function(a,
b){this.__cw(a);
qx.lang.Array.insertAt(this._children,
a,
b);
return this;
},
remove:function(a){if(arguments[1]){var b;
for(var c=0,
d=arguments.length;c<d;c++){b=arguments[c];
this.__cx(b);
qx.lang.Array.remove(this._children,
b);
}}else{this.__cx(a);
qx.lang.Array.remove(this._children,
a);
}return this;
},
removeAt:function(a){var b=this._children[a];
if(!b){throw new Error("Has no child at this position!");
}this.__cx(b);
qx.lang.Array.removeAt(this._children,
a);
return this;
},
removeAll:function(){var a=this._children;
for(var b=0,
c=a.length;b<c;b++){this.__cx(a[b]);
}a.length=0;
return this;
},
getParent:function(){return this._parent||null;
},
insertInto:function(a,
b){a.__cw(this);
if(b==null){a._children.push(this);
}else{qx.lang.Array.insertAt(this._children,
this,
b);
}return this;
},
insertBefore:function(a){var b=a._parent;
b.__cw(this);
qx.lang.Array.insertBefore(b._children,
this,
a);
return this;
},
insertAfter:function(a){var b=a._parent;
b.__cw(this);
qx.lang.Array.insertAfter(b._children,
this,
a);
return this;
},
moveTo:function(a){var b=this._parent;
b.__cy(this);
var c=b._children.indexOf(this);
if(c===a){throw new Error("Could not move to same index!");
}else if(c<a){a--;
}qx.lang.Array.removeAt(b._children,
c);
qx.lang.Array.insertAt(b._children,
this,
a);
return this;
},
moveBefore:function(a){var b=this._parent;
return this.moveTo(b._children.indexOf(a));
},
moveAfter:function(a){var b=this._parent;
return this.moveTo(b._children.indexOf(a)+1);
},
free:function(){var a=this._parent;
if(!a){throw new Error("Has no parent to remove from.");
}a.__cx(this);
qx.lang.Array.remove(a._children,
this);
return this;
},
getDomElement:function(){return this._element||null;
},
getNodeName:function(){return this._nodeName;
},
isFocusable:function(){var a=this.getAttribute("tabIndex");
if(a>=1){return true;
}var b=qx.event.handler.Focus.FOCUSABLE_ELEMENTS;
if(a>=0&&b[this._nodeName]){return true;
}return false;
},
isNativelyFocusable:function(){return !!qx.event.handler.Focus.FOCUSABLE_ELEMENTS[this._nodeName];
},
include:function(){if(this._included){return;
}delete this._included;
if(this._parent){this._parent._scheduleChildrenUpdate();
}return this;
},
exclude:function(){if(!this._included){return;
}this._included=false;
if(this._parent){this._parent._scheduleChildrenUpdate();
}return this;
},
isIncluded:function(){return this._included===true;
},
show:function(){if(this._visible){return;
}
if(this._element){qx.html.Element._visibility[this.$$hash]=this;
qx.html.Element._scheduleFlush("element");
}if(this._parent){this._parent._scheduleChildrenUpdate();
}delete this._visible;
},
hide:function(){if(!this._visible){return;
}
if(this._element){qx.html.Element._visibility[this.$$hash]=this;
qx.html.Element._scheduleFlush("element");
}this._visible=false;
},
isVisible:function(){return this._visible===true;
},
scrollChildIntoViewX:function(a,
b){var c=this._element;
var d=a.getDomElement();
if(c&&c.offsetWidth&&d&&d.offsetWidth){qx.bom.element.Scroll.intoViewX(d,
c,
b);
}else{this.__lazyScrollIntoViewX={element:a,
align:b};
qx.html.Element._scroll[this.$$hash]=this;
qx.html.Element._scheduleFlush("element");
}delete this.__lazyScrollX;
},
scrollChildIntoViewY:function(a,
b){var c=this._element;
var d=a.getDomElement();
if(c&&c.offsetWidth&&d&&d.offsetWidth){qx.bom.element.Scroll.intoViewY(d,
c,
b);
}else{this.__lazyScrollIntoViewY={element:a,
align:b};
qx.html.Element._scroll[this.$$hash]=this;
qx.html.Element._scheduleFlush("element");
}delete this.__lazyScrollY;
},
scrollToX:function(a,
b){var c=this._element;
if(b!==true&&c&&c.offsetWidth){c.scrollLeft=a;
}else{this.__lazyScrollX=a;
qx.html.Element._scroll[this.$$hash]=this;
qx.html.Element._scheduleFlush("element");
}delete this.__lazyScrollIntoViewX;
},
getScrollX:function(){var a=this._element;
if(a){return a.scrollLeft;
}return this.__lazyScrollX||0;
},
scrollToY:function(a,
b){var c=this._element;
if(b!==true&&c&&c.offsetWidth){c.scrollTop=a;
}else{this.__lazyScrollY=a;
qx.html.Element._scroll[this.$$hash]=this;
qx.html.Element._scheduleFlush("element");
}delete this.__lazyScrollIntoViewY;
},
getScrollY:function(){var a=this._element;
if(a){return a.scrollTop;
}return this.__lazyScrollY||0;
},
getSelection:function(){var a=this._element;
if(a){return qx.bom.Selection.get(a);
}return null;
},
getSelectionLength:function(){var a=this._element;
if(a){return qx.bom.Selection.getLength(a);
}return null;
},
setSelection:function(a,
b){var c=this._element;
if(c){qx.bom.Selection.set(c,
a,
b);
}},
clearSelection:function(){var a=this._element;
if(a){qx.bom.Selection.clear(a);
}},
focus:function(){var a=this._element;
if(a){return qx.bom.Element.focus(a);
}qx.html.Element._actions.focus=this;
qx.html.Element._scheduleFlush("element");
},
blur:function(){var a=this._element;
if(a){qx.bom.Element.blur(a);
}},
activate:function(){var a=this._element;
if(a){return qx.bom.Element.activate(a);
}qx.html.Element._actions.activate=this;
qx.html.Element._scheduleFlush("element");
},
deactivate:function(){var a=this._element;
if(a){qx.bom.Element.deactivate(a);
}},
capture:function(){var a=this._element;
if(a){return qx.bom.Element.capture(a);
}qx.html.Element._actions.capture=this;
qx.html.Element._scheduleFlush("element");
},
releaseCapture:function(){var a=this._element;
if(a){qx.bom.Element.releaseCapture(a);
}},
setStyle:function(a,
b,
c){if(!this.__styleValues){this.__styleValues={};
}
if(this.__styleValues[a]==b){return;
}
if(b==null){delete this.__styleValues[a];
}else{this.__styleValues[a]=b;
}if(this._element){if(c){qx.bom.element.Style.set(this._element,
a,
b);
return this;
}if(!this.__styleJobs){this.__styleJobs={};
}this.__styleJobs[a]=true;
qx.html.Element._modified[this.$$hash]=this;
qx.html.Element._scheduleFlush("element");
}return this;
},
setStyles:function(a,
b){for(var c in a){this.setStyle(c,
a[c],
b);
}return this;
},
removeStyle:function(a,
b){this.setStyle(a,
null,
b);
},
getStyle:function(a){return this.__styleValues?this.__styleValues[a]:null;
},
setAttribute:function(a,
b,
c){if(!this.__attribValues){this.__attribValues={};
}
if(this.__attribValues[a]==b){return;
}
if(b==null){delete this.__attribValues[a];
}else{this.__attribValues[a]=b;
}if(this._element){if(c){qx.bom.element.Attribute.set(this._element,
a,
b);
return this;
}if(!this.__attribJobs){this.__attribJobs={};
}this.__attribJobs[a]=true;
qx.html.Element._modified[this.$$hash]=this;
qx.html.Element._scheduleFlush("element");
}return this;
},
setAttributes:function(a,
b){for(var c in a){this.setAttribute(c,
a[c],
b);
}return this;
},
removeAttribute:function(a,
b){this.setAttribute(a,
null,
b);
},
getAttribute:function(a){return this.__attribValues?this.__attribValues[a]:null;
},
_applyProperty:function(a,
b){},
_setProperty:function(a,
b,
c){if(!this.__propertyValues){this.__propertyValues={};
}
if(this.__propertyValues[a]==b){return;
}
if(b==null){delete this.__propertyValues[a];
}else{this.__propertyValues[a]=b;
}if(this._element){if(c){this._applyProperty(a,
b);
return this;
}if(!this.__propertyJobs){this.__propertyJobs={};
}this.__propertyJobs[a]=true;
qx.html.Element._modified[this.$$hash]=this;
qx.html.Element._scheduleFlush("element");
}return this;
},
_removeProperty:function(a,
b){this._setProperty(a,
null,
b);
},
_getProperty:function(a){return this.__propertyValues?this.__propertyValues[a]:null;
},
addListener:function(a,
b,
c,
d){if(this.isDisposed()){return;
}{var e="Failed to add event listener for type '"+a+"'"+" to the target '"+this+"': ";
this.assertString(a,
e+"Invalid event type.");
this.assertFunction(b,
e+"Invalid callback function");
if(c!==undefined){this.assertObject(c,
"Invalid context for callback.");
}
if(d!==undefined){this.assertBoolean(d,
"Invalid capture falg.");
}};
if(this._element){qx.event.Registration.addListener(this._element,
a,
b,
c,
d);
}else{if(!this.__eventValues){this.__eventValues={};
}var f=this.__cv(a,
b,
c,
d);
if(this.__eventValues[f]){this.warn("A listener of this configuration does already exist!");
return false;
}this.__eventValues[f]={type:a,
listener:b,
self:c,
capture:d};
}return this;
},
removeListener:function(a,
b,
c,
d){if(this.isDisposed()){return;
}{var e="Failed to dd event listener for type '"+a+"'"+" to the target '"+this+"': ";
this.assertString(a,
e+"Invalid event type.");
this.assertFunction(b,
e+"Invalid callback function");
if(c!==undefined){this.assertObject(c,
"Invalid context for callback.");
}
if(d!==undefined){this.assertBoolean(d,
"Invalid capture falg.");
}};
if(this._element){qx.event.Registration.removeListener(this._element,
a,
b,
c,
d);
}else{var f=this.__cv(a,
b,
c,
d);
if(!this.__eventValues||!this.__eventValues[f]){this.warn("A listener of this configuration does not exist!");
return false;
}delete this.__eventValues[f];
}return this;
},
hasListener:function(a,
b){throw new Error("hasListener() needs implementation!");
}},
defer:function(a){a.__deferredCall=new qx.util.DeferredCall(a.flush,
a);
},
destruct:function(){var a=this._element;
if(a){qx.event.Registration.getManager(a).removeAllListeners(a);
}
if(this._parent){this._parent.remove(this);
}this._disposeArray("_children");
this._disposeFields("__attribValues",
"__styleValues",
"__eventValues",
"__propertyValues",
"__attribJobs",
"__styleJobs",
"__propertyJobs",
"_element",
"_parent");
}});
qx.Class.define("qx.ui.core.queue.Manager",
{statics:{__cz:false,
__cA:{},
scheduleFlush:function(a){var b=qx.ui.core.queue.Manager;
b.__cA[a]=true;
if(!b.__cz){b.__deferredCall.schedule();
b.__cz=true;
}},
flush:function(){var a=qx.ui.core.queue.Manager;
if(a.__inFlush){return;
}a.__inFlush=true;
a.__deferredCall.cancel();
var b=a.__cA;
while(b.widget||b.appearance||b.decorator||b.layout){if(b.widget){delete b.widget;
qx.ui.core.queue.Widget.flush();
}
if(b.appearance){delete b.appearance;
qx.ui.core.queue.Appearance.flush();
}
if(b.layout){delete b.layout;
qx.ui.core.queue.Layout.flush();
}}qx.ui.core.queue.Manager.__cz=false;
if(b.element){delete b.element;
qx.html.Element.flush();
}
if(b.dispose){delete b.dispose;
qx.ui.core.queue.Dispose.flush();
}a.__inFlush=false;
}},
defer:function(a){a.__deferredCall=new qx.util.DeferredCall(a.flush);
qx.html.Element._scheduleFlush=a.scheduleFlush;
qx.event.Registration.addListener(window,
"useraction",
a.flush);
}});
qx.Class.define("qx.dom.Hierarchy",
{statics:{getNodeIndex:function(a){var b=0;
while(a&&(a=a.previousSibling)){b++;
}return b;
},
getElementIndex:function(a){var b=0;
var c=qx.dom.Node.ELEMENT;
while(a&&(a=a.previousSibling)){if(a.nodeType==c){b++;
}}return b;
},
getNextElementSibling:function(a){while(a&&(a=a.nextSibling)&&!qx.dom.Node.isElement(a)){continue;
}return a||null;
},
getPreviousElementSibling:function(a){while(a&&(a=a.previousSibling)&&!qx.dom.Node.isElement(a)){continue;
}return a||null;
},
contains:qx.core.Variant.select("qx.client",
{"webkit|mshtml|opera":function(a,
b){if(qx.dom.Node.isDocument(a)){var c=qx.dom.Node.getDocument(b);
return a&&c==a;
}else if(qx.dom.Node.isDocument(b)){return false;
}else{return a.contains(b);
}},
"gecko":function(a,
b){return !!(a.compareDocumentPosition(b)&16);
},
"default":function(a,
b){while(b){if(a==b){return true;
}b=b.parentNode;
}return false;
}}),
isRendered:function(a){if(!a.offsetParent){return false;
}var b=a.ownerDocument||a.document;
if(b.body.contains){return b.body.contains(a);
}if(b.compareDocumentPosition){return !!(b.compareDocumentPosition(a)&16);
}throw new Error("Missing support for isRendered()!");
},
isDescendantOf:function(a,
b){return this.contains(b,
a);
},
getCommonParent:qx.core.Variant.select("qx.client",
{"mshtml|opera":function(a,
b){if(a===b){return a;
}
while(a){if(a.contains(b)){return a;
}a=a.parentNode;
}return null;
},
"default":function(a,
b){if(a===b){return a;
}var c={};
var d=qx.core.ObjectRegistry;
var e,
f;
while(a||b){if(a){e=d.toHashCode(a);
if(c[e]){return c[e];
}c[e]=a;
a=a.parentNode;
}
if(b){f=d.toHashCode(b);
if(c[f]){return c[f];
}c[f]=b;
b=b.parentNode;
}}return null;
}}),
getAncestors:function(a){return this._recursivelyCollect(a,
"parentNode");
},
getChildElements:function(a){a=a.firstChild;
if(!a){return [];
}var b=this.getNextSiblings(a);
b.unshift(a);
return b;
},
getDescendants:function(a){return qx.lang.Array.fromCollection(a.getElementsByTagName("*"));
},
getFirstDescendant:function(a){a=a.firstChild;
while(a&&a.nodeType!=1){a=a.nextSibling;
}return a;
},
getLastDescendant:function(a){a=a.lastChild;
while(a&&a.nodeType!=1){a=a.previousSibling;
}return a;
},
getPreviousSiblings:function(a){return this._recursivelyCollect(a,
"previousSibling");
},
getNextSiblings:function(a){return this._recursivelyCollect(a,
"nextSibling");
},
_recursivelyCollect:function(a,
b){var c=[];
while(a=a[b]){if(a.nodeType==1){c.push(a);
}}return c;
},
getSiblings:function(a){return this.getPreviousSiblings(a).reverse().concat(this.getNextSiblings(a));
},
isEmpty:function(a){a=a.firstChild;
while(a){if(a.nodeType===qx.dom.Node.ELEMENT||a.nodeType===qx.dom.Node.TEXT){return false;
}a=a.nextSibling;
}return true;
},
cleanWhitespace:function(a){var b=a.firstChild;
while(b){var c=b.nextSibling;
if(b.nodeType==3&&!/\S/.test(b.nodeValue)){a.removeChild(b);
}b=c;
}}}});
qx.Class.define("qx.bom.element.Scroll",
{statics:{intoViewX:function(a,
b,
c){var d=a.parentNode;
var e=qx.dom.Node.getDocument(a);
var f=e.body;
var g,
h,
i;
var j,
k,
l;
var m,
n,
o;
var p,
q,
r,
s;
var t,
u,
v;
var w=c==="left";
var x=c==="right";
b=b?b.parentNode:e;
while(d&&d!=b){if(d.scrollWidth>d.clientWidth&&(d===f||qx.bom.element.Overflow.getY(d)!="visible")){if(d===f){h=d.scrollLeft;
i=h+qx.bom.Viewport.getWidth();
j=qx.bom.Viewport.getWidth();
k=d.clientWidth;
l=d.scrollWidth;
m=0;
n=0;
o=0;
}else{g=qx.bom.element.Location.get(d);
h=g.left;
i=g.right;
j=d.offsetWidth;
k=d.clientWidth;
l=d.scrollWidth;
m=parseInt(qx.bom.element.Style.get(d,
"borderLeftWidth"),
10)||0;
n=parseInt(qx.bom.element.Style.get(d,
"borderRightWidth"),
10)||0;
o=j-k-m-n;
}p=qx.bom.element.Location.get(a);
q=p.left;
r=p.right;
s=a.offsetWidth;
t=q-h-m;
u=r-i+n;
v=0;
if(w){v=t;
}else if(x){v=u+o;
}else if(t<0||s>k){v=t;
}else if(u>0){v=u+o;
}d.scrollLeft+=v;
if(qx.bom.client.Engine.GECKO){qx.event.Registration.fireNonBubblingEvent(d,
"scroll");
}}
if(d===f){break;
}d=d.parentNode;
}},
intoViewY:function(a,
b,
c){var d=a.parentNode;
var e=qx.dom.Node.getDocument(a);
var f=e.body;
var g,
h,
i;
var j,
k,
l;
var m,
n,
o;
var p,
q,
r,
s;
var t,
u,
v;
var w=c==="top";
var x=c==="bottom";
b=b?b.parentNode:e;
while(d&&d!=b){if(d.scrollHeight>d.clientHeight&&(d===f||qx.bom.element.Overflow.getY(d)!="visible")){if(d===f){h=d.scrollTop;
i=h+qx.bom.Viewport.getHeight();
j=qx.bom.Viewport.getHeight();
k=d.clientHeight;
l=d.scrollHeight;
m=0;
n=0;
o=0;
}else{g=qx.bom.element.Location.get(d);
h=g.top;
i=g.bottom;
j=d.offsetHeight;
k=d.clientHeight;
l=d.scrollHeight;
m=parseInt(qx.bom.element.Style.get(d,
"borderTopWidth"),
10)||0;
n=parseInt(qx.bom.element.Style.get(d,
"borderBottomWidth"),
10)||0;
o=j-k-m-n;
}p=qx.bom.element.Location.get(a);
q=p.top;
r=p.bottom;
s=a.offsetHeight;
t=q-h-m;
u=r-i+n;
v=0;
if(w){v=t;
}else if(x){v=u+o;
}else if(t<0||s>k){v=t;
}else if(u>0){v=u+o;
}d.scrollTop+=v;
if(qx.bom.client.Engine.GECKO){qx.event.Registration.fireNonBubblingEvent(d,
"scroll");
}}
if(d===f){break;
}d=d.parentNode;
}},
intoView:function(a,
b,
c,
d){this.intoViewX(a,
b,
c);
this.intoViewY(a,
b,
d);
}}});
qx.Class.define("qx.event.handler.Appear",
{extend:qx.core.Object,
implement:qx.event.IEventHandler,
construct:function(a){arguments.callee.base.call(this);
this.__manager=a;
this.__targets={};
qx.event.handler.Appear.__cB[this.$$hash]=this;
},
statics:{PRIORITY:qx.event.Registration.PRIORITY_NORMAL,
SUPPORTED_TYPES:{appear:true,
disappear:true},
TARGET_CHECK:qx.event.IEventHandler.TARGET_DOMNODE,
IGNORE_CAN_HANDLE:true,
__cB:{},
refresh:function(){var a=this.__cB;
for(var b in a){a[b].refresh();
}}},
members:{canHandleEvent:function(a,
b){},
registerEvent:function(a,
b,
c){var d=qx.core.ObjectRegistry.toHashCode(a);
var e=this.__targets;
if(e&&!e[d]){e[d]=a;
a.$$displayed=a.offsetWidth>0;
}},
unregisterEvent:function(a,
b,
c){var d=qx.core.ObjectRegistry.toHashCode(a);
var e=this.__targets;
if(!e){return;
}
if(e[d]){delete e[d];
a.$$displayed=null;
}},
refresh:function(){var a=this.__targets;
var b;
for(var c in a){b=a[c];
var d=b.offsetWidth>0;
if((!!b.$$displayed)!==d){b.$$displayed=d;
var e=qx.event.Registration.createEvent(d?"appear":"disappear");
this.__manager.dispatchEvent(b,
e);
}}}},
destruct:function(){this._disposeFields("__manager",
"__targets");
delete qx.event.handler.Appear.__cB[this.$$hash];
},
defer:function(a){qx.event.Registration.addHandler(a);
}});
qx.Class.define("qx.event.dispatch.DomBubbling",
{extend:qx.event.dispatch.AbstractBubbling,
statics:{PRIORITY:qx.event.Registration.PRIORITY_NORMAL},
members:{_getParent:function(a){return a.parentNode;
},
canDispatchEvent:function(a,
b,
c){return a.nodeType!==undefined&&b.getBubbles();
}},
defer:function(a){qx.event.Registration.addDispatcher(a);
}});
qx.Class.define("qx.event.handler.Keyboard",
{extend:qx.core.Object,
implement:qx.event.IEventHandler,
construct:function(a){arguments.callee.base.call(this);
this._manager=a;
this._window=a.getWindow();
if(qx.core.Variant.isSet("qx.client",
"gecko")){this._root=this._window;
}else{this._root=this._window.document.documentElement;
}this._lastUpDownType={};
this._initKeyObserver();
},
statics:{PRIORITY:qx.event.Registration.PRIORITY_NORMAL,
SUPPORTED_TYPES:{keyup:1,
keydown:1,
keypress:1,
keyinput:1},
TARGET_CHECK:qx.event.IEventHandler.TARGET_DOMNODE,
IGNORE_CAN_HANDLE:true,
isValidKeyIdentifier:function(a){if(this._identifierToKeyCodeMap[a]){return true;
}
if(a.length!=1){return false;
}
if(a>="0"&&a<="9"){return true;
}
if(a>="A"&&a<="Z"){return true;
}
switch(a){case "+":case "-":case "*":case "/":return true;
default:return false;
}}},
members:{canHandleEvent:function(a,
b){},
registerEvent:function(a,
b,
c){},
unregisterEvent:function(a,
b,
c){},
_fireInputEvent:function(a,
b){var c=this._manager.getHandler(qx.event.handler.Focus);
var d=c.getActive();
if(!d||d.offsetWidth==0){d=c.getFocus();
}if(d&&d.offsetWidth!=0){var e=qx.event.Registration.createEvent("keyinput",
qx.event.type.KeyInput,
[a,
d,
b]);
this._manager.dispatchEvent(d,
e);
}qx.event.Registration.fireEvent(this._window,
"useraction");
},
_fireSequenceEvent:function(a,
b,
c){var d=this._manager.getHandler(qx.event.handler.Focus);
var e=d.getActive();
if(!e||e.offsetWidth==0){e=d.getFocus();
}if(!e||e.offsetWidth==0){e=this._manager.getWindow().document.body;
}var f=qx.event.Registration.createEvent(b,
qx.event.type.KeySequence,
[a,
e,
c]);
this._manager.dispatchEvent(e,
f);
qx.event.Registration.fireEvent(this._window,
"useraction");
},
_initKeyObserver:function(){this._onKeyUpDownWrapper=qx.lang.Function.listener(this._onKeyUpDown,
this);
this._onKeyPressWrapper=qx.lang.Function.listener(this._onKeyPress,
this);
var a=qx.bom.Event;
a.addNativeListener(this._root,
"keyup",
this._onKeyUpDownWrapper);
a.addNativeListener(this._root,
"keydown",
this._onKeyUpDownWrapper);
a.addNativeListener(this._root,
"keypress",
this._onKeyPressWrapper);
},
_stopKeyObserver:function(){var a=qx.bom.Event;
a.removeNativeListener(this._root,
"keyup",
this._onKeyUpDownWrapper);
a.removeNativeListener(this._root,
"keydown",
this._onKeyUpDownWrapper);
a.removeNativeListener(this._root,
"keypress",
this._onKeyPressWrapper);
},
_onKeyUpDown:qx.core.Variant.select("qx.client",
{"mshtml":function(a){a=window.event||a;
var b=a.keyCode;
var c=0;
var d=a.type;
if(!(this._lastUpDownType[b]=="keydown"&&d=="keydown")){this._idealKeyHandler(b,
c,
d,
a);
}if(d=="keydown"){if(this._isNonPrintableKeyCode(b)||b==8||b==9){this._idealKeyHandler(b,
c,
"keypress",
a);
}}this._lastUpDownType[b]=d;
},
"gecko":function(a){var b=this._keyCodeFix[a.keyCode]||a.keyCode;
var c=a.charCode;
var d=a.type;
if(qx.bom.client.Platform.WIN){var e=b?this._keyCodeToIdentifier(b):this._charCodeToIdentifier(c);
if(!(this._lastUpDownType[e]=="keypress"&&d=="keydown")){this._idealKeyHandler(b,
c,
d,
a);
}this._lastUpDownType[e]=d;
}else{this._idealKeyHandler(b,
c,
d,
a);
}},
"webkit":function(a){var b=0;
var c=a.type;
if(qx.bom.client.Engine.VERSION<525.13){var d=0;
if(c=="keyup"||c=="keydown"){d=this._charCode2KeyCode[a.charCode]||a.keyCode;
}else{if(this._charCode2KeyCode[a.charCode]){d=this._charCode2KeyCode[a.charCode];
}else{b=a.charCode;
}}this._idealKeyHandler(d,
b,
c,
a);
}else{var d=a.keyCode;
if(!(this._lastUpDownType[d]=="keydown"&&c=="keydown")){this._idealKeyHandler(d,
b,
c,
a);
}if(c=="keydown"){if(this._isNonPrintableKeyCode(d)||d==8||d==9){this._idealKeyHandler(d,
b,
"keypress",
a);
}}this._lastUpDownType[d]=c;
}},
"opera":function(a){this._idealKeyHandler(a.keyCode,
0,
a.type,
a);
}}),
_onKeyPress:qx.core.Variant.select("qx.client",
{"mshtml":function(a){var a=window.event||a;
if(this._charCode2KeyCode[a.keyCode]){this._idealKeyHandler(this._charCode2KeyCode[a.keyCode],
0,
a.type,
a);
}else{this._idealKeyHandler(0,
a.keyCode,
a.type,
a);
}},
"gecko":function(a){var b=this._keyCodeFix[a.keyCode]||a.keyCode;
var c=a.charCode;
var d=a.type;
this._idealKeyHandler(b,
c,
d,
a);
},
"webkit":function(a){if(qx.bom.client.Engine.VERSION<525.13){var b=0;
var c=0;
var d=a.type;
if(d=="keyup"||d=="keydown"){b=this._charCode2KeyCode[a.charCode]||a.keyCode;
}else{if(this._charCode2KeyCode[a.charCode]){b=this._charCode2KeyCode[a.charCode];
}else{c=a.charCode;
}}this._idealKeyHandler(b,
c,
d,
a);
}else{if(this._charCode2KeyCode[a.keyCode]){this._idealKeyHandler(this._charCode2KeyCode[a.keyCode],
0,
a.type,
a);
}else{this._idealKeyHandler(0,
a.keyCode,
a.type,
a);
}}},
"opera":function(a){if(this._keyCodeToIdentifierMap[a.keyCode]){this._idealKeyHandler(a.keyCode,
0,
a.type,
a);
}else{this._idealKeyHandler(0,
a.keyCode,
a.type,
a);
}}}),
_idealKeyHandler:function(a,
b,
c,
d){if(!a&&!b){return;
}var e;
if(a){e=this._keyCodeToIdentifier(a);
this._fireSequenceEvent(d,
c,
e);
}else{e=this._charCodeToIdentifier(b);
this._fireSequenceEvent(d,
"keypress",
e);
this._fireInputEvent(d,
b);
}},
_specialCharCodeMap:{8:"Backspace",
9:"Tab",
13:"Enter",
27:"Escape",
32:"Space"},
_keyCodeToIdentifierMap:{16:"Shift",
17:"Control",
18:"Alt",
20:"CapsLock",
224:"Meta",
37:"Left",
38:"Up",
39:"Right",
40:"Down",
33:"PageUp",
34:"PageDown",
35:"End",
36:"Home",
45:"Insert",
46:"Delete",
112:"F1",
113:"F2",
114:"F3",
115:"F4",
116:"F5",
117:"F6",
118:"F7",
119:"F8",
120:"F9",
121:"F10",
122:"F11",
123:"F12",
144:"NumLock",
44:"PrintScreen",
145:"Scroll",
19:"Pause",
91:"Win",
93:"Apps"},
_numpadToCharCode:{96:"0".charCodeAt(0),
97:"1".charCodeAt(0),
98:"2".charCodeAt(0),
99:"3".charCodeAt(0),
100:"4".charCodeAt(0),
101:"5".charCodeAt(0),
102:"6".charCodeAt(0),
103:"7".charCodeAt(0),
104:"8".charCodeAt(0),
105:"9".charCodeAt(0),
106:"*".charCodeAt(0),
107:"+".charCodeAt(0),
109:"-".charCodeAt(0),
110:",".charCodeAt(0),
111:"/".charCodeAt(0)},
_charCodeA:"A".charCodeAt(0),
_charCodeZ:"Z".charCodeAt(0),
_charCode0:"0".charCodeAt(0),
_charCode9:"9".charCodeAt(0),
_isNonPrintableKeyCode:function(a){return this._keyCodeToIdentifierMap[a]?true:false;
},
_isIdentifiableKeyCode:function(a){if(a>=this._charCodeA&&a<=this._charCodeZ){return true;
}if(a>=this._charCode0&&a<=this._charCode9){return true;
}if(this._specialCharCodeMap[a]){return true;
}if(this._numpadToCharCode[a]){return true;
}if(this._isNonPrintableKeyCode(a)){return true;
}return false;
},
_keyCodeToIdentifier:function(a){if(this._isIdentifiableKeyCode(a)){var b=this._numpadToCharCode[a];
if(b){return String.fromCharCode(b);
}return (this._keyCodeToIdentifierMap[a]||this._specialCharCodeMap[a]||String.fromCharCode(a));
}else{return "Unidentified";
}},
_charCodeToIdentifier:function(a){return this._specialCharCodeMap[a]||String.fromCharCode(a).toUpperCase();
},
_identifierToKeyCode:function(a){return qx.event.handler.Keyboard._identifierToKeyCodeMap[a]||a.charCodeAt(0);
}},
destruct:function(){this._stopKeyObserver();
this._disposeFields("_manager",
"_window",
"_root",
"_lastUpDownType");
},
defer:function(a,
b,
c){qx.event.Registration.addHandler(a);
if(!a._identifierToKeyCodeMap){a._identifierToKeyCodeMap={};
for(var d in b._keyCodeToIdentifierMap){a._identifierToKeyCodeMap[b._keyCodeToIdentifierMap[d]]=parseInt(d,
10);
}
for(var d in b._specialCharCodeMap){a._identifierToKeyCodeMap[b._specialCharCodeMap[d]]=parseInt(d,
10);
}}
if(qx.core.Variant.isSet("qx.client",
"mshtml")){b._charCode2KeyCode={13:13,
27:27};
}else if(qx.core.Variant.isSet("qx.client",
"gecko")){b._keyCodeFix={12:b._identifierToKeyCode("NumLock")};
}else if(qx.core.Variant.isSet("qx.client",
"webkit")){if(qx.bom.client.Engine.VERSION<525.13){b._charCode2KeyCode={63289:b._identifierToKeyCode("NumLock"),
63276:b._identifierToKeyCode("PageUp"),
63277:b._identifierToKeyCode("PageDown"),
63275:b._identifierToKeyCode("End"),
63273:b._identifierToKeyCode("Home"),
63234:b._identifierToKeyCode("Left"),
63232:b._identifierToKeyCode("Up"),
63235:b._identifierToKeyCode("Right"),
63233:b._identifierToKeyCode("Down"),
63272:b._identifierToKeyCode("Delete"),
63302:b._identifierToKeyCode("Insert"),
63236:b._identifierToKeyCode("F1"),
63237:b._identifierToKeyCode("F2"),
63238:b._identifierToKeyCode("F3"),
63239:b._identifierToKeyCode("F4"),
63240:b._identifierToKeyCode("F5"),
63241:b._identifierToKeyCode("F6"),
63242:b._identifierToKeyCode("F7"),
63243:b._identifierToKeyCode("F8"),
63244:b._identifierToKeyCode("F9"),
63245:b._identifierToKeyCode("F10"),
63246:b._identifierToKeyCode("F11"),
63247:b._identifierToKeyCode("F12"),
63248:b._identifierToKeyCode("PrintScreen"),
3:b._identifierToKeyCode("Enter"),
12:b._identifierToKeyCode("NumLock"),
13:b._identifierToKeyCode("Enter")};
}else{b._charCode2KeyCode={13:13,
27:27};
}}}});
qx.Class.define("qx.event.handler.Mouse",
{extend:qx.core.Object,
implement:qx.event.IEventHandler,
construct:function(a){arguments.callee.base.call(this);
this._manager=a;
this._window=a.getWindow();
this._root=this._window.document.documentElement;
this._initButtonObserver();
this._initMoveObserver();
this._initWheelObserver();
},
statics:{PRIORITY:qx.event.Registration.PRIORITY_NORMAL,
SUPPORTED_TYPES:{mousemove:1,
mouseover:1,
mouseout:1,
mousedown:1,
mouseup:1,
click:1,
dblclick:1,
contextmenu:1,
mousewheel:1},
TARGET_CHECK:qx.event.IEventHandler.TARGET_DOMNODE,
IGNORE_CAN_HANDLE:true},
members:{canHandleEvent:function(a,
b){},
registerEvent:function(a,
b,
c){},
unregisterEvent:function(a,
b,
c){},
__cC:function(a,
b,
c){if(!c){c=a.target||a.srcElement;
}qx.event.Registration.fireEvent(c,
b||a.type,
qx.event.type.Mouse,
[a,
c,
null,
true,
true]);
qx.event.Registration.fireEvent(this._window,
"useraction");
},
_initButtonObserver:function(){this._onButtonEventWrapper=qx.lang.Function.listener(this._onButtonEvent,
this);
var a=qx.bom.Event;
a.addNativeListener(this._root,
"mousedown",
this._onButtonEventWrapper);
a.addNativeListener(this._root,
"mouseup",
this._onButtonEventWrapper);
a.addNativeListener(this._root,
"click",
this._onButtonEventWrapper);
a.addNativeListener(this._root,
"dblclick",
this._onButtonEventWrapper);
a.addNativeListener(this._root,
"contextmenu",
this._onButtonEventWrapper);
},
_initMoveObserver:function(){this._onMoveEventWrapper=qx.lang.Function.listener(this._onMoveEvent,
this);
var a=qx.bom.Event;
a.addNativeListener(this._root,
"mousemove",
this._onMoveEventWrapper);
a.addNativeListener(this._root,
"mouseover",
this._onMoveEventWrapper);
a.addNativeListener(this._root,
"mouseout",
this._onMoveEventWrapper);
},
_initWheelObserver:function(){this._onWheelEventWrapper=qx.lang.Function.listener(this._onWheelEvent,
this);
var a=qx.bom.Event;
var b=qx.core.Variant.isSet("qx.client",
"mshtml|webkit|opera")?"mousewheel":"DOMMouseScroll";
a.addNativeListener(this._root,
b,
this._onWheelEventWrapper);
},
_stopButtonObserver:function(){var a=qx.bom.Event;
a.removeNativeListener(this._root,
"mousedown",
this._onButtonEventWrapper);
a.removeNativeListener(this._root,
"mouseup",
this._onButtonEventWrapper);
a.removeNativeListener(this._root,
"click",
this._onButtonEventWrapper);
a.removeNativeListener(this._root,
"dblclick",
this._onButtonEventWrapper);
a.removeNativeListener(this._root,
"contextmenu",
this._onButtonEventWrapper);
},
_stopMoveObserver:function(){var a=qx.bom.Event;
a.removeNativeListener(this._root,
"mousemove",
this._onMoveEventWrapper);
a.removeNativeListener(this._root,
"mouseover",
this._onMoveEventWrapper);
a.removeNativeListener(this._root,
"mouseout",
this._onMoveEventWrapper);
},
_stopWheelObserver:function(){var a=qx.bom.Event;
var b=qx.core.Variant.isSet("qx.client",
"mshtml|webkit|opera")?"mousewheel":"DOMMouseScroll";
a.removeNativeListener(this._root,
b,
this._onWheelEventWrapper);
},
_onMoveEvent:function(a){this.__cC(a);
},
_onButtonEvent:function(a){var b=a.type;
var c=a.target||a.srcElement;
if(qx.core.Variant.isSet("qx.client",
"gecko|webkit")){if(c&&c.nodeType==3){c=c.parentNode;
}}
if(this.__cD){this.__cD(a,
b,
c);
}
if(this.__cF){this.__cF(a,
b,
c);
}this.__cC(a,
b,
c);
if(this.__cE){this.__cE(a,
b,
c);
}
if(this.__cG){this.__cG(a,
b,
c);
}this._lastEventType=b;
},
_onWheelEvent:function(a){this.__cC(a,
"mousewheel");
},
__cD:qx.core.Variant.select("qx.client",
{"webkit":function(a,
b,
c){if(b=="contextmenu"){this.__cC(a,
"mousedown",
c);
this.__cC(a,
"mouseup",
c);
}},
"default":null}),
__cE:qx.core.Variant.select("qx.client",
{"opera":function(a,
b,
c){if(b=="mouseup"&&a.button==2){this.__cC(a,
"contextmenu",
c);
}},
"default":null}),
__cF:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b,
c){if(b=="mouseup"&&this._lastEventType=="click"){this.__cC(a,
"mousedown",
c);
}else if(b=="dblclick"){this.__cC(a,
"click",
c);
}},
"default":null}),
__cG:qx.core.Variant.select("qx.client",
{"mshtml":null,
"default":function(a,
b,
c){switch(b){case "mousedown":this.__lastMouseDownTarget=c;
break;
case "mouseup":if(c!==this.__lastMouseDownTarget){var d=qx.dom.Hierarchy.getCommonParent(c,
this.__lastMouseDownTarget);
this.__cC(a,
"click",
d);
}}}})},
destruct:function(){this._stopButtonObserver();
this._stopMoveObserver();
this._stopWheelObserver();
this._disposeFields("_manager",
"_window",
"_root");
},
defer:function(a){qx.event.Registration.addHandler(a);
}});
qx.Class.define("qx.event.handler.Capture",
{extend:qx.core.Object,
implement:qx.event.IEventHandler,
statics:{PRIORITY:qx.event.Registration.PRIORITY_NORMAL,
SUPPORTED_TYPES:{capture:true,
losecapture:true},
TARGET_CHECK:qx.event.IEventHandler.TARGET_DOMNODE,
IGNORE_CAN_HANDLE:true},
members:{canHandleEvent:function(a,
b){},
registerEvent:function(a,
b,
c){},
unregisterEvent:function(a,
b,
c){}},
defer:function(a){qx.event.Registration.addHandler(a);
}});
qx.Class.define("qx.event.handler.DragDrop",
{extend:qx.core.Object,
implement:qx.event.IEventHandler,
construct:function(a){arguments.callee.base.call(this);
this.__manager=a;
this.__root=a.getWindow().document.documentElement;
this.__manager.addListener(this.__root,
"mousedown",
this._onMouseDown,
this);
this.__cH();
},
statics:{PRIORITY:qx.event.Registration.PRIORITY_NORMAL,
SUPPORTED_TYPES:{dragstart:1,
dragend:1,
dragover:1,
dragleave:1,
drop:1,
drag:1,
dragchange:1,
droprequest:1},
IGNORE_CAN_HANDLE:true},
members:{canHandleEvent:function(a,
b){},
registerEvent:function(a,
b,
c){},
unregisterEvent:function(a,
b,
c){},
addType:function(a){this.__types[a]=true;
},
addAction:function(a){this.__actions[a]=true;
},
supportsType:function(a){return !!this.__types[a];
},
supportsAction:function(a){return !!this.__actions[a];
},
getData:function(a){if(!this.__cO||!this.__dropTarget){throw new Error("This method must not be used outside the drop event listener!");
}
if(!this.__types[a]){throw new Error("Unsupported data type: "+a+"!");
}
if(!this.__cache[a]){this.__currentType=a;
this.__cJ("droprequest",
this.__dragTarget,
false);
}
if(!this.__cache[a]){throw new Error("Please use a dragrequest listener to the drag target to fill the manager with data!");
}return this.__cache[a]||null;
},
getCurrentAction:function(){return this.__currentAction;
},
addData:function(a,
b){this.__cache[a]=b;
},
getCurrentType:function(){return this.__currentType;
},
__cH:function(){this.__types={};
this.__actions={};
this.__keys={};
this.__cache={};
},
__cI:function(){var a=this.__actions;
var b=this.__keys;
var c=null;
if(this.__cO){if(b.Shift&&b.Ctrl&&a.alias){c="alias";
}else if(b.Shift&&b.Alt&&a.copy){c="copy";
}else if(b.Shift&&a.move){c="move";
}else if(b.Alt&&a.alias){c="alias";
}else if(b.Ctrl&&a.copy){c="copy";
}else if(a.move){c="move";
}else if(a.copy){c="copy";
}else if(a.alias){c="alias";
}}
if(c!=this.__currentAction){this.__currentAction=c;
this.__cJ("dragchange",
this.__dragTarget,
false);
}},
__cJ:function(a,
b,
c,
d){var e=qx.event.Registration;
var f=e.createEvent(a,
qx.event.type.Drag,
[c,
d]);
return e.dispatchEvent(b,
f);
},
__cK:function(a){while(a&&a.nodeType==1){if(a.getAttribute("qxDraggable")=="on"){return a;
}a=a.parentNode;
}return null;
},
__cL:function(a){while(a&&a.nodeType==1){if(a.getAttribute("qxDroppable")=="on"){return a;
}a=a.parentNode;
}return null;
},
__cM:function(){this.__dragTarget=null;
this.__manager.removeListener(this.__root,
"mousemove",
this._onMouseMove,
this,
true);
this.__manager.removeListener(this.__root,
"mouseup",
this._onMouseUp,
this,
true);
qx.event.Registration.removeListener(window,
"blur",
this._onWindowBlur,
this);
this.__cH();
},
__cN:function(){if(this.__sessionActive){this.__manager.removeListener(this.__root,
"mouseover",
this._onMouseOver,
this,
true);
this.__manager.removeListener(this.__root,
"mouseout",
this._onMouseOut,
this,
true);
this.__manager.removeListener(this.__root,
"keydown",
this._onKeyDown,
this,
true);
this.__manager.removeListener(this.__root,
"keyup",
this._onKeyUp,
this,
true);
this.__cJ("dragend",
this.__dragTarget,
false);
this.__sessionActive=false;
}this.__cO=false;
this.__dropTarget=null;
this.__cM();
},
__cO:false,
_onWindowBlur:function(a){this.__cN();
},
_onKeyDown:function(a){var b=a.getKeyIdentifier();
switch(b){case "Alt":case "Ctrl":case "Shift":if(!this.__keys[b]){this.__keys[b]=true;
this.__cI();
}}},
_onKeyUp:function(a){var b=a.getKeyIdentifier();
switch(b){case "Alt":case "Ctrl":case "Shift":if(this.__keys[b]){this.__keys[b]=false;
this.__cI();
}}},
_onMouseDown:function(a){if(this.__sessionActive){return;
}var b=this.__cK(a.getTarget());
if(b){this.__startLeft=a.getDocumentLeft();
this.__startTop=a.getDocumentTop();
this.__dragTarget=b;
this.__manager.addListener(this.__root,
"mousemove",
this._onMouseMove,
this,
true);
this.__manager.addListener(this.__root,
"mouseup",
this._onMouseUp,
this,
true);
qx.event.Registration.addListener(window,
"blur",
this._onWindowBlur,
this);
}},
_onMouseUp:function(a){if(this.__cO){this.__cJ("drop",
this.__dropTarget,
false,
a.getNativeEvent());
}if(this.__sessionActive){a.stopPropagation();
}this.__cN();
},
_onMouseMove:function(a){if(this.__sessionActive){if(!this.__cJ("drag",
this.__dragTarget,
true,
a.getNativeEvent())){this.__cN();
}}else{if(Math.abs(a.getDocumentLeft()-this.__startLeft)>3||Math.abs(a.getDocumentTop()-this.__startTop)>3){if(this.__cJ("dragstart",
this.__dragTarget,
true,
a.getNativeEvent())){this.__sessionActive=true;
this.__manager.addListener(this.__root,
"mouseover",
this._onMouseOver,
this,
true);
this.__manager.addListener(this.__root,
"mouseout",
this._onMouseOut,
this,
true);
this.__manager.addListener(this.__root,
"keydown",
this._onKeyDown,
this,
true);
this.__manager.addListener(this.__root,
"keyup",
this._onKeyUp,
this,
true);
var b=this.__keys;
b.Ctrl=a.isCtrlPressed();
b.Shift=a.isShiftPressed();
b.Alt=a.isAltPressed();
this.__cI();
}else{this.__cJ("dragend",
this.__dragTarget,
false);
this.__cM();
}}}},
_onMouseOver:function(a){var b=a.getTarget();
var c=this.__cL(b);
if(c&&c!=this.__dropTarget){this.__cO=this.__cJ("dragover",
c,
true,
a.getNativeEvent());
this.__dropTarget=c;
this.__cI();
}},
_onMouseOut:function(a){var b=a.getTarget();
var c=this.__cL(b);
if(c&&c==this.__dropTarget){this.__cJ("dragleave",
this.__dropTarget,
false,
a.getNativeEvent());
this.__dropTarget=null;
this.__cO=false;
this.__cI();
}}},
destruct:function(){this.__cN();
this.__manager.removeListener(this.__root,
"mousedown",
this._onMouseDown,
this);
this._disposeFields("__dragTarget",
"__dropTarget",
"__manager",
"__root");
},
defer:function(a){qx.event.Registration.addHandler(a);
}});
qx.Class.define("qx.event.handler.Element",
{extend:qx.core.Object,
implement:qx.event.IEventHandler,
construct:function(a){arguments.callee.base.call(this);
this._manager=a;
this._registeredEvents={};
},
statics:{PRIORITY:qx.event.Registration.PRIORITY_NORMAL,
SUPPORTED_TYPES:{abort:true,
scroll:true,
select:true,
reset:true,
submit:true},
TARGET_CHECK:qx.event.IEventHandler.TARGET_DOMNODE,
IGNORE_CAN_HANDLE:true},
members:{canHandleEvent:function(a,
b){},
registerEvent:function(a,
b,
c){var d=qx.core.ObjectRegistry.toHashCode(a);
var e=d+"-"+b;
var f=qx.lang.Function.listener(this._onNative,
this,
e);
qx.bom.Event.addNativeListener(a,
b,
f);
this._registeredEvents[e]={element:a,
type:b,
listener:f};
},
unregisterEvent:function(a,
b,
c){var d=this._registeredEvents;
if(!d){return;
}var e=qx.core.ObjectRegistry.toHashCode(a);
var f=e+"-"+b;
var g=this._registeredEvents[f];
qx.bom.Event.removeNativeListener(a,
b,
g.listener);
delete this._registeredEvents[f];
},
_onNative:function(a,
b){var c=this._registeredEvents;
if(!c){return;
}var d=c[b];
qx.event.Registration.fireNonBubblingEvent(d.element,
d.type,
qx.event.type.Native,
[a]);
}},
destruct:function(){var a;
var b=this._registeredEvents;
for(var c in b){a=b[c];
qx.bom.Event.removeNativeListener(a.element,
a.type,
a.listener);
}this._disposeFields("_manager",
"_registeredEvents");
},
defer:function(a){qx.event.Registration.addHandler(a);
}});
qx.Class.define("qx.bom.Element",
{statics:{__cP:{"onload":true,
"onpropertychange":true,
"oninput":true,
"onchange":true,
"name":true,
"type":true,
"checked":true,
"disabled":true},
create:function(a,
b,
c,
d){if(!c){c=window;
}
if(!a){throw new Error("The tag name is missing!");
}var e=this.__cP;
var f="";
for(var g in b){if(e[g]){f+=g+"='"+b[g]+"' ";
}}var h;
if(f!=""){if(qx.bom.client.Engine.MSHTML){h=c.document.createElement("<"+a+" "+f+">");
}else{var i=c.document.createElement("div");
i.innerHTML="<"+a+" "+f+"></"+a+">";
h=i.firstChild;
}}else{if(c.document.createElementNS){h=c.document.createElementNS("http://www.w3.org/1999/xhtml",
a);
}else{h=c.document.createElement(a);
}}
for(var g in b){if(!e[g]){qx.bom.element.Attribute.set(h,
g,
b[g]);
}}return h;
},
empty:function(a){return a.innerHTML="";
},
addListener:function(a,
b,
c,
d,
e){return qx.event.Registration.addListener(a,
b,
c,
d,
e);
},
removeListener:function(a,
b,
c,
d,
e){return qx.event.Registration.removeListener(a,
b,
c,
d,
e);
},
hasListener:function(a,
b,
c){return qx.event.Registration.hasListener(a,
b,
c);
},
focus:function(a){qx.event.Registration.getManager(a).getHandler(qx.event.handler.Focus).focus(a);
},
blur:function(a){qx.event.Registration.getManager(a).getHandler(qx.event.handler.Focus).blur(a);
},
activate:function(a){qx.event.Registration.getManager(a).getHandler(qx.event.handler.Focus).activate(a);
},
deactivate:function(a){qx.event.Registration.getManager(a).getHandler(qx.event.handler.Focus).deactivate(a);
},
capture:function(a){qx.event.Registration.getManager(a).getDispatcher(qx.event.dispatch.MouseCapture).activateCapture(a);
},
releaseCapture:function(a){qx.event.Registration.getManager(a).getDispatcher(qx.event.dispatch.MouseCapture).releaseCapture(a);
}}});
qx.Class.define("qx.event.handler.Focus",
{extend:qx.core.Object,
implement:qx.event.IEventHandler,
construct:function(a){arguments.callee.base.call(this);
this._manager=a;
this._window=a.getWindow();
this._document=this._window.document;
this._root=this._document.documentElement;
this._body=this._document.body;
this._initObserver();
},
properties:{active:{apply:"_applyActive",
nullable:true},
focus:{apply:"_applyFocus",
nullable:true}},
statics:{PRIORITY:qx.event.Registration.PRIORITY_NORMAL,
SUPPORTED_TYPES:{focus:1,
blur:1,
focusin:1,
focusout:1,
activate:1,
deactivate:1},
IGNORE_CAN_HANDLE:true,
FOCUSABLE_ELEMENTS:qx.core.Variant.select("qx.client",
{"mshtml|gecko":{a:1,
body:1,
button:1,
frame:1,
iframe:1,
img:1,
input:1,
object:1,
select:1,
textarea:1},
"opera|webkit":{button:1,
input:1,
select:1,
textarea:1}})},
members:{canHandleEvent:function(a,
b){},
registerEvent:function(a,
b,
c){},
unregisterEvent:function(a,
b,
c){},
focus:function(a){try{a.focus();
}catch(ex){}this.setFocus(a);
this.setActive(a);
},
activate:function(a){this.setActive(a);
},
blur:function(a){try{a.blur();
}catch(ex){}
if(this.getActive()===a){this.resetActive();
}
if(this.getFocus()===a){this.resetFocus();
}},
deactivate:function(a){if(this.getActive()===a){this.resetActive();
}},
tryActivate:function(a){var b=this.__de(a);
if(b){this.setActive(b);
}},
__cQ:function(a,
b,
c,
d){var e=qx.event.Registration;
var f=e.createEvent(c,
qx.event.type.Focus,
[a,
b,
d]);
e.dispatchEvent(a,
f);
},
_windowFocused:true,
__cR:function(){if(this._windowFocused){this._windowFocused=false;
this.__cQ(this._window,
null,
"blur",
false);
}},
__cS:function(){if(!this._windowFocused){this._windowFocused=true;
this.__cQ(this._window,
null,
"focus",
false);
}},
_initObserver:qx.core.Variant.select("qx.client",
{"gecko":function(){this.__onNativeMouseDownWrapper=qx.lang.Function.listener(this.__cY,
this);
this.__onNativeMouseUpWrapper=qx.lang.Function.listener(this.__da,
this);
this.__onNativeFocusWrapper=qx.lang.Function.listener(this.__cX,
this);
this.__onNativeBlurWrapper=qx.lang.Function.listener(this.__cW,
this);
this.__onNativeDragGestureWrapper=qx.lang.Function.listener(this.__cT,
this);
this._document.addEventListener("mousedown",
this.__onNativeMouseDownWrapper,
true);
this._document.addEventListener("mouseup",
this.__onNativeMouseUpWrapper,
true);
this._window.addEventListener("focus",
this.__onNativeFocusWrapper,
true);
this._window.addEventListener("blur",
this.__onNativeBlurWrapper,
true);
this._window.addEventListener("draggesture",
this.__onNativeDragGestureWrapper,
true);
},
"mshtml":function(){this.__onNativeMouseDownWrapper=qx.lang.Function.listener(this.__cY,
this);
this.__onNativeMouseUpWrapper=qx.lang.Function.listener(this.__da,
this);
this.__onNativeFocusInWrapper=qx.lang.Function.listener(this.__cU,
this);
this.__onNativeFocusOutWrapper=qx.lang.Function.listener(this.__cV,
this);
this.__onNativeSelectStartWrapper=qx.lang.Function.listener(this.__db,
this);
this._document.attachEvent("onmousedown",
this.__onNativeMouseDownWrapper);
this._document.attachEvent("onmouseup",
this.__onNativeMouseUpWrapper);
this._document.attachEvent("onfocusin",
this.__onNativeFocusInWrapper);
this._document.attachEvent("onfocusout",
this.__onNativeFocusOutWrapper);
this._document.attachEvent("onselectstart",
this.__onNativeSelectStartWrapper);
},
"webkit":function(){this.__onNativeMouseDownWrapper=qx.lang.Function.listener(this.__cY,
this);
this.__onNativeMouseUpWrapper=qx.lang.Function.listener(this.__da,
this);
this.__onNativeFocusOutWrapper=qx.lang.Function.listener(this.__cV,
this);
this.__onNativeFocusWrapper=qx.lang.Function.listener(this.__cX,
this);
this.__onNativeBlurWrapper=qx.lang.Function.listener(this.__cW,
this);
this.__onNativeSelectStartWrapper=qx.lang.Function.listener(this.__db,
this);
this._document.addEventListener("mousedown",
this.__onNativeMouseDownWrapper,
true);
this._document.addEventListener("mouseup",
this.__onNativeMouseUpWrapper,
true);
this._document.addEventListener("selectstart",
this.__onNativeSelectStartWrapper,
false);
this._window.addEventListener("DOMFocusOut",
this.__onNativeFocusOutWrapper,
true);
this._window.addEventListener("focus",
this.__onNativeFocusWrapper,
true);
this._window.addEventListener("blur",
this.__onNativeBlurWrapper,
true);
},
"opera":function(){this.__onNativeMouseDownWrapper=qx.lang.Function.listener(this.__cY,
this);
this.__onNativeMouseUpWrapper=qx.lang.Function.listener(this.__da,
this);
this.__onNativeFocusInWrapper=qx.lang.Function.listener(this.__cU,
this);
this.__onNativeFocusOutWrapper=qx.lang.Function.listener(this.__cV,
this);
this._document.addEventListener("mousedown",
this.__onNativeMouseDownWrapper,
true);
this._document.addEventListener("mouseup",
this.__onNativeMouseUpWrapper,
true);
this._window.addEventListener("DOMFocusIn",
this.__onNativeFocusInWrapper,
true);
this._window.addEventListener("DOMFocusOut",
this.__onNativeFocusOutWrapper,
true);
}}),
_stopObserver:qx.core.Variant.select("qx.client",
{"gecko":function(){this._document.removeEventListener("mousedown",
this.__onNativeMouseDownWrapper,
true);
this._document.removeEventListener("mouseup",
this.__onNativeMouseUpWrapper,
true);
this._window.removeEventListener("focus",
this.__onNativeFocusWrapper,
true);
this._window.removeEventListener("blur",
this.__onNativeBlurWrapper,
true);
this._window.removeEventListener("draggesture",
this.__onNativeDragGestureWrapper,
true);
},
"mshtml":function(){this._document.detachEvent("onmousedown",
this.__onNativeMouseDownWrapper);
this._document.detachEvent("onmouseup",
this.__onNativeMouseUpWrapper);
this._document.detachEvent("onfocusin",
this.__onNativeFocusInWrapper);
this._document.detachEvent("onfocusout",
this.__onNativeFocusOutWrapper);
this._document.detachEvent("onselectstart",
this.__onNativeSelectStartWrapper);
},
"webkit":function(){this._document.removeEventListener("mousedown",
this.__onNativeMouseDownWrapper,
true);
this._document.removeEventListener("selectstart",
this.__onNativeSelectStartWrapper,
false);
this._window.removeEventListener("DOMFocusIn",
this.__onNativeFocusInWrapper,
true);
this._window.removeEventListener("DOMFocusOut",
this.__onNativeFocusOutWrapper,
true);
this._window.removeEventListener("focus",
this.__onNativeFocusWrapper,
true);
this._window.removeEventListener("blur",
this.__onNativeBlurWrapper,
true);
},
"opera":function(){this._document.removeEventListener("mousedown",
this.__onNativeMouseDownWrapper,
true);
this._window.removeEventListener("DOMFocusIn",
this.__onNativeFocusInWrapper,
true);
this._window.removeEventListener("DOMFocusOut",
this.__onNativeFocusOutWrapper,
true);
this._window.removeEventListener("focus",
this.__onNativeFocusWrapper,
true);
this._window.removeEventListener("blur",
this.__onNativeBlurWrapper,
true);
}}),
__cT:qx.core.Variant.select("qx.client",
{"gecko":function(a){if(!this.__df(a.target)){a.preventDefault();
}},
"default":null}),
__cU:qx.core.Variant.select("qx.client",
{"mshtml":function(a){this.__cS();
var b=a.srcElement;
var c=this.__dd(b);
if(c){this.setFocus(c);
}this.tryActivate(b);
},
"opera":function(a){var b=a.target;
if(b==this._document||b==this._window){this.__cS();
if(this.__previousFocus){this.setFocus(this.__previousFocus);
delete this.__previousFocus;
}
if(this.__previousActive){this.setActive(this.__previousActive);
delete this.__previousActive;
}}else{this.setFocus(b);
this.tryActivate(b);
if(!this.__df(b)){b.selectionStart=0;
b.selectionEnd=0;
}}},
"default":null}),
__cV:qx.core.Variant.select("qx.client",
{"mshtml":function(a){if(!a.toElement){this.__cR();
this.resetFocus();
this.resetActive();
}},
"webkit":function(a){var b=a.target;
if(b===this.getFocus()){this.resetFocus();
}
if(b===this.getActive()){this.resetActive();
}},
"opera":function(a){var b=a.target;
if(b==this._document){this.__cR();
this.__previousFocus=this.getFocus();
this.__previousActive=this.getActive();
this.resetFocus();
this.resetActive();
}else{if(b===this.getFocus()){this.resetFocus();
}
if(b===this.getActive()){this.resetActive();
}}},
"default":null}),
__cW:qx.core.Variant.select("qx.client",
{"gecko":function(a){if(a.target===this._window||a.target===this._document){this.__cR();
this.resetActive();
this.resetFocus();
}},
"webkit":function(a){if(a.target===this._window||a.target===this._document){this.__cR();
this.__previousFocus=this.getFocus();
this.__previousActive=this.getActive();
this.resetActive();
this.resetFocus();
}},
"default":null}),
__cX:qx.core.Variant.select("qx.client",
{"gecko":function(a){var b=a.target;
if(b===this._window||b===this._document){this.__cS();
b=this._body;
}this.setFocus(b);
this.tryActivate(b);
},
"webkit":function(a){var b=a.target;
if(b===this._window||b===this._document){this.__cS();
if(this.__previousFocus){this.setFocus(this.__previousFocus);
delete this.__previousFocus;
}
if(this.__previousActive){this.setActive(this.__previousActive);
delete this.__previousActive;
}}else{this.setFocus(b);
this.tryActivate(b);
}},
"default":null}),
__cY:qx.core.Variant.select("qx.client",
{"gecko":function(a){var b=a.target;
var c=this.__dd(b);
var d=this.__df(b);
if(!d){qx.bom.Event.preventDefault(a);
if(c){c.focus();
}}else if(!c){qx.bom.Event.preventDefault(a);
}},
"mshtml":function(a){var b=a.srcElement;
var c=this.__dd(b);
if(c){if(!this.__df(b)){b.unselectable="on";
document.selection.empty();
b.focus();
}}else{qx.bom.Event.preventDefault(a);
if(!this.__df(b)){b.unselectable="on";
}}},
"webkit":function(a){var b=a.target;
var c=this.__dd(b);
if(c){this.setFocus(c);
}else{qx.bom.Event.preventDefault(a);
}},
"opera":function(a){var b=a.target;
var c=this.__dd(b);
if(!this.__df(b)){qx.bom.Event.preventDefault(a);
if(c){var d=this.getFocus();
if(d&&d.selectionEnd){d.selectionStart=0;
d.selectionEnd=0;
d.blur();
}if(c){this.setFocus(c);
}}}else if(c){this.setFocus(c);
}},
"default":null}),
__da:qx.core.Variant.select("qx.client",
{"mshtml":function(a){var b=a.srcElement;
if(b.unselectable){b.unselectable="off";
}this.tryActivate(b);
},
"gecko":function(a){var b=a.target;
while(b&&b.offsetWidth===undefined){b=b.parentNode;
}
if(b){this.tryActivate(b);
}if(this.__lastUserSelectBlocked){this.__lastUserSelectBlocked.style.MozUserSelect="";
this.__lastUserSelectBlocked=null;
}},
"webkit|opera":function(a){this.tryActivate(a.target);
},
"default":null}),
__db:qx.core.Variant.select("qx.client",
{"mshtml|webkit":function(a){if(!this.__df(a.srcElement)){qx.bom.Event.preventDefault(a);
}},
"default":null}),
__dc:function(a){var b=qx.bom.element.Attribute.get(a,
"tabIndex");
if(b>=1){return true;
}var c=qx.event.handler.Focus.FOCUSABLE_ELEMENTS;
if(b>=0&&c[a.tagName]){return true;
}return false;
},
__dd:function(a){while(a&&a.nodeType===1){if(a.getAttribute("qxKeepFocus")=="on"){return null;
}
if(this.__dc(a)){return a;
}a=a.parentNode;
}return this._body;
},
__de:function(a){var b=a;
while(a&&a.nodeType===1){if(a.getAttribute("qxKeepActive")=="on"){return null;
}a=a.parentNode;
}return b;
},
__df:function(a){while(a&&a.nodeType===1){var b=a.getAttribute("qxSelectable");
if(b!=null){return b==="on";
}a=a.parentNode;
}return true;
},
_applyActive:function(a,
b){if(b){this.__cQ(b,
a,
"deactivate",
true);
}
if(a){this.__cQ(a,
b,
"activate",
true);
}},
_applyFocus:function(a,
b){if(b){this.__cQ(b,
a,
"focusout",
true);
}
if(a){this.__cQ(a,
b,
"focusin",
true);
}if(b){this.__cQ(b,
a,
"blur",
false);
}
if(a){this.__cQ(a,
b,
"focus",
false);
}}},
destruct:function(){this._stopObserver();
this._disposeFields("_manager",
"_window",
"_document",
"_root",
"_body",
"__mouseActive");
},
defer:function(a){qx.event.Registration.addHandler(a);
var b=a.FOCUSABLE_ELEMENTS;
for(var c in b){b[c.toUpperCase()]=1;
}}});
qx.Class.define("qx.event.type.Focus",
{extend:qx.event.type.Event,
members:{init:function(a,
b,
c){arguments.callee.base.call(this,
c,
false);
this._target=a;
this._relatedTarget=b;
return this;
}}});
qx.Class.define("qx.bom.element.Attribute",
{statics:{__dg:{names:{"class":"className",
"for":"htmlFor",
html:"innerHTML",
text:qx.core.Variant.isSet("qx.client",
"mshtml")?"innerText":"textContent",
colspan:"colSpan",
rowspan:"rowSpan",
valign:"vAlign",
datetime:"dateTime",
accesskey:"accessKey",
tabindex:"tabIndex",
enctype:"encType",
maxlength:"maxLength",
readonly:"readOnly",
longdesc:"longDesc",
cellpadding:"cellPadding",
cellspacing:"cellSpacing",
frameborder:"frameBorder",
usemap:"useMap"},
runtime:{"html":1,
"text":1},
bools:{compact:1,
nowrap:1,
ismap:1,
declare:1,
noshade:1,
checked:1,
disabled:1,
readonly:1,
multiple:1,
selected:1,
noresize:1,
defer:1},
property:{$$html:1,
$$widget:1,
disabled:1,
checked:1,
readOnly:1,
multiple:1,
selected:1,
value:1,
maxLength:1,
className:1,
innerHTML:1,
innerText:1,
textContent:1,
htmlFor:1,
tabIndex:1},
original:{href:1,
src:1,
type:1}},
compile:function(a){var b=[];
var c=this.__dg.runtime;
for(var d in a){if(!c[d]){b.push(d,
"='",
a[d],
"'");
}}return b.join("");
},
get:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b){var c=this.__dg;
var d;
b=c.names[b]||b;
if(c.original[b]){d=a.getAttribute(b,
2);
}else if(c.property[b]){d=a[b];
}else{d=a.getAttribute(b);
}if(c.bools[b]){return !!d;
}return d;
},
"default":function(a,
b){var c=this.__dg;
var d;
b=c.names[b]||b;
if(c.property[b]){d=a[b];
if(d==null){d=a.getAttribute(b);
}}else{d=a.getAttribute(b);
}if(c.bools[b]){return !!d;
}return d;
}}),
set:function(a,
b,
c){var d=this.__dg;
b=d.names[b]||b;
if(d.bools[b]){c=!!c;
}if(d.property[b]){a[b]=c;
}else if(c===true){a.setAttribute(b,
b);
}else if(c===false||c===null){a.removeAttribute(b);
}else{a.setAttribute(b,
c);
}},
reset:function(a,
b){this.set(a,
b,
null);
}}});
qx.Class.define("qx.event.type.Native",
{extend:qx.event.type.Event,
members:{init:function(a,
b,
c,
d,
e){arguments.callee.base.call(this,
d,
e);
this._target=b||qx.bom.Event.getTarget(a);
this._relatedTarget=c||qx.bom.Event.getRelatedTarget(a);
if(a.timeStamp){this._timeStamp=a.timeStamp;
}this._native=a;
return this;
},
clone:function(a){var b=arguments.callee.base.call(this,
a);
b._native=this._native;
return b;
},
preventDefault:function(){arguments.callee.base.call(this);
qx.bom.Event.preventDefault(this._native);
},
stop:function(){this.stopPropagation();
this.preventDefault();
},
getNativeEvent:function(){return this._native;
}},
destruct:function(){this._disposeFields("_native");
}});
qx.Class.define("qx.event.type.Dom",
{extend:qx.event.type.Native,
statics:{SHIFT_MASK:1,
CTRL_MASK:2,
ALT_MASK:4,
META_MASK:8},
members:{getModifiers:function(){if(!this.__modifiers){var a=0;
var b=this._native;
if(b.shiftKey){a|=qx.event.type.Dom.SHIFT_MASK;
}
if(b.ctrlKey){a|=qx.event.type.Dom.CTRL_MASK;
}
if(b.altKey){a|=qx.event.type.Dom.ALT_MASK;
}
if(b.metaKey){a|=qx.event.type.Dom.META_MASK;
}return a;
}return this.__modifiers;
},
isCtrlPressed:function(){return this._native.ctrlKey;
},
isShiftPressed:function(){return this._native.shiftKey;
},
isAltPressed:function(){return this._native.altKey;
},
isMetaPressed:function(){return this._native.metaKey;
},
isCtrlOrCommandPressed:function(){if(qx.bom.client.Platform.MAC){return this._native.metaKey;
}else{return this._native.ctrlKey;
}}}});
qx.Class.define("qx.event.type.KeyInput",
{extend:qx.event.type.Dom,
members:{init:function(a,
b,
c){arguments.callee.base.call(this,
a,
b,
null,
true,
true);
this._charCode=c;
return this;
},
clone:function(a){var b=arguments.callee.base.call(this,
a);
b._charCode=this._charCode;
return b;
},
getCharCode:function(){return this._charCode;
},
getChar:function(){return String.fromCharCode(this._charCode);
}}});
qx.Bootstrap.define("qx.bom.client.Platform",
{statics:{NAME:"",
WIN:false,
MAC:false,
UNIX:false,
__dh:function(){var a=navigator.platform;
if(a==null||a===""){a=navigator.userAgent;
}
if(a.indexOf("Windows")!=-1||a.indexOf("Win32")!=-1||a.indexOf("Win64")!=-1){this.WIN=true;
this.NAME="win";
}else if(a.indexOf("Macintosh")!=-1||a.indexOf("MacPPC")!=-1||a.indexOf("MacIntel")!=-1||a.indexOf("iPod")!=-1||a.indexOf("iPhone")!=-1){this.MAC=true;
this.NAME="mac";
}else if(a.indexOf("X11")!=-1||a.indexOf("Linux")!=-1||a.indexOf("BSD")!=-1){this.UNIX=true;
this.NAME="unix";
}else{throw new Error("Unable to detect platform: "+a);
}}},
defer:function(a){a.__dh();
}});
qx.Class.define("qx.event.type.KeySequence",
{extend:qx.event.type.Dom,
members:{init:function(a,
b,
c){arguments.callee.base.call(this,
a,
b,
null,
true,
true);
this._identifier=c;
return this;
},
clone:function(a){var b=arguments.callee.base.call(this,
a);
b._identifier=this._identifier;
return b;
},
getKeyIdentifier:function(){return this._identifier;
}}});
qx.Class.define("qx.event.type.Mouse",
{extend:qx.event.type.Dom,
members:{init:function(a,
b,
c,
d,
e){arguments.callee.base.call(this,
a,
b,
c,
d,
e);
if(!c){this._relatedTarget=qx.bom.Event.getRelatedTarget(a);
}return this;
},
__di:qx.core.Variant.select("qx.client",
{"mshtml":{1:"left",
2:"right",
4:"middle"},
"default":{0:"left",
2:"right",
1:"middle"}}),
stop:function(){this.stopPropagation();
},
getButton:function(){switch(this._type){case "click":case "dblclick":return "left";
case "contextmenu":return "right";
default:return this.__di[this._native.button]||"none";
}},
isLeftPressed:function(){return this.getButton()==="left";
},
isMiddlePressed:function(){return this.getButton()==="middle";
},
isRightPressed:function(){return this.getButton()==="right";
},
getRelatedTarget:function(){return this._relatedTarget;
},
getViewportLeft:function(){return this._native.clientX;
},
getViewportTop:function(){return this._native.clientY;
},
getDocumentLeft:qx.core.Variant.select("qx.client",
{"mshtml":function(){var a=qx.dom.Node.getWindow(this._native.srcElement);
return this._native.clientX+qx.bom.Viewport.getScrollLeft(a);
},
"default":function(){return this._native.pageX;
}}),
getDocumentTop:qx.core.Variant.select("qx.client",
{"mshtml":function(){var a=qx.dom.Node.getWindow(this._native.srcElement);
return this._native.clientY+qx.bom.Viewport.getScrollTop(a);
},
"default":function(){return this._native.pageY;
}}),
getScreenLeft:function(){return this._native.screenX;
},
getScreenTop:function(){return this._native.screenY;
},
getWheelDelta:qx.core.Variant.select("qx.client",
{"default":function(){return -(this._native.wheelDelta/40);
},
"gecko":function(){return this._native.detail;
}})}});
qx.Class.define("qx.event.type.Drag",
{extend:qx.event.type.Event,
members:{init:function(a,
b){arguments.callee.base.call(this,
false,
a);
this._native=b||null;
return this;
},
clone:function(a){var b=arguments.callee.base.call(this,
a);
b._native=this._native;
return b;
},
getDocumentLeft:qx.core.Variant.select("qx.client",
{"mshtml":function(){if(this._native==null){return 0;
}var a=qx.dom.Node.getWindow(this._native.srcElement);
return this._native.clientX+qx.bom.Viewport.getScrollLeft(a);
},
"default":function(){if(this._native==null){return 0;
}return this._native.pageX;
}}),
getDocumentTop:qx.core.Variant.select("qx.client",
{"mshtml":function(){if(this._native==null){return 0;
}var a=qx.dom.Node.getWindow(this._native.srcElement);
return this._native.clientY+qx.bom.Viewport.getScrollTop(a);
},
"default":function(){if(this._native==null){return 0;
}return this._native.pageY;
}}),
getManager:function(){return qx.event.Registration.getManager(this.getTarget()).getHandler(qx.event.handler.DragDrop);
},
addType:function(a){this.getManager().addType(a);
},
addAction:function(a){this.getManager().addAction(a);
},
supportsType:function(a){return this.getManager().supportsType(a);
},
supportsAction:function(a){return this.getManager().supportsAction(a);
},
addData:function(a,
b){this.getManager().addData(a,
b);
},
getData:function(a){return this.getManager().getData(a);
},
getCurrentType:function(){return this.getManager().getCurrentType();
},
getCurrentAction:function(){return this.getManager().getCurrentAction();
}}});
qx.Class.define("qx.event.dispatch.MouseCapture",
{extend:qx.core.Object,
implement:qx.event.IEventDispatcher,
construct:function(a){arguments.callee.base.call(this);
this._manager=a;
this._window=a.getWindow();
a.addListener(this._window,
"blur",
this.releaseCapture,
this);
a.addListener(this._window,
"focus",
this.releaseCapture,
this);
a.addListener(this._window,
"scroll",
this.releaseCapture,
this);
},
statics:{PRIORITY:qx.event.Registration.PRIORITY_FIRST},
members:{canDispatchEvent:function(a,
b,
c){return this._captureElement&&this.__dj[c];
},
dispatchEvent:function(a,
b,
c){if(c=="click"){b.stopPropagation();
this.releaseCapture();
return;
}var d=this._manager.getListeners(this._captureElement,
c,
false);
if(d){b.setCurrentTarget(this._captureElement);
b.setEventPhase(qx.event.type.Event.AT_TARGET);
for(var e=0,
f=d.length;e<f;e++){var g=d[e].context||b.getCurrentTarget();
d[e].handler.call(g,
b);
}}},
__dj:{"mouseup":1,
"mousedown":1,
"click":1,
"dblclick":1,
"mousemove":1,
"mouseout":1,
"mouseover":1},
activateCapture:function(a){if(this._captureElement===a){return;
}
if(this._captureElement){this.releaseCapture();
}this._captureElement=a;
qx.event.Registration.fireEvent(a,
"capture");
},
releaseCapture:function(){var a=this._captureElement;
if(!a){return;
}this._captureElement=null;
qx.event.Registration.fireEvent(a,
"losecapture");
}},
destruct:function(){this._disposeFields("_captureElement",
"_manager",
"_window");
},
defer:function(a){qx.event.Registration.addDispatcher(a);
}});
qx.Class.define("qx.event.handler.Window",
{extend:qx.core.Object,
implement:qx.event.IEventHandler,
construct:function(a){arguments.callee.base.call(this);
this._manager=a;
this._window=a.getWindow();
this._initWindowObserver();
},
statics:{PRIORITY:qx.event.Registration.PRIORITY_NORMAL,
SUPPORTED_TYPES:{error:1,
load:1,
beforeunload:1,
unload:1,
resize:1,
scroll:1},
TARGET_CHECK:qx.event.IEventHandler.TARGET_WINDOW,
IGNORE_CAN_HANDLE:true},
members:{canHandleEvent:function(a,
b){},
registerEvent:function(a,
b,
c){},
unregisterEvent:function(a,
b,
c){},
_initWindowObserver:function(){this._onNativeWrapper=qx.lang.Function.listener(this._onNative,
this);
var a=qx.event.handler.Window.SUPPORTED_TYPES;
for(var b in a){qx.bom.Event.addNativeListener(this._window,
b,
this._onNativeWrapper);
}},
_stopWindowObserver:function(){var a=qx.event.handler.Window.SUPPORTED_TYPES;
for(var b in a){qx.bom.Event.removeNativeListener(this._window,
b,
this._onNativeWrapper);
}},
_onNative:function(a){if(this.isDisposed()){return;
}var b=this._window;
var c=b.document;
var d=c.documentElement;
var f=a.target||a.srcElement;
if(f==null||f===b||f===c||f===d){qx.event.Registration.fireEvent(this._window,
a.type);
}}},
destruct:function(){this._stopWindowObserver();
this._disposeFields("_manager",
"_window");
},
defer:function(a){qx.event.Registration.addHandler(a);
}});
qx.Class.define("qx.bom.Selection",
{statics:{getSelectionObject:qx.core.Variant.select("qx.client",
{"mshtml":function(a){return a.selection;
},
"default":function(a){return qx.dom.Node.getWindow(a).getSelection();
}}),
get:qx.core.Variant.select("qx.client",
{"mshtml":function(a){var b=qx.bom.Range.get(qx.dom.Node.getDocument(a));
return b.text;
},
"default":function(a){if(qx.dom.Node.isElement(a)&&(a.nodeName.toLowerCase()=="input"||a.nodeName.toLowerCase()=="textarea")){return a.value.substring(a.selectionStart,
a.selectionEnd);
}else{return qx.bom.Selection.getSelectionObject(qx.dom.Node.getDocument(a)).toString();
}return null;
}}),
getLength:qx.core.Variant.select("qx.client",
{"mshtml":function(a){var b=qx.bom.Selection.get(a);
var c=qx.util.StringSplit.split(b,
/\r\n/);
return b.length-(c.length-1);
},
"opera":function(a){var b,
c,
d;
if(qx.dom.Node.isElement(a)&&(a.nodeName.toLowerCase()=="input"||a.nodeName.toLowerCase()=="textarea")){var e=a.selectionStart;
var f=a.selectionEnd;
b=a.value.substring(e,
f);
c=f-e;
}else{b=qx.bom.Selection.get(a);
c=b.length;
}d=qx.util.StringSplit.split(b,
/\r\n/);
return c-(d.length-1);
},
"default":function(a){if(qx.dom.Node.isElement(a)&&(a.nodeName.toLowerCase()=="input"||a.nodeName.toLowerCase()=="textarea")){return a.selectionEnd-a.selectionStart;
}else{return qx.bom.Selection.get(a).length;
}return null;
}}),
set:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b,
c){var d;
if(qx.dom.Node.isDocument(a)){a=a.body;
}
if(qx.dom.Node.isElement(a)||qx.dom.Node.isText(a)){switch(a.nodeName.toLowerCase()){case "input":case "textarea":case "button":if(c===undefined){c=a.value.length;
}
if(b>=0&&b<=a.value.length&&c>=0&&c<=a.value.length){d=qx.bom.Range.get(a);
d.collapse(true);
d.moveStart("character",
b);
d.moveEnd("character",
c);
d.select();
return true;
}break;
case "#text":if(c===undefined){c=a.nodeValue.length;
}
if(b>=0&&b<=a.nodeValue.length&&c>=0&&c<=a.nodeValue.length){d=qx.bom.Range.get(qx.dom.Node.getBodyElement(a));
d.moveToElementText(a.parentNode);
d.collapse(true);
d.moveStart("character",
b);
d.moveEnd("character",
c);
d.select();
return true;
}break;
default:if(c===undefined){c=a.childNodes.length-1;
}if(a.childNodes[b]&&a.childNodes[c]){d=qx.bom.Range.get(qx.dom.Node.getBodyElement(a));
d.moveToElementText(a.childNodes[b]);
d.collapse(true);
var e=qx.bom.Range.get(qx.dom.Node.getBodyElement(a));
e.moveToElementText(a.childNodes[c]);
d.setEndPoint("EndToEnd",
e);
d.select();
return true;
}}}return false;
},
"default":function(a,
b,
c){var d=a.nodeName.toLowerCase();
if(qx.dom.Node.isElement(a)&&(d=="input"||d=="textarea")){if(c===undefined){c=a.value.length;
}if(b>=0&&b<=a.value.length&&c>=0&&c<=a.value.length){a.select();
a.setSelectionRange(b,
c);
return true;
}}else{var e=false;
var f=qx.dom.Node.getWindow(a).getSelection();
var g=qx.dom.Node.getDocument(a);
var h=qx.bom.Range.get(a);
if(qx.dom.Node.isText(a)){if(c===undefined){c=a.length;
}
if(b>=0&&b<a.length&&c>=0&&c<=a.length){e=true;
}}else if(qx.dom.Node.isElement(a)){if(c===undefined){c=a.childNodes.length-1;
}
if(b>=0&&a.childNodes[b]&&c>=0&&a.childNodes[c]){e=true;
}}else if(qx.dom.Node.isDocument(a)){a=a.body;
if(c===undefined){c=a.childNodes.length-1;
}
if(b>=0&&a.childNodes[b]&&c>=0&&a.childNodes[c]){e=true;
}}
if(e){if(!f.isCollapsed){f.collapseToStart();
}h.setStart(a,
b);
if(qx.dom.Node.isText(a)){h.setEnd(a,
c);
}else{h.setEndAfter(a.childNodes[c]);
}if(f.rangeCount>0){f.removeAllRanges();
}f.addRange(h);
return true;
}}return false;
}}),
setAll:function(a){return qx.bom.Selection.set(a,
0);
},
clear:qx.core.Variant.select("qx.client",
{"mshtml":function(a){var b=qx.bom.Selection.getSelectionObject(qx.dom.Node.getDocument(a));
var c=qx.bom.Range.get(a);
var d=c.parentElement();
var e=qx.bom.Range.get(qx.dom.Node.getDocument(a));
var f=a.nodeName.toLowerCase();
if(d==e.parentElement()&&d==a){b.empty();
}},
"default":function(a){var b=qx.bom.Selection.getSelectionObject(qx.dom.Node.getDocument(a));
var c=a.nodeName.toLowerCase();
if(qx.dom.Node.isElement(a)&&(c=="input"||c=="textarea")){a.setSelectionRange(0,
0);
qx.bom.Element.blur(a);
}else if(qx.dom.Node.isDocument(a)||c=="body"){b.collapse(a.body?a.body:a,
0);
}else{var d=qx.bom.Range.get(a);
if(!d.collapsed){var e;
var f=d.commonAncestorContainer;
if(qx.dom.Node.isElement(a)&&qx.dom.Node.isText(f)){e=f.parentNode;
}else{e=f;
}
if(e==a){b.collapse(a,
0);
}}}}})}});
qx.Class.define("qx.bom.Range",
{statics:{get:qx.core.Variant.select("qx.client",
{"mshtml":function(a){if(qx.dom.Node.isElement(a)){switch(a.nodeName.toLowerCase()){case "input":switch(a.type){case "text":case "password":case "hidden":case "button":case "reset":case "file":case "submit":return a.createTextRange();
break;
default:return qx.bom.Selection.getSelectionObject(qx.dom.Node.getDocument(a)).createRange();
}break;
case "textarea":case "body":case "button":return a.createTextRange();
break;
default:return qx.bom.Selection.getSelectionObject(qx.dom.Node.getDocument(a)).createRange();
}}else{return qx.bom.Selection.getSelectionObject(qx.dom.Node.getDocument(a)).createRange();
}},
"default":function(a){var b=qx.dom.Node.getDocument(a);
var c=qx.bom.Selection.getSelectionObject(b);
if(c.rangeCount>0){return c.getRangeAt(0);
}else{return b.createRange();
}}})}});
qx.Bootstrap.define("qx.util.StringSplit",
{statics:{split:function(a,
b,
c){var d="";
if(b===undefined){return [a.toString()];
}else if(b===null||b.constructor!==RegExp){b=new RegExp(String(b).replace(/[.*+?^${}()|[\]\/\\]/g,
"\\$&"),
"g");
}else{d=b.toString().replace(/^[\S\s]+\//,
"");
if(!b.global){b=new RegExp(b.source,
"g"+d);
}}var e=new RegExp("^"+b.source+"$",
d);
if(c===undefined||+c<0){c=false;
}else{c=Math.floor(+c);
if(!c){return [];
}}var f,
g=[],
h=0,
k=0;
while((c?k++<=c:true)&&(f=b.exec(a))){if((f[0].length===0)&&(b.lastIndex>f.index)){b.lastIndex--;
}
if(b.lastIndex>h){if(f.length>1){f[0].replace(e,
function(){for(var l=1;l<arguments.length-2;l++){if(arguments[l]===undefined){f[l]=undefined;
}}});
}g=g.concat(a.substring(h,
f.index),
(f.index===a.length?[]:f.slice(1)));
h=b.lastIndex;
}
if(f[0].length===0){b.lastIndex++;
}}return (h===a.length)?(b.test("")?g:g.concat("")):(c?g:g.concat(a.substring(h)));
}}});
qx.Class.define("qx.ui.core.queue.Widget",
{statics:{__dk:{},
add:function(a){var b=this.__dk;
if(b[a.$$hash]){return;
}b[a.$$hash]=a;
qx.ui.core.queue.Manager.scheduleFlush("widget");
},
flush:function(){var a=this.__dk;
for(var b in a){a[b].syncWidget();
delete a[b];
}}}});
qx.Class.define("qx.ui.core.queue.Appearance",
{statics:{__dl:{},
add:function(a){var b=this.__dl;
if(b[a.$$hash]){return;
}b[a.$$hash]=a;
qx.ui.core.queue.Manager.scheduleFlush("appearance");
},
flush:function(){var a=this.__dl;
for(var b in a){a[b].syncAppearance();
delete a[b];
}}}});
qx.Class.define("qx.ui.core.queue.Dispose",
{statics:{__dm:{},
add:function(a){var b=this.__dm;
if(b[a.$$hash]){return;
}b[a.$$hash]=a;
qx.ui.core.queue.Manager.scheduleFlush("dispose");
},
flush:function(){var a=this.__dm;
for(var b in a){a[b].dispose();
delete a[b];
}}}});
qx.Class.define("qx.core.Init",
{statics:{getApplication:function(){return this.__application||null;
},
__dn:function(){qx.log.Logger.debug(this,
"Load runtime: "+(new Date-qx.Bootstrap.LOADSTART)+"ms");
var a=qx.core.Setting.get("qx.application");
var b=qx.Class.getByName(a);
if(b){this.__application=new b;
var c=new Date;
this.__application.main();
qx.log.Logger.debug(this,
"Main runtime: "+(new Date-c)+"ms");
var c=new Date;
this.__application.finalize();
qx.log.Logger.debug(this,
"Finalize runtime: "+(new Date-c)+"ms");
}else{qx.log.Logger.warn("Missing application class: "+a);
}},
__do:function(){var a=this.__application;
if(a){a.terminate();
}}},
defer:function(a){qx.event.Registration.addListener(window,
"ready",
a.__dn,
a);
qx.event.Registration.addListener(window,
"shutdown",
a.__do,
a);
}});
qx.Class.define("qx.ui.core.EventHandler",
{extend:qx.core.Object,
implement:qx.event.IEventHandler,
construct:function(){arguments.callee.base.call(this);
this.__manager=qx.event.Registration.getManager();
},
statics:{PRIORITY:qx.event.Registration.PRIORITY_FIRST,
SUPPORTED_TYPES:{mousemove:1,
mouseover:1,
mouseout:1,
mousedown:1,
mouseup:1,
click:1,
dblclick:1,
contextmenu:1,
mousewheel:1,
keyup:1,
keydown:1,
keypress:1,
keyinput:1,
capture:1,
losecapture:1,
focusin:1,
focusout:1,
focus:1,
blur:1,
activate:1,
deactivate:1,
appear:1,
disappear:1,
dragstart:1,
dragend:1,
dragover:1,
dragleave:1,
drop:1,
drag:1,
dragchange:1,
droprequest:1},
IGNORE_CAN_HANDLE:false},
members:{__dp:{focusin:1,
focusout:1,
focus:1,
blur:1},
__dq:{mouseover:1,
mouseout:1,
appear:1,
disappear:1},
canHandleEvent:function(a,
b){return a instanceof qx.ui.core.Widget;
},
_dispatchEvent:function(a){var b=a.getTarget();
var c=qx.ui.core.Widget.getWidgetByElement(b,
true);
while(c&&c.isAnonymous()){c=c.getLayoutParent();
}
if(!c){return;
}if(this.__dp[a.getType()]){c=c.getFocusTarget();
}if(a.getRelatedTarget){var d=a.getRelatedTarget();
var e=qx.ui.core.Widget.getWidgetByElement(d);
while(e&&e.isAnonymous()){e=e.getLayoutParent();
}
if(e){if(this.__dp[a.getType()]){e=e.getFocusTarget();
}if(e===c){return;
}}}var f=a.getCurrentTarget();
var g=qx.ui.core.Widget.getWidgetByElement(f);
if(!g||g.getAnonymous()){return;
}if(this.__dp[a.getType()]){g=g.getFocusTarget();
}var h=a.getType();
if(!(g.isEnabled()||this.__dq[h])){return;
}var j=a.getEventPhase()==qx.event.type.Event.CAPTURING_PHASE;
var k=this.__manager.getListeners(g,
h,
j);
if(!k||k.length===0){return;
}var m=qx.event.Pool.getInstance().getObject(a.constructor);
a.clone(m);
m.setTarget(c);
m.setRelatedTarget(e||null);
m.setCurrentTarget(c);
m.setOriginalTarget(b);
for(var n=0,
o=k.length;n<o;n++){var p=k[n].context||g;
k[n].handler.call(p,
m);
}if(m.getPropagationStopped()){a.stopPropagation();
}
if(m.getDefaultPrevented()){a.preventDefault();
}qx.event.Pool.getInstance().poolObject(m);
},
registerEvent:function(a,
b,
c){var d;
if(b==="focus"||b==="blur"){d=a.getFocusElement();
}else if(b==="load"||b==="input"){d=a.getContentElement();
}else{d=a.getContainerElement();
}d.addListener(b,
this._dispatchEvent,
this,
c);
},
unregisterEvent:function(a,
b,
c){var d;
if(b==="focus"||b==="blur"){d=a.getFocusElement();
}else if(b==="load"||b==="input"){d=a.getContentElement();
}else{d=a.getContainerElement();
}d.removeListener(b,
this._dispatchEvent,
this,
c);
}},
destruct:function(){this._disposeFields("__manager");
},
defer:function(a){qx.event.Registration.addHandler(a);
}});
qx.Class.define("qx.ui.layout.Abstract",
{extend:qx.core.Object,
members:{invalidateLayoutCache:function(){this.__sizeHint=null;
},
renderLayout:function(a,
b){this.warn("Missing renderLayout() implementation!");
},
getSizeHint:function(){if(this.__sizeHint){return this.__sizeHint;
}return this.__sizeHint=this._computeSizeHint();
},
_computeSizeHint:function(){return null;
},
invalidateChildrenCache:function(){this._invalidChildrenCache=true;
},
verifyLayoutProperty:function(a,
b,
c){},
_configureSeparators:function(a){this.__widget.configureSeparators(a);
},
_renderHorizontalSeparator:function(a,
b,
c,
d){this.__widget.renderHorizontalSeparator(a,
b,
c,
d);
},
_renderVerticalSeparator:function(a,
b,
c,
d){this.__widget.renderVerticalSeparator(a,
b,
c,
d);
},
connectToWidget:function(a){if(a&&this.__widget){throw new Error("It is not possible to manually set the connected widget.");
}this.__widget=a;
this.invalidateChildrenCache();
},
_applyLayoutChange:function(){if(this.__widget){this.__widget.scheduleLayoutUpdate();
}},
_getLayoutChildren:function(){return this.__widget.getLayoutChildren();
}},
destruct:function(){this._disposeFields("__widget");
}});
qx.Class.define("qx.util.ValueManager",
{type:"abstract",
extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
this._dynamic={};
},
members:{resolveDynamic:function(a){return this._dynamic[a];
},
isDynamic:function(a){return !!this._dynamic[a];
},
resolve:function(a){if(a&&this._dynamic[a]){return this._dynamic[a];
}return a;
}},
destruct:function(){this._disposeFields("_dynamic");
}});
qx.Class.define("qx.theme.manager.Color",
{type:"singleton",
extend:qx.util.ValueManager,
properties:{theme:{check:"Theme",
nullable:true,
apply:"_applyTheme",
event:"changeTheme"}},
members:{_applyTheme:function(a){var b=this._dynamic={};
if(a){var c=a.colors;
var d=qx.util.ColorUtil;
var e;
for(var f in c){e=c[f];
if(typeof e==="string"){if(!d.isCssString(e)){throw new Error("Could not parse color: "+e);
}}else if(e instanceof Array){e=d.rgbToRgbString(e);
}else{throw new Error("Could not parse color: "+e);
}b[f]=e;
}}}}});
qx.Class.define("qx.theme.manager.Decoration",
{type:"singleton",
extend:qx.util.ValueManager,
properties:{theme:{check:"Theme",
nullable:true,
apply:"_applyTheme",
event:"changeTheme"}},
members:{resolveDynamic:function(a){return typeof a==="object"?a:this._dynamic[a];
},
isDynamic:function(a){return a&&(typeof a=="object"||this._dynamic[a]!==undefined);
},
_applyTheme:function(a){var b=this._dynamic;
for(var c in b){if(b[c].themed){b[c].dispose();
delete b[c];
}}
if(a){var d=a.decorations;
for(var c in d){var e=d[c].style;
var f=d[c].decorator;
if(f===undefined){f=qx.ui.decoration.Uniform;
}{if(f==null){throw new Error("Could not find decoration class required by decorator: "+c+"!");
}};
b[c]=(new f).set(e);
b[c].themed=true;
}}var g=qx.util.AliasManager.getInstance();
a?g.add("decoration",
a.resource):g.remove("decoration");
}}});
qx.Interface.define("qx.ui.decoration.IDecorator",
{members:{render:function(a,
b,
c,
d,
e){},
reset:function(a){},
getInsets:function(){}}});
qx.Class.define("qx.ui.decoration.Abstract",
{type:"abstract",
extend:qx.core.Object,
implement:[qx.ui.decoration.IDecorator],
members:{_resolveColor:function(a){return qx.theme.manager.Color.getInstance().resolve(a);
}}});
qx.Class.define("qx.ui.decoration.Uniform",
{extend:qx.ui.decoration.Abstract,
properties:{width:{check:"Number",
init:0},
style:{nullable:true,
check:["solid",
"dotted",
"dashed",
"double"],
init:"solid"},
color:{nullable:true,
check:"Color"},
backgroundColor:{nullable:true,
check:"Color"},
backgroundImage:{check:"String",
nullable:true},
backgroundRepeat:{check:["repeat",
"repeat-x",
"repeat-y",
"no-repeat"],
init:"repeat"}},
members:{render:function(a,
b,
c,
d,
e){if(e.style||e.init){a.setStyle("border",
this.getWidth()+"px "+this.getStyle()+" "+(this._resolveColor(this.getColor())||""));
var f=qx.util.AliasManager.getInstance().resolve(this.getBackgroundImage());
var g=qx.bom.element.Background.getStyles(f,
this.getBackgroundRepeat());
a.setStyles(g);
}
if(e.bgcolor||e.init){a.setStyle("backgroundColor",
this._resolveColor(d||this.getBackgroundColor())||null);
}
if(e.size||e.init){var h=2*this.getWidth();
qx.ui.decoration.Util.updateSize(a,
b,
c,
h,
h);
}},
_emptyStyles:{border:null,
backgroundImage:null,
backgroundRepeat:null,
backgroundColor:null},
reset:function(a){a.setStyles(this._emptyStyles);
},
getInsets:function(){var a=this.getWidth();
return {top:a,
right:a,
bottom:a,
left:a};
}}});
qx.Class.define("qx.util.AliasManager",
{type:"singleton",
extend:qx.util.ValueManager,
construct:function(){arguments.callee.base.call(this);
this._aliases={};
this.add("static",
"qx/static");
},
members:{_preprocess:function(a){var b=this._dynamic;
if(b[a]===false){return a;
}else if(b[a]===undefined){if(a.charAt(0)==="/"||a.charAt(0)==="."||a.indexOf("http://")===0||a.indexOf("https://")==="0"||a.indexOf("file://")===0){b[a]=false;
return a;
}var c=a.substring(0,
a.indexOf("/"));
var d=this._aliases[c];
if(d!==undefined){b[a]=d+a.substring(c.length);
}}return a;
},
add:function(a,
b){this._aliases[a]=b;
var c=this._dynamic;
var d={};
for(var e in c){if(e.substring(0,
e.indexOf("/"))===a){c[e]=b+e.substring(a.length);
d[e]=true;
}}},
remove:function(a){delete this._aliases[a];
},
resolve:function(a){if(a!==null){a=this._preprocess(a);
}return this._dynamic[a]||a;
}},
destruct:function(){this._disposeFields("_aliases");
}});
qx.Class.define("qx.bom.element.Background",
{statics:{__dr:["background-image:url(",
null,
");",
"background-position:",
null,
";",
"background-repeat:",
null,
";"],
compile:function(a,
b,
c,
d){var e=qx.bom.client.Engine;
if(e.GECKO&&e.VERSION<1.9&&c==d&&c!=null){d+=0.01;
}
if(c!=null||d!=null){var f=(c==null?"0px":c+"px")+" "+(d==null?"0px":d+"px");
}else{f="0 0";
}var g=qx.util.ResourceManager.toUri(a);
if(qx.core.Variant.isSet("qx.client",
"mshtml")){g=this.__ds(g);
}var h=this.__dr;
h[1]=g;
h[4]=f;
h[7]=b;
return h.join("");
},
getStyles:function(a,
b,
c,
d){var e=qx.bom.client.Engine;
if(e.GECKO&&e.VERSION<1.9&&c==d&&c!=null){d+=0.01;
}
if(c!=null||d!=null){var f=(c==null?"0px":c+"px")+" "+(d==null?"0px":d+"px");
}var g=qx.util.ResourceManager.toUri(a);
if(qx.core.Variant.isSet("qx.client",
"mshtml")){g=this.__ds(g);
}return {backgroundImage:"url("+g+")",
backgroundPosition:f||null,
backgroundRepeat:b||null};
},
set:function(a,
b,
c,
d,
e){var f=this.getStyles(b,
c,
d,
e);
for(var g in f){a.style[g]=f[g];
}},
__ds:qx.core.Variant.select("qx.client",
{"mshtml":function(a){var b="";
if(window.location.protocol==="https:"){if(a.match(/^\/\//)!=null){b=window.location.protocol;
}else if(a.match(/^\.\//)!=null){a=a.substring(a.indexOf("/"));
b=document.URL.substring(0,
document.URL.lastIndexOf("/"));
}else{b=window.location.href.substring(0,
window.location.href.lastIndexOf("/")+1);
}}return b+a;
},
"default":function(){}})}});
qx.Class.define("qx.ui.decoration.Util",
{statics:{updateSize:function(a,
b,
c,
d,
e){if(qx.core.Variant.isSet("qx.client",
"mshtml")){if(qx.bom.client.Feature.CONTENT_BOX){b-=d;
c-=e;
}}else{a.setStyle("boxSizing",
"border-box");
}a.setStyle("width",
b+"px");
a.setStyle("height",
c+"px");
}}});
qx.Bootstrap.define("qx.bom.client.Feature",
{statics:{STANDARD_MODE:false,
QUIRKS_MODE:false,
CONTENT_BOX:false,
BORDER_BOX:false,
SVG:false,
CANVAS:false,
VML:false,
XPATH:false,
__dt:function(){this.STANDARD_MODE=document.compatMode==="CSS1Compat";
this.QUIRKS_MODE=!this.STANDARD_MODE;
this.CONTENT_BOX=!qx.bom.client.Engine.MSHTML||this.STANDARD_MODE;
this.BORDER_BOX=!this.CONTENT_BOX;
this.SVG=document.implementation&&document.implementation.hasFeature&&document.implementation.hasFeature("org.w3c.dom.svg",
"1.0");
this.CANVAS=!!window.CanvasRenderingContext2D;
this.VML=qx.bom.client.Engine.MSHTML;
this.AIR=navigator.userAgent.indexOf("adobeair")!==-1;
this.GEARS=!!(window.google&&window.google.gears);
this.XPATH=!!document.evaluate;
}},
defer:function(a){a.__dt();
}});
qx.Class.define("qx.theme.manager.Appearance",
{type:"singleton",
extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
this.__styleCache={};
this.__aliasMap={};
this.__defaultStates={};
},
properties:{appearanceTheme:{check:"Theme",
nullable:true,
apply:"_applyAppearanceTheme",
event:"changeAppearanceTheme"}},
members:{_applyAppearanceTheme:function(a,
b){},
__du:function(a,
b){var c=b.appearances;
var d=c[a];
if(!d){var e="/";
var f=[];
var g=a.split(e);
var h;
while(!d&&g.length>0){f.unshift(g.pop());
var i=g.join(e);
d=c[i];
if(d){h=d.alias||d;
if(typeof h==="string"){var j=h+e+f.join(e);
return this.__du(j,
b);
}}}return null;
}else if(typeof d==="string"){return this.__du(d,
b);
}else if(d.include&&!d.style){return this.__du(d.include,
b);
}return a;
},
styleFrom:function(a,
b,
c){if(!c){c=this.getAppearanceTheme();
}var d=this.__aliasMap;
var e=d[a];
if(!e){e=d[a]=this.__du(a,
c);
}var f=c.appearances[e];
if(!f){this.warn("Missing appearance: "+a);
return null;
}if(!f.style){return null;
}var g=e;
if(b){var h=f.$$bits;
if(!h){h=f.$$bits={};
f.$$length=0;
}var i=0;
for(var j in b){if(h[j]==null){h[j]=1<<f.$$length++;
}i+=h[j];
}if(i>0){g+=":"+i;
}}var k=this.__styleCache;
if(k[g]!==undefined){return k[g];
}if(!b){b=this.__defaultStates;
}var l;
if(f.include||f.base){var m=f.style(b);
var n;
if(f.include){n=this.styleFrom(f.include,
b,
c);
}l={};
if(f.base){var o=this.styleFrom(e,
b,
f.base);
if(f.include){for(var p in o){if(n[p]===undefined&&m[p]===undefined){l[p]=o[p];
}}}else{for(var p in o){if(m[p]===undefined){l[p]=o[p];
}}}}if(f.include){for(var p in n){if(m[p]===undefined){l[p]=n[p];
}}}for(var p in m){l[p]=m[p];
}}else{l=f.style(b);
}return k[g]=l||null;
}},
destruct:function(){this._disposeFields("__styleCache",
"__aliasMap");
}});
qx.Class.define("qx.ui.basic.Image",
{extend:qx.ui.core.Widget,
construct:function(a){arguments.callee.base.call(this);
if(a){this.setSource(a);
}},
properties:{source:{check:"String",
init:null,
nullable:true,
event:"changeSource",
apply:"_applySource",
themeable:true},
appearance:{refine:true,
init:"image"},
allowShrinkX:{refine:true,
init:false},
allowShrinkY:{refine:true,
init:false},
allowGrowX:{refine:true,
init:false},
allowGrowY:{refine:true,
init:false}},
members:{_createContentElement:function(){return new qx.html.ClippedImage();
},
_getContentHint:function(){return {width:this.__width||0,
height:this.__height||0};
},
_applyEnabled:function(a,
b){arguments.callee.base.call(this,
a,
b);
if(this.getSource()){this._styleSource();
}},
_applySource:function(a){this._styleSource();
},
_styleSource:function(){var a=qx.util.AliasManager.getInstance().resolve(this.getSource());
var b=this._contentElement;
if(!a){b.resetSource();
return;
}var c=qx.util.ResourceManager;
var d=qx.io2.ImageLoader;
if(c.has(a)){if(!this.getEnabled()){var e=a.replace(/\.([a-z]+)$/,
"-disabled.$1");
if(c.has(e)){a=e;
this.addState("replacement");
}else{this.removeState("replacement");
}}if(b.getSource()===a){return;
}b.setSource(a,
false);
this._updateSize(b.getWidth(),
b.getHeight());
}else if(d.isLoaded(a)){b.setSource(a,
false);
this._updateSize(b.getWidth(),
b.getHeight());
}else{{var f=arguments.callee.self;
if(!f._warned){f._warned={};
}
if(!f._warned[a]){this.debug("Unmanaged image: "+a);
f._warned[a]=true;
}};
if(!qx.io2.ImageLoader.isFailed(a)){qx.io2.ImageLoader.load(a,
this.__dv,
this);
}}},
__dv:function(a,
b){if(a!==qx.util.AliasManager.getInstance().resolve(this.getSource())){return;
}if(!b){this.warn("Image could not be loaded: "+a);
return;
}this._styleSource();
},
_updateSize:function(a,
b){if(a!==this.__width||b!==this.__height){this.__width=a;
this.__height=b;
qx.ui.core.queue.Layout.add(this);
}}}});
qx.Mixin.define("qx.ui.core.MAlign",
{properties:{position:{check:["top-left",
"top-right",
"bottom-left",
"bottom-right",
"left-top",
"left-bottom",
"right-top",
"right-bottom"],
init:"bottom-left",
themeable:true},
domMove:{check:"Boolean",
init:false},
smart:{check:"Boolean",
init:true,
themeable:true},
offsetLeft:{check:"Integer",
init:0,
themeable:true},
offsetTop:{check:"Integer",
init:0,
themeable:true},
offsetRight:{check:"Integer",
init:0,
themeable:true},
offsetBottom:{check:"Integer",
init:0,
themeable:true},
offset:{group:["offsetTop",
"offsetRight",
"offsetBottom",
"offsetLeft"],
mode:"shorthand",
themeable:true}},
members:{getLayoutLocation:function(a){var b,
c,
d,
e;
c=a.getBounds();
d=c.left;
e=c.top;
var f=c;
a=a.getLayoutParent();
while(a&&!a.isRootWidget()){c=a.getBounds();
d+=c.left;
e+=c.top;
b=a.getInsets();
d+=b.left;
e+=b.top;
a=a.getLayoutParent();
}if(a.isRootWidget()){var g=a.getContainerLocation();
if(g){d+=g.left;
e+=g.top;
}}return {left:d,
top:e,
right:d+f.width,
bottom:e+f.height};
},
moveTo:function(a,
b){if(this.getDomMove()){this.setDomPosition(a,
b);
}else{this.setLayoutProperties({left:a,
top:b});
}},
alignToWidget:function(a){var b=a.getContainerLocation()||this.getLayoutLocation(a);
this.__dw(b);
},
alignToMouse:function(a){var b=a.getDocumentLeft();
var c=a.getDocumentTop();
var d={left:b,
top:c,
right:b,
bottom:c};
this.__dw(d);
},
alignToElement:function(a){var b=qx.bom.element.Location.get(a);
var c={left:b.left,
top:b.top,
right:b.left+a.offsetWidth,
bottom:b.top+a.offsetHeight};
this.__dw(c);
},
alignToPoint:function(a){var b={left:a.left,
top:a.top,
right:a.left,
bottom:a.top};
this.__dw(b);
},
__dw:function(a){var b=this.getSizeHint();
var c=this.getLayoutParent().getBounds();
var d=this.getPosition();
var e=this.getSmart();
var f={left:this.getOffsetLeft(),
top:this.getOffsetTop(),
right:this.getOffsetRight(),
bottom:this.getOffsetBottom()};
var g=qx.util.AlignUtil.compute(b,
c,
a,
d,
e,
f);
this.moveTo(g.left,
g.top);
}}});
qx.Class.define("qx.ui.core.DragDropCursor",
{extend:qx.ui.basic.Image,
include:qx.ui.core.MAlign,
type:"singleton",
construct:function(){arguments.callee.base.call(this);
this.setZIndex(1e8);
this.setDomMove(true);
var a=this.getApplicationRoot();
a.add(this,
{left:-1000,
top:-1000});
},
properties:{appearance:{refine:true,
init:"dragdrop-cursor"},
action:{check:["alias",
"copy",
"move"],
apply:"_applyAction",
nullable:true}},
members:{_applyAction:function(a,
b){if(b){this.removeState(b);
}
if(a){this.addState(a);
}}}});
qx.Class.define("qx.html.ClippedImage",
{extend:qx.html.Element,
construct:function(){arguments.callee.base.call(this);
this.setStyle("overflow",
"hidden");
},
members:{setSource:function(a,
b){var c,
d;
var e=qx.io2.ImageLoader;
var f=qx.util.ResourceManager.getData(a);
if(f){this.__width=f[0];
this.__height=f[1];
if(f.length>4){a=f[4];
c=f[5];
d=f[6];
}else{c=0;
d=0;
}}else if(e.isLoaded(a)){var g=e.getSize(a);
this.__width=g.width;
this.__height=g.height;
}else{throw new Error("The image '"+a+"' must be registered at qx.util.ResourceManager!");
}var h=qx.bom.element.Background.getStyles(a,
"repeat",
c,
d);
this.setStyles(h);
if(b!==false){this.setStyle("width",
this.__width+"px");
this.setStyle("height",
this.__height+"px");
}this.__source=a;
return this;
},
resetSource:qx.core.Variant.select("qx.client",
{"mshtml":function(){this.removeStyle("filter");
this.removeStyle("backgroundImage");
this.__source=null;
},
"default":function(){this.removeStyle("backgroundImage");
this.__source=null;
}}),
getSource:function(){return this.__source||null;
},
getWidth:function(){return this.__width||0;
},
getHeight:function(){return this.__height||0;
}}});
qx.Bootstrap.define("qx.io2.ImageLoader",
{statics:{__dx:{},
isLoaded:function(a){var b=this.__dx[a];
return !!(b&&b.loaded);
},
isFailed:function(a){var b=this.__dx[a];
return !!(b&&b.failed);
},
isLoading:function(a){var b=this.__dx[a];
return !!(b&&b.loading);
},
getSize:function(a){return this.__dx[a]||
{width:0,
height:0};
},
load:function(a,
b,
c){var d=this.__dx[a];
if(!d){d=this.__dx[a]={};
}if(b&&!c){c=window;
}if(d.loaded||d.loading||d.failed){if(b){if(d.loading){d.callbacks.push(b,
c);
}else{b.call(c,
a,
d);
}}}else{d.loading=true;
d.callbacks=[];
if(b){d.callbacks.push(b,
c);
}var e=new Image();
var f=qx.lang.Function.listener(this.__dy,
this,
e,
a);
e.onload=f;
e.onerror=f;
e.src=a;
}},
__dy:function(a,
b,
c){var d=this.__dx[c];
if(a.type==="load"){d.loaded=true;
d.width=this.__dz(b);
d.height=this.__dA(b);
}else{d.failed=true;
}b.onload=b.onerror=null;
var e=d.callbacks;
delete d.loading;
delete d.callbacks;
for(var f=0,
g=e.length;f<g;f+=2){e[f].call(e[f+1],
c,
d);
}},
__dz:qx.core.Variant.select("qx.client",
{"gecko":function(a){return a.naturalWidth;
},
"default":function(a){return a.width;
}}),
__dA:qx.core.Variant.select("qx.client",
{"gecko":function(a){return a.naturalHeight;
},
"default":function(a){return a.height;
}})}});
qx.Class.define("qx.util.AlignUtil",
{statics:{compute:function(a,
b,
c,
d,
e,
f){var g=0;
var h=0;
var i=d.split("-");
var j=i[0];
var k=i[1];
var l=0,
m=0,
n=0,
o=0;
if(f){l+=f.left||0;
m+=f.top||0;
n+=f.right||0;
o+=f.bottom||0;
}switch(j){case "left":g=c.left-a.width-l;
break;
case "top":h=c.top-a.height-m;
break;
case "right":g=c.right+n;
break;
case "bottom":h=c.bottom+o;
break;
}switch(k){case "left":g=c.left;
break;
case "top":h=c.top;
break;
case "right":g=c.right-a.width;
break;
case "bottom":h=c.bottom-a.height;
break;
}
if(e===false){return {left:g,
top:h};
}else{var p=Math.min(g,
b.width-g-a.width);
if(p<0){var q=g;
if(g<0){if(j=="left"){q=c.right+n;
}else if(k=="right"){q=c.left;
}}else{if(j=="right"){q=c.left-a.width-l;
}else if(k=="left"){q=c.right-a.width;
}}fixedRatingX=Math.min(q,
b.width-q-a.width);
if(fixedRatingX>p){g=q;
p=fixedRatingX;
}}var r=Math.min(h,
b.height-h-a.height);
if(r<0){var s=h;
if(h<0){if(j=="top"){s=c.bottom+o;
}else if(k=="bottom"){s=c.top;
}}else{if(j=="bottom"){s=c.top-a.height-m;
}else if(k=="top"){s=c.bottom-a.height;
}}fixedRatingY=Math.min(s,
b.height-s-a.height);
if(fixedRatingY>r){h=s;
r=fixedRatingY;
}}return {left:g,
top:h,
ratingX:p,
ratingY:r};
}}}});
qx.Class.define("qx.ui.splitpane.Slider",
{extend:qx.ui.core.Widget,
properties:{allowShrinkX:{refine:true,
init:false},
allowShrinkY:{refine:true,
init:false}}});
qx.Class.define("qx.ui.splitpane.Splitter",
{extend:qx.ui.core.Widget,
construct:function(a){arguments.callee.base.call(this);
if(a.getOrientation()=="vertical"){this._setLayout(new qx.ui.layout.HBox(0,
"center"));
this._getLayout().setAlignY("middle");
}else{this._setLayout(new qx.ui.layout.VBox(0,
"middle"));
this._getLayout().setAlignX("center");
}this._createChildControl("knob");
},
properties:{allowShrinkX:{refine:true,
init:false},
allowShrinkY:{refine:true,
init:false}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "knob":b=new qx.ui.basic.Image;
this._add(b);
break;
}return b||arguments.callee.base.call(this,
a);
}}});
qx.Class.define("qx.ui.layout.HBox",
{extend:qx.ui.layout.Abstract,
construct:function(a,
b){arguments.callee.base.call(this);
if(a){this.setSpacing(a);
}
if(b){this.setAlignX(b);
}},
properties:{alignX:{check:["left",
"center",
"right"],
init:"left",
apply:"_applyLayoutChange"},
alignY:{check:["top",
"middle",
"bottom",
"baseline"],
init:"top",
apply:"_applyLayoutChange"},
spacing:{check:"Integer",
init:0,
apply:"_applyLayoutChange"},
separator:{check:"Array",
nullable:true,
apply:"_applyLayoutChange"},
reversed:{check:"Boolean",
init:false,
apply:"_applyReversed"}},
members:{_applyReversed:function(){this._invalidChildrenCache=true;
this._applyLayoutChange();
},
__dB:function(){var a=this._getLayoutChildren();
var b=a.length;
var c=false;
var d=this.__widths&&this.__widths.length!=b&&this._flexs&&this._widths;
var e;
var f=d?this._widths:new Array(b);
var g=d?this._flexs:new Array(b);
if(this.getReversed()){a=a.concat().reverse();
}for(var h=0;h<b;h++){e=a[h].getLayoutProperties();
if(e.width!=null){f[h]=parseFloat(e.width)/100;
}
if(e.flex!=null){g[h]=e.flex;
c=true;
}}if(!d){this.__widths=f;
this.__flexs=g;
}this.__enableFlex=c;
this.__children=a;
delete this._invalidChildrenCache;
},
verifyLayoutProperty:function(a,
b,
c){this.assert(b==="flex"||b==="width",
"The property '"+b+"' is not supported by the box layout!");
if(b=="width"){this.assertMatch(c,
qx.ui.layout.Util.PERCENT_VALUE);
}else{this.assertNumber(c);
this.assert(c>=0);
}},
renderLayout:function(a,
b){if(this._invalidChildrenCache){this.__dB();
}var c=this.__children;
var d=c.length;
var e=qx.ui.layout.Util;
var f=this.getSpacing();
var g=this.getSeparator();
if(g){var h=e.computeSeparatorGaps(c,
f,
g.length);
}else{var h=e.computeHorizontalGaps(c,
f,
true);
}var j,
k,
l,
m;
var n=[];
var o=h;
for(j=0;j<d;j+=1){m=this.__widths[j];
l=m!=null?Math.floor((a-h)*m):c[j].getSizeHint().width;
n.push(l);
o+=l;
}if(this.__enableFlex&&o!=a){var p={};
var q,
r;
for(j=0;j<d;j+=1){q=this.__flexs[j];
if(q>0){u=c[j].getSizeHint();
p[j]={min:u.minWidth,
value:n[j],
max:u.maxWidth,
flex:q};
}}var s=e.computeFlexOffsets(p,
a,
o);
for(j in s){r=s[j].offset;
n[j]+=r;
o+=r;
}}var t=c[0].getMarginLeft();
if(o<a&&this.getAlignX()!="left"){t=a-o;
if(this.getAlignX()==="center"){t=Math.round(t/2);
}}var u,
v,
w,
l,
x,
y,
z;
var f=this.getSpacing();
var g=d>1&&this.getSeparator();
if(g){this._configureSeparators(d-1);
}for(j=0;j<d;j+=1){k=c[j];
l=n[j];
u=k.getSizeHint();
y=k.getMarginTop();
z=k.getMarginBottom();
w=Math.max(u.minHeight,
Math.min(b-y-z,
u.maxHeight));
v=e.computeVerticalAlignOffset(k.getAlignY()||this.getAlignY(),
w,
b,
y,
z);
if(j>0){if(g){t+=x+f;
this._renderHorizontalSeparator(g,
j-1,
t,
b);
t+=g.length+f+k.getMarginLeft();
}else{t+=e.collapseMargins(f,
x,
k.getMarginLeft());
}}k.renderLayout(t,
v,
l,
w);
t+=l;
x=k.getMarginRight();
}},
_computeSizeHint:function(){if(this._invalidChildrenCache){this.__dB();
}var a=qx.ui.layout.Util;
var b=this.__children;
var c=0,
d=0;
var e=0,
f=0;
var g,
h,
j;
for(var k=0,
m=b.length;k<m;k+=1){g=b[k];
h=g.getSizeHint();
d+=h.width;
c+=this.__flexs[k]>0?h.minWidth:h.width;
j=g.getMarginTop()+g.getMarginBottom();
if((h.height+j)>f){f=h.height+j;
}if((h.minHeight+j)>e){e=h.minHeight+j;
}}var n=this.getSpacing();
var o=this.getSeparator();
if(o){var p=a.computeSeparatorGaps(b,
n,
o.length);
}else{var p=a.computeHorizontalGaps(b,
n,
true);
}return {minWidth:c+p,
width:d+p,
minHeight:e,
height:f};
}}});
qx.Class.define("qx.ui.layout.Util",
{statics:{PERCENT_VALUE:/[0-9]+(?:\.[0-9]+)?%/,
computeFlexOffsets:function(a,
b,
c){var d,
e,
f,
g;
var h=b>c;
var i=Math.abs(b-c);
var j,
k;
var l={};
for(e in a){d=a[e];
l[e]={potential:h?d.max-d.value:d.value-d.min,
flex:h?d.flex:1/d.flex,
offset:0};
}while(i!=0){g=Infinity;
f=0;
for(e in l){d=l[e];
if(d.potential>0){f+=d.flex;
g=Math.min(g,
d.potential/d.flex);
}}if(f==0){break;
}g=Math.min(i,
g*f)/f;
j=0;
for(e in l){d=l[e];
if(d.potential>0){k=Math.min(i,
d.potential,
Math.ceil(g*d.flex));
j+=k-g*d.flex;
if(j>=1){j-=1;
k-=1;
}d.potential-=k;
if(h){d.offset+=k;
}else{d.offset-=k;
}i-=k;
}}}return l;
},
computeHorizontalAlignOffset:function(a,
b,
c,
d,
e){if(d==null){d=0;
}
if(e==null){e=0;
}var f=0;
switch(a){case "left":f=d;
break;
case "right":f=c-b-e;
break;
case "center":f=Math.round((c-b)/2);
if(f<d){f=d;
}else if(f<e){f=Math.max(d,
c-b-e);
}break;
}return f;
},
computeVerticalAlignOffset:function(a,
b,
c,
d,
e){if(d==null){d=0;
}
if(e==null){e=0;
}var f=0;
switch(a){case "top":f=d;
break;
case "bottom":f=c-b-e;
break;
case "middle":f=Math.round((c-b)/2);
if(f<d){f=d;
}else if(f<e){f=Math.max(d,
c-b-e);
}break;
}return f;
},
collapseMargins:function(a){var b=0,
c=0;
for(var d=0,
e=arguments.length;d<e;d++){var f=arguments[d];
if(f<0){c=Math.min(c,
f);
}else if(f>0){b=Math.max(b,
f);
}}return b+c;
},
computeHorizontalGaps:function(a,
b,
c){if(b==null){b=0;
}var d=0;
if(c){d+=a[0].getMarginLeft();
for(var e=1,
f=a.length;e<f;e+=1){d+=this.collapseMargins(b,
a[e-1].getMarginRight(),
a[e].getMarginLeft());
}d+=a[f-1].getMarginRight();
}else{for(var e=1,
f=a.length;e<f;e+=1){d+=a[e].getMarginLeft()+a[e].getMarginRight();
}d+=(b*(f-1));
}return d;
},
computeVerticalGaps:function(a,
b,
c){if(b==null){b=0;
}var d=0;
if(c){d+=a[0].getMarginTop();
for(var e=1,
f=a.length;e<f;e+=1){d+=this.collapseMargins(b,
a[e-1].getMarginBottom(),
a[e].getMarginTop());
}d+=a[f-1].getMarginBottom();
}else{for(var e=1,
f=a.length;e<f;e+=1){d+=a[e].getMarginTop()+a[e].getMarginBottom();
}d+=(b*(f-1));
}return d;
},
computeSeparatorGaps:function(a,
b,
c){var d=0;
for(var e=0,
f=a.length;e<f;e++){var g=a[e];
d+=g.getMarginLeft()+g.getMarginRight();
}d+=(b+c+b)*(f-1);
return d;
},
arrangeIdeals:function(a,
b,
c,
d,
e,
f){if(b<a||e<d){if(b<a&&e<d){b=a;
e=d;
}else if(b<a){e-=(a-b);
b=a;
if(e<d){e=d;
}}else if(e<d){b-=(d-e);
e=d;
if(b<a){b=a;
}}}
if(b>c||e>f){if(b>c&&e>f){b=c;
e=f;
}else if(b>c){e+=(b-c);
b=c;
if(e>f){e=f;
}}else if(e>f){b+=(e-f);
e=f;
if(b>c){b=c;
}}}return {begin:b,
end:e};
}}});
qx.Class.define("qx.ui.layout.VBox",
{extend:qx.ui.layout.Abstract,
construct:function(a,
b){arguments.callee.base.call(this);
if(a){this.setSpacing(a);
}
if(b){this.setAlignY(b);
}},
properties:{alignY:{check:["top",
"middle",
"bottom"],
init:"top",
apply:"_applyLayoutChange"},
alignX:{check:["left",
"center",
"right",
"baseline"],
init:"left",
apply:"_applyLayoutChange"},
spacing:{check:"Integer",
init:0,
apply:"_applyLayoutChange"},
separator:{check:"Array",
nullable:true,
apply:"_applyLayoutChange"},
reversed:{check:"Boolean",
init:false,
apply:"_applyReversed"}},
members:{_applyReversed:function(){this._invalidChildrenCache=true;
this._applyLayoutChange();
},
__dC:function(){var a=this._getLayoutChildren();
var b=a.length;
var c=false;
var d=this.__heights&&this.__heights.length!=b&&this._flexs&&this._heights;
var e;
var f=d?this._heights:new Array(b);
var g=d?this._flexs:new Array(b);
if(this.getReversed()){a=a.concat().reverse();
}for(var h=0;h<b;h++){e=a[h].getLayoutProperties();
if(e.height!=null){f[h]=parseFloat(e.height)/100;
}
if(e.flex!=null){g[h]=e.flex;
c=true;
}}if(!d){this.__heights=f;
this.__flexs=g;
}this.__enableFlex=c;
this.__children=a;
delete this._invalidChildrenCache;
},
verifyLayoutProperty:function(a,
b,
c){this.assert(b==="flex"||b==="height",
"The property '"+b+"' is not supported by the box layout!");
if(b=="height"){this.assertMatch(c,
qx.ui.layout.Util.PERCENT_VALUE);
}else{this.assertNumber(c);
this.assert(c>=0);
}},
renderLayout:function(a,
b){if(this._invalidChildrenCache){this.__dC();
}var c=this.__children;
var d=c.length;
var e=qx.ui.layout.Util;
var f=this.getSpacing();
var g=this.getSeparator();
if(g){var h=e.computeSeparatorGaps(c,
f,
g.length);
}else{var h=e.computeVerticalGaps(c,
f,
true);
}var j,
k,
l,
m;
var n=[];
var o=h;
for(j=0;j<d;j+=1){m=this.__heights[j];
l=m!=null?Math.floor((b-h)*m):c[j].getSizeHint().height;
n.push(l);
o+=l;
}if(this.__enableFlex&&o!=b){var p={};
var q,
r;
for(j=0;j<d;j+=1){q=this.__flexs[j];
if(q>0){u=c[j].getSizeHint();
p[j]={min:u.minHeight,
value:n[j],
max:u.maxHeight,
flex:q};
}}var s=e.computeFlexOffsets(p,
b,
o);
for(j in s){r=s[j].offset;
n[j]+=r;
o+=r;
}}var t=c[0].getMarginTop();
if(o<b&&this.getAlignY()!="top"){t=b-o;
if(this.getAlignY()==="middle"){t=Math.round(t/2);
}}var u,
v,
w,
l,
x,
y,
z;
var f=this.getSpacing();
var g=d>1&&this.getSeparator();
if(g){this._configureSeparators(d-1);
}for(j=0;j<d;j+=1){k=c[j];
l=n[j];
u=k.getSizeHint();
y=k.getMarginLeft();
z=k.getMarginRight();
w=Math.max(u.minWidth,
Math.min(a-y-z,
u.maxWidth));
v=e.computeHorizontalAlignOffset(k.getAlignX()||this.getAlignX(),
w,
a,
y,
z);
if(j>0){if(g){t+=x+f;
this._renderVerticalSeparator(g,
j-1,
t,
a);
t+=g.length+f+k.getMarginTop();
}else{t+=e.collapseMargins(f,
x,
k.getMarginTop());
}}k.renderLayout(v,
t,
w,
l);
t+=l;
x=k.getMarginBottom();
}},
_computeSizeHint:function(){if(this._invalidChildrenCache){this.__dC();
}var a=qx.ui.layout.Util;
var b=this.__children;
var c=0,
d=0;
var e=0,
f=0;
var g,
h,
j;
for(var k=0,
m=b.length;k<m;k+=1){g=b[k];
h=g.getSizeHint();
d+=h.height;
c+=this.__flexs[k]>0?h.minHeight:h.height;
j=g.getMarginLeft()+g.getMarginRight();
if((h.width+j)>f){f=h.width+j;
}if((h.minWidth+j)>e){e=h.minWidth+j;
}}var n=this.getSpacing();
var o=this.getSeparator();
if(o){var p=a.computeSeparatorGaps(b,
n,
o.length);
}else{var p=a.computeVerticalGaps(b,
n,
true);
}return {minHeight:c+p,
height:d+p,
minWidth:e,
width:f};
}}});
qx.Class.define("qx.ui.layout.VSplit",
{extend:qx.ui.layout.Abstract,
construct:function(){arguments.callee.base.call(this);
},
members:{verifyLayoutProperty:function(a,
b,
c){this.assert(b==="type"||b==="flex",
"The property '"+b+"' is not supported by the split layout!");
if(b=="flex"){this.assertNumber(c);
}
if(b=="type"){this.assertString(c);
}},
renderLayout:function(a,
b){var c=this._getLayoutChildren();
var d=c.length;
var e,
f;
var g,
h,
j,
k;
for(var l=0;l<d;l++){e=c[l];
f=e.getLayoutProperties().type;
if(f==="splitter"){h=e;
}else if(f==="slider"){j=e;
}else if(!g){g=e;
}else{k=e;
}}
if(g&&k){var m=g.getLayoutProperties().flex;
var n=k.getLayoutProperties().flex;
if(m==null){m=1;
}
if(n==null){n=1;
}var o=g.getSizeHint();
var p=h.getSizeHint();
var q=k.getSizeHint();
var r=o.height;
var s=p.height;
var t=q.height;
if(m>0&&n>0){var u=m+n;
var v=b-s;
var r=Math.round((v/u)*m);
var t=v-r;
var w=qx.ui.layout.Util.arrangeIdeals(o.minHeight,
r,
o.maxHeight,
q.minHeight,
t,
q.maxHeight);
r=w.begin;
t=w.end;
}else if(m>0){r=b-s-t;
if(r<o.minHeight){r=o.minHeight;
}
if(r>o.maxHeight){r=o.maxHeight;
}}else if(n>0){t=b-r-s;
if(t<q.minHeight){t=q.minHeight;
}
if(t>q.maxHeight){t=q.maxHeight;
}}g.renderLayout(0,
0,
a,
r);
h.renderLayout(0,
r,
a,
s);
k.renderLayout(0,
r+s,
a,
t);
}else{h.renderLayout(0,
0,
0,
0);
if(g){g.renderLayout(0,
0,
a,
b);
}else if(k){k.renderLayout(0,
0,
a,
b);
}}},
_computeSizeHint:function(){var a=this._getLayoutChildren();
var b=a.length;
var c,
d,
e;
var f=0,
g=0,
h=0;
var j=0,
k=0,
l=0;
for(var m=0;m<b;m++){c=a[m];
e=c.getLayoutProperties();
if(e.type==="slider"){continue;
}d=c.getSizeHint();
f+=d.minHeight;
g+=d.height;
h+=d.maxHeight;
if(d.minWidth>j){j=d.minWidth;
}
if(d.width>k){k=d.width;
}
if(d.maxWidth>l){l=d.maxWidth;
}}return {minHeight:f,
height:g,
maxHeight:h,
minWidth:j,
width:k,
maxWidth:l};
}}});
qx.Class.define("qx.ui.layout.HSplit",
{extend:qx.ui.layout.Abstract,
construct:function(){arguments.callee.base.call(this);
},
members:{verifyLayoutProperty:function(a,
b,
c){this.assert(b==="type"||b==="flex",
"The property '"+b+"' is not supported by the split layout!");
if(b=="flex"){this.assertNumber(c);
}
if(b=="type"){this.assertString(c);
}},
renderLayout:function(a,
b){var c=this._getLayoutChildren();
var d=c.length;
var e,
f;
var g,
h,
j,
k;
for(var l=0;l<d;l++){e=c[l];
f=e.getLayoutProperties().type;
if(f==="splitter"){h=e;
}else if(f==="slider"){j=e;
}else if(!g){g=e;
}else{k=e;
}}
if(g&&k){var m=g.getLayoutProperties().flex;
var n=k.getLayoutProperties().flex;
if(m==null){m=1;
}
if(n==null){n=1;
}var o=g.getSizeHint();
var p=h.getSizeHint();
var q=k.getSizeHint();
var r=o.width;
var s=p.width;
var t=q.width;
if(m>0&&n>0){var u=m+n;
var v=a-s;
var r=Math.round((v/u)*m);
var t=v-r;
var w=qx.ui.layout.Util.arrangeIdeals(o.minWidth,
r,
o.maxWidth,
q.minWidth,
t,
q.maxWidth);
r=w.begin;
t=w.end;
}else if(m>0){r=a-s-t;
if(r<o.minWidth){r=o.minWidth;
}
if(r>o.maxWidth){r=o.maxWidth;
}}else if(n>0){t=a-r-s;
if(t<q.minWidth){t=q.minWidth;
}
if(t>q.maxWidth){t=q.maxWidth;
}}g.renderLayout(0,
0,
r,
b);
h.renderLayout(r,
0,
s,
b);
k.renderLayout(r+s,
0,
t,
b);
}else{h.renderLayout(0,
0,
0,
0);
if(g){g.renderLayout(0,
0,
a,
b);
}else if(k){k.renderLayout(0,
0,
a,
b);
}}},
_computeSizeHint:function(){var a=this._getLayoutChildren();
var b=a.length;
var c,
d,
e;
var f=0,
g=0,
h=0;
var j=0,
k=0,
l=0;
for(var m=0;m<b;m++){c=a[m];
e=c.getLayoutProperties();
if(e.type==="slider"){continue;
}d=c.getSizeHint();
f+=d.minWidth;
g+=d.width;
h+=d.maxWidth;
if(d.minHeight>j){j=d.minHeight;
}
if(d.height>k){k=d.height;
}
if(d.maxHeight>l){l=d.maxHeight;
}}return {minWidth:f,
width:g,
maxWidth:h,
minHeight:j,
height:k,
maxHeight:l};
}}});
qx.Class.define("qx.event.message.Bus",
{statics:{__dD:{},
getSubscriptions:function(){return this.__dD;
},
subscribe:function(a,
b,
c){if(!a||typeof b!="function"){this.error("Invalid parameters!");
return false;
}var d=this.getSubscriptions();
if(this.checkSubscription(a)){if(this.checkSubscription(a,
b,
c)){this.warn("Object method already subscribed to "+a);
return false;
}d[a].push({subscriber:b,
context:c||null});
return true;
}else{d[a]=[{subscriber:b,
context:c||null}];
return true;
}},
checkSubscription:function(a,
b,
c){var d=this.getSubscriptions();
if(!d[a]||d[a].length==0){return false;
}
if(b){for(var e=0;e<d[a].length;e++){if(d[a][e].subscriber==b&&d[a][e].context==(c||null)){return true;
}}return false;
}return true;
},
unsubscribe:function(a,
b,
c){var d=this.getSubscriptions();
if(!d[a]){return false;
}
if(b){for(var e=0;e<d[a].length;e++){if(d[a][e].subscriber==b&&d[a][e].context==(c||null)){d[a].splice(e,
1);
return true;
}}}d[a]=null;
return true;
},
dispatch:function(a){if(typeof a=="string"){var b=typeof arguments[1]!="undefined"?arguments[1]:true;
a=new qx.event.message.Message(a,
b);
}var c=this.getSubscriptions();
var d=a.getName();
for(var e in c){var f=e.indexOf("*");
if(f>-1){if(f==1||e.substr(0,
f)==d.substr(0,
f)){for(var g=0;g<c[e].length;g++){var h=c[e][g].subscriber;
var j=c[e][g].context;
h.call(j,
a);
}}}else{if(e==d){for(var g=0;g<c[d].length;g++){var h=c[d][g].subscriber;
var j=c[d][g].context;
h.call(j,
a);
}return true;
}}}}}});
qx.Class.define("qx.event.message.Message",
{extend:qx.core.Object,
construct:function(a,
b){arguments.callee.base.call(this);
if(a!=null){this.setName(a);
}
if(b!=null){this.setData(b);
}},
properties:{name:{check:"String"},
data:{},
sender:{check:"Object"}}});
qx.Mixin.define("qx.ui.core.MRemoteChildrenHandling",
{members:{getChildren:function(){return this.getChildrenContainer().getChildren();
},
hasChildren:function(){return this.getChildrenContainer().hasChildren();
},
add:function(a,
b){return this.getChildrenContainer().add(a,
b);
},
remove:function(a){return this.getChildrenContainer().remove(a);
},
removeAll:function(){return this.getChildrenContainer().removeAll();
},
indexOf:function(a){return this.getChildrenContainer().indexOf(a);
},
addAt:function(a,
b,
c){return this.getChildrenContainer().addAt(a,
b,
c);
},
addBefore:function(a,
b,
c){return this.getChildrenContainer().addBefore(a,
b,
c);
},
addAfter:function(a,
b,
c){return this.getChildrenContainer().addAfter(a,
b,
c);
},
removeAt:function(a){return this.getChildrenContainer().removeAt(a);
}}});
qx.Class.define("qx.ui.toolbar.Part",
{extend:qx.ui.core.Widget,
include:[qx.ui.core.MRemoteChildrenHandling],
construct:function(){arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.HBox);
this._createChildControl("handle");
},
properties:{appearance:{refine:true,
init:"toolbar/part"},
show:{init:"inherit",
check:["both",
"label",
"icon",
"none"],
nullable:true,
inheritable:true,
event:"changeShow"}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "handle":b=new qx.ui.core.Widget();
b.setHeight(0);
this._add(b);
break;
case "container":b=new qx.ui.toolbar.PartContainer;
this._add(b);
break;
}return b||arguments.callee.base.call(this,
a);
},
getChildrenContainer:function(){return this._getChildControl("container");
},
addSeparator:function(){this.add(new qx.ui.toolbar.Separator);
},
getMenuButtons:function(){var a=this.getChildren();
var b=[];
var c;
for(var d=0,
e=a.length;d<e;d++){c=a[d];
if(c instanceof qx.ui.toolbar.MenuButton){b.push(c);
}}return b;
}}});
qx.Mixin.define("qx.ui.core.MChildrenHandling",
{members:{getChildren:function(){return this._getChildren();
},
hasChildren:function(){return this._hasChildren();
},
indexOf:function(a){return this._indexOf(a);
},
add:function(a,
b){this._add(a,
b);
},
addAt:function(a,
b,
c){this._addAt(a,
b,
c);
},
addBefore:function(a,
b,
c){this._addBefore(a,
b,
c);
},
addAfter:function(a,
b,
c){this._addAfter(a,
b,
c);
},
remove:function(a){this._remove(a);
},
removeAt:function(a){this._removeAt(a);
},
removeAll:function(){this._removeAll();
}},
statics:{remap:function(a){a.getChildren=a._getChildren;
a.hasChildren=a._hasChildren;
a.indexOf=a._indexOf;
a.add=a._add;
a.addAt=a._addAt;
a.addBefore=a._addBefore;
a.addAfter=a._addAfter;
a.remove=a._remove;
a.removeAt=a._removeAt;
a.removeAll=a._removeAll;
}}});
qx.Mixin.define("qx.ui.core.MLayoutHandling",
{members:{setLayout:function(a){return this._setLayout(a);
},
getLayout:function(){return this._getLayout();
}},
statics:{remap:function(a){a.getLayout=a._getLayout;
a.setLayout=a._setLayout;
}}});
qx.Class.define("qx.ui.container.Composite",
{extend:qx.ui.core.Widget,
include:[qx.ui.core.MChildrenHandling,
qx.ui.core.MLayoutHandling],
construct:function(a){arguments.callee.base.call(this);
if(a!=null){this._setLayout(a);
}},
events:{addChildWidget:"qx.event.type.Data",
removeChildWidget:"qx.event.type.Data"},
members:{_afterAddChild:function(a){this.fireNonBubblingEvent("addChildWidget",
qx.event.type.Data,
[a]);
},
_afterRemoveChild:function(a){this.fireNonBubblingEvent("removeChildWidget",
qx.event.type.Data,
[a]);
}},
defer:function(a,
b){qx.ui.core.MChildrenHandling.remap(b);
qx.ui.core.MLayoutHandling.remap(b);
}});
qx.Class.define("qx.ui.toolbar.PartContainer",
{extend:qx.ui.container.Composite,
construct:function(){arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.HBox);
},
properties:{appearance:{refine:true,
init:"toolbar/part/container"},
show:{init:"inherit",
check:["both",
"label",
"icon",
"none"],
nullable:true,
inheritable:true,
event:"changeShow"}}});
qx.Class.define("qx.ui.toolbar.Separator",
{extend:qx.ui.core.Widget,
properties:{appearance:{refine:true,
init:"toolbar-separator"},
width:{refine:true,
init:0},
height:{refine:true,
init:0}}});
qx.Class.define("qx.ui.basic.Atom",
{extend:qx.ui.core.Widget,
construct:function(a,
b){{this.assertArgumentsCount(arguments,
0,
2);
};
arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.Atom());
if(a!=null){this.setLabel(a);
}
if(b!=null){this.setIcon(b);
}},
properties:{appearance:{refine:true,
init:"atom"},
label:{apply:"_applyLabel",
nullable:true,
dispose:true,
check:"String"},
rich:{check:"Boolean",
init:false,
apply:"_applyRich"},
icon:{check:"String",
apply:"_applyIcon",
nullable:true,
themeable:true},
gap:{check:"Integer",
nullable:false,
event:"changeGap",
apply:"_applyGap",
themeable:true,
init:4},
show:{init:"both",
check:["both",
"label",
"icon"],
themeable:true,
nullable:true,
inheritable:true,
apply:"_applyShow",
event:"changeShow"},
iconPosition:{init:"left",
check:["top",
"right",
"bottom",
"left"],
themeable:true,
apply:"_applyIconPosition"}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "label":b=new qx.ui.basic.Label(this.getLabel());
b.setAnonymous(true);
b.setRich(this.getRich());
this._add(b);
if(this.getLabel()==null||this.getShow()==="icon"){b.exclude();
}break;
case "icon":b=new qx.ui.basic.Image(this.getIcon());
b.setAnonymous(true);
this._addAt(b,
0);
if(this.getIcon()==null||this.getShow()==="label"){b.exclude();
}break;
}return b||arguments.callee.base.call(this,
a);
},
_forwardStates:{focused:true,
hovered:true},
_handleLabel:function(){if(this.getLabel()==null||this.getShow()==="icon"){this._excludeChildControl("label");
}else{this._showChildControl("label");
}},
_handleIcon:function(){if(this.getIcon()==null||this.getShow()==="label"){this._excludeChildControl("icon");
}else{this._showChildControl("icon");
}},
_applyLabel:function(a,
b){var c=this._getChildControl("label",
true);
if(c){c.setContent(a);
}this._handleLabel();
},
_applyRich:function(a,
b){var c=this._getChildControl("label",
true);
if(c){c.setRich(a);
}},
_applyIcon:function(a,
b){var c=this._getChildControl("icon",
true);
if(c){c.setSource(a);
}this._handleIcon();
},
_applyGap:function(a,
b){this._getLayout().setGap(a);
},
_applyShow:function(a,
b){this._handleLabel();
this._handleIcon();
},
_applyIconPosition:function(a,
b){this._getLayout().setAlign(a);
}}});
qx.Mixin.define("qx.ui.core.MExecutable",
{events:{"execute":"qx.event.type.Event"},
properties:{command:{check:"qx.event.Command",
apply:"_applyCommand",
event:"changeCommand",
nullable:true}},
members:{execute:function(){var a=this.getCommand();
if(a){a.execute(this);
}this.fireEvent("execute");
},
_applyCommand:function(a,
b){if(b){b.removeListener("changeEnabled",
this._onChangeEnabledCommand,
this);
}
if(a){a.addListener("changeEnabled",
this._onChangeEnabledCommand,
this);
this.setEnabled(a.getEnabled());
}},
_onChangeEnabledCommand:function(a){this.setEnabled(a.getData());
}}});
qx.Class.define("qx.ui.form.Button",
{extend:qx.ui.basic.Atom,
include:qx.ui.core.MExecutable,
implement:qx.ui.form.IFormElement,
construct:function(a,
b,
c){arguments.callee.base.call(this,
a,
b);
if(c!=null){this.setCommand(c);
}this.addListener("mouseover",
this._onMouseOver);
this.addListener("mouseout",
this._onMouseOut);
this.addListener("mousedown",
this._onMouseDown);
this.addListener("mouseup",
this._onMouseUp);
this.addListener("keydown",
this._onKeyDown);
this.addListener("keyup",
this._onKeyUp);
},
properties:{name:{check:"String",
nullable:true,
event:"changeName"},
value:{check:"String",
nullable:true,
event:"changeValue"},
appearance:{refine:true,
init:"button"},
focusable:{refine:true,
init:true}},
members:{press:function(){if(this.hasState("abandoned")){return;
}this.addState("pressed");
},
release:function(){if(this.hasState("pressed")){this.removeState("pressed");
}},
reset:function(){this.removeState("pressed");
this.removeState("abandoned");
this.removeState("hovered");
},
_onMouseOver:function(a){if(!this.isEnabled()||a.getTarget()!==this){return;
}
if(this.hasState("abandoned")){this.removeState("abandoned");
this.addState("pressed");
}this.addState("hovered");
},
_onMouseOut:function(a){if(!this.isEnabled()||a.getTarget()!==this){return;
}this.removeState("hovered");
if(this.hasState("pressed")){this.removeState("pressed");
this.addState("abandoned");
}},
_onMouseDown:function(a){if(!a.isLeftPressed()){return;
}a.stopPropagation();
this.capture();
this.removeState("abandoned");
this.addState("pressed");
},
_onMouseUp:function(a){this.releaseCapture();
var b=this.hasState("pressed");
var c=this.hasState("abandoned");
if(b){this.removeState("pressed");
}
if(c){this.removeState("abandoned");
}else{this.addState("hovered");
if(b){this.execute();
}}a.stopPropagation();
},
_onKeyDown:function(a){switch(a.getKeyIdentifier()){case "Enter":case "Space":this.removeState("abandoned");
this.addState("pressed");
a.stopPropagation();
}},
_onKeyUp:function(a){switch(a.getKeyIdentifier()){case "Enter":case "Space":if(this.hasState("pressed")){this.removeState("abandoned");
this.removeState("pressed");
this.execute();
a.stopPropagation();
}}}}});
qx.Class.define("qx.ui.form.MenuButton",
{extend:qx.ui.form.Button,
construct:function(a,
b,
c){arguments.callee.base.call(this,
a,
b);
if(c!=null){this.setMenu(c);
}},
properties:{menu:{check:"qx.ui.menu.Menu",
nullable:true,
apply:"_applyMenu",
event:"changeMenu"}},
members:{_applyMenu:function(a,
b){if(b){b.removeListener("changeVisibility",
this._onMenuChange,
this);
b.resetOpener();
}
if(a){a.addListener("changeVisibility",
this._onMenuChange,
this);
a.setOpener(this);
}},
open:function(a){var b=this.getMenu();
if(b){qx.ui.menu.Manager.getInstance().hideAll();
b.open();
if(a){var c=b.getChildren()[0];
if(c){b.setSelectedButton(c);
}}}},
_onMenuChange:function(a){var b=this.getMenu();
if(b.isVisible()){this.addState("pressed");
}else{this.removeState("pressed");
}},
_onMouseDown:function(a){var b=this.getMenu();
if(b){if(!b.isVisible()){this.open();
}else{b.exclude();
}a.stopPropagation();
}},
_onMouseUp:function(a){a.stopPropagation();
},
_onMouseOver:function(a){this.addState("hovered");
},
_onMouseOut:function(a){this.removeState("hovered");
},
_onKeyDown:function(a){switch(a.getKeyIdentifier()){case "Enter":this.removeState("abandoned");
this.addState("pressed");
var b=this.getMenu();
if(b){if(!b.isVisible()){this.open();
}else{b.exclude();
}}a.stopPropagation();
}},
_onKeyUp:function(a){}}});
qx.Class.define("qx.ui.toolbar.MenuButton",
{extend:qx.ui.form.MenuButton,
construct:function(a,
b,
c){arguments.callee.base.call(this,
a,
b,
c);
this.removeListener("keydown",
this._onKeyDown);
this.removeListener("keyup",
this._onKeyUp);
},
properties:{appearance:{refine:true,
init:"toolbar-button"},
show:{refine:true,
init:"inherit"},
focusable:{refine:true,
init:false}},
members:{getToolBar:function(){var a=this;
while(a){if(a instanceof qx.ui.toolbar.ToolBar){return a;
}a=a.getLayoutParent();
}return null;
},
_onMenuChange:function(a){var b=this.getMenu();
var c=this.getToolBar();
if(b.isVisible()){this.addState("pressed");
if(c){c.setOpenMenu(b);
}}else{this.removeState("pressed");
if(c&&c.getOpenMenu()==b){c.resetOpenMenu();
}}},
_onMouseOver:function(a){this.addState("hovered");
if(this.getMenu()){var b=this.getToolBar();
var c=b.getOpenMenu();
if(c&&c!=this.getMenu()){qx.ui.menu.Manager.getInstance().hideAll();
this.open();
}}}}});
qx.Class.define("qx.ui.layout.Atom",
{extend:qx.ui.layout.Abstract,
properties:{gap:{check:"Integer",
init:4,
apply:"_applyLayoutChange"},
align:{check:["left",
"top",
"right",
"bottom"],
init:"left",
apply:"_applyLayoutChange"}},
members:{verifyLayoutProperty:function(a,
b,
c){this.assert(false,
"The property '"+b+"' is not supported by the atom layout!");
},
renderLayout:function(a,
b){var c=qx.ui.layout.Util;
var d=this.getAlign();
var e=this._getLayoutChildren();
var f=e.length;
var g,
h,
j,
k;
var l,
m;
var n=this.getGap();
if(d==="bottom"||d==="right"){var o=f-1;
var p=-1;
var q=-1;
}else{var o=0;
var p=f;
var q=1;
}if(d=="top"||d=="bottom"){h=0;
for(var r=o;r!=p;r+=q){l=e[r];
m=l.getSizeHint();
j=Math.min(m.maxWidth,
Math.max(a,
m.minWidth));
k=m.height;
g=c.computeHorizontalAlignOffset("center",
j,
a);
l.renderLayout(g,
h,
j,
k);
if(k>0){h+=k+n;
}}}else{var s=a;
var t=null;
for(var r=o;r!=p;r+=q){l=e[r];
j=l.getSizeHint().width;
if(j>0){if(!t&&l instanceof qx.ui.basic.Label){t=l;
}else{s-=j;
}
if(r<(f-1)){s-=n;
}}}g=0;
for(var r=o;r!=p;r+=q){l=e[r];
m=l.getSizeHint();
k=Math.min(m.maxHeight,
Math.max(b,
m.minHeight));
if(l===t){j=Math.max(m.minWidth,
Math.min(s,
m.width));
}else{j=m.width;
}h=c.computeVerticalAlignOffset("middle",
m.height,
b);
l.renderLayout(g,
h,
j,
k);
if(j>0){g+=j+n;
}}}},
_computeSizeHint:function(){var a=this._getLayoutChildren();
var b=a.length;
var c,
d;
if(b===1){var c=a[0].getSizeHint();
d={width:c.width,
height:c.height,
minWidth:c.minWidth,
minHeight:c.minHeight};
}else{var e=0,
f=0;
var g=0,
h=0;
var j=this.getAlign();
var k=this.getGap();
if(j==="top"||j==="bottom"){for(var l=0;l<b;l++){c=a[l].getSizeHint();
f=Math.max(f,
c.width);
e=Math.max(e,
c.minWidth);
if(c.height>0){h+=c.height;
g+=c.minHeight;
if(l<(b-1)){h+=k;
g+=k;
}}}}else{for(var l=0;l<b;l++){c=a[l].getSizeHint();
h=Math.max(h,
c.height);
g=Math.max(g,
c.minHeight);
if(c.width>0){f+=c.width;
e+=c.minWidth;
if(l<(b-1)){f+=k;
e+=k;
}}}}d={minWidth:e,
width:f,
minHeight:g,
height:h};
}return d;
}}});
qx.Class.define("qx.ui.basic.Label",
{extend:qx.ui.core.Widget,
construct:function(a){arguments.callee.base.call(this);
if(a!=null){this.setContent(a);
}
if(qx.core.Variant.isSet("qx.dynamicLocaleSwitch",
"on")){qx.locale.Manager.getInstance().addListener("changeLocale",
this._onChangeLocale,
this);
}},
properties:{rich:{check:"Boolean",
init:false,
apply:"_applyRich"},
content:{check:"String",
apply:"_applyContent",
event:"changeContent",
nullable:true},
textAlign:{check:["left",
"center",
"right"],
nullable:true,
themeable:true,
apply:"_applyTextAlign"},
appearance:{refine:true,
init:"label"},
allowGrowX:{refine:true,
init:false},
allowGrowY:{refine:true,
init:false}},
members:{_getContentHint:function(){if(this.__invalidContentSize){this.__dF();
delete this.__invalidContentSize;
}return {width:this.__dE.width,
height:this.__dE.height};
},
_hasHeightForWidth:function(){return this.getRich();
},
_getContentHeightForWidth:function(a){if(!this.getRich()){return null;
}var b=this._font?this._font.getStyles():qx.bom.Font.getDefaultStyles();
return qx.bom.Label.getHtmlSize(this.getContent(),
b,
a).height;
},
_createContentElement:function(){return new qx.html.Label;
},
_applyTextAlign:function(a,
b){this._contentElement.setStyle("textAlign",
a);
},
_applyTextColor:function(a,
b){if(a){this.getContentElement().setStyle("color",
qx.theme.manager.Color.getInstance().resolve(a));
}else{this.getContentElement().removeStyle("color");
}},
__dE:{width:0,
height:0},
_applyFont:function(a,
b){var c;
if(a){this._font=qx.theme.manager.Font.getInstance().resolve(a);
c=this._font.getStyles();
}else{this._font=null;
c=qx.bom.Font.getDefaultStyles();
}this._contentElement.setStyles(c);
this.__invalidContentSize=true;
qx.ui.core.queue.Layout.add(this);
},
__dF:function(){var a=qx.bom.Label;
var b=this.getFont();
{if(b==="inherit"){this.debug("Could not resolve inheritable font!");
b=null;
}};
var c=b?this._font.getStyles():qx.bom.Font.getDefaultStyles();
var d=this.getContent()||"A";
var e=this.getRich();
this.__dE=e?a.getHtmlSize(d,
c):a.getTextSize(d,
c);
},
_applyRich:function(a){this._contentElement.setRich(a);
this.__invalidContentSize=true;
qx.ui.core.queue.Layout.add(this);
},
_onChangeLocale:qx.core.Variant.select("qx.dynamicLocaleSwitch",
{"on":function(a){var b=this.getContent();
if(b.translate){this.setContent(b.translate());
}},
"off":null}),
_applyContent:function(a){this._contentElement.setContent(a);
this.__invalidContentSize=true;
qx.ui.core.queue.Layout.add(this);
}}});
qx.Class.define("qx.bom.Font",
{extend:qx.core.Object,
construct:function(a,
b){arguments.callee.base.call(this);
if(a!==undefined){this.setSize(a);
}
if(b!==undefined){this.setFamily(b);
}},
statics:{fromString:function(a){var b=new qx.bom.Font();
var c=a.split(/\s+/);
var d=[];
var e;
for(var f=0;f<c.length;f++){switch(e=c[f]){case "bold":b.setBold(true);
break;
case "italic":b.setItalic(true);
break;
case "underline":b.setDecoration("underline");
break;
default:var g=parseInt(e,
10);
if(g==e||qx.lang.String.contains(e,
"px")){b.setSize(g);
}else{d.push(e);
}break;
}}
if(d.length>0){b.setFamily(d);
}return b;
},
fromConfig:function(a){var b=new qx.bom.Font;
b.set(a);
return b;
},
__dG:{fontFamily:"",
fontSize:"",
fontWeight:"",
fontStyle:"",
textDecoration:"",
lineHeight:1.2},
getDefaultStyles:function(){return this.__dG;
}},
properties:{size:{check:"Integer",
nullable:true,
apply:"_applySize"},
lineHeight:{check:"Number",
nullable:true,
apply:"_applyLineHeight"},
family:{check:"Array",
nullable:true,
apply:"_applyFamily"},
bold:{check:"Boolean",
nullable:true,
apply:"_applyBold"},
italic:{check:"Boolean",
nullable:true,
apply:"_applyItalic"},
decoration:{check:["underline",
"line-through",
"overline"],
nullable:true,
apply:"_applyDecoration"}},
members:{__dH:null,
__dI:null,
__dJ:null,
__dK:null,
__dL:null,
__dM:null,
_applySize:function(a,
b){this.__dH=a===null?null:a+"px";
},
_applyLineHeight:function(a,
b){this.__dM=a===null?null:a;
},
_applyFamily:function(a,
b){var c="";
for(var d=0,
e=a.length;d<e;d++){if(a[d].indexOf(" ")>0){c+='"'+a[d]+'"';
}else{c+=a[d];
}
if(d!==e-1){c+=",";
}}this.__dI=c;
},
_applyBold:function(a,
b){this.__dJ=a===null?null:a?"bold":"normal";
},
_applyItalic:function(a,
b){this.__dK=a===null?null:a?"italic":"normal";
},
_applyDecoration:function(a,
b){this.__dL=a===null?null:a;
},
getStyles:function(){return {fontFamily:this.__dI,
fontSize:this.__dH,
fontWeight:this.__dJ,
fontStyle:this.__dK,
textDecoration:this.__dL,
lineHeight:this.__dM};
}}});
qx.Class.define("qx.bom.Label",
{statics:{__dN:{fontFamily:1,
fontSize:1,
fontWeight:1,
fontStyle:1,
lineHeight:1},
__dO:function(){var a=document.createElement("div");
var b=a.style;
b.width=b.height="auto";
b.left=b.top="-1000px";
b.visibility="hidden";
b.position="absolute";
b.overflow="visible";
b.whiteSpace="nowrap";
if(qx.core.Variant.isSet("qx.client",
"gecko")){var c=document.createElementNS("http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul",
"label");
a.appendChild(c);
}document.body.insertBefore(a,
document.body.firstChild);
return this._textElement=a;
},
__dP:function(){var a=qx.bom.Element.create("div");
var b=a.style;
b.width=b.height="auto";
b.left=b.top="-1000px";
b.visibility="hidden";
b.position="absolute";
b.overflow="visible";
b.whiteSpace="normal";
document.body.insertBefore(a,
document.body.firstChild);
return this._htmlElement=a;
},
create:function(a,
b,
c){if(!c){c=window;
}
if(b){var d=c.document.createElement("div");
d.useHtml=true;
}else if(qx.core.Variant.isSet("qx.client",
"gecko")){var d=c.document.createElement("div");
var e=c.document.createElementNS("http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul",
"label");
e.style.cursor="inherit";
e.style.overflow="hidden";
e.style.maxWidth="100%";
e.setAttribute("crop",
"end");
d.appendChild(e);
}else{var d=c.document.createElement("div");
}
if(a){this.setContent(d,
a);
}return d;
},
getStyles:function(a){var b={};
if(a){b.whiteSpace="normal";
}else if(qx.core.Variant.isSet("qx.client",
"gecko")){b.display="block";
}else{b.overflow="hidden";
b.whiteSpace="nowrap";
b.textOverflow="ellipsis";
if(qx.core.Variant.isSet("qx.client",
"opera")){b.OTextOverflow="ellipsis";
}}b.userSelect="none";
return b;
},
setContent:function(a,
b){b=b||"";
if(a.useHtml){a.innerHTML=b;
}else if(qx.core.Variant.isSet("qx.client",
"gecko")){a.firstChild.setAttribute("value",
b);
}else{qx.bom.element.Attribute.set(a,
"text",
b);
}},
getContent:function(a){if(a.useHtml){return a.innerHTML;
}else if(qx.core.Variant.isSet("qx.client",
"gecko")){return a.firstChild.getAttribute("value")||"";
}else{return qx.bom.element.Attribute.get(a,
"text");
}},
getHtmlSize:function(a,
b,
c){var d=this._htmlElement||this.__dP();
var e=this.__dN;
if(!b){b={};
}
for(var f in e){d.style[f]=b[f]||"";
}d.style.width=c!=null?c+"px":"auto";
d.innerHTML=a;
return {width:d.clientWidth,
height:d.clientHeight};
},
getTextSize:function(a,
b){var c=this._textElement||this.__dO();
var d=this.__dN;
if(!b){b={};
}
for(var e in d){c.style[e]=b[e]||"";
}if(qx.core.Variant.isSet("qx.client",
"gecko")){c.firstChild.setAttribute("value",
a);
}else if(qx.core.Variant.isSet("qx.client",
"mshtml|opera")){c.innerText=a;
}else{c.textContent=a;
}var f=c.clientWidth;
var g=c.clientHeight;
if(qx.core.Variant.isSet("qx.client",
"gecko")){if(qx.bom.client.Platform.MAC){f++;
}}return {width:f,
height:g};
}}});
qx.Class.define("qx.html.Label",
{extend:qx.html.Element,
members:{_applyProperty:function(a,
b){arguments.callee.base.call(this,
a,
b);
if(a=="content"){qx.bom.Label.setContent(this._element,
b);
}},
_createDomElement:function(){var a=this.__rich;
var b=qx.bom.Label.create(this._content,
a);
var c=qx.bom.Label.getStyles(a);
for(var d in c){this.setStyle(d,
c[d]);
}return b;
},
setRich:function(a){if(this._element){throw new Error("The label mode cannot be modified after initial creation");
}a=!!a;
if(this.__rich==a){return;
}this.__rich=a;
return this;
},
setContent:function(a){this._setProperty("content",
a);
return this;
},
getContent:function(){return this._getProperty("content");
}}});
qx.Class.define("qx.theme.manager.Font",
{type:"singleton",
extend:qx.util.ValueManager,
properties:{theme:{check:"Theme",
nullable:true,
apply:"_applyTheme",
event:"changeTheme"}},
members:{resolveDynamic:function(a){return a instanceof qx.bom.Font?a:this._dynamic[a];
},
isDynamic:function(a){return a&&(a instanceof qx.bom.Font||this._dynamic[a]!==undefined);
},
_applyTheme:function(a){var b=this._dynamic;
for(var c in b){if(b[c].themed){b[c].dispose();
delete b[c];
}}
if(a){var d=a.fonts;
var e=qx.bom.Font;
for(var c in d){b[c]=(new e).set(d[c]);
b[c].themed=true;
}}}}});
qx.Class.define("qx.ui.menu.Manager",
{type:"singleton",
extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
this.__objects=[];
var a=qx.core.Init.getApplication().getRoot();
a.addListener("mousedown",
this._onMouseDown,
this,
true);
a.addListener("mouseup",
this._onMouseUp,
this);
a.addListener("keydown",
this._onKeyUpDown,
this,
true);
a.addListener("keyup",
this._onKeyUpDown,
this,
true);
a.addListener("keypress",
this._onKeyPress,
this,
true);
qx.bom.Element.addListener(window,
"blur",
this.hideAll,
this);
this._openTimer=new qx.event.Timer;
this._openTimer.addListener("interval",
this._onOpenInterval,
this);
this._closeTimer=new qx.event.Timer;
this._closeTimer.addListener("interval",
this._onCloseInterval,
this);
},
members:{_getChild:function(a,
b,
c,
d){var e=a.getChildren();
var f=e.length;
var g;
for(var h=b;h<f&&h>=0;h+=c){g=e[h];
if(g.isEnabled()&&!g.isAnonymous()){return g;
}}
if(d){h=h==f?0:f-1;
for(;h!=b;h+=c){g=e[h];
if(g.isEnabled()&&!g.isAnonymous()){return g;
}}}return null;
},
_isInMenu:function(a){while(a){if(a instanceof qx.ui.menu.Menu){return true;
}a=a.getLayoutParent();
}return false;
},
add:function(a){{if(!(a instanceof qx.ui.menu.Menu)){throw new Error("Object is no menu: "+a);
}};
var b=this.__objects;
b.push(a);
a.setZIndex(1e6+b.length);
},
remove:function(a){{if(!(a instanceof qx.ui.menu.Menu)){throw new Error("Object is no menu: "+a);
}};
var b=qx.lang.Array.remove(this.__objects,
a);
},
hideAll:function(){var a=this.__objects;
for(var b=a.length-1;b>=0;b--){a[b].exclude();
}},
getActiveMenu:function(){var a=this.__objects;
return a.length>0?a[a.length-1]:null;
},
scheduleOpen:function(a){this.cancelClose(a);
if(a.isVisible()){if(this._scheduleOpen){this.cancelOpen(this._scheduleOpen);
}}else if(this._scheduleOpen!=a){this._scheduleOpen=a;
this._openTimer.restartWith(a.getOpenInterval());
}},
scheduleClose:function(a){this.cancelOpen(a);
if(!a.isVisible()){if(this._scheduleClose){this.cancelClose(this._scheduleClose);
}}else if(this._scheduleClose!=a){this._scheduleClose=a;
this._closeTimer.restartWith(a.getCloseInterval());
}},
cancelOpen:function(a){if(this._scheduleOpen==a){this._openTimer.stop();
this._scheduleOpen=null;
}},
cancelClose:function(a){if(this._scheduleClose==a){this._closeTimer.stop();
this._scheduleClose=null;
}},
_onOpenInterval:function(a){this._openTimer.stop();
this._scheduleOpen.open();
this._scheduleOpen=null;
},
_onCloseInterval:function(a){this._closeTimer.stop();
this._scheduleClose.exclude();
this._scheduleClose=null;
},
_onMouseDown:function(a){var b=a.getTarget();
if(b.getMenu&&b.getMenu()&&b.getMenu().isVisible()){return;
}if(!this._isInMenu(b)){this.hideAll();
}},
_onMouseUp:function(a){var b=a.getTarget();
if(!(b instanceof qx.ui.menu.Menu)){this.hideAll();
}},
__dQ:{"Enter":1,
"Space":1},
__dR:{"Escape":1,
"Up":1,
"Down":1,
"Left":1,
"Right":1},
_onKeyUpDown:function(a){var b=this.getActiveMenu();
if(!b){return;
}var c=a.getKeyIdentifier();
if(this.__dR[c]||(this.__dQ[c]&&b.getSelectedButton())){a.stopPropagation();
}},
_onKeyPress:function(a){var b=this.getActiveMenu();
if(!b){return;
}var c=a.getKeyIdentifier();
var d=this.__dR[c];
var f=this.__dQ[c];
if(d){switch(c){case "Up":this._onKeyPressUp(b);
break;
case "Down":this._onKeyPressDown(b);
break;
case "Left":this._onKeyPressLeft(b);
break;
case "Right":this._onKeyPressRight(b);
break;
case "Escape":this.hideAll();
break;
}a.stopPropagation();
}else if(f){var g=b.getSelectedButton();
if(g){switch(c){case "Enter":this._onKeyPressEnter(b,
g,
a);
break;
case "Space":this._onKeyPressSpace(b,
g,
a);
break;
}a.stopPropagation();
}}},
_onKeyPressUp:function(a){var b=a.getSelectedButton();
var c=a.getChildren();
var d=b?a.indexOf(b)-1:c.length-1;
var e=this._getChild(a,
d,
-1,
true);
if(e){a.setSelectedButton(e);
}else{a.resetSelectedButton();
}},
_onKeyPressDown:function(a){var b=a.getSelectedButton();
var c=b?a.indexOf(b)+1:0;
var d=this._getChild(a,
c,
1,
true);
if(d){a.setSelectedButton(d);
}else{a.resetSelectedButton();
}},
_onKeyPressLeft:function(a){var b=a.getOpener();
if(!b){return;
}if(b instanceof qx.ui.menu.Button){var c=b.getLayoutParent();
c.resetOpenedButton();
c.setSelectedButton(b);
}else if(b instanceof qx.ui.toolbar.MenuButton){var d=b.getToolBar().getMenuButtons();
var e=d.indexOf(b);
if(e===-1){return;
}var f=e==0?d[d.length-1]:d[e-1];
if(f!=b){f.open(true);
}}},
_onKeyPressRight:function(a){var b=a.getSelectedButton();
if(b){var c=b.getMenu();
if(c){a.setOpenedButton(b);
var d=this._getChild(c,
0,
1);
if(d){c.setSelectedButton(d);
}return;
}}else if(!a.getOpenedButton()){var d=this._getChild(a,
0,
1);
if(d){a.setSelectedButton(d);
if(d.getMenu()){a.setOpenedButton(d);
}return;
}}var e=a.getOpener();
if(e instanceof qx.ui.menu.Button&&b){while(e){e=e.getLayoutParent();
if(e instanceof qx.ui.menu.Menu){e=e.getOpener();
if(e instanceof qx.ui.toolbar.MenuButton){break;
}}else{break;
}}
if(!e){return;
}}if(e instanceof qx.ui.toolbar.MenuButton){var f=e.getToolBar().getMenuButtons();
var g=f.indexOf(e);
if(g===-1){return;
}var h=f[g+1];
if(!h){h=f[0];
}
if(h!=e){h.open(true);
}}},
_onKeyPressEnter:function(a,
b,
c){if(b.hasListener("keypress")){var d=c.clone();
d.setBubbles(false);
d.setTarget(b);
b.dispatchEvent(d);
}this.hideAll();
},
_onKeyPressSpace:function(a,
b,
c){if(b.hasListener("keypress")){var d=c.clone();
d.setBubbles(false);
d.setTarget(b);
b.dispatchEvent(d);
}}}});
qx.Class.define("qx.event.Timer",
{extend:qx.core.Object,
construct:function(a){arguments.callee.base.call(this);
this.setEnabled(false);
if(a!=null){this.setInterval(a);
}this.__oninterval=qx.lang.Function.bind(this._oninterval,
this);
},
events:{"interval":"qx.event.type.Event"},
statics:{once:function(a,
b,
c){var d=new qx.event.Timer(c);
d.addListener("interval",
function(f){a.call(b,
f);
d.dispose();
b=null;
},
b);
d.start();
return d;
}},
properties:{enabled:{init:true,
check:"Boolean",
apply:"_applyEnabled"},
interval:{check:"Integer",
init:1000,
apply:"_applyInterval"}},
members:{__dS:null,
_applyInterval:function(a,
b){if(this.getEnabled()){this.restart();
}},
_applyEnabled:function(a,
b){if(b){window.clearInterval(this.__dS);
this.__dS=null;
}else if(a){this.__dS=window.setInterval(this.__oninterval,
this.getInterval());
}},
start:function(){this.setEnabled(true);
},
startWith:function(a){this.setInterval(a);
this.start();
},
stop:function(){this.setEnabled(false);
},
restart:function(){this.stop();
this.start();
},
restartWith:function(a){this.stop();
this.startWith(a);
},
_oninterval:function(){if(this.getEnabled()){this.fireEvent("interval");
}}},
destruct:function(){if(this.__dS){window.clearInterval(this.__dS);
}this._disposeFields("__dS",
"__oninterval");
}});
qx.Class.define("qx.ui.menu.Menu",
{extend:qx.ui.core.Widget,
include:[qx.ui.core.MAlign,
qx.ui.core.MChildrenHandling],
construct:function(){arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.Menu);
this.getApplicationRoot().add(this);
this.addListener("mouseover",
this._onMouseOver);
this.addListener("mouseout",
this._onMouseOut);
},
properties:{appearance:{refine:true,
init:"menu"},
allowGrowX:{refine:true,
init:false},
allowGrowY:{refine:true,
init:false},
visibility:{refine:true,
init:"excluded"},
keepFocus:{refine:true,
init:true},
keepActive:{refine:true,
init:true},
spacingX:{check:"Integer",
apply:"_applySpacingX",
init:0,
themeable:true},
spacingY:{check:"Integer",
apply:"_applySpacingY",
init:0,
themeable:true},
iconColumnWidth:{check:"Integer",
init:0,
themeable:true,
apply:"_applyIconColumnWidth"},
arrowColumnWidth:{check:"Integer",
init:0,
themeable:true,
apply:"_applyArrowColumnWidth"},
selectedButton:{check:"qx.ui.core.Widget",
nullable:true,
apply:"_applySelectedButton"},
openedButton:{check:"qx.ui.core.Widget",
nullable:true,
apply:"_applyOpenedButton"},
opener:{check:"qx.ui.core.Widget",
nullable:true},
openInterval:{check:"Integer",
themeable:true,
init:250,
apply:"_applyOpenInterval"},
closeInterval:{check:"Integer",
themeable:true,
init:250,
apply:"_applyCloseInterval"}},
members:{open:function(){this.alignToWidget(this.getOpener());
this.show();
},
addSeparator:function(){this.add(new qx.ui.menu.Separator);
},
getColumnSizes:function(){return this._getLayout().getColumnSizes();
},
_applyIconColumnWidth:function(a,
b){this._getLayout().setIconColumnWidth(a);
},
_applyArrowColumnWidth:function(a,
b){this._getLayout().setArrowColumnWidth(a);
},
_applySpacingX:function(a,
b){this._getLayout().setColumnSpacing(a);
},
_applySpacingY:function(a,
b){this._getLayout().setSpacing(a);
},
_applyVisibility:function(a,
b){arguments.callee.base.call(this,
a,
b);
var c=qx.ui.menu.Manager.getInstance();
if(a==="visible"){c.add(this);
var d=this.getOpener();
var e=d.getLayoutParent();
if(e&&e instanceof qx.ui.menu.Menu){e.setOpenedButton(d);
}}else{c.remove(this);
var d=this.getOpener();
var e=d.getLayoutParent();
if(e&&e instanceof qx.ui.menu.Menu&&e.getOpenedButton()==d){e.resetOpenedButton();
}this.resetOpenedButton();
this.resetSelectedButton();
}},
_applySelectedButton:function(a,
b){if(b){b.removeState("selected");
}
if(a){a.addState("selected");
}},
_applyOpenedButton:function(a,
b){if(b){b.getMenu().exclude();
}
if(a){a.getMenu().open();
}},
_onMouseOver:function(a){var b=qx.ui.menu.Manager.getInstance();
b.cancelClose(this);
var c=a.getTarget();
if(c.isEnabled()&&c instanceof qx.ui.menu.AbstractButton){this.setSelectedButton(c);
var d=c.getMenu&&c.getMenu();
if(d){b.scheduleOpen(d);
this._scheduledOpen=d;
}else{var f=this.getOpenedButton();
if(f){b.scheduleClose(f.getMenu());
}
if(this._scheduledOpen){b.cancelOpen(this._scheduledOpen);
this._scheduledOpen=null;
}}}else if(!this.getOpenedButton()){this.resetSelectedButton();
}},
_onMouseOut:function(a){var b=qx.ui.menu.Manager.getInstance();
if(!qx.ui.core.Widget.contains(this,
a.getRelatedTarget())){var c=this.getOpenedButton();
c?this.setSelectedButton(c):this.resetSelectedButton();
if(c){b.cancelClose(c.getMenu());
}if(this._scheduledOpen){b.cancelOpen(this._scheduledOpen);
}}}}});
qx.Class.define("qx.ui.layout.Menu",
{extend:qx.ui.layout.VBox,
properties:{columnSpacing:{check:"Integer",
init:0,
apply:"_applyLayoutChange"},
spanColumn:{check:"Integer",
init:1,
nullable:true,
apply:"_applyLayoutChange"},
iconColumnWidth:{check:"Integer",
init:0,
themeable:true,
apply:"_applyLayoutChange"},
arrowColumnWidth:{check:"Integer",
init:0,
themeable:true,
apply:"_applyLayoutChange"}},
members:{_computeSizeHint:function(){var a=this._getLayoutChildren();
var b,
c;
var d=this.getSpanColumn();
var e=this._columnSizes=[0,
0,
0,
0];
var f=this.getColumnSpacing();
var g=0;
var h=0;
for(var j=0,
k=a.length;j<k;j++){b=a[j];
if(b.isAnonymous()){continue;
}c=b.getChildrenSizes();
for(var m=0;m<c.length;m++){if(d!=null&&m==d&&c[d+1]==0){g=Math.max(g,
c[m]);
}else{e[m]=Math.max(e[m],
c[m]);
}}var n=a[j].getInsets();
h=Math.max(h,
n.left+n.right);
}if(d!=null&&e[d]+f+e[d+1]<g){e[d]=g-e[d+1]-f;
}if(g==0){var o=f*2;
}else{var o=f*3;
}if(e[0]==0){e[0]=this.getIconColumnWidth();
}if(e[3]==0){e[3]=this.getArrowColumnWidth();
}return {height:arguments.callee.base.call(this).height,
width:qx.lang.Array.sum(e)+h+o};
},
getColumnSizes:function(){return this._columnSizes||null;
}}});
qx.Class.define("qx.ui.menu.Separator",
{extend:qx.ui.core.Widget,
properties:{appearance:{refine:true,
init:"menu-separator"},
anonymous:{refine:true,
init:true}}});
qx.Class.define("qx.ui.menu.AbstractButton",
{extend:qx.ui.core.Widget,
type:"abstract",
construct:function(){arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.MenuButton);
this.addListener("mouseup",
this._onMouseUp);
this.addListener("keypress",
this._onKeyPress);
},
properties:{label:{check:"String",
apply:"_applyLabel",
nullable:true},
menu:{check:"qx.ui.menu.Menu",
apply:"_applyMenu",
nullable:true},
icon:{check:"String",
apply:"_applyIcon",
themeable:true,
nullable:true}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "icon":b=new qx.ui.basic.Image;
b.setAnonymous(true);
this._add(b,
{column:0});
break;
case "label":b=new qx.ui.basic.Label;
b.setAnonymous(true);
this._add(b,
{column:1});
break;
case "shortcut":b=new qx.ui.basic.Label;
b.setAnonymous(true);
this._add(b,
{column:2});
break;
case "arrow":b=new qx.ui.basic.Image;
b.setAnonymous(true);
this._add(b,
{column:3});
break;
}return b||arguments.callee.base.call(this,
a);
},
_forwardStates:{selected:1},
getChildrenSizes:function(){var a=0,
b=0,
c=0,
d=0;
if(this._isChildControlVisible("icon")){var e=this._getChildControl("icon");
a=e.getMarginLeft()+e.getSizeHint().width+e.getMarginRight();
}
if(this._isChildControlVisible("label")){var f=this._getChildControl("label");
b=f.getMarginLeft()+f.getSizeHint().width+f.getMarginRight();
}
if(this._isChildControlVisible("shortcut")){var g=this._getChildControl("shortcut");
c=g.getMarginLeft()+g.getSizeHint().width+g.getMarginRight();
}
if(this._isChildControlVisible("arrow")){var h=this._getChildControl("arrow");
d=h.getMarginLeft()+h.getSizeHint().width+h.getMarginRight();
}return [a,
b,
c,
d];
},
_onMouseUp:function(a){},
_onKeyPress:function(a){},
_applyIcon:function(a,
b){if(a){this._showChildControl("icon").setSource(a);
}else{this._excludeChildControl("icon");
}},
_applyLabel:function(a,
b){if(a){this._showChildControl("label").setContent(a);
}else{this._excludeChildControl("label");
}},
_applyMenu:function(a,
b){if(b){b.resetOpener();
b.removeState("submenu");
}
if(a){this._showChildControl("arrow");
a.setOpener(this);
a.addState("submenu");
}else{this._excludeChildControl("arrow");
}}}});
qx.Class.define("qx.ui.layout.MenuButton",
{extend:qx.ui.layout.Abstract,
members:{verifyLayoutProperty:function(a,
b,
c){this.assert(b=="column",
"The property '"+b+"' is not supported by the MenuButton layout!");
},
renderLayout:function(a,
b){var c=this._getLayoutChildren();
var d;
var e;
var f=[];
for(var g=0,
h=c.length;g<h;g++){d=c[g];
e=d.getLayoutProperties().column;
f[e]=d;
}var j=c[0].getLayoutParent().getLayoutParent();
var k=j.getColumnSizes();
var m=j.getSpacingX();
var n=0,
o=0;
var p=qx.ui.layout.Util;
for(var g=0,
h=k.length;g<h;g++){d=f[g];
if(d){hint=d.getSizeHint();
var o=p.computeVerticalAlignOffset(d.getAlignY()||"middle",
hint.height,
b,
0,
0);
var q=p.computeHorizontalAlignOffset(d.getAlignX()||"left",
hint.width,
k[g],
d.getMarginLeft(),
d.getMarginRight());
d.renderLayout(n+q,
o,
hint.width,
hint.height);
}n+=k[g]+m;
}},
_computeSizeHint:function(){var a=this._getLayoutChildren();
var b=0;
for(var c=0,
d=a.length;c<d;c++){b=Math.max(b,
a[c].getSizeHint().height);
}return {width:0,
height:b};
}}});
qx.Class.define("qx.ui.menu.Button",
{extend:qx.ui.menu.AbstractButton,
include:qx.ui.core.MExecutable,
construct:function(a,
b,
c,
d){arguments.callee.base.call(this);
this.addListener("changeCommand",
this._onChangeCommand,
this);
if(a!=null){this.setLabel(a);
}
if(b!=null){this.setIcon(b);
}
if(c!=null){this.setCommand(c);
}
if(d!=null){this.setMenu(d);
}},
properties:{appearance:{refine:true,
init:"menu-button"}},
members:{_onChangeCommand:function(a){this._getChildControl("shortcut").setContent(a.getData().toString());
},
_onMouseUp:function(a){if(a.isLeftPressed()){this.execute();
if(this.getMenu()){a.stopPropagation();
}}},
_onKeyPress:function(a){this.execute();
}}});
qx.Class.define("qx.ui.toolbar.ToolBar",
{extend:qx.ui.core.Widget,
include:qx.ui.core.MChildrenHandling,
construct:function(){arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.HBox());
},
properties:{appearance:{refine:true,
init:"toolbar"},
openMenu:{check:"qx.ui.menu.Menu",
event:"changeOpenMenu",
nullable:true},
show:{init:"both",
check:["both",
"label",
"icon",
"none"],
nullable:true,
inheritable:true,
event:"changeShow"}},
members:{addSpacer:function(){var a=new qx.ui.core.Spacer;
this._add(a,
{flex:1});
return a;
},
addSeparator:function(){this.add(new qx.ui.toolbar.Separator);
},
getMenuButtons:function(){var a=this.getChildren();
var b=[];
var c;
for(var d=0,
e=a.length;d<e;d++){c=a[d];
if(c instanceof qx.ui.toolbar.MenuButton){b.push(c);
}else if(c instanceof qx.ui.toolbar.Part){b.push.apply(b,
c.getMenuButtons());
}}return b;
}}});
qx.Class.define("qx.ui.core.Spacer",
{extend:qx.ui.core.LayoutItem,
construct:function(a,
b){arguments.callee.base.call(this);
this.setWidth(a!=null?a:0);
this.setHeight(b!=null?b:0);
}});
qx.Class.define("qx.fx.Base",
{extend:qx.core.Object,
construct:function(a){arguments.callee.base.call(this);
this.setQueue(qx.fx.queue.Manager.getInstance().getDefaultQueue());
this._state=qx.fx.Base.EffectState.IDLE;
this._element=a;
},
events:{"setup":"qx.event.type.Event",
"update":"qx.event.type.Event",
"finish":"qx.event.type.Event"},
properties:{duration:{init:0.5,
check:"Number",
apply:"_applyDuration"},
fps:{init:100,
check:"Number"},
sync:{init:false,
check:"Boolean"},
from:{init:0,
check:"Number"},
to:{init:1,
check:"Number"},
delay:{init:0.0,
check:"Number"},
queue:{check:"Object"},
transition:{init:"linear",
check:["linear",
"easeInQuad",
"easeOutQuad",
"sinodial",
"reverse",
"flicker",
"wobble",
"pulse",
"spring",
"none",
"full"]}},
statics:{EffectState:{IDLE:'idle',
PREPARING:'preparing',
FINISHED:'finished',
RUNNING:'running'}},
members:{_applyDuration:function(a,
b){},
init:function(){this._state=qx.fx.Base.EffectState.PREPARING;
this._currentFrame=0;
this._startOn=this.getDelay()*1000;
this._finishOn=this._startOn+(this.getDuration()*1000);
this._fromToDelta=this.getTo()-this.getFrom();
this._totalTime=this._finishOn-this._startOn;
this._totalFrames=this.getFps()*this.getDuration();
},
beforeFinishInternal:function(){},
beforeFinish:function(){},
afterFinishInternal:function(){},
afterFinish:function(){},
beforeSetupInternal:function(){},
beforeSetup:function(){},
afterSetupInternal:function(){},
afertSetup:function(){},
beforeUpdateInternal:function(){},
beforeUpdate:function(){},
afterUpdateInternal:function(){},
afterUpdate:function(){},
beforeStartInternal:function(){},
beforeStart:function(){},
setup:function(){this.fireEvent("setup");
},
update:function(a){},
finish:function(){this.fireEvent("finish");
},
start:function(){if(this._state!=qx.fx.Base.EffectState.IDLE){return false;
}this.init();
this.beforeStartInternal();
this.beforeStart();
if(!this.getSync()){this.getQueue().add(this);
}return true;
},
end:function(){this.render(1.0);
this.cancel();
this.beforeFinishInternal();
this.beforeFinish();
this.finish();
this.afterFinishInternal();
this.afterFinish();
},
render:function(a){if(this._state==qx.fx.Base.EffectState.PREPARING){this._state=qx.fx.Base.EffectState.RUNNING;
this.beforeSetupInternal();
this.beforeSetup();
this.setup();
this.afterSetupInternal();
this.afertSetup();
}
if(this._state==qx.fx.Base.EffectState.RUNNING){this._position=qx.fx.Transition.get(this.getTransition())(a)*this._fromToDelta+this.getFrom();
this.beforeUpdateInternal();
this.beforeUpdate();
this.update(this._position);
this.afterUpdateInternal();
this.afterUpdate();
if(this.hasListener("update")){this.fireEvent("update");
}}},
loop:function(a){if(a>=this._startOn){if(a>=this._finishOn){this.end();
}var b=(a-this._startOn)/this._totalTime;
var c=Math.round(b*this._totalFrames);
if(c>this._currentFrame){this.render(b);
this._currentFrame=c;
}}},
cancel:function(){if(!this.getSync()){this.getQueue().remove(this);
}this._state=qx.fx.Base.EffectState.IDLE;
}},
destruct:function(){this._disposeFields("_element");
}});
qx.Class.define("qx.fx.effect.combination.Grow",
{extend:qx.fx.Base,
construct:function(a){arguments.callee.base.call(this,
a);
this._moveEffect=new qx.fx.effect.core.Move(this._element);
this._scaleEffect=new qx.fx.effect.core.Scale(this._element);
this._mainEffect=new qx.fx.effect.core.Parallel(this._moveEffect,
this._scaleEffect);
},
properties:{direction:{init:"center",
check:["top-left",
"top-right",
"bottom-left",
"bottom-right",
"center"]},
scaleTransition:{init:"sinodial",
check:["linear",
"easeInQuad",
"easeOutQuad",
"sinodial",
"reverse",
"flicker",
"wobble",
"pulse",
"spring",
"none",
"full"]},
moveTransition:{init:"sinodial",
check:["linear",
"easeInQuad",
"easeOutQuad",
"sinodial",
"reverse",
"flicker",
"wobble",
"pulse",
"spring",
"none",
"full"]}},
members:{setup:function(){arguments.callee.base.call(this);
},
start:function(){if(!arguments.callee.base.call(this)){return;
}qx.bom.element.Style.set(this._element,
"display",
"block");
qx.bom.element.Style.set(this._element,
"overflow",
"hidden");
var a,
b;
var c,
d;
var e={top:qx.bom.element.Location.getTop(this._element),
left:qx.bom.element.Location.getLeft(this._element),
width:qx.bom.element.Dimension.getWidth(this._element),
height:qx.bom.element.Dimension.getHeight(this._element),
overflow:"visible"};
this._scaleEffect.afterFinishInternal=function(){var f;
for(var g in e){f=e[g];
if(g!="overflow"){f+="px";
}qx.bom.element.Style.set(this._element,
g,
f);
}};
switch(this.getDirection()){case 'top-left':a=b=c=d=0;
break;
case 'top-right':a=e.width;
b=d=0;
c=-e.width;
break;
case 'bottom-left':a=c=0;
b=e.height;
d=-e.height;
break;
case 'bottom-right':a=e.width;
b=e.height;
c=-e.width;
d=-e.height;
break;
case 'center':a=Math.round(e.width/2);
b=Math.round(e.height/2);
c=-Math.round(e.width/2);
d=-Math.round(e.height/2);
break;
}this._moveEffect.set({x:c,
y:d,
sync:true,
transition:this.getMoveTransition()});
this._scaleEffect.set({scaleTo:100,
sync:true,
scaleFrom:0,
scaleFromCenter:false,
transition:this.getScaleTransition(),
alternateDimensions:[e.width,
e.height]});
qx.bom.element.Style.set(this._element,
"top",
(e.top+b)+"px");
qx.bom.element.Style.set(this._element,
"left",
(e.left+a)+"px");
qx.bom.element.Style.set(this._element,
"height",
"0px");
qx.bom.element.Style.set(this._element,
"width",
"0px");
this._mainEffect.start();
}},
destruct:function(){this._disposeObjects("_moveEffect",
"_scaleEffect",
"_mainEffect");
}});
qx.Class.define("qx.fx.queue.Manager",
{extend:qx.core.Object,
type:"singleton",
members:{_instances:{},
getQueue:function(a){if(typeof (this._instances[a])=="object"){return this._instances[a];
}else{return this._instances[a]=new qx.fx.queue.Queue;
}},
getDefaultQueue:function(){return this.getQueue("__default");
}},
destruct:function(){this._disposeMap("_instances");
}});
qx.Class.define("qx.fx.queue.Queue",
{extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
},
properties:{limit:{init:Infinity,
check:"Number"}},
members:{_effects:[],
add:function(a){var b=new Date().getTime();
a._startOn+=b;
a._finishOn+=b;
if(this._effects.length<this.getLimit()){this._effects.push(a);
}
if(!this._interval){this._interval=qx.lang.Function.periodical(this.loop,
15,
this);
}},
remove:function(a){qx.lang.Array.remove(this._effects,
a);
if(this._effects.length==0){window.clearInterval(this._interval);
delete this._interval;
}},
loop:function(){var a=new Date().getTime();
for(var b=0,
c=this._effects.length;b<c;b++){this._effects[b]&&this._effects[b].loop(a);
}}},
destruct:function(){this._disposeFields("_effects");
}});
qx.Class.define("qx.fx.Transition",
{type:"static",
statics:{get:function(a){return qx.fx.Transition[a]||false;
},
linear:function(a){return a;
},
easeInQuad:function(a){return Math.pow(2,
10*(a-1));
},
easeOutQuad:function(a){return (-Math.pow(2,
-10*a)+1);
},
sinodial:function(a){return (-Math.cos(a*Math.PI)/2)+0.5;
},
reverse:function(a){return 1-a;
},
flicker:function(a){var a=((-Math.cos(a*Math.PI)/4)+0.75)+Math.random()/4;
return a>1?1:a;
},
wobble:function(a){return (-Math.cos(a*Math.PI*(9*a))/2)+0.5;
},
pulse:function(a,
b){b=(typeof (b)=="Number")?b:5;
return (Math.round((a%(1/b))*b)==0?Math.floor((a*b*2)-(a*b*2)):1-Math.floor((a*b*2)-(a*b*2)));
},
spring:function(a){return 1-(Math.cos(a*4.5*Math.PI)*Math.exp(-a*6));
},
none:function(a){return 0;
},
full:function(a){return 1;
}}});
qx.Class.define("qx.fx.effect.core.Move",
{extend:qx.fx.Base,
properties:{mode:{init:"relative",
check:["relative",
"absolute"]},
x:{init:0,
check:"Number"},
y:{init:0,
check:"Number"}},
members:{setup:function(){arguments.callee.base.call(this);
if(this._element.parentNode){this._originalLeft=qx.bom.element.Location.getLeft(this._element)-qx.bom.element.Location.getLeft(this._element.parentNode);
this._originalTop=qx.bom.element.Location.getTop(this._element)-qx.bom.element.Location.getTop(this._element.parentNode);
}else{this._originalLeft=qx.bom.element.Location.getLeft(this._element);
this._originalTop=qx.bom.element.Location.getTop(this._element);
}this._originalPosition=qx.bom.element.Style.get(this._element,
"position");
if(this.getMode()=='absolute'){this._x=this.getX()-this._originalLeft;
this._y=this.getY()-this._originalTop;
}else{this._x=this.getX();
this._y=this.getY();
}},
update:function(a){arguments.callee.base.call(this);
var b=Math.round(this._x*a+this._originalLeft);
var c=Math.round(this._y*a+this._originalTop);
qx.bom.element.Style.set(this._element,
"left",
b+"px");
qx.bom.element.Style.set(this._element,
"top",
c+"px");
},
afterFinishInternal:function(){qx.bom.element.Style.set(this._element,
"position",
this._originalPosition);
}}});
qx.Class.define("qx.fx.effect.core.Scale",
{extend:qx.fx.Base,
properties:{scaleX:{init:true,
check:"Boolean"},
scaleY:{init:true,
check:"Boolean"},
scaleContent:{init:true,
check:"Boolean"},
scaleFromCenter:{init:true,
check:"Boolean"},
scaleFrom:{init:100.0,
check:"Number"},
scaleTo:{init:100,
check:"Number"},
restoreAfterFinish:{init:false,
check:"Boolean"},
alternateDimensions:{init:[],
check:"Array"}},
members:{_originalStyle:{'top':null,
'left':null,
'width':null,
'height':null,
'fontSize':null},
_fontTypes:{'em':'em',
'px':'px',
'%':'%',
'pt':'pt'},
setup:function(){arguments.callee.base.call(this);
this._elementPositioning=qx.bom.element.Style.get(this._element,
"position");
for(var a in this._originalStyle){this._originalStyle[a]=this._element.style[a];
}this._originalTop=qx.bom.element.Location.getTop(this._element);
this._originalLeft=qx.bom.element.Location.getLeft(this._element);
try{var b=qx.bom.element.Style.get(this._element,
"fontSize");
}catch(e){if(typeof (b)!="string"){b=(qx.bom.client.Engine.MSHTML)?"12px":"100%";
}}
for(var c in this._fontTypes){if(b.indexOf(c)>0){this._fontSize=parseFloat(b);
this._fontSizeType=c;
break;
}}this._factor=(this.getScaleTo()-this.getScaleFrom())/100;
var d=this.getAlternateDimensions();
if(d.length==0){this._dims=[this._element.offsetWidth,
this._element.offsetHeight];
}else{this._dims=d;
}},
update:function(a){arguments.callee.base.call(this);
var b=(this.getScaleFrom()/100.0)+(this._factor*a);
if(this.getScaleContent()&&this._fontSize){qx.bom.element.Style.set(this._element,
"fontSize",
this._fontSize*b+this._fontSizeType);
}this._setDimensions(this._dims[0]*b,
this._dims[1]*b);
},
finish:function(){arguments.callee.base.call(this);
if(this.getRestoreAfterFinish()){for(var a in this._originalStyle){var b=this._originalStyle[a];
qx.bom.element.Style.set(this._element,
a,
b);
}}},
_setDimensions:function(a,
b){var c={};
var e=this.getScaleX();
var f=this.getScaleY();
if(e){c.width=Math.round(a)+'px';
}
if(f){c.height=Math.round(b)+'px';
}
if(this.getScaleFromCenter()){var g=(a-this._dims[0])/2;
var h=(b-this._dims[1])/2;
if(this._elementPositioning=="absolute"){if(f){c.top=this._originalTop-h+'px';
}
if(e){c.left=this._originalLeft-g+'px';
}}else{if(f){c.top=-h+'px';
}
if(e){c.left=-g+'px';
}}}
for(var i in c){qx.bom.element.Style.set(this._element,
i,
c[i]);
}}},
destruct:function(){this._disposeFields("_dims");
}});
qx.Class.define("qx.fx.effect.core.Parallel",
{extend:qx.fx.Base,
construct:function(){arguments.callee.base.call(this);
this._effects=arguments;
},
members:{finish:function(){arguments.callee.base.call(this);
var a=this._effects;
for(var b=0;b<a.length;b++){a[b].render(1.0);
a[b].cancel();
a[b].beforeFinishInternal();
a[b].beforeFinish();
a[b].finish(1.0);
a[b].afterFinishInternal();
a[b].afterFinish();
}},
update:function(a){arguments.callee.base.call(this);
var b=this._effects;
for(var c=0;c<b.length;c++){b[c].render(a);
}},
start:function(){if(!arguments.callee.base.call(this)){return;
}var a=this._effects;
for(var b=0;b<a.length;b++){a[b].start();
}}},
destruct:function(){this._disposeArray("_effects");
}});
qx.Class.define("qx.bom.element.Dimension",
{statics:{getWidth:function(a){return a.offsetWidth;
},
getHeight:function(a){return a.offsetHeight;
},
getClientWidth:function(a){return a.clientWidth;
},
getClientHeight:function(a){return a.clientHeight;
},
getScrollWidth:function(a){return a.scrollWidth;
},
getScrollHeight:function(a){return a.scrollHeight;
}}});
qx.Interface.define("qx.ui.table.ICellRenderer",
{members:{createDataCellHtml:function(a,
b){return true;
}}});
qx.Class.define("qx.ui.table.cellrenderer.Abstract",
{type:"abstract",
implement:qx.ui.table.ICellRenderer,
extend:qx.core.Object,
construct:function(){var a=qx.ui.table.cellrenderer.Abstract;
if(!a.__clazz){a.__clazz=arguments.callee.self;
var b=".qooxdoo-table-cell {"+
qx.bom.element.Style.compile({position:"absolute",
top:"0px",
overflow:"hidden",
whiteSpace:"nowrap",
borderRight:"1px solid #eeeeee",
borderBottom:"1px solid #eeeeee",
padding:"0px 6px",
cursor:"default",
textOverflow:"ellipsis",
userSelect:"none",
boxSizing:"content-box"})+"} "+".qooxdoo-table-cell-right { text-align:right } "+".qooxdoo-table-cell-italic { font-style:italic} "+".qooxdoo-table-cell-bold { font-weight:bold } ";
a.__clazz.stylesheet=qx.bom.Stylesheet.createElement(b);
}},
members:{_insetX:6+6+1,
_insetY:1,
_getCellClass:function(a){return "qooxdoo-table-cell";
},
_getCellStyle:function(a){return a.style||"";
},
_getContentHtml:function(a){return a.value||"";
},
_getCellSizeStyle:function(a,
b,
c,
d){var e="";
if(qx.bom.client.Feature.CONTENT_BOX){a-=c;
b-=d;
}e+=";width:"+a+"px;";
e+="height:"+b+"px;";
return e;
},
createDataCellHtml:function(a,
b){b.push('<div class="',
this._getCellClass(a),
'" style="',
'left:',
a.styleLeft,
'px;',
this._getCellSizeStyle(a.styleWidth,
a.styleHeight,
this._insetX,
this._insetY),
this._getCellStyle(a),
'">'+this._getContentHtml(a),
'</div>');
}}});
qx.Class.define("qx.io.remote.Exchange",
{extend:qx.core.Object,
construct:function(a){arguments.callee.base.call(this);
this.setRequest(a);
a.setTransport(this);
},
events:{"sending":"qx.event.type.Event",
"receiving":"qx.event.type.Event",
"completed":"qx.io.remote.Response",
"aborted":"qx.io.remote.Response",
"failed":"qx.io.remote.Response",
"timeout":"qx.io.remote.Response"},
statics:{typesOrder:["qx.io.remote.transport.XmlHttp",
"qx.io.remote.transport.Iframe",
"qx.io.remote.transport.Script"],
typesReady:false,
typesAvailable:{},
typesSupported:{},
registerType:function(a,
b){qx.io.remote.Exchange.typesAvailable[b]=a;
},
initTypes:function(){if(qx.io.remote.Exchange.typesReady){return;
}
for(var a in qx.io.remote.Exchange.typesAvailable){var b=qx.io.remote.Exchange.typesAvailable[a];
if(b.isSupported()){qx.io.remote.Exchange.typesSupported[a]=b;
}}qx.io.remote.Exchange.typesReady=true;
if(qx.lang.Object.isEmpty(qx.io.remote.Exchange.typesSupported)){throw new Error("No supported transport types were found!");
}},
canHandle:function(a,
b,
c){if(!qx.lang.Array.contains(a.handles.responseTypes,
c)){return false;
}
for(var d in b){if(!a.handles[d]){return false;
}}return true;
},
_nativeMap:{0:"created",
1:"configured",
2:"sending",
3:"receiving",
4:"completed"},
wasSuccessful:function(a,
b,
c){if(c){switch(a){case null:case 0:return true;
case -1:return b<4;
default:return typeof a==="undefined";
}}else{switch(a){case -1:{if(qx.core.Setting.get("qx.ioRemoteDebug")&&b>3){qx.log.Logger.debug(this,
"Failed with statuscode: -1 at readyState "+b);
}};
return b<4;
case 200:case 304:return true;
case 201:case 202:case 203:case 204:case 205:return true;
case 206:{if(qx.core.Setting.get("qx.ioRemoteDebug")&&b===4){qx.log.Logger.debug(this,
"Failed with statuscode: 206 (Partial content while being complete!)");
}};
return b!==4;
case 300:case 301:case 302:case 303:case 305:case 400:case 401:case 402:case 403:case 404:case 405:case 406:case 407:case 408:case 409:case 410:case 411:case 412:case 413:case 414:case 415:case 500:case 501:case 502:case 503:case 504:case 505:{if(qx.core.Setting.get("qx.ioRemoteDebug")){qx.log.Logger.debug(this,
"Failed with typical HTTP statuscode: "+a);
}};
return false;
case 12002:case 12007:case 12029:case 12030:case 12031:case 12152:case 13030:{if(qx.core.Setting.get("qx.ioRemoteDebug")){qx.log.Logger.debug(this,
"Failed with MSHTML specific HTTP statuscode: "+a);
}};
return false;
default:if(a>206&&a<300){return true;
}qx.log.Logger.debug(this,
"Unknown status code: "+a+" ("+b+")");
return false;
}}},
statusCodeToString:function(a){switch(a){case -1:return "Not available";
case 200:return "Ok";
case 304:return "Not modified";
case 206:return "Partial content";
case 204:return "No content";
case 300:return "Multiple choices";
case 301:return "Moved permanently";
case 302:return "Moved temporarily";
case 303:return "See other";
case 305:return "Use proxy";
case 400:return "Bad request";
case 401:return "Unauthorized";
case 402:return "Payment required";
case 403:return "Forbidden";
case 404:return "Not found";
case 405:return "Method not allowed";
case 406:return "Not acceptable";
case 407:return "Proxy authentication required";
case 408:return "Request time-out";
case 409:return "Conflict";
case 410:return "Gone";
case 411:return "Length required";
case 412:return "Precondition failed";
case 413:return "Request entity too large";
case 414:return "Request-URL too large";
case 415:return "Unsupported media type";
case 500:return "Server error";
case 501:return "Not implemented";
case 502:return "Bad gateway";
case 503:return "Out of resources";
case 504:return "Gateway time-out";
case 505:return "HTTP version not supported";
case 12002:return "Server timeout";
case 12029:return "Connection dropped";
case 12030:return "Connection dropped";
case 12031:return "Connection dropped";
case 12152:return "Connection closed by server";
case 13030:return "MSHTML-specific HTTP status code";
default:return "Unknown status code";
}}},
properties:{request:{check:"qx.io.remote.Request",
nullable:true},
implementation:{check:"qx.io.remote.transport.Abstract",
nullable:true,
apply:"_applyImplementation"},
state:{check:["configured",
"sending",
"receiving",
"completed",
"aborted",
"timeout",
"failed"],
init:"configured",
event:"changeState",
apply:"_applyState"}},
members:{send:function(){var a=this.getRequest();
if(!a){return this.error("Please attach a request object first");
}qx.io.remote.Exchange.initTypes();
var b=qx.io.remote.Exchange.typesOrder;
var c=qx.io.remote.Exchange.typesSupported;
var d=a.getResponseType();
var e={};
if(a.getAsynchronous()){e.asynchronous=true;
}else{e.synchronous=true;
}
if(a.getCrossDomain()){e.crossDomain=true;
}
if(a.getFileUpload()){e.fileUpload=true;
}for(var f in a.getFormFields()){e.programaticFormFields=true;
break;
}var g,
h;
for(var j=0,
k=b.length;j<k;j++){g=c[b[j]];
if(g){if(!qx.io.remote.Exchange.canHandle(g,
e,
d)){continue;
}
try{{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.debug("Using implementation: "+g.classname);
}};
h=new g;
this.setImplementation(h);
h.setUseBasicHttpAuth(a.getUseBasicHttpAuth());
h.send();
return true;
}catch(ex){this.error("Request handler throws error");
this.error(ex);
return;
}}}this.error("There is no transport implementation available to handle this request: "+a);
},
abort:function(){var a=this.getImplementation();
if(a){{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.debug("Abort: implementation "+a.toHashCode());
}};
a.abort();
}else{{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.debug("Abort: forcing state to be aborted");
}};
this.setState("aborted");
}},
timeout:function(){var a=this.getImplementation();
if(a){this.warn("Timeout: implementation "+a.toHashCode());
a.timeout();
}else{this.warn("Timeout: forcing state to timeout");
this.setState("timeout");
}if(this.getRequest()){this.getRequest().setTimeout(0);
}},
_onsending:function(a){this.setState("sending");
},
_onreceiving:function(a){this.setState("receiving");
},
_oncompleted:function(a){this.setState("completed");
},
_onabort:function(a){this.setState("aborted");
},
_onfailed:function(a){this.setState("failed");
},
_ontimeout:function(a){this.setState("timeout");
},
_applyImplementation:function(a,
b){if(b){b.removeListener("sending",
this._onsending,
this);
b.removeListener("receiving",
this._onreceiving,
this);
b.removeListener("completed",
this._oncompleted,
this);
b.removeListener("aborted",
this._onabort,
this);
b.removeListener("timeout",
this._ontimeout,
this);
b.removeListener("failed",
this._onfailed,
this);
}
if(a){var c=this.getRequest();
a.setUrl(c.getUrl());
a.setMethod(c.getMethod());
a.setAsynchronous(c.getAsynchronous());
a.setUsername(c.getUsername());
a.setPassword(c.getPassword());
a.setParameters(c.getParameters());
a.setFormFields(c.getFormFields());
a.setRequestHeaders(c.getRequestHeaders());
a.setData(c.getData());
a.setResponseType(c.getResponseType());
a.addListener("sending",
this._onsending,
this);
a.addListener("receiving",
this._onreceiving,
this);
a.addListener("completed",
this._oncompleted,
this);
a.addListener("aborted",
this._onabort,
this);
a.addListener("timeout",
this._ontimeout,
this);
a.addListener("failed",
this._onfailed,
this);
}},
_applyState:function(a,
b){{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.debug("State: "+b+" => "+a);
}};
switch(a){case "sending":this.fireEvent("sending");
break;
case "receiving":this.fireEvent("receiving");
break;
case "completed":case "aborted":case "timeout":case "failed":var c=this.getImplementation();
if(!c){break;
}
if(this.hasListener(a)){var d=qx.event.Registration.createEvent(a,
qx.io.remote.Response);
if(a=="completed"){var e=c.getResponseContent();
d.setContent(e);
if(e===null){{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.debug("Altered State: "+a+" => failed");
}};
a="failed";
}}d.setStatusCode(c.getStatusCode());
d.setResponseHeaders(c.getResponseHeaders());
this.dispatchEvent(d);
}this.setImplementation(null);
c.dispose();
break;
}}},
settings:{"qx.ioRemoteDebug":false,
"qx.ioRemoteDebugData":false},
destruct:function(){var a=this.getImplementation();
if(a){this.setImplementation(null);
a.dispose();
}this.setRequest(null);
}});
qx.Class.define("qx.io.remote.transport.Abstract",
{type:"abstract",
extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
},
events:{"created":"qx.event.type.Event",
"configured":"qx.event.type.Event",
"sending":"qx.event.type.Event",
"receiving":"qx.event.type.Event",
"completed":"qx.event.type.Event",
"aborted":"qx.event.type.Event",
"failed":"qx.event.type.Event",
"timeout":"qx.event.type.Event"},
properties:{url:{check:"String",
nullable:true},
method:{check:"String",
nullable:true},
asynchronous:{check:"Boolean",
nullable:true},
data:{check:"String",
nullable:true},
username:{check:"String",
nullable:true},
password:{check:"String",
nullable:true},
state:{check:["created",
"configured",
"sending",
"receiving",
"completed",
"aborted",
"timeout",
"failed"],
init:"created",
event:"changeState",
apply:"_applyState"},
requestHeaders:{check:"Object",
nullable:true},
parameters:{check:"Object",
nullable:true},
formFields:{check:"Object",
nullable:true},
responseType:{check:"String",
nullable:true},
useBasicHttpAuth:{check:"Boolean",
nullable:true}},
members:{send:function(){throw new Error("send is abstract");
},
abort:function(){{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.warn("Aborting...");
}};
this.setState("aborted");
},
timeout:function(){{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.warn("Timeout...");
}};
this.setState("timeout");
},
failed:function(){{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.warn("Failed...");
}};
this.setState("failed");
},
setRequestHeader:function(a,
b){throw new Error("setRequestHeader is abstract");
},
getResponseHeader:function(a){throw new Error("getResponseHeader is abstract");
},
getResponseHeaders:function(){throw new Error("getResponseHeaders is abstract");
},
getStatusCode:function(){throw new Error("getStatusCode is abstract");
},
getStatusText:function(){throw new Error("getStatusText is abstract");
},
getResponseText:function(){throw new Error("getResponseText is abstract");
},
getResponseXml:function(){throw new Error("getResponseXml is abstract");
},
getFetchedLength:function(){throw new Error("getFetchedLength is abstract");
},
_applyState:function(a,
b){{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.debug("State: "+a);
}};
switch(a){case "created":this.fireEvent("created");
break;
case "configured":this.fireEvent("configured");
break;
case "sending":this.fireEvent("sending");
break;
case "receiving":this.fireEvent("receiving");
break;
case "completed":this.fireEvent("completed");
break;
case "aborted":this.fireEvent("aborted");
break;
case "failed":this.fireEvent("failed");
break;
case "timeout":this.fireEvent("timeout");
break;
}return true;
}}});
qx.Class.define("qx.io.remote.transport.XmlHttp",
{extend:qx.io.remote.transport.Abstract,
construct:function(){arguments.callee.base.call(this);
this._req=qx.io.remote.transport.XmlHttp.createRequestObject();
this._req.onreadystatechange=qx.lang.Function.bind(this._onreadystatechange,
this);
},
events:{"created":"qx.event.type.Event",
"configured":"qx.event.type.Event",
"sending":"qx.event.type.Event",
"receiving":"qx.event.type.Event",
"completed":"qx.event.type.Event",
"aborted":"qx.event.type.Event",
"failed":"qx.event.type.Event",
"timeout":"qx.event.type.Event"},
statics:{handles:{synchronous:true,
asynchronous:true,
crossDomain:false,
fileUpload:false,
programaticFormFields:false,
responseTypes:["text/plain",
"text/javascript",
"application/json",
"application/xml",
"text/html"]},
requestObjects:[],
requestObjectCount:0,
createRequestObject:qx.core.Variant.select("qx.client",
{"default":function(){return new XMLHttpRequest;
},
"mshtml":function(){if(window.ActiveXObject&&qx.xml.Document.XMLHTTP){return new ActiveXObject(qx.xml.Document.XMLHTTP);
}
if(window.XMLHttpRequest){return new XMLHttpRequest;
}}}),
isSupported:function(){return !!this.createRequestObject();
},
__dT:function(){}},
members:{_localRequest:false,
_lastReadyState:0,
getRequest:function(){return this._req;
},
send:function(){this._lastReadyState=0;
var a=this.getRequest();
var b=this.getMethod();
var c=this.getAsynchronous();
var d=this.getUrl();
var e=(window.location.protocol==="file:"&&!(/^http(s){0,1}\:/.test(d)));
this._localRequest=e;
var f=this.getParameters();
var g=[];
for(var h in f){var j=f[h];
if(j instanceof Array){for(var k=0;k<j.length;k++){g.push(encodeURIComponent(h)+"="+encodeURIComponent(j[k]));
}}else{g.push(encodeURIComponent(h)+"="+encodeURIComponent(j));
}}
if(g.length>0){d+=(d.indexOf("?")>=0?"&":"?")+g.join("&");
}var l=function(m){var n="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
var o="";
var p,
q,
r;
var s,
t,
u,
v;
var k=0;
do{p=m.charCodeAt(k++);
q=m.charCodeAt(k++);
r=m.charCodeAt(k++);
s=p>>2;
t=((p&3)<<4)|(q>>4);
u=((q&15)<<2)|(r>>6);
v=r&63;
if(isNaN(q)){u=v=64;
}else if(isNaN(r)){v=64;
}o+=n.charAt(s)+n.charAt(t)+n.charAt(u)+n.charAt(v);
}while(k<m.length);
return o;
};
a.onreadystatechange=qx.lang.Function.bind(this._onreadystatechange,
this);
try{if(this.getUsername()){if(this.getUseBasicHttpAuth()){a.open(b,
d,
c);
a.setRequestHeader('Authorization',
'Basic '+l(this.getUsername()+':'+this.getPassword()));
}else{a.open(b,
d,
c,
this.getUsername(),
this.getPassword());
}}else{a.open(b,
d,
c);
}}catch(ex){this.error("Failed with exception: "+ex);
this.failed();
return;
}if(!qx.core.Variant.isSet("qx.client",
"webkit")){a.setRequestHeader('Referer',
window.location.href);
}var w=this.getRequestHeaders();
for(var h in w){a.setRequestHeader(h,
w[h]);
}try{{if(qx.core.Setting.get("qx.ioRemoteDebugData")){this.debug("Request: "+this.getData());
}};
a.send(this.getData());
}catch(ex){if(e){this.failedLocally();
}else{this.error("Failed to send data: "+ex,
"send");
this.failed();
}return;
}if(!c){this._onreadystatechange();
}},
failedLocally:function(){if(this.getState()==="failed"){return;
}this.warn("Could not load from file: "+this.getUrl());
this.failed();
},
_onreadystatechange:function(a){switch(this.getState()){case "completed":case "aborted":case "failed":case "timeout":{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.warn("Ignore Ready State Change");
}};
return;
}var b=this.getReadyState();
if(b==4){if(!qx.io.remote.Exchange.wasSuccessful(this.getStatusCode(),
b,
this._localRequest)){return this.failed();
}}while(this._lastReadyState<b){this.setState(qx.io.remote.Exchange._nativeMap[++this._lastReadyState]);
}},
getReadyState:function(){var a=null;
try{a=this._req.readyState;
}catch(ex){}return a;
},
setRequestHeader:function(a,
b){this._req.setRequestHeader(a,
b);
},
getResponseHeader:function(a){var b=null;
try{this.getRequest().getResponseHeader(a)||null;
}catch(ex){}return b;
},
getStringResponseHeaders:function(){var a=null;
try{var b=this._req.getAllResponseHeaders();
if(b){a=b;
}}catch(ex){}return a;
},
getResponseHeaders:function(){var a=this.getStringResponseHeaders();
var b={};
if(a){var c=a.split(/[\r\n]+/g);
for(var d=0,
e=c.length;d<e;d++){var f=c[d].match(/^([^:]+)\s*:\s*(.+)$/i);
if(f){b[f[1]]=f[2];
}}}return b;
},
getStatusCode:function(){var a=-1;
try{a=this.getRequest().status;
}catch(ex){}return a;
},
getStatusText:function(){var a="";
try{a=this.getRequest().statusText;
}catch(ex){}return a;
},
getResponseText:function(){var a=null;
var b=this.getStatusCode();
var c=this.getReadyState();
if(qx.io.remote.Exchange.wasSuccessful(b,
c,
this._localRequest)){try{a=this.getRequest().responseText;
}catch(ex){}}return a;
},
getResponseXml:function(){var a=null;
var b=this.getStatusCode();
var c=this.getReadyState();
if(qx.io.remote.Exchange.wasSuccessful(b,
c,
this._localRequest)){try{a=this.getRequest().responseXML;
}catch(ex){}}if(typeof a=="object"&&a!=null){if(!a.documentElement){var d=String(this.getRequest().responseText).replace(/<\?xml[^\?]*\?>/,
"");
a.loadXML(d);
}if(!a.documentElement){throw new Error("Missing Document Element!");
}
if(a.documentElement.tagName=="parseerror"){throw new Error("XML-File is not well-formed!");
}}else{throw new Error("Response was not a valid xml document ["+this.getRequest().responseText+"]");
}return a;
},
getFetchedLength:function(){var a=this.getResponseText();
return typeof a=="string"?a.length:0;
},
getResponseContent:function(){if(this.getState()!=="completed"){{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.warn("Transfer not complete, ignoring content!");
}};
return null;
}{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.debug("Returning content for responseType: "+this.getResponseType());
}};
var a=this.getResponseText();
switch(this.getResponseType()){case "text/plain":case "text/html":{if(qx.core.Setting.get("qx.ioRemoteDebugData")){this.debug("Response: "+a);
}};
return a;
case "application/json":{if(qx.core.Setting.get("qx.ioRemoteDebugData")){this.debug("Response: "+a);
}};
try{if(a&&a.length>0){return qx.util.Json.parseQx(a)||null;
}else{return null;
}}catch(ex){this.error("Could not execute json: ["+a+"]",
ex);
return "<pre>Could not execute json: \n"+a+"\n</pre>";
}case "text/javascript":{if(qx.core.Setting.get("qx.ioRemoteDebugData")){this.debug("Response: "+a);
}};
try{if(a&&a.length>0){return window.eval(a)||null;
}else{return null;
}}catch(ex){this.error("Could not execute javascript: ["+a+"]",
ex);
return null;
}case "application/xml":a=this.getResponseXml();
{if(qx.core.Setting.get("qx.ioRemoteDebugData")){this.debug("Response: "+a);
}};
return a||null;
default:this.warn("No valid responseType specified ("+this.getResponseType()+")!");
return null;
}},
_applyState:function(a,
b){{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.debug("State: "+a);
}};
switch(a){case "created":this.fireEvent("created");
break;
case "configured":this.fireEvent("configured");
break;
case "sending":this.fireEvent("sending");
break;
case "receiving":this.fireEvent("receiving");
break;
case "completed":this.fireEvent("completed");
break;
case "failed":this.fireEvent("failed");
break;
case "aborted":this.getRequest().abort();
this.fireEvent("aborted");
break;
case "timeout":this.getRequest().abort();
this.fireEvent("timeout");
break;
}}},
defer:function(a,
b){qx.io.remote.Exchange.registerType(qx.io.remote.transport.XmlHttp,
"qx.io.remote.transport.XmlHttp");
},
destruct:function(){var a=this.getRequest();
if(a){a.onreadystatechange=qx.io.remote.transport.XmlHttp.__dT;
switch(a.readyState){case 1:case 2:case 3:a.abort();
}}this._disposeFields("_req");
}});
qx.Bootstrap.define("qx.xml.Document",
{statics:{DOMDOC:null,
XMLHTTP:null,
create:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b){var c=new ActiveXObject(this.DOMDOC);
c.setProperty("SelectionLanguage",
"XPath");
if(b){var d='<?xml version="1.0" encoding="utf-8"?>\n<';
d+=b;
if(a){d+=" xmlns='"+a+"'";
}d+=" />";
c.loadXML(d);
}return c;
},
"default":function(a,
b){return document.implementation.createDocument(a||"",
b||"",
null);
}}),
fromString:qx.core.Variant.select("qx.client",
{"mshtml":function(a){var b=qx.xml.Document.create();
b.loadXML(a);
return b;
},
"default":function(a){var b=new DOMParser();
return b.parseFromString(a,
"text/xml");
}})},
defer:function(a){if(qx.core.Variant.isSet("qx.client",
"mshtml")){var b=["MSXML2.DOMDocument.6.0",
"MSXML2.DOMDocument.3.0"];
var c=["MSXML2.XMLHTTP.6.0",
"MSXML2.XMLHTTP.3.0"];
for(var d=0,
e=b.length;d<e;d++){try{new ActiveXObject(b[d]);
new ActiveXObject(c[d]);
}catch(ex){continue;
}a.DOMDOC=b[d];
a.XMLHTTP=c[d];
break;
}}}});
qx.Class.define("qx.io.remote.transport.Iframe",
{extend:qx.io.remote.transport.Abstract,
construct:function(){arguments.callee.base.call(this);
var a=(new Date).valueOf();
var b="frame_"+a;
var c="form_"+a;
if(qx.core.Variant.isSet("qx.client",
"mshtml")){this._frame=document.createElement('<iframe name="'+b+'"></iframe>');
}else{this._frame=document.createElement("iframe");
}this._frame.src="javascript:void(0)";
this._frame.id=this._frame.name=b;
this._frame.onload=qx.lang.Function.bind(this._onload,
this);
this._frame.style.display="none";
document.body.appendChild(this._frame);
this._form=document.createElement("form");
this._form.target=b;
this._form.id=this._form.name=c;
this._form.style.display="none";
document.body.appendChild(this._form);
this._data=document.createElement("textarea");
this._data.id=this._data.name="_data_";
this._form.appendChild(this._data);
this._frame.onreadystatechange=qx.lang.Function.bind(this._onreadystatechange,
this);
},
statics:{handles:{synchronous:false,
asynchronous:true,
crossDomain:false,
fileUpload:true,
programaticFormFields:true,
responseTypes:["text/plain",
"text/javascript",
"application/json",
"application/xml",
"text/html"]},
isSupported:function(){return true;
},
_numericMap:{"uninitialized":1,
"loading":2,
"loaded":2,
"interactive":3,
"complete":4}},
members:{_lastReadyState:0,
send:function(){var a=this.getMethod();
var b=this.getUrl();
var c=this.getParameters();
var d=[];
for(var e in c){var f=c[e];
if(f instanceof Array){for(var g=0;g<f.length;g++){d.push(encodeURIComponent(e)+"="+encodeURIComponent(f[g]));
}}else{d.push(encodeURIComponent(e)+"="+encodeURIComponent(f));
}}
if(d.length>0){b+=(b.indexOf("?")>=0?"&":"?")+d.join("&");
}var h=this.getFormFields();
for(var e in h){var j=document.createElement("textarea");
j.name=e;
j.appendChild(document.createTextNode(h[e]));
this._form.appendChild(j);
}this._form.action=b;
this._form.method=a;
this._data.appendChild(document.createTextNode(this.getData()));
this._form.submit();
this.setState("sending");
},
_onload:function(a){if(this._form.src){return;
}this._switchReadyState(qx.io.remote.transport.Iframe._numericMap.complete);
},
_onreadystatechange:function(a){this._switchReadyState(qx.io.remote.transport.Iframe._numericMap[this._frame.readyState]);
},
_switchReadyState:function(a){switch(this.getState()){case "completed":case "aborted":case "failed":case "timeout":this.warn("Ignore Ready State Change");
return;
}while(this._lastReadyState<a){this.setState(qx.io.remote.Exchange._nativeMap[++this._lastReadyState]);
}},
setRequestHeader:function(a,
b){},
getResponseHeader:function(a){return null;
},
getResponseHeaders:function(){return {};
},
getStatusCode:function(){return 200;
},
getStatusText:function(){return "";
},
getIframeWindow:function(){return qx.bom.Iframe.getWindow(this._frame);
},
getIframeDocument:function(){return qx.bom.Iframe.getDocument(this._frame);
},
getIframeBody:function(){return qx.bom.Iframe.getBody(this._frame);
},
getIframeTextContent:function(){var a=this.getIframeBody();
if(!a){return null;
}
if(!a.firstChild){return "";
}if(a.firstChild.tagName&&a.firstChild.tagName.toLowerCase()=="pre"){return a.firstChild.innerHTML;
}else{return a.innerHTML;
}},
getIframeHtmlContent:function(){var a=this.getIframeBody();
return a?a.innerHTML:null;
},
getFetchedLength:function(){return 0;
},
getResponseContent:function(){if(this.getState()!=="completed"){{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.warn("Transfer not complete, ignoring content!");
}};
return null;
}{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.debug("Returning content for responseType: "+this.getResponseType());
}};
var a=this.getIframeTextContent();
switch(this.getResponseType()){case "text/plain":{if(qx.core.Setting.get("qx.ioRemoteDebugData")){this.debug("Response: "+this._responseContent);
}};
return a;
break;
case "text/html":a=this.getIframeHtmlContent();
{if(qx.core.Setting.get("qx.ioRemoteDebugData")){this.debug("Response: "+this._responseContent);
}};
return a;
break;
case "application/json":a=this.getIframeHtmlContent();
{if(qx.core.Setting.get("qx.ioRemoteDebugData")){this.debug("Response: "+this._responseContent);
}};
try{return a&&a.length>0?qx.util.Json.parseQx(a):null;
}catch(ex){return this.error("Could not execute json: ("+a+")",
ex);
}case "text/javascript":a=this.getIframeHtmlContent();
{if(qx.core.Setting.get("qx.ioRemoteDebugData")){this.debug("Response: "+this._responseContent);
}};
try{return a&&a.length>0?window.eval(a):null;
}catch(ex){return this.error("Could not execute javascript: ("+a+")",
ex);
}case "application/xml":a=this.getIframeDocument();
{if(qx.core.Setting.get("qx.ioRemoteDebugData")){this.debug("Response: "+this._responseContent);
}};
return a;
default:this.warn("No valid responseType specified ("+this.getResponseType()+")!");
return null;
}}},
defer:function(a,
b,
c){qx.io.remote.Exchange.registerType(qx.io.remote.transport.Iframe,
"qx.io.remote.transport.Iframe");
},
destruct:function(){if(this._frame){this._frame.onload=null;
this._frame.onreadystatechange=null;
if(qx.core.Variant.isSet("qx.client",
"gecko")){this._frame.src=qx.util.ResourceManager.toUri("qx/static/image/blank.gif");
}document.body.removeChild(this._frame);
}
if(this._form){document.body.removeChild(this._form);
}this._disposeFields("_frame",
"_form");
}});
qx.Class.define("qx.event.handler.Iframe",
{extend:qx.core.Object,
implement:qx.event.IEventHandler,
statics:{PRIORITY:qx.event.Registration.PRIORITY_NORMAL,
SUPPORTED_TYPES:{load:1},
TARGET_CHECK:qx.event.IEventHandler.TARGET_DOMNODE,
IGNORE_CAN_HANDLE:false,
onevent:function(a){qx.event.Registration.fireEvent(a,
"load");
}},
members:{canHandleEvent:function(a,
b){return a.tagName.toLowerCase()==="iframe";
},
registerEvent:function(a,
b,
c){},
unregisterEvent:function(a,
b,
c){}},
defer:function(a){qx.event.Registration.addHandler(a);
}});
qx.Class.define("qx.bom.Iframe",
{statics:{create:function(a,
b){var a=a?qx.lang.Object.copy(a):{};
a.onload="qx.event.handler.Iframe.onevent(this)";
a.frameBorder="0";
a.frameSpacing="0";
a.marginWidth="0";
a.marginHeight="0";
a.hspace="0";
a.vspace="0";
a.border="0";
a.allowTransparency="true";
return qx.bom.Element.create("iframe",
a,
b);
},
getWindow:qx.core.Variant.select("qx.client",
{"mshtml|gecko":function(a){try{return a.contentWindow;
}catch(ex){return null;
}},
"default":function(a){try{var b=this.getDocument(a);
return b?b.defaultView:null;
}catch(ex){return null;
}}}),
getDocument:qx.core.Variant.select("qx.client",
{"mshtml":function(a){try{var b=this.getWindow(a);
return b?b.document:null;
}catch(ex){return null;
}},
"default":function(a){try{return a.contentDocument;
}catch(ex){return null;
}}}),
getBody:function(a){var b=this.getDocument(a);
return b?b.getElementsByTagName("body")[0]:null;
},
setSource:function(a,
b){try{if(this.getWindow(a)){try{this.getWindow(a).location.replace(b);
}catch(ex){a.src=b;
}}else{a.src=b;
}}catch(ex){qx.log.Logger.warn("Iframe source could not be set! This may be related to AdBlock Plus Firefox Extension.");
}},
queryCurrentUrl:function(a){var b=this.getDocument(a);
try{if(b&&b.location){return b.location.href;
}}catch(ex){}return null;
}}});
qx.Class.define("qx.io.remote.transport.Script",
{extend:qx.io.remote.transport.Abstract,
construct:function(){arguments.callee.base.call(this);
var a=++qx.io.remote.transport.Script._uniqueId;
if(a>=2000000000){qx.io.remote.transport.Script._uniqueId=a=1;
}this._element=null;
this._uniqueId=a;
},
statics:{_uniqueId:0,
_instanceRegistry:{},
ScriptTransport_PREFIX:"_ScriptTransport_",
ScriptTransport_ID_PARAM:"_ScriptTransport_id",
ScriptTransport_DATA_PARAM:"_ScriptTransport_data",
handles:{synchronous:false,
asynchronous:true,
crossDomain:true,
fileUpload:false,
programaticFormFields:false,
responseTypes:["text/plain",
"text/javascript",
"application/json"]},
isSupported:function(){return true;
},
_numericMap:{"uninitialized":1,
"loading":2,
"loaded":2,
"interactive":3,
"complete":4},
_requestFinished:function(a,
b){var c=qx.io.remote.transport.Script._instanceRegistry[a];
if(c==null){{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.warn("Request finished for an unknown instance (probably aborted or timed out before)");
}};
}else{c._responseContent=b;
c._switchReadyState(qx.io.remote.transport.Script._numericMap.complete);
}}},
members:{_lastReadyState:0,
send:function(){var a=this.getUrl();
a+=(a.indexOf("?")>=0?"&":"?")+qx.io.remote.transport.Script.ScriptTransport_ID_PARAM+"="+this._uniqueId;
var b=this.getParameters();
var c=[];
for(var d in b){if(d.indexOf(qx.io.remote.transport.Script.ScriptTransport_PREFIX)==0){this.error("Illegal parameter name. The following prefix is used internally by qooxdoo): "+qx.io.remote.transport.Script.ScriptTransport_PREFIX);
}var e=b[d];
if(e instanceof Array){for(var f=0;f<e.length;f++){c.push(encodeURIComponent(d)+"="+encodeURIComponent(e[f]));
}}else{c.push(encodeURIComponent(d)+"="+encodeURIComponent(e));
}}
if(c.length>0){a+="&"+c.join("&");
}var g=this.getData();
if(g!=null){a+="&"+qx.io.remote.transport.Script.ScriptTransport_DATA_PARAM+"="+encodeURIComponent(g);
}qx.io.remote.transport.Script._instanceRegistry[this._uniqueId]=this;
this._element=document.createElement("script");
this._element.charset="utf-8";
this._element.src=a;
{if(qx.core.Setting.get("qx.ioRemoteDebugData")){this.debug("Request: "+a);
}};
document.body.appendChild(this._element);
},
_switchReadyState:function(a){switch(this.getState()){case "completed":case "aborted":case "failed":case "timeout":this.warn("Ignore Ready State Change");
return;
}while(this._lastReadyState<a){this.setState(qx.io.remote.Exchange._nativeMap[++this._lastReadyState]);
}},
setRequestHeader:function(a,
b){},
getResponseHeader:function(a){return null;
},
getResponseHeaders:function(){return {};
},
getStatusCode:function(){return 200;
},
getStatusText:function(){return "";
},
getFetchedLength:function(){return 0;
},
getResponseContent:function(){if(this.getState()!=="completed"){{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.warn("Transfer not complete, ignoring content!");
}};
return null;
}{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.debug("Returning content for responseType: "+this.getResponseType());
}};
switch(this.getResponseType()){case "text/plain":case "application/json":case "text/javascript":{if(qx.core.Setting.get("qx.ioRemoteDebugData")){this.debug("Response: "+this._responseContent);
}};
return this._responseContent||null;
default:this.warn("No valid responseType specified ("+this.getResponseType()+")!");
return null;
}}},
defer:function(a,
b,
c){qx.io.remote.Exchange.registerType(qx.io.remote.transport.Script,
"qx.io.remote.transport.Script");
qx.io.remote.ScriptTransport=a;
},
destruct:function(){if(this._element){delete qx.io.remote.transport.Script._instanceRegistry[this._uniqueId];
document.body.removeChild(this._element);
}this._disposeFields("_element");
}});
qx.Class.define("qx.io.remote.Response",
{extend:qx.event.type.Event,
properties:{state:{check:"Integer",
nullable:true},
statusCode:{check:"Integer",
nullable:true},
content:{nullable:true},
responseHeaders:{check:"Object",
nullable:true}},
members:{clone:function(a){var b=arguments.callee.base.call(this,
a);
b.setType(this.getType());
b.setState(this.getState());
b.setStatusCode(this.getStatusCode());
b.setContent(this.getContent());
b.setResponseHeaders(this.getResponseHeaders());
return b;
},
getResponseHeader:function(a){var b=this.getResponseHeaders();
if(b){return b[a]||null;
}return null;
}}});
qx.Interface.define("qx.ui.table.ICellEditorFactory",
{members:{createCellEditor:function(a){return true;
},
getCellEditorValue:function(a){return true;
}}});
qx.Class.define("qx.ui.table.celleditor.ComboBox",
{extend:qx.core.Object,
implement:qx.ui.table.ICellEditorFactory,
construct:function(){arguments.callee.base.call(this);
},
properties:{validationFunction:{check:"Function",
nullable:true,
init:null},
listData:{check:"Array",
init:null,
nullable:true}},
members:{createCellEditor:function(a){var b=new qx.ui.form.ComboBox().set({appearance:"table-editor-combobox"});
var c=a.value;
b.originalValue=c;
var d=a.table.getTableColumnModel().getDataCellRenderer(a.col);
var e=d._getContentHtml(a);
if(c!=e){c=e;
}if(c===null){c="";
}var f=this.getListData();
if(f){var g;
for(var h=0,
j=f.length;h<j;h++){var k=f[h];
if(k instanceof Array){g=new qx.ui.form.ListItem(k[0],
k[1],
k[2]);
}else{g=new qx.ui.form.ListItem(k,
null,
k);
}b.add(g);
}}b.setValue(""+c);
b.addListener("appear",
function(){b.selectAll();
});
return b;
},
getCellEditorValue:function(a){var b=a.getValue()||"";
var c=this.getValidationFunction();
if(!this._done&&c){b=c(b,
a.originalValue);
this._done=true;
}
if(typeof a.originalValue=="number"){b=parseFloat(b);
}return b;
}}});
qx.Class.define("qx.ui.form.AbstractSelectBox",
{extend:qx.ui.core.Widget,
include:qx.ui.core.MRemoteChildrenHandling,
type:"abstract",
construct:function(){arguments.callee.base.call(this);
var a=new qx.ui.layout.HBox();
this._setLayout(a);
a.setAlignY("middle");
this.addListener("keypress",
this._onKeyPress);
this.addListener("blur",
this.close,
this);
this.addListener("resize",
this._onResize,
this);
},
properties:{width:{refine:true,
init:120},
name:{check:"String",
nullable:true,
event:"changeName"},
maxListHeight:{check:"Number",
apply:"_applyMaxListHeight",
nullable:true,
init:200}},
events:{"changeValue":"qx.event.type.Data"},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "list":b=new qx.ui.form.List().set({focusable:false,
keepFocus:true,
height:null,
width:null,
maxHeight:this.getMaxListHeight(),
selectionMode:"one"});
b.addListener("changeSelection",
this._onListChangeSelection,
this);
b.addListener("changeValue",
this._onListChangeValue,
this);
break;
case "popup":b=new qx.ui.popup.Popup(new qx.ui.layout.VBox);
b.setAutoHide(false);
b.addListener("mouseup",
this.close,
this);
b.addListener("activate",
this._onActivateList,
this);
b.add(this._getChildControl("list"));
break;
}return b||arguments.callee.base.call(this,
a);
},
_applyMaxListHeight:function(a,
b){this._getChildControl("list").setMaxHeight(a);
},
getChildrenContainer:function(){return this._getChildControl("list");
},
open:function(){var a=this._getChildControl("popup");
a.alignToWidget(this);
a.show();
},
close:function(){this._getChildControl("popup").hide();
},
toggle:function(){var a=this._getChildControl("popup").isVisible();
if(a){this.close();
}else{this.open();
}},
_onActivateList:function(a){this.activate();
a.stopPropagation();
},
_onKeyPress:function(a){var b=a.getKeyIdentifier();
var c=this._getChildControl("popup");
if(b=="PageDown"||b=="PageUp"){if(c.isHidden()){return;
}}if(b=="Escape"){this.close();
if(b=="Escape"){a.stopPropagation();
}return;
}this._getChildControl("list").handleKeyPress(a);
},
_onResize:function(a){this._getChildControl("list").setMinWidth(a.getData().width);
},
_onListChangeSelection:function(a){throw new Error("Abstract method: _onListChangeSelection()");
},
_onListChangeValue:function(a){throw new Error("Abstract method: _onListChangeValue()");
}}});
qx.Class.define("qx.ui.form.ComboBox",
{extend:qx.ui.form.AbstractSelectBox,
implement:qx.ui.form.IFormElement,
construct:function(){arguments.callee.base.call(this);
this._createChildControl("textfield");
this._createChildControl("button");
this.addListener("click",
this._onClick);
},
properties:{focusable:{refine:true,
init:true},
appearance:{refine:true,
init:"combobox"}},
events:{"input":"qx.event.type.Data"},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "textfield":b=new qx.ui.form.TextField();
b.setFocusable(false);
b.addState("inner");
b.addListener("changeValue",
this._onTextFieldChangeValue,
this);
b.addListener("input",
this._onTextFieldInput,
this);
this._add(b,
{flex:1});
break;
case "button":b=new qx.ui.form.Button();
b.setFocusable(false);
b.addState("inner");
b.addListener("activate",
this._onActivateButton,
this);
this._add(b);
break;
}return b||arguments.callee.base.call(this,
a);
},
_forwardStates:{focused:true},
tabFocus:function(){this._getChildControl("textfield").getFocusElement().focus();
},
setValue:function(a){var b=this._getChildControl("textfield");
if(b.getValue()==a){return;
}b.setValue(a);
var c=this._getChildControl("list");
var d=c.findItem(a);
if(d){c.select(d);
}else{c.clearSelection();
}},
getValue:function(){return this._getChildControl("textfield").getValue();
},
_onClick:function(a){var b=a.getTarget();
if(b==this._getChildControl("button")){this.toggle();
}else{this.close();
}},
_onActivateButton:function(a){this.activate();
a.stopPropagation();
},
_onListChangeSelection:function(a){var b=a.getData();
if(b.length>0){this.setValue(b[0].getLabel());
}},
_onListChangeValue:function(a){},
_onTextFieldInput:function(a){this.fireDataEvent("input",
a.getData());
},
_onTextFieldChangeValue:function(a){this.setValue(a.getData());
},
getSelection:function(){return this._getChildControl("textfield").getSelection();
},
getSelectionLength:function(){return this._getChildControl("textfield").getSelectionLength();
},
setSelection:function(a,
b){this._getChildControl("textfield").setSelection(a,
b);
},
clearSelection:function(){this._getChildControl("textfield").clearSelection();
},
selectAll:function(){this._getChildControl("textfield").setSelection(0);
}}});
qx.Class.define("qx.ui.core.ScrollArea",
{extend:qx.ui.core.Widget,
construct:function(){arguments.callee.base.call(this);
var a=new qx.ui.layout.Grid();
a.setColumnFlex(0,
1);
a.setRowFlex(0,
1);
this._setLayout(a);
this.addListener("mousewheel",
this._onMouseWheel,
this);
},
properties:{appearance:{refine:true,
init:"scrollarea"},
width:{refine:true,
init:100},
height:{refine:true,
init:200},
scrollbarX:{check:["auto",
"on",
"off"],
init:"auto",
apply:"_computeScrollbars"},
scrollbarY:{check:["auto",
"on",
"off"],
init:"auto",
apply:"_computeScrollbars"},
scrollbar:{group:["scrollbarX",
"scrollbarY"]}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "pane":b=new qx.ui.core.ScrollPane();
b.addListener("update",
this._computeScrollbars,
this);
b.addListener("scrollX",
this._onScrollPaneX,
this);
b.addListener("scrollY",
this._onScrollPaneY,
this);
this._add(b,
{row:0,
column:0});
break;
case "scrollbar-x":b=new qx.ui.core.ScrollBar("horizontal");
b.exclude();
b.addListener("scroll",
this._onScrollBarX,
this);
b.addListener("changeVisibility",
this._onChangeScrollbarXVisibility,
this);
this._add(b,
{row:1,
column:0});
break;
case "scrollbar-y":b=new qx.ui.core.ScrollBar("vertical");
b.exclude();
b.addListener("scroll",
this._onScrollBarY,
this);
b.addListener("changeVisibility",
this._onChangeScrollbarYVisibility,
this);
this._add(b,
{row:0,
column:1});
break;
case "corner":b=new qx.ui.core.Widget();
b.exclude();
this._add(b,
{row:1,
column:1});
break;
}return b||arguments.callee.base.call(this,
a);
},
getPaneSize:function(){return this._getChildControl("pane").getBounds();
},
getItemTop:function(a){return this._getChildControl("pane").getItemTop(a);
},
getItemBottom:function(a){return this._getChildControl("pane").getItemBottom(a);
},
getItemLeft:function(a){return this._getChildControl("pane").getItemLeft(a);
},
getItemRight:function(a){return this._getChildControl("pane").getItemRight(a);
},
scrollToX:function(a){this._getChildControl("scrollbar-x").scrollTo(a);
},
scrollByX:function(a){this._getChildControl("scrollbar-x").scrollBy(a);
},
getScrollX:function(){var a=this._getChildControl("scrollbar-x",
true);
return a?a.getPosition():0;
},
scrollToY:function(a){this._getChildControl("scrollbar-y").scrollTo(a);
},
scrollByY:function(a){this._getChildControl("scrollbar-y").scrollBy(a);
},
getScrollY:function(){var a=this._getChildControl("scrollbar-y",
true);
return a?a.getPosition():0;
},
_onScrollBarX:function(a){this._getChildControl("pane").scrollToX(a.getData());
},
_onScrollBarY:function(a){this._getChildControl("pane").scrollToY(a.getData());
},
_onScrollPaneX:function(a){this.scrollToX(a.getData());
},
_onScrollPaneY:function(a){this.scrollToY(a.getData());
},
_onMouseWheel:function(a){var b=this._getChildControl("scrollbar-y",
true);
if(b){b.scrollBySteps(a.getWheelDelta());
}a.stop();
},
_onChangeScrollbarXVisibility:function(a){var b=this._isChildControlVisible("scrollbar-x");
var c=this._isChildControlVisible("scrollbar-y");
if(!b){this.scrollToX(0);
}b&&c?this._showChildControl("corner"):this._excludeChildControl("corner");
},
_onChangeScrollbarYVisibility:function(a){var b=this._isChildControlVisible("scrollbar-x");
var c=this._isChildControlVisible("scrollbar-y");
if(!c){this.scrollToY(0);
}b&&c?this._showChildControl("corner"):this._excludeChildControl("corner");
},
_computeScrollbars:function(){var a=this._getChildControl("pane");
var b=a.getChild();
if(!b){this._excludeChildControl("scrollbar-x");
this._excludeChildControl("scrollbar-y");
return;
}var c=this.getInnerSize();
var d=a.getBounds();
var e=a.getScrollSize();
if(!d||!e){return;
}var f=this.getScrollbarX();
var g=this.getScrollbarY();
if(f==="auto"&&g==="auto"){var h=e.width>c.width;
var i=e.height>c.height;
if((h||i)&&!(h&&i)){if(h){i=e.height>d.height;
}else if(i){h=e.width>d.width;
}}}else{var h=f==="on";
var i=g==="on";
if(e.width>(h?d.width:c.width)&&f==="auto"){h=true;
}
if(e.height>(h?d.height:c.height)&&g==="auto"){i=true;
}}if(h){var j=this._getChildControl("scrollbar-x");
j.show();
j.setMaximum(Math.max(0,
e.width-d.width));
j.setKnobFactor(d.width/e.width);
}else{this._excludeChildControl("scrollbar-x");
}
if(i){var k=this._getChildControl("scrollbar-y");
k.show();
k.setMaximum(Math.max(0,
e.height-d.height));
k.setKnobFactor(d.height/e.height);
}else{this._excludeChildControl("scrollbar-y");
}}}});
qx.Mixin.define("qx.ui.core.MSelectionHandling",
{construct:function(){var a=this.SELECTION_MANAGER;
var b=this.__manager=new a(this);
this.addListener("mousedown",
b.handleMouseDown,
b);
this.addListener("mouseup",
b.handleMouseUp,
b);
this.addListener("mousemove",
b.handleMouseMove,
b);
this.addListener("losecapture",
b.handleLoseCapture,
b);
this.addListener("keypress",
b.handleKeyPress,
b);
this.addListener("addItem",
b.handleAddItem,
b);
this.addListener("removeItem",
b.handleRemoveItem,
b);
b.addListener("changeSelection",
this._onSelectionChange,
this);
},
events:{"changeSelection":"qx.event.type.Data"},
properties:{selectionMode:{check:["single",
"multi",
"additive",
"one"],
init:"single",
apply:"_applySelectionMode"},
dragSelection:{check:"Boolean",
init:false,
apply:"_applyDragSelection"}},
members:{selectAll:function(){this.__manager.selectAll();
},
select:function(a){this.__manager.selectItem(a);
},
isSelected:function(a){this.__manager.isSelected(a);
},
addToSelection:function(a){this.__manager.addItem(a);
},
removeFromSelection:function(a){this.__manager.removeItem(a);
},
selectRange:function(a,
b){this.__manager.selectItemRange(a,
b);
},
clearSelection:function(){this.__manager.clearSelection();
},
replaceSelection:function(a){this.__manager.replaceSelection(a);
},
getSelectedItem:function(){return this.__manager.getSelectedItem();
},
getSelection:function(){return this.__manager.getSelection();
},
isSelectionEmpty:function(){return this.__manager.isSelectionEmpty();
},
_getManager:function(){return this.__manager;
},
_applySelectionMode:function(a,
b){this.__manager.setMode(a);
},
_applyDragSelection:function(a,
b){this.__manager.setDrag(a);
},
_onSelectionChange:function(a){this.fireDataEvent("changeSelection",
a.getData());
}},
destruct:function(){this._disposeObjects("__manager");
}});
qx.Class.define("qx.ui.core.selection.Abstract",
{extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
this.__selection={};
},
events:{"changeSelection":"qx.event.type.Data"},
properties:{mode:{check:["single",
"multi",
"additive",
"one"],
init:"single",
apply:"_applyMode"},
drag:{check:"Boolean",
init:false}},
members:{selectAll:function(){this._selectAllItems();
this._fireChange();
},
selectItem:function(a){this._setSelectedItem(a);
var b=this.getMode();
if(b!=="single"&&b!=="one"){this._setLeadItem(a);
this._setAnchorItem(a);
}this._scrollItemIntoView(a);
this._fireChange();
},
addItem:function(a){var b=this.getMode();
if(b==="single"||b==="one"){this._setSelectedItem(a);
}else{if(!this._getAnchorItem()){this._setAnchorItem(a);
}this._setLeadItem(a);
this._addToSelection(a);
}this._scrollItemIntoView(a);
this._fireChange();
},
removeItem:function(a){this._removeFromSelection(a);
if(this.getMode()==="one"&&this.isSelectionEmpty()){var b=this._getFirstSelectable();
if(b){this.addItem(b);
}}
if(this._getLeadItem()==a){this._setLeadItem(null);
}
if(this._getAnchorItem()==a){this._setAnchorItem(null);
}this._fireChange();
},
selectItemRange:function(a,
b){this._selectItemRange(a,
b);
this._setAnchorItem(a);
this._setLeadItem(b);
this._scrollItemIntoView(b);
this._fireChange();
},
clearSelection:function(){if(this.getMode()=="one"){return;
}this._clearSelection();
this._setLeadItem(null);
this._setAnchorItem(null);
this._fireChange();
},
replaceSelection:function(a){this._clearSelection();
this._setLeadItem(null);
this._setAnchorItem(null);
for(var b=0,
c=a.length;b<c;b++){this._addToSelection(a[b]);
}if(c>0){this._scrollItemIntoView(a[c-1]);
}else if(this.getMode()=="one"){var d=this._getFirstSelectable();
if(d){this._addToSelection(d);
}}this._fireChange();
},
getSelectedItem:function(){var a=this.getMode();
if(a==="single"||a==="one"){return this._getSelectedItem()||null;
}throw new Error("The method getSelectedItem() is only supported in 'single' and 'one' selection mode!");
},
getSelection:function(){return qx.lang.Object.getValues(this.__selection);
},
isItemSelected:function(a){var b=this._selectableToHashCode(a);
return !!this.__selection[b];
},
isSelectionEmpty:function(){return qx.lang.Object.isEmpty(this.__selection);
},
_setLeadItem:function(a){var b=this.__leadItem;
if(b){this._styleSelectable(b,
"lead",
false);
}
if(a){this._styleSelectable(a,
"lead",
true);
}this.__leadItem=a;
},
_getLeadItem:function(){return this.__leadItem||null;
},
_setAnchorItem:function(a){var b=this.__anchorItem;
if(b){this._styleSelectable(b,
"anchor",
false);
}
if(a){this._styleSelectable(a,
"anchor",
true);
}this.__anchorItem=a;
},
_getAnchorItem:function(){return this.__anchorItem||null;
},
_isSelectable:function(a){throw new Error("Abstract method call: _isSelectable()");
},
_getSelectableFromTarget:function(a){return this._isSelectable(a)?a:null;
},
_selectableToHashCode:function(a){throw new Error("Abstract method call: _selectableToHashCode()");
},
_styleSelectable:function(a,
b,
c){throw new Error("Abstract method call: _styleSelectable()");
},
_capture:function(){throw new Error("Abstract method call: _capture()");
},
_releaseCapture:function(){throw new Error("Abstract method call: _releaseCapture()");
},
_getLocation:function(){throw new Error("Abstract method call: _getLocation()");
},
_getDimension:function(){throw new Error("Abstract method call: _getDimension()");
},
_getSelectableLocationX:function(a){throw new Error("Abstract method call: _getSelectableLocationX()");
},
_getSelectableLocationY:function(a){throw new Error("Abstract method call: _getSelectableLocationY()");
},
_getScroll:function(){throw new Error("Abstract method call: _getScroll()");
},
_scrollBy:function(a,
b){throw new Error("Abstract method call: _scrollBy()");
},
_scrollItemIntoView:function(a){throw new Error("Abstract method call: _scrollItemIntoView()");
},
_getSelectables:function(){throw new Error("Abstract method call: _getSelectables()");
},
_getSelectableRange:function(a,
b){throw new Error("Abstract method call: _getSelectableRange()");
},
_getFirstSelectable:function(){throw new Error("Abstract method call: _getFirstSelectable()");
},
_getLastSelectable:function(){throw new Error("Abstract method call: _getLastSelectable()");
},
_getRelatedSelectable:function(a,
b){throw new Error("Abstract method call: _getRelatedSelectable()");
},
_getPage:function(a,
b){throw new Error("Abstract method call: _getPage()");
},
_applyMode:function(a,
b){this._setLeadItem(null);
this._setAnchorItem(null);
this._clearSelection();
if(a==="one"){var c=this._getFirstSelectable();
if(c){this._setSelectedItem(c);
this._scrollItemIntoView(c);
}}this._fireChange();
},
handleMouseDown:function(a){var b=this._getSelectableFromTarget(a.getTarget());
if(!b){return;
}var c=a.isCtrlPressed()||(qx.bom.client.Platform.MAC&&a.isMetaPressed());
var d=a.isShiftPressed();
if(this.isItemSelected(b)&&!d&&!c){this.__mouseDownOnSelected=b;
return;
}else{this.__mouseDownOnSelected=null;
}this._scrollItemIntoView(b);
switch(this.getMode()){case "single":case "one":this._setSelectedItem(b);
break;
case "additive":this._setLeadItem(b);
this._setAnchorItem(b);
this._toggleInSelection(b);
break;
case "multi":this._setLeadItem(b);
if(d){var e=this._getAnchorItem();
if(!e){this._setAnchorItem(e=this.getFirstItem());
}this._selectItemRange(e,
b,
c);
}else if(c){this._setAnchorItem(b);
this._toggleInSelection(b);
}else{this._setAnchorItem(b);
this._setSelectedItem(b);
}break;
}var f=this.getMode();
if(this.getDrag()&&f!=="single"&&f!=="one"&&!d&&!c){this._frameLocation=this._getLocation();
this._frameScroll=this._getScroll();
this._dragStartX=a.getDocumentLeft()+this._frameScroll.left;
this._dragStartY=a.getDocumentTop()+this._frameScroll.top;
this._inCapture=true;
this._capture();
}this._fireChange();
},
handleMouseUp:function(a){var b=a.isCtrlPressed()||(qx.bom.client.Platform.MAC&&a.isMetaPressed());
var c=a.isShiftPressed();
if(!b&&!c){var d=this._getSelectableFromTarget(a.getTarget());
if(d&&this.isItemSelected(d)&&this.__mouseDownOnSelected){this._setSelectedItem(d);
switch(this.getMode()){case "single":case "one":break;
default:this._setLeadItem(d);
this._setAnchorItem(d);
}}}this._cleanup();
},
handleLoseCapture:function(a){this._cleanup();
},
handleMouseMove:function(a){if(!this._inCapture){return;
}this._mouseX=a.getDocumentLeft();
this._mouseY=a.getDocumentTop();
var b=this._mouseX+this._frameScroll.left;
if(b>this._dragStartX){this._moveDirectionX=1;
}else if(b<this._dragStartX){this._moveDirectionX=-1;
}else{this._moveDirectionX=0;
}var c=this._mouseY+this._frameScroll.top;
if(c>this._dragStartY){this._moveDirectionY=1;
}else if(c<this._dragStartY){this._moveDirectionY=-1;
}else{this._moveDirectionY=0;
}var d=this._frameLocation;
if(this._mouseX<d.left){this._scrollStepX=this._mouseX-d.left;
}else if(this._mouseX>d.right){this._scrollStepX=this._mouseX-d.right;
}else{this._scrollStepX=0;
}
if(this._mouseY<d.top){this._scrollStepY=this._mouseY-d.top;
}else if(this._mouseY>d.bottom){this._scrollStepY=this._mouseY-d.bottom;
}else{this._scrollStepY=0;
}if(!this._scrollTimer){this._scrollTimer=new qx.event.Timer(100);
this._scrollTimer.addListener("interval",
this._onInterval,
this);
}this._scrollTimer.start();
this._autoSelect();
},
handleAddItem:function(a){var b=a.getData();
if(this.getMode()==="one"&&this.isSelectionEmpty()){this.addItem(b);
}},
handleRemoveItem:function(a){var b=a.getData();
this.removeItem(b);
},
_cleanup:function(){if(!this.getDrag()&&this._inCapture){return;
}delete this._inCapture;
delete this._lastRelX;
delete this._lastRelY;
this._releaseCapture();
if(this._scrollTimer){this._scrollTimer.stop();
}},
_onInterval:function(a){this._scrollBy(this._scrollStepX,
this._scrollStepY);
this._frameScroll=this._getScroll();
this._autoSelect();
},
_autoSelect:function(){var a=this._getDimension();
var b=Math.max(0,
Math.min(this._mouseX-this._frameLocation.left,
a.width))+this._frameScroll.left;
var c=Math.max(0,
Math.min(this._mouseY-this._frameLocation.top,
a.height))+this._frameScroll.top;
if(this._lastRelX===b&&this._lastRelY===c){return;
}this._lastRelX=b;
this._lastRelY=c;
var d=this._getAnchorItem();
var e=this._moveDirectionX,
f=d;
var g,
h,
i=0;
while(e!==0){g=e>0?this._getRelatedSelectable(f,
"right"):this._getRelatedSelectable(f,
"left");
if(g){h=this._getSelectableLocationX(g);
if((e>0&&h.left<=b)||(e<0&&h.right>=b)){f=g;
i++;
continue;
}}break;
}var j=this._moveDirectionY,
k=d;
var l,
m,
n=0;
while(j!==0){l=j>0?this._getRelatedSelectable(k,
"under"):this._getRelatedSelectable(k,
"above");
if(l){m=this._getSelectableLocationY(l);
if((j>0&&m.top<=c)||(j<0&&m.bottom>=c)){k=l;
n++;
continue;
}}break;
}var o=i>n?f:k;
var p=this.getMode();
if(p==="multi"){this._selectItemRange(d,
o);
}else if(p==="additive"){if(this.isItemSelected(d)){this._selectItemRange(d,
o,
true);
}else{this._deselectItemRange(d,
o);
}this._setAnchorItem(o);
}this._fireChange();
},
__dU:{Home:1,
Down:1,
Right:1,
PageDown:1,
End:1,
Up:1,
Left:1,
PageUp:1},
handleKeyPress:function(a){var b,
c;
var d=a.getKeyIdentifier();
var e=this.getMode();
var f=a.isCtrlPressed()||(qx.bom.client.Platform.MAC&&a.isMetaPressed());
var g=a.isShiftPressed();
if(d==="A"&&f){if(e!=="single"&&e!=="one"){this._selectAllItems();
}}else if(d==="Escape"){if(e!=="single"&&e!=="one"){this._clearSelection();
}}else if(d==="Space"){var h=this._getLeadItem();
if(h&&!g){if(f||e==="additive"){this._toggleInSelection(h);
}else{this._setSelectedItem(h);
}}}else if(this.__dU[d]){if(e==="single"||e=="one"){b=this._getSelectedItem();
}else{b=this._getLeadItem();
}var i=this._getFirstSelectable();
var j=this._getLastSelectable();
if(b){switch(d){case "Home":c=i;
break;
case "End":c=j;
break;
case "Up":c=this._getRelatedSelectable(b,
"above");
break;
case "Down":c=this._getRelatedSelectable(b,
"under");
break;
case "Left":c=this._getRelatedSelectable(b,
"left");
break;
case "Right":c=this._getRelatedSelectable(b,
"right");
break;
case "PageUp":c=this._getPage(b,
true);
break;
case "PageDown":c=this._getPage(b,
false);
break;
}}else{switch(d){case "Home":case "Down":case "Right":case "PageDown":c=i;
break;
case "End":case "Up":case "Left":case "PageUp":c=j;
break;
}}if(c){switch(e){case "single":case "one":this._setSelectedItem(c);
break;
case "additive":this._setLeadItem(c);
break;
case "multi":if(g){var k=this._getAnchorItem();
if(!k){this._setAnchorItem(k=this._getFirstSelectable());
}this._setLeadItem(c);
this._selectItemRange(k,
c,
f);
}else{this._setAnchorItem(c);
this._setLeadItem(c);
if(!f){this._setSelectedItem(c);
}}break;
}this._scrollItemIntoView(c);
}}else{return ;
}a.stop();
this._fireChange();
},
_selectAllItems:function(){var a=this._getSelectables();
for(var b=0,
c=a.length;b<c;b++){this._addToSelection(a[b]);
}},
_clearSelection:function(){var a=this.__selection;
for(var b in a){this._removeFromSelection(a[b]);
}},
_selectItemRange:function(a,
b,
c){var d=this._getSelectableRange(a,
b);
if(!c){var e=this.__selection;
var f=this.__dV(d);
for(var g in e){if(!f[g]){this._removeFromSelection(e[g]);
}}}for(var h=0,
j=d.length;h<j;h++){this._addToSelection(d[h]);
}},
_deselectItemRange:function(a,
b){var c=this._getSelectableRange(a,
b);
for(var d=0,
e=c.length;d<e;d++){this._removeFromSelection(c[d]);
}},
__dV:function(a){var b={};
var c;
for(var d=0,
e=a.length;d<e;d++){c=a[d];
b[this._selectableToHashCode(c)]=c;
}return b;
},
_getSelectedItem:function(){for(var a in this.__selection){return this.__selection[a];
}return null;
},
_setSelectedItem:function(a){this._clearSelection();
this._addToSelection(a);
},
_addToSelection:function(a){var b=this._selectableToHashCode(a);
if(!this.__selection[b]){this.__selection[b]=a;
this._styleSelectable(a,
"selected",
true);
this.__selectionModified=true;
}},
_toggleInSelection:function(a){var b=this._selectableToHashCode(a);
if(!this.__selection[b]){this.__selection[b]=a;
this._styleSelectable(a,
"selected",
true);
}else{delete this.__selection[b];
this._styleSelectable(a,
"selected",
false);
}this.__selectionModified=true;
},
_removeFromSelection:function(a){var b=this._selectableToHashCode(a);
if(this.__selection[b]){delete this.__selection[b];
this._styleSelectable(a,
"selected",
false);
this.__selectionModified=true;
}},
_fireChange:function(){if(this.__selectionModified){this.fireDataEvent("changeSelection",
this.getSelection());
delete this.__selectionModified;
}}},
destruct:function(){this._disposeObjects("_scrollTimer");
this._disposeFields("__selection");
}});
qx.Class.define("qx.ui.core.selection.Widget",
{extend:qx.ui.core.selection.Abstract,
construct:function(a){arguments.callee.base.call(this);
this._widget=a;
},
members:{_isSelectable:function(a){return a.isEnabled()&&a.getLayoutParent()===this._widget;
},
_selectableToHashCode:function(a){return a.$$hash;
},
_styleSelectable:function(a,
b,
c){c?a.addState(b):a.removeState(b);
},
_capture:function(){this._widget.capture();
},
_releaseCapture:function(){this._widget.releaseCapture();
},
_getLocation:function(){var a=this._widget.getContentElement().getDomElement();
return a?qx.bom.element.Location.get(a):null;
},
_getDimension:function(){return this._widget.getInnerSize();
},
_getSelectableLocationX:function(a){var b=a.getBounds();
if(b){return {left:b.left,
right:b.left+b.width};
}},
_getSelectableLocationY:function(a){var b=a.getBounds();
if(b){return {top:b.top,
bottom:b.top+b.height};
}},
_getScroll:function(){return {left:0,
top:0};
},
_scrollBy:function(a,
b){},
_scrollItemIntoView:function(a){this._widget.scrollChildIntoView(a);
},
_getSelectables:function(){var a=this._widget.getChildren();
var b=[];
var c;
for(var d=0,
e=a.length;d<e;d++){c=a[d];
if(c.isEnabled()){b.push(c);
}}return b;
},
_getSelectableRange:function(a,
b){if(a===b){return [a];
}var c=this._widget.getChildren();
var d=[];
var e=false;
var f;
for(var g=0,
h=c.length;g<h;g++){f=c[g];
if(f===a||f===b){if(e){d.push(f);
break;
}else{e=true;
}}
if(e&&f.isEnabled()){d.push(f);
}}return d;
},
_getFirstSelectable:function(){var a=this._widget.getChildren();
for(var b=0,
c=a.length;b<c;b++){if(a[b].isEnabled()){return a[b];
}}return null;
},
_getLastSelectable:function(){var a=this._widget.getChildren();
for(var b=a.length-1;b>0;b--){if(a[b].isEnabled()){return a[b];
}}return null;
},
_getRelatedSelectable:function(a,
b){var c=this._widget.getOrientation()==="vertical";
var d=this._widget.getChildren();
var e=d.indexOf(a);
var f;
if((c&&b==="above")||(!c&&b==="left")){for(var g=e-1;g>=0;g--){f=d[g];
if(f.isEnabled()){return f;
}}}else if((c&&b==="under")||(!c&&b==="right")){for(var g=e+1;g<d.length;g++){f=d[g];
if(f.isEnabled()){return f;
}}}return null;
},
_getPage:function(a,
b){if(b){return this._getFirstSelectable();
}else{return this._getLastSelectable();
}}},
destruct:function(){this._disposeFields("_widget");
}});
qx.Class.define("qx.ui.core.selection.ScrollArea",
{extend:qx.ui.core.selection.Widget,
members:{_isSelectable:function(a){return a.isEnabled()&&a.getLayoutParent()===this._widget.getChildrenContainer();
},
_getDimension:function(){return this._widget.getPaneSize();
},
_getScroll:function(){var a=this._widget;
return {left:a.getScrollX(),
top:a.getScrollY()};
},
_scrollBy:function(a,
b){var c=this._widget;
c.scrollByX(a);
c.scrollByY(b);
},
_getPage:function(a,
b){var c=this._getSelectables();
var d=c.length;
var e=c.indexOf(a);
if(e===-1){throw new Error("Invalid lead item: "+a);
}var f=this._widget;
var g=f.getScrollY();
var h=f.getInnerSize().height;
var j,
k,
l;
if(b){var m=g;
var n=e;
while(1){for(;n>=0;n--){j=f.getItemTop(c[n]);
if(j<m){l=n+1;
break;
}}if(l==null){var o=this._getFirstSelectable();
return o==a?null:o;
}if(l>=e){m-=h+g-f.getItemBottom(a);
l=null;
continue;
}return c[l];
}}else{var p=h+g;
var n=e;
while(1){for(;n<d;n++){k=f.getItemBottom(c[n]);
if(k>p){l=n-1;
break;
}}if(l==null){var q=this._getLastSelectable();
return q==a?null:q;
}if(l<=e){p+=f.getItemTop(a)-g;
l=null;
continue;
}return c[l];
}}}}});
qx.Class.define("qx.ui.form.List",
{extend:qx.ui.core.ScrollArea,
implement:qx.ui.form.IFormElement,
include:[qx.ui.core.MRemoteChildrenHandling,
qx.ui.core.MSelectionHandling],
construct:function(a){arguments.callee.base.call(this);
this.__content=new qx.ui.container.Composite();
this.__content.addListener("addChildWidget",
this._onAddChild,
this);
this.__content.addListener("removeChildWidget",
this._onRemoveChild,
this);
this._getChildControl("pane").add(this.__content);
if(a){this.setOrientation("horizontal");
}else{this.initOrientation();
}this.addListener("keypress",
this._onKeyPress);
this.addListener("keyinput",
this._onKeyInput);
this.addListener("changeSelection",
this._onChangeSelection);
this._pressedString="";
},
events:{addItem:"qx.event.type.Data",
removeItem:"qx.event.type.Data",
changeValue:"qx.event.type.Data"},
properties:{appearance:{refine:true,
init:"list"},
focusable:{refine:true,
init:true},
orientation:{check:["horizontal",
"vertical"],
init:"vertical",
apply:"_applyOrientation"},
spacing:{check:"Integer",
init:0,
apply:"_applySpacing",
themeable:true},
enableInlineFind:{check:"Boolean",
init:true},
name:{check:"String",
nullable:true,
event:"changeName"}},
members:{SELECTION_MANAGER:qx.ui.core.selection.ScrollArea,
getChildrenContainer:function(){return this.__content;
},
_onAddChild:function(a){this.fireDataEvent("addItem",
a.getData());
},
_onRemoveChild:function(a){this.fireDataEvent("removeItem",
a.getData());
},
getValue:function(){var a=this.getSelection();
var b=[];
var c;
for(var d=0,
e=a.length;d<e;d++){c=a[d].getValue();
if(c==null){c=a[d].getLabel();
}b.push(c);
}return b.join(",");
},
setValue:function(a){var b=a.split(",");
var c=[];
var d;
for(var e=0,
f=b.length;e<f;e++){d=this.findItem(b[e]);
if(d){c.push(d);
}else{this.warn("Could not find item: "+b[e]+"!");
}}this.replaceSelection(c);
},
handleKeyPress:function(a){if(!this._onKeyPress(a)){this._getManager().handleKeyPress(a);
}},
_applyOrientation:function(a,
b){var c=a==="horizontal";
var d=c?new qx.ui.layout.HBox():new qx.ui.layout.VBox();
var e=this.__content;
e.setLayout(d);
e.setAllowGrowX(!c);
e.setAllowGrowY(c);
this._applySpacing(this.getSpacing());
},
_applySpacing:function(a,
b){this.__content.getLayout().setSpacing(a);
},
_onKeyPress:function(a){if(a.getKeyIdentifier()=="Enter"&&!a.isAltPressed()){var b=this.getSelection();
for(var c=0;c<b.length;c++){b[c].fireEvent("action");
}return true;
}return false;
},
_onChangeSelection:function(){if(this.hasListener("changeValue")){this.fireDataEvent("changeValue",
this.getValue());
}},
_onKeyInput:function(a){if(!this.getEnableInlineFind()){return;
}var b=this.getSelectionMode();
if(!(b==="single"||b==="one")){return;
}if(((new Date).valueOf()-this._lastKeyPress)>1000){this._pressedString="";
}this._pressedString+=a.getChar();
var c=this.findItemByLabelFuzzy(this._pressedString);
if(c){this.select(c);
}this._lastKeyPress=(new Date).valueOf();
a.preventDefault();
},
findItemByLabelFuzzy:function(a){a=a.toLowerCase();
var b=this.getChildren();
for(var c=0,
d=b.length;c<d;c++){var e=b[c].getLabel();
if(e&&e.toLowerCase().indexOf(a)==0){return b[c];
}}return null;
},
findItem:function(a){a=a.toLowerCase();
var b=this.getChildren();
var c;
for(var d=0,
e=b.length;d<e;d++){c=b[d];
if(c.getFormValue().toLowerCase()==a){return c;
}}return null;
}},
destruct:function(){this._disposeObjects("__content");
}});
qx.Class.define("qx.ui.layout.Grid",
{extend:qx.ui.layout.Abstract,
construct:function(a,
b){arguments.callee.base.call(this);
this.__rowData=[];
this.__colData=[];
if(a){this.setSpacingX(a);
}
if(b){this.setSpacingY(b);
}},
properties:{spacingX:{check:"Integer",
init:0,
apply:"_applyLayoutChange"},
spacingY:{check:"Integer",
init:0,
apply:"_applyLayoutChange"}},
members:{verifyLayoutProperty:function(a,
b,
c){var d={"row":1,
"column":1,
"rowSpan":1,
"colSpan":1};
this.assert(d[b]==1,
"The property '"+b+"' is not supported by the grid layout!");
this.assertInteger(c);
this.assert(c>=0,
"Value must be positive");
},
__dW:function(){var a=[];
var b=[];
var c=[];
var d=0;
var e=0;
var f=this._getLayoutChildren();
for(var g=0,
h=f.length;g<h;g++){var j=f[g];
var k=j.getLayoutProperties();
var m=k.row;
var n=k.column;
k.colSpan=k.colSpan||1;
k.rowSpan=k.rowSpan||1;
if(m==null||n==null){throw new Error("The layout properties 'row' and 'column' must be defined!");
}
if(a[m]&&a[m][n]){throw new Error("There is already a widget in this cell ("+m+", "+n+")");
}
for(var o=n;o<n+k.colSpan;o++){for(var p=m;p<m+k.rowSpan;p++){if(a[p]==undefined){a[p]=[];
}a[p][o]=j;
e=Math.max(e,
o);
d=Math.max(d,
p);
}}
if(k.rowSpan>1){c.push(j);
}
if(k.colSpan>1){b.push(j);
}}for(var p=0;p<=d;p++){if(a[p]==undefined){a[p]=[];
}}this.__grid=a;
this.__colSpans=b;
this.__rowSpans=c;
this._maxRowIndex=d;
this._maxColIndex=e;
delete this._invalidChildrenCache;
},
_setRowData:function(a,
b,
c){var d=this.__rowData[a];
if(!d){this.__rowData[a]={};
this.__rowData[a][b]=c;
}else{d[b]=c;
}},
_setColumnData:function(a,
b,
c){var d=this.__colData[a];
if(!d){this.__colData[a]={};
this.__colData[a][b]=c;
}else{d[b]=c;
}},
setSpacing:function(a){this.setSpacingY(a);
this.setSpacingX(a);
},
setColumnAlign:function(a,
b,
c){{this.assertInArray(b,
["left",
"center",
"right"]);
this.assertInArray(c,
["top",
"middle",
"bottom"]);
};
this._setColumnData(a,
"hAlign",
b);
this._setColumnData(a,
"vAlign",
c);
this._applyLayoutChange();
return this;
},
getColumnAlign:function(a){var b=this.__colData[a]||{};
return {vAlign:b.vAlign||"top",
hAlign:b.hAlign||"left"};
},
setRowAlign:function(a,
b,
c){{this.assertInArray(b,
["left",
"center",
"right"]);
this.assertInArray(c,
["top",
"middle",
"bottom"]);
};
this._setRowData(a,
"hAlign",
b);
this._setRowData(a,
"vAlign",
c);
this._applyLayoutChange();
return this;
},
getRowAlign:function(a){var b=this.__rowData[a]||{};
return {vAlign:b.vAlign||"top",
hAlign:b.hAlign||"left"};
},
getCellWidget:function(a,
b){if(this._invalidChildrenCache){this.__dW();
}return this.__grid[a][b]||null;
},
getCellAlign:function(a,
b){var c="top";
var d="left";
var e=this.__rowData[a];
var f=this.__colData[b];
var g=this.__grid[a][b];
if(g){var h={vAlign:g.getAlignY(),
hAlign:g.getAlignX()};
}else{h={};
}if(h.vAlign){c=h.vAlign;
}else if(e&&e.vAlign){c=e.vAlign;
}else if(f&&f.vAlign){c=f.vAlign;
}if(h.hAlign){d=h.hAlign;
}else if(f&&f.hAlign){d=f.hAlign;
}else if(e&&e.hAlign){d=e.hAlign;
}return {vAlign:c,
hAlign:d};
},
setColumnFlex:function(a,
b){this._setColumnData(a,
"flex",
b);
this._applyLayoutChange();
return this;
},
getColumnFlex:function(a){var b=this.__colData[a]||{};
return b.flex!==undefined?b.flex:0;
},
setRowFlex:function(a,
b){this._setRowData(a,
"flex",
b);
this._applyLayoutChange();
return this;
},
getRowFlex:function(a){var b=this.__rowData[a]||{};
var c=b.flex!==undefined?b.flex:0;
return c;
},
setColumnMaxWidth:function(a,
b){this._setColumnData(a,
"maxWidth",
b);
this._applyLayoutChange();
return this;
},
getColumnMaxWidth:function(a){var b=this.__colData[a]||{};
return b.maxWidth!==undefined?b.maxWidth:Infinity;
},
setColumnWidth:function(a,
b){this._setColumnData(a,
"width",
b);
this._applyLayoutChange();
return this;
},
getColumnWidth:function(a){var b=this.__colData[a]||{};
return b.width!==undefined?b.width:null;
},
setColumnMinWidth:function(a,
b){this._setColumnData(a,
"minWidth",
b);
this._applyLayoutChange();
return this;
},
getColumnMinWidth:function(a){var b=this.__colData[a]||{};
return b.minWidth||0;
},
setRowMaxHeight:function(a,
b){this._setRowData(a,
"maxHeight",
b);
this._applyLayoutChange();
return this;
},
getRowMaxHeight:function(a){var b=this.__rowData[a]||{};
return b.maxHeight||Infinity;
},
setRowHeight:function(a,
b){this._setRowData(a,
"height",
b);
this._applyLayoutChange();
return this;
},
getRowHeight:function(a){var b=this.__rowData[a]||{};
return b.height!==undefined?b.height:null;
},
setRowMinHeight:function(a,
b){this._setRowData(a,
"minHeight",
b);
this._applyLayoutChange();
return this;
},
getRowMinHeight:function(a){var b=this.__rowData[a]||{};
return b.minHeight||0;
},
__dX:function(a){var b=a.getSizeHint();
var c=a.getMarginLeft()+a.getMarginRight();
var d=a.getMarginTop()+a.getMarginBottom();
var e={height:b.height+d,
width:b.width+c,
minHeight:b.minHeight+d,
minWidth:b.minWidth+c,
maxHeight:b.maxHeight+d,
maxWidth:b.maxWidth+c};
return e;
},
_fixHeightsRowSpan:function(a){var b=this.getSpacingY();
for(var c=0,
d=this.__rowSpans.length;c<d;c++){var e=this.__rowSpans[c];
var f=this.__dX(e);
var g=e.getLayoutProperties();
var h=g.row;
var k=b*(g.rowSpan-1);
var m=k;
var n={};
for(var o=0;o<g.rowSpan;o++){var p=g.row+o;
var q=a[p];
var r=this.getRowFlex(p);
if(r>0){n[p]={min:q.minHeight,
value:q.height,
max:q.maxHeight,
flex:r};
}k+=q.height;
m+=q.minHeight;
}if(k<f.height){var s=qx.ui.layout.Util.computeFlexOffsets(n,
f.height,
k);
for(var o=0;o<g.rowSpan;o++){var t=s[h+o]?s[h+o].offset:0;
a[h+o].height+=t;
}}if(m<f.minHeight){var s=qx.ui.layout.Util.computeFlexOffsets(n,
f.minHeight,
m);
for(var o=0;o<g.rowSpan;o++){var t=s[h+o]?s[h+o].offset:0;
a[h+o].minHeight+=t;
}}}},
_fixWidthsColSpan:function(a){var b=this.getSpacingX();
for(var c=0,
d=this.__colSpans.length;c<d;c++){var e=this.__colSpans[c];
var f=this.__dX(e);
var g=e.getLayoutProperties();
var h=g.column;
var k=b*(g.colSpan-1);
var m=k;
var n={};
var o;
for(var p=0;p<g.colSpan;p++){var q=g.column+p;
var r=a[q];
var s=this.getColumnFlex(q);
if(s>0){n[q]={min:r.minWidth,
value:r.width,
max:r.maxWidth,
flex:s};
}k+=r.width;
m+=r.minWidth;
}if(k<f.width){var t=qx.ui.layout.Util.computeFlexOffsets(n,
f.width,
k);
for(var p=0;p<g.colSpan;p++){o=t[h+p]?t[h+p].offset:0;
a[h+p].width+=o;
}}if(m<f.minWidth){var t=qx.ui.layout.Util.computeFlexOffsets(n,
f.minWidth,
m);
for(var p=0;p<g.colSpan;p++){o=t[h+p]?t[h+p].offset:0;
a[h+p].minWidth+=o;
}}}},
_getRowHeights:function(){if(this.__rowHeights!=null){return this.__rowHeights;
}var a=[];
var b=this._maxRowIndex;
var c=this._maxColIndex;
for(var d=0;d<=b;d++){var e=0;
var f=0;
var g=0;
for(var h=0;h<=c;h++){var i=this.__grid[d][h];
if(!i){continue;
}var j=i.getLayoutProperties().rowSpan||0;
if(j>1){continue;
}var k=this.__dX(i);
if(this.getRowFlex(d)>0){e=Math.max(e,
k.minHeight);
}else{e=Math.max(e,
k.height);
}f=Math.max(f,
k.height);
}var e=Math.max(e,
this.getRowMinHeight(d));
var g=this.getRowMaxHeight(d);
if(this.getRowHeight(d)!==null){var f=this.getRowHeight(d);
}else{var f=Math.max(e,
Math.min(f,
g));
}a[d]={minHeight:e,
height:f,
maxHeight:g};
}
if(this.__rowSpans.length>0){this._fixHeightsRowSpan(a);
}this.__rowHeights=a;
return a;
},
_getColWidths:function(){if(this.__colWidths!=null){return this.__colWidths;
}var a=[];
var b=this._maxColIndex;
var c=this._maxRowIndex;
for(var d=0;d<=b;d++){var e=0;
var f=0;
var g=Infinity;
for(var h=0;h<=c;h++){var i=this.__grid[h][d];
if(!i){continue;
}var j=i.getLayoutProperties().colSpan||0;
if(j>1){continue;
}var k=this.__dX(i);
if(this.getColumnFlex(d)>0){f=Math.max(f,
k.minWidth);
}else{f=Math.max(f,
k.width);
}e=Math.max(e,
k.width);
}var f=Math.max(f,
this.getColumnMinWidth(d));
var g=this.getColumnMaxWidth(d);
if(this.getColumnWidth(d)!==null){var e=this.getColumnWidth(d);
}else{var e=Math.max(f,
Math.min(e,
g));
}a[d]={minWidth:f,
width:e,
maxWidth:g};
}
if(this.__colSpans.length>0){this._fixWidthsColSpan(a);
}this.__colWidths=a;
return a;
},
_getColumnFlexOffsets:function(a){var b=this.getSizeHint();
var c=a-b.width;
if(c==0){return {};
}var d=this._getColWidths();
var e={};
for(var f=0,
g=d.length;f<g;f++){var h=d[f];
var j=this.getColumnFlex(f);
if((j<=0)||(h.width==h.maxWidth&&c>0)||(h.width==h.minWidth&&c<0)){continue;
}e[f]={min:h.minWidth,
value:h.width,
max:h.maxWidth,
flex:j};
}return qx.ui.layout.Util.computeFlexOffsets(e,
a,
b.width);
},
_getRowFlexOffsets:function(a){var b=this.getSizeHint();
var c=a-b.height;
if(c==0){return {};
}var d=this._getRowHeights();
var e={};
for(var f=0,
g=d.length;f<g;f++){var h=d[f];
var j=this.getRowFlex(f);
if((j<=0)||(h.height==h.maxHeight&&c>0)||(h.height==h.minHeight&&c<0)){continue;
}e[f]={min:h.minHeight,
value:h.height,
max:h.maxHeight,
flex:j};
}return qx.ui.layout.Util.computeFlexOffsets(e,
a,
b.height);
},
renderLayout:function(a,
b){if(this._invalidChildrenCache){this.__dW();
}var c=qx.ui.layout.Util;
var d=this.getSpacingX();
var e=this.getSpacingY();
var f=this._getColWidths();
var g=this._getColumnFlexOffsets(a);
var h=[];
var j=this._maxColIndex;
var k=this._maxRowIndex;
var l;
for(var m=0;m<=j;m++){l=g[m]?g[m].offset:0;
h[m]=f[m].width+l;
}var n=this._getRowHeights();
var o=this._getRowFlexOffsets(b);
var p=[];
for(var q=0;q<=k;q++){l=o[q]?o[q].offset:0;
p[q]=n[q].height+l;
}var r=0;
for(var m=0;m<=j;m++){var s=0;
for(var q=0;q<=k;q++){var t=this.__grid[q][m];
if(!t){s+=p[q]+e;
continue;
}var u=t.getLayoutProperties();
if(u.row!==q||u.column!==m){s+=p[q]+e;
continue;
}var v=d*(u.colSpan-1);
for(var w=0;w<u.colSpan;w++){v+=h[m+w];
}var x=e*(u.rowSpan-1);
for(var w=0;w<u.rowSpan;w++){x+=p[q+w];
}var y=t.getSizeHint();
var z=t.getMarginTop();
var A=t.getMarginLeft();
var B=t.getMarginBottom();
var C=t.getMarginRight();
var D=Math.max(y.minWidth,
Math.min(v-A-C,
y.maxWidth));
var E=Math.max(y.minHeight,
Math.min(x-z-B,
y.maxHeight));
var F=this.getCellAlign(q,
m);
var G=r+c.computeHorizontalAlignOffset(F.hAlign,
D,
v,
A,
C);
var H=s+c.computeVerticalAlignOffset(F.vAlign,
E,
x,
z,
B);
t.renderLayout(G,
H,
D,
E);
s+=p[q]+e;
}r+=h[m]+d;
}},
invalidateLayoutCache:function(){arguments.callee.base.call(this);
this.__colWidths=null;
this.__rowHeights=null;
},
_computeSizeHint:function(){if(this._invalidChildrenCache){this.__dW();
}var a=this._getColWidths();
var b=0,
c=0;
for(var d=0,
e=a.length;d<e;d++){var f=a[d];
if(this.getColumnFlex(d)>0){b+=f.minWidth;
}else{b+=f.width;
}c+=f.width;
}var g=this._getRowHeights();
var h=0,
j=0;
for(var d=0,
e=g.length;d<e;d++){var k=g[d];
if(this.getRowFlex(d)>0){h+=k.minHeight;
}else{h+=k.height;
}j+=k.height;
}var m=this.getSpacingX()*(a.length-1);
var n=this.getSpacingY()*(g.length-1);
var o={minWidth:b+m,
width:c+m,
minHeight:h+n,
height:j+n};
return o;
}},
destruct:function(){this._disposeFields("__grid",
"__rowData",
"__colData",
"__colSpans",
"__rowSpans");
}});
qx.Class.define("qx.ui.core.ScrollPane",
{extend:qx.ui.core.Widget,
construct:function(){arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.Grow());
this.addListener("resize",
this._onUpdate);
this._contentElement.addListener("scroll",
this._onScroll,
this);
this._contentElement.addListener("appear",
this._onAppear,
this);
},
events:{update:"qx.event.type.Event"},
properties:{scrollX:{check:"typeof value=='number'&&value>=0&&value<=this.getScrollMaxX()",
apply:"_applyScrollX",
event:"scrollX",
init:0},
scrollY:{check:"typeof value=='number'&&value>=0&&value<=this.getScrollMaxY()",
apply:"_applyScrollY",
event:"scrollY",
init:0}},
members:{add:function(a){var b=this._getChildren()[0];
if(b){this._remove(b);
b.removeListener("resize",
this._onUpdate,
this);
}
if(a){this._add(a);
a.addListener("resize",
this._onUpdate,
this);
}},
remove:function(a){if(a){this._remove(a);
a.removeListener("resize",
this._onUpdate,
this);
}},
getChild:function(){return this._getChildren()[0]||null;
},
_onUpdate:function(a){this.fireEvent("update");
},
_onScroll:function(a){var b=this._contentElement;
this.setScrollX(b.getScrollX());
this.setScrollY(b.getScrollY());
},
_onAppear:function(a){var b=this._contentElement;
var c=this.getScrollX();
var d=b.getScrollX();
if(c!=d){b.scrollToX(c);
}var f=this.getScrollY();
var g=b.getScrollY();
if(f!=g){b.scrollToY(f);
}},
getItemTop:function(a){var b=0;
do{b+=a.getBounds().top;
a=a.getLayoutParent();
}while(a&&a!==this);
return b;
},
getItemBottom:function(a){return this.getItemTop(a)+a.getBounds().height;
},
getItemLeft:function(a){var b=0;
var c;
do{b+=a.getBounds().left;
c=a.getLayoutParent();
if(c){b+=c.getInsets().left;
}a=c;
}while(a&&a!==this);
return b;
},
getItemRight:function(a){return this.getItemLeft(a)+a.getBounds().width;
},
getScrollSize:function(){return this.getChild().getBounds();
},
getScrollMaxX:function(){var a=this.getBounds();
var b=this.getScrollSize();
if(a&&b){return Math.max(0,
b.width-a.width);
}return 0;
},
getScrollMaxY:function(){var a=this.getBounds();
var b=this.getScrollSize();
if(a&&b){return Math.max(0,
b.height-a.height);
}return 0;
},
scrollToX:function(a){var b=this.getScrollMaxX();
if(a<0){a=0;
}else if(a>b){a=b;
}this.setScrollX(a);
},
scrollToY:function(a){var b=this.getScrollMaxY();
if(a<0){a=0;
}else if(a>b){a=b;
}this.setScrollY(a);
},
scrollByX:function(a){this.scrollToX(this.getScrollX()+a);
},
scrollByY:function(a){this.scrollToY(this.getScrollY()+a);
},
_applyScrollX:function(a){this._contentElement.scrollToX(a);
},
_applyScrollY:function(a){this._contentElement.scrollToY(a);
}}});
qx.Class.define("qx.ui.layout.Grow",
{extend:qx.ui.layout.Abstract,
members:{verifyLayoutProperty:function(a,
b,
c){this.assert(false,
"The property '"+b+"' is not supported by the atom layout!");
},
renderLayout:function(a,
b){var c=this._getLayoutChildren();
var d,
e,
f,
g;
for(var h=0,
j=c.length;h<j;h++){d=c[h];
e=d.getSizeHint();
f=a;
if(f<e.minWidth){f=e.minWidth;
}else if(f>e.maxWidth){f=e.maxWidth;
}g=b;
if(g<e.minHeight){g=e.minHeight;
}else if(g>e.maxHeight){g=e.maxHeight;
}d.renderLayout(0,
0,
f,
g);
}},
_computeSizeHint:function(){var a=this._getLayoutChildren();
var b,
c;
var d=0,
e=0;
for(var f=0,
g=a.length;f<g;f++){b=a[f];
c=b.getSizeHint();
d=Math.max(d,
c.width);
e=Math.max(e,
c.height);
}return {width:d,
height:e};
}}});
qx.Class.define("qx.ui.core.ScrollBar",
{extend:qx.ui.core.Widget,
construct:function(a){arguments.callee.base.call(this);
this._createChildControl("button-begin");
this._createChildControl("slider");
this._createChildControl("button-end");
if(a!=null){this.setOrientation(a);
}else{this.initOrientation();
}},
properties:{appearance:{refine:true,
init:"scrollbar"},
orientation:{check:["horizontal",
"vertical"],
init:"horizontal",
apply:"_applyOrientation"},
maximum:{check:"PositiveInteger",
apply:"_applyMaximum",
init:100},
position:{check:"typeof value==='number'&&value>=0&&value<=this.getMaximum()",
init:0,
apply:"_applyPosition",
event:"scroll"},
singleStep:{check:"Integer",
init:20},
pageStep:{check:"Integer",
init:10,
apply:"_applyPageStep"},
knobFactor:{check:"PositiveNumber",
apply:"_applyKnobFactor",
nullable:true}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "slider":b=new qx.ui.form.AbstractSlider;
b.setPageStep(100);
b.addListener("changeValue",
this._onChangeSliderValue,
this);
this._add(b,
{flex:1});
break;
case "button-begin":b=new qx.ui.form.RepeatButton;
b.setFocusable(false);
b.addListener("execute",
this._onExecuteBegin,
this);
this._add(b);
break;
case "button-end":b=new qx.ui.form.RepeatButton;
b.setFocusable(false);
b.addListener("execute",
this._onExecuteEnd,
this);
this._add(b);
break;
}return b||arguments.callee.base.call(this,
a);
},
_applyMaximum:function(a){this._getChildControl("slider").setMaximum(a);
},
_applyPosition:function(a){this._getChildControl("slider").setValue(a);
},
_applyKnobFactor:function(a){this._getChildControl("slider").setKnobFactor(a);
},
_applyPageStep:function(a){this._getChildControl("slider").setPageStep(a);
},
_applyOrientation:function(a,
b){var c=this._getLayout();
if(c){c.dispose();
}if(a==="horizontal"){this._setLayout(new qx.ui.layout.HBox());
this.setAllowStretchX(true);
this.setAllowStretchY(false);
this.replaceState("vertical",
"horizontal");
this._getChildControl("button-begin").replaceState("up",
"left");
this._getChildControl("button-end").replaceState("down",
"right");
}else{this._setLayout(new qx.ui.layout.VBox());
this.setAllowStretchX(false);
this.setAllowStretchY(true);
this.replaceState("horizontal",
"vertical");
this._getChildControl("button-begin").replaceState("left",
"up");
this._getChildControl("button-end").replaceState("right",
"down");
}this._getChildControl("slider").setOrientation(a);
},
scrollTo:function(a){this._getChildControl("slider").slideTo(a);
},
scrollBy:function(a){this._getChildControl("slider").slideBy(a);
},
scrollBySteps:function(a){var b=this.getSingleStep();
this._getChildControl("slider").slideBy(a*b);
},
_onExecuteBegin:function(a){this.scrollBy(-this.getSingleStep());
},
_onExecuteEnd:function(a){this.scrollBy(this.getSingleStep());
},
_onChangeSliderValue:function(a){this.setPosition(a.getData());
}}});
qx.Class.define("qx.ui.form.AbstractSlider",
{extend:qx.ui.core.Widget,
implement:qx.ui.form.IFormElement,
construct:function(a){arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.Canvas());
this.addListener("mousedown",
this._onMouseDown,
this);
this.addListener("mouseup",
this._onMouseUp,
this);
this.addListener("losecapture",
this._onMouseUp,
this);
this.addListener("resize",
this._onUpdate,
this);
if(a!=null){this.setOrientation(a);
}else{this.initOrientation();
}},
properties:{orientation:{check:["horizontal",
"vertical"],
init:"horizontal",
apply:"_applyOrientation"},
name:{check:"String",
nullable:true,
event:"changeName"},
value:{check:"typeof value==='number'&&value>=this.getMinimum()&&value<=this.getMaximum()",
init:0,
apply:"_applyValue",
event:"changeValue"},
minimum:{check:"Integer",
init:0,
apply:"_applyMinimum"},
maximum:{check:"Integer",
init:100,
apply:"_applyMaximum"},
singleStep:{check:"Integer",
init:1},
pageStep:{check:"Integer",
init:10},
knobFactor:{check:"Number",
apply:"_applyKnobFactor",
nullable:true}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "knob":b=new qx.ui.core.Widget().set({minWidth:4,
minHeight:4});
b.addListener("resize",
this._onUpdate,
this);
this._add(b);
break;
}return b||arguments.callee.base.call(this,
a);
},
_onMouseDown:function(a){var b=this.__dY;
var c=this._getChildControl("knob");
var d=b?"left":"top";
var f=b?"width":"height";
var g=b?a.getDocumentLeft():a.getDocumentTop();
var h=this.__sliderLocation=qx.bom.element.Location.get(this.getContentElement().getDomElement())[d];
var i=this.__knobLocation=qx.bom.element.Location.get(c.getContainerElement().getDomElement())[d];
if(a.getTarget()===c){this.__dragMode=true;
this.__dragOffset=g+h-i;
}else{this.__trackingMode=true;
this.__trackingDirection=g<=i?-1:1;
this.__eb(a);
this._onInterval();
if(!this.__timer){this.__timer=new qx.event.Timer(100);
this.__timer.addListener("interval",
this._onInterval,
this);
}this.__timer.start();
}this.addListener("mousemove",
this._onMouseMove);
this.capture();
a.stopPropagation();
},
_onMouseUp:function(a){if(this.__dragMode){this.releaseCapture();
delete this.__dragMode;
delete this.__dragOffset;
}else if(this.__trackingMode){this.__timer.stop();
this.releaseCapture();
delete this.__trackingMode;
delete this.__trackingDirection;
delete this.__trackingEnd;
}this.removeListener("mousemove",
this._onMouseMove);
if(a.getType()==="mouseup"){a.stopPropagation();
}},
_onMouseMove:function(a){if(this.__dragMode){var b=this.__dY?a.getDocumentLeft():a.getDocumentTop();
var c=b-this.__dragOffset;
this.slideTo(this._positionToValue(c));
}else if(this.__trackingMode){this.__eb(a);
}a.stopPropagation();
},
_onInterval:function(a){var b=this.getValue()+(this.__trackingDirection*this.getPageStep());
if(b<this.getMinimum()){b=this.getMinimum();
}else if(b>this.getMaximum()){b=this.getMaximum();
}var c=this.__trackingDirection==-1;
if((c&&b<=this.__trackingEnd)||(!c&&b>=this.__trackingEnd)){b=this.__trackingEnd;
}this.slideTo(b);
},
_onUpdate:function(a){var b=this.getInnerSize();
var c=this._getChildControl("knob").getBounds();
var d=this.__dY?"width":"height";
this._updateKnobSize();
this._updateKnobPosition();
this.__ea=b[d]-c[d];
this.__knobSize=c[d];
},
__dY:false,
__ea:0,
__eb:function(a){var b=this.__dY;
var c=b?a.getDocumentLeft():a.getDocumentTop();
var d=this.__sliderLocation;
var f=this.__knobLocation;
var g=this.__knobSize;
var h=c<=f;
var i=c-d;
if(c>=f){i-=g;
}var j=this._positionToValue(i);
var k=this.getMinimum();
var l=this.getMaximum();
if(j<k){j=k;
}else if(j>l){j=l;
}else{var m=this.getValue();
var n=this.getPageStep();
var o=this.__trackingDirection<0?"floor":"ceil";
j=m+(Math[o]((j-m)/n)*n);
}if(this.__trackingEnd==null||(this.__trackingDirection==-1&&j<=this.__trackingEnd)||(this.__trackingDirection==1&&j>=this.__trackingEnd)){this.__trackingEnd=j;
}},
_positionToValue:function(a){var b=this.__ea;
if(b==null||b==0){return 0;
}var c=a/b;
if(c<0){c=0;
}else if(c>1){c=1;
}var d=this.getMaximum()-this.getMinimum();
return this.getMinimum()+Math.round(d*c);
},
_valueToPosition:function(a){var b=this.__ea;
if(b==null){return 0;
}var c=this.getMaximum()-this.getMinimum();
if(c==0){return 0;
}var a=a-this.getMinimum();
var d=a/c;
if(d<0){d=0;
}else if(d>1){d=1;
}return Math.round(b*d);
},
_updateKnobPosition:function(){this._setKnobPosition(this._valueToPosition(this.getValue()));
},
_setKnobPosition:function(a){var b=this._getChildControl("knob").getContainerElement();
if(this.__dY){b.setStyle("left",
a+"px",
true);
}else{b.setStyle("top",
a+"px",
true);
}},
_updateKnobSize:function(){var a=this.getKnobFactor();
if(a==null){return;
}var b=this.getInnerSize();
if(b==null){return;
}if(this.__dY){this._getChildControl("knob").setWidth(Math.round(a*b.width));
}else{this._getChildControl("knob").setHeight(Math.round(a*b.height));
}},
slideToBegin:function(){this.slideTo(this.getMinimum());
},
slideToEnd:function(){this.slideTo(this.getMaximum());
},
slideForward:function(){this.slideBy(this.getSingleStep());
},
slideBack:function(){this.slideBy(-this.getSingleStep());
},
slidePageForward:function(){this.slideBy(this.getPageStep());
},
slidePageBack:function(){this.slideBy(-this.getPageStep());
},
slideBy:function(a){this.slideTo(this.getValue()+a);
},
slideTo:function(a){if(a<this.getMinimum()){a=this.getMinimum();
}else if(a>this.getMaximum()){a=this.getMaximum();
}else{a=this.getMinimum()+Math.round((a-this.getMinimum())/this.getSingleStep())*this.getSingleStep();
}this.setValue(a);
},
_applyOrientation:function(a,
b){var c=this._getChildControl("knob");
this.__dY=a==="horizontal";
if(this.__dY){this.removeState("vertical");
c.removeState("vertical");
this.addState("horizontal");
c.addState("horizontal");
c.setLayoutProperties({top:0,
right:null,
bottom:0});
}else{this.removeState("horizontal");
c.removeState("horizontal");
this.addState("vertical");
c.addState("vertical");
c.setLayoutProperties({right:0,
bottom:null,
left:0});
}this._updateKnobPosition();
},
_applyKnobFactor:function(a,
b){if(a!=null){this._updateKnobSize();
}else{if(this.__dY){this._getChildControl("knob").resetWidth();
}else{this._getChildControl("knob").resetHeight();
}}},
_applyValue:function(a,
b){this._updateKnobPosition();
},
_applyMinimum:function(a,
b){this._updateKnobPosition();
},
_applyMaximum:function(a,
b){this._updateKnobPosition();
}}});
qx.Class.define("qx.ui.layout.Canvas",
{extend:qx.ui.layout.Abstract,
members:{verifyLayoutProperty:function(a,
b,
c){var d={top:1,
left:1,
bottom:1,
right:1,
width:1,
height:1,
edge:1};
this.assert(d[b]==1,
"The property '"+b+"' is not supported by the canvas layout!");
if(b=="width"||b=="height"){this.assertMatch(c,
qx.ui.layout.Util.PERCENT_VALUE);
}else{if(typeof c==="number"){this.assertInteger(c);
}else if(typeof c=="string"){this.assertMatch(c,
qx.ui.layout.Util.PERCENT_VALUE);
}else{this.fail("Bad format of layout property '"+b+"': "+c+". The value must be either an integer or an percent string.");
}}},
renderLayout:function(a,
b){var c=this._getLayoutChildren();
var d,
e,
f;
var g,
h,
j,
k,
m,
n;
var o,
p,
q,
r;
for(var s=0,
t=c.length;s<t;s++){d=c[s];
e=d.getSizeHint();
f=d.getLayoutProperties();
o=d.getMarginTop();
p=d.getMarginRight();
q=d.getMarginBottom();
r=d.getMarginLeft();
g=f.left!=null?f.left:f.edge;
if(g&&typeof g==="string"){g=Math.round(parseFloat(g)*a/100);
}j=f.right!=null?f.right:f.edge;
if(j&&typeof j==="string"){j=Math.round(parseFloat(j)*a/100);
}h=f.top!=null?f.top:f.edge;
if(h&&typeof h==="string"){h=Math.round(parseFloat(h)*b/100);
}k=f.bottom!=null?f.bottom:f.edge;
if(k&&typeof k==="string"){k=Math.round(parseFloat(k)*b/100);
}if(g!=null&&j!=null){m=a-g-j-r-p;
if(m<e.minWidth){m=e.minWidth;
}else if(m>e.maxWidth){m=e.maxWidth;
}g+=r;
}else{m=f.width;
if(m==null){m=e.width;
}else{m=Math.round(parseFloat(m)*a/100);
if(m<e.minWidth){m=e.minWidth;
}else if(m>e.maxWidth){m=e.maxWidth;
}}
if(j!=null){g=a-m-j-p-r;
}else if(g==null){g=r;
}else{g+=r;
}}if(h!=null&&k!=null){n=b-h-k-o-q;
if(n<e.minHeight){n=e.minHeight;
}else if(m>e.maxHeight){n=e.maxHeight;
}h+=o;
}else{n=f.height;
if(n==null){n=e.height;
}else{n=Math.round(parseFloat(n)*b/100);
if(n<e.minHeight){n=e.minHeight;
}else if(m>e.maxHeight){n=e.maxHeight;
}}
if(k!=null){h=b-n-k-q-o;
}else if(h==null){h=o;
}else{h+=o;
}}d.renderLayout(g,
h,
m,
n);
}},
_computeSizeHint:function(){var a=0,
b=0;
var c=0,
d=0;
var e,
f;
var g,
h;
var j=this._getLayoutChildren();
var k,
m,
n;
var o,
p,
q,
r;
for(var s=0,
t=j.length;s<t;s++){k=j[s];
m=k.getLayoutProperties();
n=k.getSizeHint();
var u=k.getMarginLeft()+k.getMarginRight();
var v=k.getMarginTop()+k.getMarginBottom();
e=n.width+u;
f=n.minWidth+u;
o=m.left!=null?m.left:m.edge;
if(o&&typeof o==="number"){e+=o;
f+=o;
}q=m.right!=null?m.right:m.edge;
if(q&&typeof q==="number"){e+=q;
f+=q;
}a=Math.max(a,
e);
b=Math.max(b,
f);
g=n.height+v;
h=n.minHeight+v;
p=m.top!=null?m.top:m.edge;
if(p&&typeof p==="number"){g+=p;
h+=p;
}r=m.bottom!=null?m.bottom:m.edge;
if(r&&typeof r==="number"){g+=r;
h+=r;
}c=Math.max(c,
g);
d=Math.max(d,
h);
}return {width:a,
minWidth:b,
height:c,
minHeight:d};
}}});
qx.Class.define("qx.ui.form.RepeatButton",
{extend:qx.ui.form.Button,
construct:function(a,
b){arguments.callee.base.call(this,
a,
b);
this.__timer=new qx.event.Timer(this.getInterval());
this.__timer.addListener("interval",
this._onInterval,
this);
},
events:{"execute":"qx.event.type.Event",
"press":"qx.event.type.Event",
"release":"qx.event.type.Event"},
properties:{interval:{check:"Integer",
init:100},
firstInterval:{check:"Integer",
init:500},
minTimer:{check:"Integer",
init:20},
timerDecrease:{check:"Integer",
init:2}},
members:{press:function(){if(this.isEnabled()){if(!this.hasState("pressed")){this.__ec();
}this.removeState("abandoned");
this.addState("pressed");
}},
release:function(a){if(!this.isEnabled()){return;
}if(this.hasState("pressed")){if(!this.__executed){this.execute();
}}this.removeState("pressed");
this.removeState("abandoned");
this.__ed();
},
_applyEnabled:function(a,
b){arguments.callee.base.call(this,
a,
b);
if(!a){this.removeState("pressed");
this.removeState("abandoned");
this.__ed();
}},
_onMouseOver:function(a){if(!this.isEnabled()||a.getTarget()!==this){return;
}
if(this.hasState("abandoned")){this.removeState("abandoned");
this.addState("pressed");
this.__timer.start();
}this.addState("hovered");
},
_onMouseOut:function(a){if(!this.isEnabled()||a.getTarget()!==this){return;
}this.removeState("hovered");
if(this.hasState("pressed")){this.removeState("pressed");
this.addState("abandoned");
this.__timer.stop();
this._currentInterval=this.getInterval();
}},
_onMouseDown:function(a){if(!a.isLeftPressed()){return;
}this.capture();
this.__ec();
a.stopPropagation();
},
_onMouseUp:function(a){this.releaseCapture();
if(!this.hasState("abandoned")){this.addState("hovered");
if(this.hasState("pressed")&&!this.__executed){this.execute();
}}this.__ed();
a.stopPropagation();
},
_onKeyUp:function(a){switch(a.getKeyIdentifier()){case "Enter":case "Space":if(this.hasState("pressed")){if(!this.__executed){this.execute();
}this.removeState("pressed");
this.removeState("abandoned");
a.stopPropagation();
this.__ed();
}}},
_onKeyDown:function(a){switch(a.getKeyIdentifier()){case "Enter":case "Space":this.removeState("abandoned");
this.addState("pressed");
a.stopPropagation();
this.__ec();
}},
_onInterval:function(a){this.__timer.stop();
if(this._currentInterval==null){this._currentInterval=this.getInterval();
}this._currentInterval=(Math.max(this.getMinTimer(),
this._currentInterval-this.getTimerDecrease()));
this.__timer.restartWith(this._currentInterval);
this.__executed=true;
this.fireEvent("execute");
},
__ec:function(){this.fireEvent("press");
this.__executed=false;
this.__timer.setInterval(this.getFirstInterval());
this.__timer.start();
this.removeState("abandoned");
this.addState("pressed");
},
__ed:function(){this.fireEvent("release");
this.__timer.stop();
this._currentInterval=null;
this.removeState("abandoned");
this.removeState("pressed");
}},
destruct:function(){this._disposeObjects("__timer");
}});
qx.Class.define("qx.ui.popup.Popup",
{extend:qx.ui.container.Composite,
include:qx.ui.core.MAlign,
construct:function(a){arguments.callee.base.call(this,
a);
qx.core.Init.getApplication().getRoot().add(this);
},
properties:{appearance:{refine:true,
init:"popup"},
visibility:{refine:true,
init:"excluded"},
autoHide:{check:"Boolean",
init:true}},
members:{_applyVisibility:function(a,
b){arguments.callee.base.call(this,
a,
b);
var c=qx.ui.popup.Manager.getInstance();
a==="visible"?c.add(this):c.remove(this);
}},
destruct:function(){qx.ui.popup.Manager.getInstance().remove(this);
}});
qx.Class.define("qx.ui.popup.Manager",
{type:"singleton",
extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
this.__objects={};
var a=qx.core.Init.getApplication().getRoot();
a.addListener("mousedown",
this.__ef,
this,
true);
qx.bom.Element.addListener(window,
"blur",
this.hideAll,
this);
},
members:{add:function(a){{if(!(a instanceof qx.ui.popup.Popup)){throw new Error("Object is no popup: "+a);
}};
this.__objects[a.$$hash]=a;
this.__ee();
},
remove:function(a){{if(!(a instanceof qx.ui.popup.Popup)){throw new Error("Object is no popup: "+a);
}};
delete this.__objects[a.$$hash];
this.__ee();
},
hideAll:function(){var a=this.__objects;
for(var b in a){a[b].exclude();
}},
__ee:function(){var a=1e6;
var b=this.__objects;
for(var c in b){b[c].setZIndex(a++);
}},
__ef:function(a){var b=a.getTarget();
var c=this.__objects;
for(var d in c){obj=c[d];
if(!obj.getAutoHide()||b==obj||qx.ui.core.Widget.contains(obj,
b)){continue;
}obj.exclude();
}}},
destruct:function(){this._disposeMap("__objects");
}});
qx.Class.define("qx.ui.form.AbstractField",
{extend:qx.ui.core.Widget,
implement:qx.ui.form.IFormElement,
type:"abstract",
construct:function(a){arguments.callee.base.call(this);
if(a!=null){this.setValue(a);
}this._contentElement.addListener("change",
this._onChangeContent,
this);
},
events:{"input":"qx.event.type.Data",
"changeValue":"qx.event.type.Data"},
properties:{name:{check:"String",
nullable:true,
event:"changeName"},
textAlign:{check:["left",
"center",
"right"],
nullable:true,
themeable:true,
apply:"_applyTextAlign"},
readOnly:{check:"Boolean",
apply:"_applyReadOnly",
init:false},
selectable:{refine:true,
init:true},
focusable:{refine:true,
init:true}},
members:{getFocusElement:function(){return this._contentElement;
},
_createInputElement:function(){var a=new qx.html.Input("text");
a.setStyle("overflow",
"hidden");
return a;
},
_createContentElement:function(){var a=this._createInputElement();
a.setAttribute("spellcheck",
"false");
a.setStyles({"border":"none",
"padding":0,
"margin":0,
"background":"transparent",
"outline":"none",
"resize":"none",
"appearance":"none"});
return a;
},
_applyEnabled:function(a,
b){arguments.callee.base.call(this,
a,
b);
this._contentElement.setAttribute("disabled",
a===false);
},
_textSize:{width:16,
height:16},
_getContentHint:function(){return {width:this._textSize.width*10,
height:this._textSize.height||16};
},
_applyFont:function(a,
b){var c;
if(a){var d=qx.theme.manager.Font.getInstance().resolve(a);
c=d.getStyles();
}else{c=qx.bom.Font.getDefaultStyles();
}this._contentElement.setStyles(c);
if(a){this._textSize=qx.bom.Label.getTextSize("A",
c);
}else{delete this._textSize;
}qx.ui.core.queue.Layout.add(this);
},
_applyTextColor:function(a,
b){if(a){this.getContentElement().setStyle("color",
qx.theme.manager.Color.getInstance().resolve(a));
}else{this.getContentElement().removeStyle("color");
}},
tabFocus:function(){arguments.callee.base.call(this);
this.selectAll();
},
setValue:function(a){if(typeof a==="string"||a instanceof String){var b=this._contentElement;
if(b.getValue()!=a){b.setValue(a);
this.fireNonBubblingEvent("changeValue",
qx.event.type.Data,
[a]);
}return a;
}throw new Error("Invalid value type: "+a);
},
getValue:function(){return this._contentElement.getValue();
},
_onChangeContent:function(a){this.fireNonBubblingEvent("changeValue",
qx.event.type.Data,
[a.getData()]);
},
getSelection:function(){return this.getContentElement().getSelection();
},
getSelectionLength:function(){return this.getContentElement().getSelectionLength();
},
setSelection:function(a,
b){this.getContentElement().setSelection(a,
b);
},
clearSelection:function(){this.getContentElement().clearSelection();
},
selectAll:function(){this.setSelection(0);
},
_applyTextAlign:function(a,
b){this._contentElement.setStyle("textAlign",
a);
},
_applyReadOnly:function(a,
b){this._contentElement.setAttribute("readOnly",
a);
if(a){this.addState("readonly");
}else{this.removeState("readonly");
}}}});
qx.Class.define("qx.ui.form.TextField",
{extend:qx.ui.form.AbstractField,
properties:{maxLength:{check:"Integer",
apply:"_applyMaxLength",
nullable:true},
appearance:{refine:true,
init:"textfield"},
allowGrowY:{refine:true,
init:false},
allowShrinkY:{refine:true,
init:false}},
events:{"input":"qx.event.type.Data"},
members:{_createInputElement:function(){var a=new qx.html.Input("text");
a.addListener("input",
this._onHtmlInput,
this);
return a;
},
_onHtmlInput:function(a){this.fireDataEvent("input",
a.getData());
},
_applyMaxLength:function(a,
b){this._contentElement.setAttribute("maxLength",
a==null?"":a);
}}});
qx.Class.define("qx.html.Input",
{extend:qx.html.Element,
construct:function(a){arguments.callee.base.call(this);
this.__type=a;
if(a==="select"||a==="textarea"){this._nodeName=a;
}else{this._nodeName="input";
}},
members:{_createDomElement:function(){return qx.bom.Input.create(this.__type);
},
_applyProperty:function(a,
b){arguments.callee.base.call(this,
a,
b);
if(a==="value"){qx.bom.Input.setValue(this._element,
b);
}else if(a==="wrap"){qx.bom.Input.setWrap(this._element,
b);
}},
setValue:function(a){if(this._element){if(this._element.value!=a){qx.bom.Input.setValue(this._element,
a);
}}else{this._setProperty("value",
a);
}return this;
},
getValue:function(){if(this._element){return qx.bom.Input.getValue(this._element);
}return this._getProperty("value")||"";
},
setWrap:function(a){if(this.__type==="textarea"){this._setProperty("wrap",
a);
}else{throw new Error("Text wrapping is only support by textareas!");
}return this;
},
getWrap:function(){if(this.__type==="textarea"){return this._getProperty("wrap");
}else{throw new Error("Text wrapping is only support by textareas!");
}}}});
qx.Class.define("qx.event.handler.Input",
{extend:qx.core.Object,
implement:qx.event.IEventHandler,
construct:function(){arguments.callee.base.call(this);
this._onChangeCheckedWrapper=qx.lang.Function.listener(this._onChangeChecked,
this);
this._onChangeValueWrapper=qx.lang.Function.listener(this._onChangeValue,
this);
this._onInputWrapper=qx.lang.Function.listener(this._onInput,
this);
this._onPropertyWrapper=qx.lang.Function.listener(this._onProperty,
this);
},
statics:{PRIORITY:qx.event.Registration.PRIORITY_NORMAL,
SUPPORTED_TYPES:{input:1,
change:1},
TARGET_CHECK:qx.event.IEventHandler.TARGET_DOMNODE,
IGNORE_CAN_HANDLE:false},
members:{canHandleEvent:function(a,
b){var c=a.tagName.toLowerCase();
if(b==="input"&&(c==="input"||c==="textarea")){return true;
}
if(b==="change"&&(c==="input"||c==="textarea"||c==="select")){return true;
}return false;
},
registerEvent:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b,
c){if(!a.__inputHandlerAttached){var d=a.tagName.toLowerCase();
var b=a.type;
if(b==="text"||d==="textarea"||b==="checkbox"||b==="radio"){qx.bom.Event.addNativeListener(a,
"propertychange",
this._onPropertyWrapper);
}
if(b!=="checkbox"&&b!=="radio"){qx.bom.Event.addNativeListener(a,
"change",
this._onChangeValueWrapper);
}a.__inputHandlerAttached=true;
}},
"default":function(a,
b,
c){if(b==="input"){qx.bom.Event.addNativeListener(a,
"input",
this._onInputWrapper);
}else if(b==="change"){if(a.type==="radio"||a.type==="checkbox"){qx.bom.Event.addNativeListener(a,
"change",
this._onChangeCheckedWrapper);
}else{qx.bom.Event.addNativeListener(a,
"change",
this._onChangeValueWrapper);
}}}}),
unregisterEvent:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b){if(!a.__inputHandlerAttached){var c=a.tagName.toLowerCase();
var b=a.type;
if(b==="text"||c==="textarea"||b==="checkbox"||b==="radio"){qx.bom.Event.removeNativeListener(a,
"propertychange",
this._onPropertyWrapper);
}
if(b!=="checkbox"&&b!=="radio"){qx.bom.Event.removeNativeListener(a,
"change",
this._onChangeValueWrapper);
}delete a.__inputHandlerAttached;
}},
"default":function(a,
b){if(b==="input"){qx.bom.Event.removeNativeListener(a,
"input",
this._onInputWrapper);
}else if(b==="change"){if(a.type==="radio"||a.type==="checkbox"){qx.bom.Event.removeNativeListener(a,
"change",
this._onChangeCheckedWrapper);
}else{qx.bom.Event.removeNativeListener(a,
"change",
this._onChangeValueWrapper);
}}}}),
_onInput:function(a){var b=a.target;
qx.event.Registration.fireEvent(b,
"input",
qx.event.type.Data,
[b.value]);
},
_onChangeValue:function(a){var b=a.target||a.srcElement;
var c=b.value;
if(b.type==="select-multiple"){var c=[];
for(var d=0,
f=b.options,
g=f.length;d<g;d++){if(f[d].selected){c.push(f[d].value);
}}}qx.event.Registration.fireEvent(b,
"change",
qx.event.type.Data,
[c]);
},
_onChangeChecked:function(a){var b=a.target;
if(b.type==="radio"){if(b.checked){qx.event.Registration.fireEvent(b,
"change",
qx.event.type.Data,
[b.value]);
}}else{qx.event.Registration.fireEvent(b,
"change",
qx.event.type.Data,
[b.checked]);
}},
_onProperty:qx.core.Variant.select("qx.client",
{"mshtml":function(a){var b=a.target||a.srcElement;
var c=a.propertyName;
if(c==="value"&&(b.type==="text"||b.tagName.toLowerCase()==="textarea")){if(!b.__inValueSet){qx.event.Registration.fireEvent(b,
"input",
qx.event.type.Data,
[b.value]);
}}else if(c==="checked"){if(b.type==="checkbox"){qx.event.Registration.fireEvent(b,
"change",
qx.event.type.Data,
[b.checked]);
}else if(b.checked){qx.event.Registration.fireEvent(b,
"change",
qx.event.type.Data,
[b.value]);
}}},
"default":function(){}})},
defer:function(a){qx.event.Registration.addHandler(a);
}});
qx.Class.define("qx.bom.Input",
{statics:{__eg:{text:1,
textarea:1,
select:1,
checkbox:1,
radio:1,
password:1,
hidden:1,
submit:1,
image:1,
file:1,
search:1,
reset:1,
button:1},
create:function(a,
b,
c){{qx.core.Assert.assertKeyInMap(a,
this.__eg,
"Unsupported input type.");
};
var b=b?qx.lang.Object.copy(b):{};
var d;
if(a==="textarea"||a==="select"){d=a;
}else{d="input";
b.type=a;
}return qx.bom.Element.create(d,
b,
c);
},
setValue:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b){a.__inValueSet=true;
a.value=b;
a.__inValueSet=null;
},
"default":function(a,
b){a.value=b;
}}),
getValue:function(a){return a.value;
},
setWrap:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b){a.wrap=b?"soft":"off";
},
"gecko":function(a,
b){var c=b?"soft":"off";
var d=b?"":"auto";
a.setAttribute('wrap',
c);
a.style.overflow=d;
},
"default":function(a,
b){a.style.whiteSpace=b?"normal":"nowrap";
}})}});
qx.Class.define("qx.ui.form.ListItem",
{extend:qx.ui.basic.Atom,
construct:function(a,
b,
c){arguments.callee.base.call(this,
a,
b);
if(c!=null){this.setValue(c);
}},
events:{"action":"qx.event.type.Event"},
properties:{appearance:{refine:true,
init:"listitem"},
manager:{check:"qx.ui.form.RadioGroup",
nullable:true,
apply:"_applyManager"},
value:{check:"String",
nullable:true,
event:"changeValue"}},
members:{_applyManager:function(a,
b){if(b){b.remove(this);
}
if(a){a.add(this);
}},
getFormValue:function(){var a=this.getValue();
if(a==null){a=this.getLabel();
}return a;
}}});
qx.Class.define("qx.fx.effect.core.Highlight",
{extend:qx.fx.Base,
properties:{startColor:{init:"#ffffff",
check:"Color"},
endColor:{init:"#ffffaa",
check:"Color"},
restoreBackground:{init:true,
check:"Boolean"},
keepBackgroundImage:{init:false,
check:"Boolean"}},
members:{setup:function(){arguments.callee.base.call(this);
this._oldStyle={backgroundImage:qx.bom.element.Style.get(this._element,
"backgroundImage"),
backgroundColor:qx.bom.element.Style.get(this._element,
"backgroundColor")};
if(!this.getKeepBackgroundImage()){qx.bom.element.Style.set(this._element,
"backgroundImage",
"none");
}this._startColor=qx.util.ColorUtil.cssStringToRgb(this.getStartColor());
this._endColor=qx.util.ColorUtil.cssStringToRgb(this.getEndColor());
this._deltaColor=[this._endColor[0]-this._startColor[0],
this._endColor[1]-this._startColor[1],
this._endColor[2]-this._startColor[2]];
},
update:function(a){arguments.callee.base.call(this);
var b=[this._startColor[0]+Math.round(this._deltaColor[0]*a),
this._startColor[1]+Math.round(this._deltaColor[1]*a),
this._startColor[2]+Math.round(this._deltaColor[2]*a)];
var c="#"+qx.util.ColorUtil.rgbToHexString([b[0].toString(16),
b[1].toString(16),
b[2].toString(16)]);
qx.bom.element.Style.set(this._element,
"backgroundColor",
c);
},
finish:function(){arguments.callee.base.call(this);
if(this.getRestoreBackground()){qx.lang.Function.delay(this._restore,
1000,
this);
}},
_restore:function(){for(var a in this._oldStyle){qx.bom.element.Style.set(this._element,
a,
this._oldStyle[a]);
}}},
destruct:function(){this._disposeFields("_startColor",
"_endColor",
"_deltaColor");
}});
qx.Class.define("qx.fx.effect.combination.ColorFlow",
{extend:qx.fx.Base,
construct:function(a){arguments.callee.base.call(this,
a);
this._highlightEffects=[new qx.fx.effect.core.Highlight(this._element),
new qx.fx.effect.core.Highlight(this._element)];
},
properties:{startColor:{init:"#ffffff",
check:"Color"},
endColor:{init:"#ffffaa",
check:"Color"},
forwardTransition:{init:"linear",
check:["linear",
"easeInQuad",
"easeOutQuad",
"sinodial",
"reverse",
"flicker",
"wobble",
"pulse",
"spring",
"none",
"full"]},
backwardTransition:{init:"linear",
check:["linear",
"easeInQuad",
"easeOutQuad",
"sinodial",
"reverse",
"flicker",
"wobble",
"pulse",
"spring",
"none",
"full"]},
forwardDuration:{init:1.0,
check:"Number"},
backwardDuration:{init:1.0,
check:"Number"},
delayBetween:{init:0.3,
check:"Number"},
restoreBackground:{init:true,
check:"Boolean"},
keepBackgroundImage:{init:false,
check:"Boolean"}},
members:{start:function(){if(!arguments.callee.base.call(this)){return;
}this.setDuration(this.getForwardDuration()+this.getDelayBetween()+this.getBackwardDuration());
this._oldStyle={backgroundImage:qx.bom.element.Style.get(this._element,
"backgroundImage"),
backgroundColor:qx.bom.element.Style.get(this._element,
"backgroundColor")};
this._highlightEffects[0].set({startColor:this.getStartColor(),
endColor:this.getEndColor(),
duration:this.getForwardDuration(),
transition:this.getForwardTransition(),
restoreBackground:false,
keepBackgroundImage:this.getKeepBackgroundImage()});
this._highlightEffects[1].set({startColor:this.getEndColor(),
endColor:this.getStartColor(),
duration:this.getBackwardDuration(),
transition:this.getBackwardTransition(),
restoreBackground:this.getRestoreBackground(),
keepBackgroundImage:this.getKeepBackgroundImage(),
delay:this.getDelayBetween()});
var a=this;
this._highlightEffects[0].afterFinishInternal=function(){a._highlightEffects[1].start();
};
this._highlightEffects[0].start();
}},
destruct:function(){this._disposeArray("_highlightEffects");
this._disposeObjects("_mainEffect");
}});
qx.Class.define("qx.ui.form.ToggleButton",
{extend:qx.ui.basic.Atom,
implement:qx.ui.form.IFormElement,
construct:function(a,
b){arguments.callee.base.call(this,
a,
b);
this.addListener("mouseover",
this._onMouseOver);
this.addListener("mouseout",
this._onMouseOut);
this.addListener("mousedown",
this._onMouseDown);
this.addListener("mouseup",
this._onMouseUp);
this.addListener("keydown",
this._onKeyDown);
this.addListener("keyup",
this._onKeyUp);
},
properties:{appearance:{refine:true,
init:"button"},
checked:{check:"Boolean",
init:false,
apply:"_applyChecked",
event:"changeChecked"},
focusable:{refine:true,
init:true},
name:{check:"String",
nullable:true,
event:"changeName"},
value:{check:"String",
nullable:true,
event:"changeValue"}},
members:{_applyChecked:function(a,
b){a?this.addState("checked"):this.removeState("checked");
},
_onMouseOver:function(a){if(a.getTarget()!==this){return;
}this.addState("hovered");
if(this.hasState("abandoned")){this.removeState("abandoned");
this.addState("pressed");
}},
_onMouseOut:function(a){if(a.getTarget()!==this){return;
}this.removeState("hovered");
if(this.hasState("pressed")){if(!this.getChecked()){this.removeState("pressed");
}this.addState("abandoned");
}},
_onMouseDown:function(a){if(!a.isLeftPressed()){return;
}this.capture();
this.removeState("abandoned");
this.addState("pressed");
a.stopPropagation();
},
_onMouseUp:function(a){this.releaseCapture();
if(this.hasState("abandoned")){this.removeState("abandoned");
}else if(this.hasState("pressed")){this.toggleChecked();
}this.removeState("pressed");
a.stopPropagation();
},
_onKeyDown:function(a){switch(a.getKeyIdentifier()){case "Enter":case "Space":this.removeState("abandoned");
this.addState("pressed");
a.stopPropagation();
}},
_onKeyUp:function(a){if(!this.hasState("pressed")){return;
}
switch(a.getKeyIdentifier()){case "Enter":case "Space":this.removeState("abandoned");
this.toggleChecked();
a.stopPropagation();
}}}});
qx.Class.define("qx.ui.control.ColorSelector",
{extend:qx.ui.core.Widget,
construct:function(a,
b,
c){arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.VBox());
this.setDecorator("outset");
this._createChildControl("control-bar");
this._createChildControl("button-bar");
},
events:{"dialogok":"qx.event.type.Event",
"dialogcancel":"qx.event.type.Event"},
properties:{appearance:{refine:true,
init:"colorselector"},
red:{check:"Integer",
init:255,
apply:"_applyRed"},
green:{check:"Integer",
init:255,
apply:"_applyGreen"},
blue:{check:"Integer",
init:255,
apply:"_applyBlue"},
hue:{check:"Number",
init:0,
apply:"_applyHue"},
saturation:{check:"Number",
init:0,
apply:"_applySaturation"},
brightness:{check:"Number",
init:100,
apply:"_applyBrightness"}},
members:{_updateContext:null,
_createChildControlImpl:function(a){var b;
switch(a){case "control-bar":b=new qx.ui.container.Composite(new qx.ui.layout.HBox());
b.add(this._getChildControl("control-pane"));
b.add(this._getChildControl("hue-saturation-pane"));
b.add(this._getChildControl("brightness-pane"));
this._add(b);
break;
case "button-bar":b=new qx.ui.container.Composite(new qx.ui.layout.HBox(4,
"right"));
b.setPadding(2,
4);
this._add(b);
b.add(this._getChildControl("cancle-button"));
b.add(this._getChildControl("ok-button"));
break;
case "cancle-button":b=new qx.ui.form.Button(this.tr("Cancel"),
"icon/16/actions/dialog-cancel.png");
b.addListener("execute",
this._onButtonCancelExecute,
this);
break;
case "ok-button":b=new qx.ui.form.Button(this.tr("OK"),
"icon/16/actions/dialog-ok.png");
b.addListener("execute",
this._onButtonOkExecute,
this);
break;
case "control-pane":b=new qx.ui.container.Composite(new qx.ui.layout.VBox());
b.setPadding(4);
b.setPaddingBottom(7);
b.add(this._getChildControl("preset-field-set"));
b.add(this._getChildControl("input-field-set"));
b.add(this._getChildControl("preview-field-set"),
{flex:1});
break;
case "hue-saturation-pane":b=new qx.ui.container.Composite(new qx.ui.layout.Canvas());
b.setPadding(6,
4);
b.addListener("mousewheel",
this._onHueSaturationPaneMouseWheel,
this);
b.add(this._getChildControl("hue-saturation-field"));
b.add(this._getChildControl("hue-saturation-handle"),
{left:0,
top:256});
break;
case "hue-saturation-field":b=new qx.ui.basic.Image("decoration/colorselector/huesaturation-field.jpg");
b.setDecorator("inset-thin");
b.setMargin(5);
b.addListener("mousedown",
this._onHueSaturationFieldMouseDown,
this);
break;
case "hue-saturation-handle":b=new qx.ui.basic.Image("decoration/colorselector/huesaturation-handle.gif");
b.addListener("mousedown",
this._onHueSaturationHandleMouseDown,
this);
b.addListener("mouseup",
this._onHueSaturationHandleMouseUp,
this);
b.addListener("mousemove",
this._onHueSaturationHandleMouseMove,
this);
break;
case "brightness-pane":b=new qx.ui.container.Composite(new qx.ui.layout.Canvas());
b.setPadding(6,
4);
b.addListener("mousewheel",
this._onBrightnessPaneMouseWheel,
this);
b.add(this._getChildControl("brightness-field"));
b.add(this._getChildControl("brightness-handle"));
break;
case "brightness-field":b=new qx.ui.basic.Image("decoration/colorselector/brightness-field.jpg");
b.setDecorator("inset-thin");
b.setMargin(5,
7);
b.addListener("mousedown",
this._onBrightnessFieldMouseDown,
this);
break;
case "brightness-handle":b=new qx.ui.basic.Image("decoration/colorselector/brightness-handle.gif");
b.addListener("mousedown",
this._onBrightnessHandleMouseDown,
this);
b.addListener("mouseup",
this._onBrightnessHandleMouseUp,
this);
b.addListener("mousemove",
this._onBrightnessHandleMouseMove,
this);
break;
case "preset-field-set":b=new qx.ui.groupbox.GroupBox(this.tr("Presets"));
b.setLayout(new qx.ui.layout.Grow());
b.add(this._getChildControl("preset-grid"));
break;
case "preset-grid":f=new qx.ui.layout.Grid(2,
2);
b=new qx.ui.container.Composite(f);
for(var c=0;c<10;c++){f.setColumnWidth(c,
18);
}f.setRowHeight(0,
16);
f.setRowHeight(1,
16);
this._presetTable=["maroon",
"red",
"orange",
"yellow",
"olive",
"purple",
"fuchsia",
"lime",
"green",
"navy",
"blue",
"aqua",
"teal",
"black",
"#333",
"#666",
"#999",
"#BBB",
"#EEE",
"white"];
var d;
for(var c=0;c<2;c++){for(var e=0;e<10;e++){d=new qx.ui.core.Widget();
d.setDecorator("inset-thin");
d.setBackgroundColor(this._presetTable[c*10+e]);
d.addListener("mousedown",
this._onColorFieldClick,
this);
b.add(d,
{column:e,
row:c});
}}break;
case "input-field-set":b=new qx.ui.groupbox.GroupBox(this.tr("Details"));
var f=new qx.ui.layout.VBox();
f.setSpacing(10);
b.setLayout(f);
b.add(this._getChildControl("hex-field-composite"));
b.add(this._getChildControl("rgb-spinner-composite"));
b.add(this._getChildControl("hsb-spinner-composite"));
break;
case "preview-field-set":b=new qx.ui.groupbox.GroupBox(this.tr("Preview (Old/New)"));
var f=new qx.ui.layout.HBox();
f.setSpacing(10);
b.setLayout(f);
b.add(this._getChildControl("preview-content-old"),
{flex:1});
b.add(this._getChildControl("preview-content-new"),
{flex:1});
break;
case "hex-field-composite":b=new qx.ui.container.Composite(new qx.ui.layout.HBox(4));
var g=new qx.ui.basic.Label(this.tr("Hex"));
g.setWidth(25);
b.add(g);
var h=new qx.ui.basic.Label("#");
b.add(h);
b.add(this._getChildControl("hex-field"));
break;
case "hex-field":b=new qx.ui.form.TextField("FFFFFF");
b.setWidth(50);
b.addListener("changeValue",
this._onHexFieldChange,
this);
break;
case "rgb-spinner-composite":b=new qx.ui.container.Composite(new qx.ui.layout.HBox(4));
var k=new qx.ui.basic.Label(this.tr("RGB"));
k.setWidth(25);
b.add(k);
b.add(this._getChildControl("rgb-spinner-red"));
b.add(this._getChildControl("rgb-spinner-green"));
b.add(this._getChildControl("rgb-spinner-blue"));
break;
case "rgb-spinner-red":b=new qx.ui.form.Spinner(0,
255,
255);
b.setWidth(50);
b.addListener("change",
this._setRedFromSpinner,
this);
break;
case "rgb-spinner-green":b=new qx.ui.form.Spinner(0,
255,
255);
b.setWidth(50);
b.addListener("change",
this._setGreenFromSpinner,
this);
break;
case "rgb-spinner-blue":b=new qx.ui.form.Spinner(0,
255,
255);
b.setWidth(50);
b.addListener("change",
this._setBlueFromSpinner,
this);
break;
case "hsb-spinner-composite":b=new qx.ui.container.Composite(new qx.ui.layout.HBox(4));
var l=new qx.ui.basic.Label(this.tr("HSB"));
l.setWidth(25);
b.add(l);
b.add(this._getChildControl("hsb-spinner-hue"));
b.add(this._getChildControl("hsb-spinner-saturation"));
b.add(this._getChildControl("hsb-spinner-brightness"));
break;
case "hsb-spinner-hue":b=new qx.ui.form.Spinner(0,
0,
360);
b.setWidth(50);
b.addListener("change",
this._setHueFromSpinner,
this);
break;
case "hsb-spinner-saturation":b=new qx.ui.form.Spinner(0,
0,
100);
b.setWidth(50);
b.addListener("change",
this._setSaturationFromSpinner,
this);
break;
case "hsb-spinner-brightness":b=new qx.ui.form.Spinner(0,
100,
100);
b.setWidth(50);
b.addListener("change",
this._setBrightnessFromSpinner,
this);
break;
case "preview-content-old":b=new qx.ui.core.Widget();
b.setDecorator("inset-thin");
break;
case "preview-content-new":b=new qx.ui.core.Widget();
b.setDecorator("inset-thin");
b.setBackgroundColor("white");
break;
}return b||arguments.callee.base.call(this,
a);
},
_applyRed:function(a,
b){if(this._updateContext===null){this._updateContext="redModifier";
}
if(this._updateContext!=="rgbSpinner"){this._getChildControl("rgb-spinner-red").setValue(a);
}
if(this._updateContext!=="hexField"){this._setHexFromRgb();
}
switch(this._updateContext){case "rgbSpinner":case "hexField":case "redModifier":this._setHueFromRgb();
}this._setPreviewFromRgb();
if(this._updateContext==="redModifier"){this._updateContext=null;
}},
_applyGreen:function(a,
b){if(this._updateContext===null){this._updateContext="greenModifier";
}
if(this._updateContext!=="rgbSpinner"){this._getChildControl("rgb-spinner-green").setValue(a);
}
if(this._updateContext!=="hexField"){this._setHexFromRgb();
}
switch(this._updateContext){case "rgbSpinner":case "hexField":case "greenModifier":this._setHueFromRgb();
}this._setPreviewFromRgb();
if(this._updateContext==="greenModifier"){this._updateContext=null;
}},
_applyBlue:function(a,
b){if(this._updateContext===null){this._updateContext="blueModifier";
}
if(this._updateContext!=="rgbSpinner"){this._getChildControl("rgb-spinner-blue").setValue(a);
}
if(this._updateContext!=="hexField"){this._setHexFromRgb();
}
switch(this._updateContext){case "rgbSpinner":case "hexField":case "blueModifier":this._setHueFromRgb();
}this._setPreviewFromRgb();
if(this._updateContext==="blueModifier"){this._updateContext=null;
}},
_applyHue:function(a,
b){if(this._updateContext===null){this._updateContext="hueModifier";
}
if(this._updateContext!=="hsbSpinner"){this._getChildControl("hsb-spinner-hue").setValue(a);
}
if(this._updateContext!=="hueSaturationField"){if(this._getChildControl("hue-saturation-handle").getBounds()){this._getChildControl("hue-saturation-handle").setDomLeft(Math.round(a/1.40625)+this._getChildControl("hue-saturation-pane").getPaddingLeft());
}else{this._getChildControl("hue-saturation-handle").setLeft(Math.round(a/1.40625));
}}
switch(this._updateContext){case "hsbSpinner":case "hueSaturationField":case "hueModifier":this._setRgbFromHue();
}
if(this._updateContext==="hueModifier"){this._updateContext=null;
}},
_applySaturation:function(a,
b){if(this._updateContext===null){this._updateContext="saturationModifier";
}
if(this._updateContext!=="hsbSpinner"){this._getChildControl("hsb-spinner-saturation").setValue(a);
}
if(this._updateContext!=="hueSaturationField"){if(this._getChildControl("hue-saturation-handle").getBounds()){this._getChildControl("hue-saturation-handle").setDomTop(256-Math.round(a*2.56)+this._getChildControl("hue-saturation-pane").getPaddingTop());
}else{this._getChildControl("hue-saturation-handle").setTop(256-Math.round(a*2.56));
}}
switch(this._updateContext){case "hsbSpinner":case "hueSaturationField":case "saturationModifier":this._setRgbFromHue();
}
if(this._updateContext==="saturationModifier"){this._updateContext=null;
}},
_applyBrightness:function(a,
b){if(this._updateContext===null){this._updateContext="brightnessModifier";
}
if(this._updateContext!=="hsbSpinner"){this._getChildControl("hsb-spinner-brightness").setValue(a);
}
if(this._updateContext!=="brightnessField"){var c=256-Math.round(a*2.56);
if(this._getChildControl("brightness-handle").getBounds()){this._getChildControl("brightness-handle").setDomTop(c+this._getChildControl("brightness-pane").getPaddingTop());
}else{this._getChildControl("brightness-handle").setTop(c);
}}
switch(this._updateContext){case "hsbSpinner":case "brightnessField":case "brightnessModifier":this._setRgbFromHue();
}
if(this._updateContext==="brightnessModifier"){this._updateContext=null;
}},
_onBrightnessHandleMouseDown:function(a){this._getChildControl("brightness-handle").capture();
this._capture="brightness-handle";
var b=this._getChildControl("brightness-field").getContainerLocation();
var c=this._getChildControl("brightness-handle").getContainerLocation();
this._brightnessSubtract=b.top+(a.getDocumentTop()-c.top);
a.stopPropagation();
},
_onBrightnessHandleMouseUp:function(a){this._getChildControl("brightness-handle").releaseCapture();
this._capture=null;
},
_onBrightnessHandleMouseMove:function(a){if(this._capture==="brightness-handle"){this._setBrightnessOnFieldEvent(a);
}},
_onBrightnessFieldMouseDown:function(a){var b=this._getChildControl("brightness-field").getContainerLocation();
var c=this._getChildControl("brightness-handle").getBounds();
this._brightnessSubtract=b.top+(c.height/2);
this._setBrightnessOnFieldEvent(a);
this._getChildControl("brightness-handle").capture();
this._capture="brightness-handle";
},
_onBrightnessPaneMouseWheel:function(a){this.setBrightness(qx.lang.Number.limit(this.getBrightness()+a.getWheelDelta(),
0,
100));
},
_setBrightnessOnFieldEvent:function(a){var b=qx.lang.Number.limit(a.getDocumentTop()-this._brightnessSubtract,
0,
256);
this._updateContext="brightnessField";
if(this._getChildControl("brightness-handle").getBounds()){this._getChildControl("brightness-handle").setDomTop(b+this._getChildControl("brightness-pane").getPaddingTop());
}else{this._getChildControl("brightness-handle").setTop(b);
}this.setBrightness(100-Math.round(b/2.56));
this._updateContext=null;
},
_onButtonOkExecute:function(a){this.fireEvent("dialogok");
},
_onButtonCancelExecute:function(a){this.fireEvent("dialogcancel");
},
_onHueSaturationHandleMouseDown:function(a){this._getChildControl("hue-saturation-handle").capture();
this._capture="hue-saturation-handle";
var b=this._getChildControl("hue-saturation-field").getContainerLocation();
var c=this._getChildControl("hue-saturation-handle").getBounds();
this._hueSaturationSubtractTop=b.top+(a.getDocumentTop()-c.top);
this._hueSaturationSubtractLeft=b.left+(a.getDocumentLeft()-c.left);
a.stopPropagation();
},
_onHueSaturationHandleMouseUp:function(a){this._getChildControl("hue-saturation-handle").releaseCapture();
this._capture=null;
},
_onHueSaturationHandleMouseMove:function(a){if(this._capture==="hue-saturation-handle"){this._setHueSaturationOnFieldEvent(a);
}},
_onHueSaturationFieldMouseDown:function(a){var b=this._getChildControl("hue-saturation-field").getContainerLocation();
var c=this._getChildControl("hue-saturation-handle").getBounds();
this._hueSaturationSubtractTop=b.top+(c.height/2);
this._hueSaturationSubtractLeft=b.left+(c.width/2);
this._setHueSaturationOnFieldEvent(a);
this._getChildControl("hue-saturation-handle").capture();
this._capture="hue-saturation-handle";
},
_onHueSaturationPaneMouseWheel:function(a){this.setSaturation(qx.lang.Number.limit(this.getSaturation()+a.getWheelDelta(),
0,
100));
},
_setHueSaturationOnFieldEvent:function(a){var b=qx.lang.Number.limit(a.getDocumentTop()-this._hueSaturationSubtractTop,
0,
256);
var c=qx.lang.Number.limit(a.getDocumentLeft()-this._hueSaturationSubtractLeft,
0,
256);
if(this._getChildControl("hue-saturation-handle").getBounds()){this._getChildControl("hue-saturation-handle").setDomPosition(c,
b);
}else{this._getChildControl("hue-saturation-handle").setLayoutProperties({top:b,
left:c});
}this._updateContext="hueSaturationField";
this.setSaturation(100-Math.round(b/2.56));
this.setHue(Math.round(c*1.40625));
this._updateContext=null;
},
_setRedFromSpinner:function(){if(this._updateContext!==null){return;
}this._updateContext="rgbSpinner";
this.setRed(this._rgbSpinRed.getValue());
this._updateContext=null;
},
_setGreenFromSpinner:function(){if(this._updateContext!==null){return;
}this._updateContext="rgbSpinner";
this.setGreen(this._rgbSpinGreen.getValue());
this._updateContext=null;
},
_setBlueFromSpinner:function(){if(this._updateContext!==null){return;
}this._updateContext="rgbSpinner";
this.setBlue(this._rgbSpinBlue.getValue());
this._updateContext=null;
},
_setHueFromSpinner:function(){if(this._updateContext!==null){return;
}this._updateContext="hsbSpinner";
this.setHue(this._hsbSpinHue.getValue());
this._updateContext=null;
},
_setSaturationFromSpinner:function(){if(this._updateContext!==null){return;
}this._updateContext="hsbSpinner";
this.setSaturation(this._hsbSpinSaturation.getValue());
this._updateContext=null;
},
_setBrightnessFromSpinner:function(){if(this._updateContext!==null){return;
}this._updateContext="hsbSpinner";
this.setBrightness(this._hsbSpinBrightness.getValue());
this._updateContext=null;
},
_onHexFieldChange:function(a){if(this._updateContext!==null){return;
}
try{var b=qx.util.ColorUtil.hexStringToRgb("#"+this._hexField.getValue());
}catch(ex){return;
}this._updateContext="hexField";
this.setRed(b[0]);
this.setGreen(b[1]);
this.setBlue(b[2]);
this._updateContext=null;
},
_setHexFromRgb:function(){this._getChildControl("hex-field").setValue(qx.util.ColorUtil.rgbToHexString([this.getRed(),
this.getGreen(),
this.getBlue()]));
},
_onColorFieldClick:function(a){var b=a.getTarget().getBackgroundColor();
if(!b){return this.error("Missing backgroundColor value for field: "+a.getTarget());
}var c=qx.util.ColorUtil.stringToRgb(b);
this.setRed(c[0]);
this.setGreen(c[1]);
this.setBlue(c[2]);
},
_setHueFromRgb:function(){switch(this._updateContext){case "hsbSpinner":case "hueSaturationField":case "brightnessField":break;
default:var a=qx.util.ColorUtil.rgbToHsb([this.getRed(),
this.getGreen(),
this.getBlue()]);
this.setHue(a[0]);
this.setSaturation(a[1]);
this.setBrightness(a[2]);
}},
_setRgbFromHue:function(){switch(this._updateContext){case "rgbSpinner":case "hexField":break;
default:var a=qx.util.ColorUtil.hsbToRgb([this.getHue(),
this.getSaturation(),
this.getBrightness()]);
this.setRed(a.red);
this.setGreen(a.green);
this.setBlue(a.blue);
}},
_setPreviewFromRgb:function(){this._getChildControl("preview-content-new").setBackgroundColor(qx.util.ColorUtil.rgbToRgbString([this.getRed(),
this.getGreen(),
this.getBlue()]));
},
setPreviousColor:function(a,
b,
c){this._oldColorPreview.setBackgroundImage(null);
this._oldColorPreview.setBackgroundColor(qx.util.ColorUtil.rgbToRgbString([a,
b,
c]));
this.setRed(a);
this.setGreen(b);
this.setBlue(c);
}},
destruct:function(){this._disposeObjects("_controlBar",
"_btnbar",
"_btncancel",
"_btnok",
"_controlPane",
"_hueSaturationPane",
"_hueSaturationField",
"_hueSaturationHandle",
"_brightnessPane",
"_brightnessField",
"_brightnessHandle",
"_presetFieldSet",
"_presetGrid",
"_inputFieldSet",
"_inputLayout",
"_previewFieldSet",
"_previewLayout",
"_hexLayout",
"_hexLabel",
"_hexHelper",
"_hexField",
"_rgbSpinLayout",
"_rgbSpinLabel",
"_rgbSpinRed",
"_rgbSpinGreen",
"_rgbSpinBlue",
"_hsbSpinLayout",
"_hsbSpinLabel",
"_hsbSpinHue",
"_hsbSpinSaturation",
"_hsbSpinBrightness",
"_oldColorPreview",
"_newColorPreview");
this._disposeFields("_presetTable");
}});
qx.Mixin.define("qx.ui.core.MRemoteLayoutHandling",
{members:{setLayout:function(a){return this.getChildrenContainer().setLayout(a);
},
getLayout:function(){return this.getChildrenContainer().getLayout();
}}});
qx.Class.define("qx.ui.groupbox.GroupBox",
{extend:qx.ui.core.Widget,
include:[qx.ui.core.MRemoteChildrenHandling,
qx.ui.core.MRemoteLayoutHandling],
construct:function(a,
b){arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.Canvas);
this._createChildControl("frame");
this._createChildControl("legend");
if(a!=null){this.setLegend(a);
}
if(b!=null){this.setIcon(b);
}},
properties:{appearance:{refine:true,
init:"groupbox"},
legendPosition:{check:["top",
"middle"],
init:"middle",
apply:"_applyLegendPosition",
themeable:true}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "frame":b=new qx.ui.container.Composite();
this._add(b,
{left:0,
top:6,
right:0,
bottom:0});
break;
case "legend":b=new qx.ui.basic.Atom();
b.addListener("resize",
this._repositionFrame,
this);
this._add(b);
break;
}return b||arguments.callee.base.call(this,
a);
},
_getStyleTarget:function(){return this._getChildControl("frame");
},
_applyLegendPosition:function(a){if(this._getChildControl("legend").getBounds()){this._repositionFrame();
}},
_repositionFrame:function(){var a=this._getChildControl("legend");
var b=this._getChildControl("frame");
var c=a.getBounds().height;
if(this.getLegendPosition()=="middle"){b.setLayoutProperties({"top":Math.round(c/2)});
}else if(this.getLegendPosition()=="top"){b.setLayoutProperties({"top":c});
}},
getChildrenContainer:function(){return this._getChildControl("frame");
},
setLegend:function(a){var b=this._getChildControl("legend");
if(a!==null){b.setLabel(a);
b.show();
}else{b.exclude();
}},
getLegend:function(){return this._getChildControl("legend").getLabel();
},
setIcon:function(a){this._getChildControl("legend").setIcon(a);
},
getIcon:function(){this._getChildControl("legend").getIcon();
}}});
qx.Class.define("qx.ui.form.Spinner",
{extend:qx.ui.core.Widget,
implement:qx.ui.form.IFormElement,
construct:function(a,
b,
c){arguments.callee.base.call(this);
var d=new qx.ui.layout.Grid();
d.setColumnFlex(0,
1);
d.setRowFlex(0,
1);
d.setRowFlex(1,
1);
this._setLayout(d);
this.addListener("keydown",
this._onKeyDown,
this);
this.addListener("keyup",
this._onKeyUp,
this);
this.addListener("mousewheel",
this._onMouseWheel,
this);
this._createChildControl("textfield");
this._createChildControl("upbutton");
this._createChildControl("downbutton");
if(a!=null){this.setMin(a);
}
if(c!=null){this.setMax(c);
}
if(b!=null){this.setValue(b);
}else{this.initValue();
}},
properties:{appearance:{refine:true,
init:"spinner"},
focusable:{refine:true,
init:true},
singleStep:{check:"Number",
init:1},
pageStep:{check:"Number",
init:10},
min:{check:"Number",
apply:"_applyMin",
init:0},
name:{check:"String",
nullable:true,
event:"changeName"},
value:{check:"typeof value==='number'&&value>=this.getMin()&&value<=this.getMax()",
apply:"_applyValue",
init:0,
event:"changeValue"},
max:{check:"Number",
apply:"_applyMax",
init:100},
wrap:{check:"Boolean",
init:false,
apply:"_applyWrap"},
editable:{check:"Boolean",
init:true,
apply:"_applyEditable"},
numberFormat:{check:"qx.util.format.NumberFormat",
apply:"_applyNumberFormat",
nullable:true},
allowShrinkY:{refine:true,
init:false}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "textfield":b=new qx.ui.form.TextField();
b.addState("inner");
b.setWidth(40);
b.setFocusable(false);
b.addListener("changeValue",
this._onTextChange,
this);
this._add(b,
{column:0,
row:0,
rowSpan:2});
break;
case "upbutton":b=new qx.ui.form.RepeatButton();
b.addState("inner");
b.setFocusable(false);
b.addListener("execute",
this._countUp,
this);
this._add(b,
{column:1,
row:0});
break;
case "downbutton":b=new qx.ui.form.RepeatButton();
b.addState("inner");
b.setFocusable(false);
b.addListener("execute",
this._countDown,
this);
this._add(b,
{column:1,
row:1});
break;
}return b||arguments.callee.base.call(this,
a);
},
_forwardStates:{focused:true},
_getStyleTarget:function(){return this._getChildControl("textfield");
},
tabFocus:function(){this._getChildControl("textfield").getFocusElement().focus();
},
_applyMin:function(a,
b){this.setMax(Math.max(this.getMax(),
a));
this.setValue(Math.max(this.getValue(),
a));
},
_applyMax:function(a,
b){this.setMin(Math.min(this.getMin(),
a));
this.setValue(Math.min(this.getValue(),
a));
},
_applyValue:function(a,
b){var c=this._getChildControl("upbutton");
var d=this._getChildControl("downbutton");
var e=this._getChildControl("textfield");
if(a<this.getMax()){if(this.getEnabled()){c.resetEnabled();
}}else{if(!this.getWrap()){c.setEnabled(false);
}}if(a>this.getMin()){if(this.getEnabled()){d.resetEnabled();
}}else{if(!this.getWrap()){d.setEnabled(false);
}}this._lastValidValue=a;
if(this.getNumberFormat()){e.setValue(this.getNumberFormat().format(a));
}else{e.setValue(a+"");
}},
_applyEditable:function(a,
b){var c=this._getChildControl("textfield");
if(c){c.setReadOnly(!a);
}},
_applyWrap:function(a,
b){if(a){var c=this._getChildControl("upbutton");
var d=this._getChildControl("downbutton");
if(this.getEnabled()){c.setEnabled(true);
d.setEnabled(true);
}}},
_applyNumberFormat:function(a,
b){this._getChildControl("textfield").setValue(this.getNumberFormat().format(this._lastValidValue));
},
_onKeyDown:function(a){switch(a.getKeyIdentifier()){case "PageUp":this._pageUpMode=true;
case "Up":this._getChildControl("upbutton").press();
break;
case "PageDown":this._pageDownMode=true;
case "Down":this._getChildControl("downbutton").press();
break;
default:return ;
}a.stopPropagation();
a.preventDefault();
},
_onKeyUp:function(a){switch(a.getKeyIdentifier()){case "PageUp":this._getChildControl("upbutton").release();
this._pageUpMode=false;
break;
case "Up":this._getChildControl("upbutton").release();
break;
case "PageDown":this._getChildControl("downbutton").release();
this._pageDownMode=false;
break;
case "Down":this._getChildControl("downbutton").release();
break;
}},
_onMouseWheel:function(a){var b=a.getWheelDelta()>0?1:-1;
this.gotoValue(this.getValue()+(b*this.getSingleStep()));
a.stopPropagation();
},
_onTextChange:function(a){var b=this._getChildControl("textfield");
if(this.getNumberFormat()){try{var c=this.getNumberFormat().parse(b.getValue());
this.gotoValue(c);
return;
}catch(a){}}var c=parseFloat(b.getValue(),
10);
if(!isNaN(c)){if(c>this.getMax()){c=this.getMax();
}else if(c<this.getMin()){c=this.getMin();
}if(c==this.getValue()){b.setValue(c+"");
}else{this.setValue(c);
}}else{b.setValue(this._lastValidValue+"");
}},
_countUp:function(){if(this._pageUpMode){var a=this.getValue()+this.getPageStep();
}else{var a=this.getValue()+this.getSingleStep();
}if(this.getWrap()){if(a>this.getMax()){var b=this.getMax()-a;
a=this.getMin()+b;
}}this.gotoValue(a);
},
_countDown:function(){if(this._pageDownMode){var a=this.getValue()-this.getPageStep();
}else{var a=this.getValue()-this.getSingleStep();
}if(this.getWrap()){if(a<this.getMin()){var b=this.getMin()+a;
a=this.getMax()-b;
}}this.gotoValue(a);
},
gotoValue:function(a){return this.setValue(Math.min(this.getMax(),
Math.max(this.getMin(),
a)));
}}});
qx.Mixin.define("qx.ui.core.MResizable",
{construct:function(){this.addListener("mousedown",
this.__em,
this,
true);
this.addListener("mouseup",
this.__en,
this);
this.addListener("mousemove",
this.__ep,
this);
this.addListener("mouseout",
this.__eq,
this);
this.addListener("losecapture",
this.__eo,
this);
},
properties:{resizable:{check:"Boolean",
init:true},
resizeAllEdges:{check:"Boolean",
init:true},
resizeSensitivity:{check:"Integer",
init:5},
useResizeFrame:{check:"Boolean",
init:true}},
members:{__eh:function(){var a=this.__resizeFrame;
if(!a){a=this.__resizeFrame=new qx.ui.core.Widget();
a.setAppearance("resize-frame");
a.exclude();
qx.core.Init.getApplication().getRoot().add(a);
}return a;
},
__ei:function(){var a=this.getBounds();
var b=this.__eh();
b.setUserBounds(a.left,
a.top,
a.width,
a.height);
b.show();
b.setZIndex(this.getZIndex()+1);
},
__ej:function(a){var b=this._resizeActive;
var c=this.getSizeHint();
var d=this.__resizeStart;
var f=d.width;
var g=d.height;
var h=d.left;
var i=d.top;
if(b&1||b&2){var j=a.getDocumentTop()-this.__resizeTop;
if(b&1){g-=j;
}else{g+=j;
}
if(g<c.minHeight){g=c.minHeight;
}else if(g>c.maxHeight){g=c.maxHeight;
}
if(b&1){i+=d.height-g;
}}if(b&4||b&8){var j=a.getDocumentLeft()-this.__resizeLeft;
if(b&4){f-=j;
}else{f+=j;
}
if(f<c.minWidth){f=c.minWidth;
}else if(f>c.maxWidth){f=c.maxWidth;
}
if(b&4){h+=d.width-f;
}}return {left:h,
top:i,
width:f,
height:g};
},
__ek:{1:"n-resize",
2:"s-resize",
4:"w-resize",
8:"e-resize",
5:"nw-resize",
6:"sw-resize",
9:"ne-resize",
10:"se-resize"},
__el:function(a){if(!this.getResizable()){return;
}var b=this.getContentLocation();
var c=this.getResizeAllEdges();
var d=this.getResizeSensitivity();
var f=a.getDocumentLeft();
var g=a.getDocumentTop();
var h=0;
if(c&&Math.abs(b.top-g)<d){h+=1;
}else if(Math.abs(b.bottom-g)<d){h+=2;
}
if(c&&Math.abs(b.left-f)<d){h+=4;
}else if(Math.abs(b.right-f)<d){h+=8;
}this._resizeActive=h;
},
__em:function(a){if(!this._resizeActive){return;
}this.addState("resize");
this.capture();
this.__resizeLeft=a.getDocumentLeft();
this.__resizeTop=a.getDocumentTop();
this.__resizeStart=qx.lang.Object.copy(this.getBounds());
if(this.getUseResizeFrame()){this.__ei();
}a.stop();
},
__en:function(a){if(!this._resizeActive){return;
}if(this.getUseResizeFrame()){this.__eh().exclude();
}var b=this.__ej(a);
this.setWidth(b.width);
this.setHeight(b.height);
this.setLayoutProperties({left:b.left,
top:b.top});
this._resizeActive=0;
this.removeState("resize");
this.resetCursor();
this.getApplicationRoot().resetGlobalCursor();
this.releaseCapture();
},
__eo:function(a){if(!this._resizeActive){return;
}this.resetCursor();
this.getApplicationRoot().resetGlobalCursor();
this.removeState("move");
if(this.getUseMoveFrame()){this.__getMoveFrame().exclude();
}},
__ep:function(a){if(this.hasState("resize")){var b=this.__ej(a);
if(this.getUseResizeFrame()){var c=this.__eh();
c.setUserBounds(b.left,
b.top,
b.width,
b.height);
}else{this.setWidth(b.width);
this.setHeight(b.height);
this.setLayoutProperties({left:b.left,
top:b.top});
}a.stop();
}else if(!this.hasState("maximized")){this.__el(a);
var d=this._resizeActive;
var f=this.getApplicationRoot();
if(d){var g=this.__ek[d];
this.setCursor(g);
f.setGlobalCursor(g);
}else if(this.getCursor()){this.resetCursor();
f.resetGlobalCursor();
}}},
__eq:function(a){if(this.getCursor()&&!this.hasState("resize")){this.resetCursor();
this.getApplicationRoot().resetGlobalCursor();
}}},
destruct:function(){this._disposeObjects("__resizeFrame");
}});
qx.Mixin.define("qx.ui.core.MMovable",
{properties:{movable:{check:"Boolean",
init:true,
apply:"_applyMoveable"},
useMoveFrame:{check:"Boolean",
init:false}},
members:{_activateMoveHandle:function(a){if(this.__moveHandle){throw new Error("The move handle could not be redefined!");
}this.__moveHandle=a;
a.addListener("mousedown",
this._onMoveMouseDown,
this);
a.addListener("mouseup",
this._onMoveMouseUp,
this);
a.addListener("mousemove",
this._onMoveMouseMove,
this);
a.addListener("losecapture",
this.__eu,
this);
},
__er:function(){var a=this.__moveFrame;
if(!a){a=this.__moveFrame=new qx.ui.core.Widget();
a.setAppearance("move-frame");
a.exclude();
qx.core.Init.getApplication().getRoot().add(a);
}return a;
},
__es:function(){var a=this.getBounds();
var b=this.__er();
b.setUserBounds(a.left,
a.top,
a.width,
a.height);
b.show();
b.setZIndex(this.getZIndex()+1);
},
__et:function(a){var b=this._dragRange;
var c=Math.max(b.left,
Math.min(b.right,
a.getDocumentLeft()));
var d=Math.max(b.top,
Math.min(b.bottom,
a.getDocumentTop()));
return {left:this._dragLeft+c,
top:this._dragTop+d};
},
_onMoveMouseDown:function(a){if(!this.getMovable()||this.hasState("maximized")){return;
}var b=this.getLayoutParent();
var c=b.getContentLocation();
var d=b.getBounds();
this._dragRange={left:c.left,
top:c.top,
right:c.left+d.width,
bottom:c.top+d.height};
var f=this.getContainerLocation();
this._dragLeft=f.left-a.getDocumentLeft();
this._dragTop=f.top-a.getDocumentTop();
this.addState("move");
this.__moveHandle.capture();
if(this.getUseMoveFrame()){this.__es();
}a.stop();
},
_onMoveMouseMove:function(a){if(!this.hasState("move")){return;
}var b=this.__et(a);
if(this.getUseMoveFrame()){this.__er().setDomPosition(b.left,
b.top);
}else{this.setDomPosition(b.left,
b.top);
}},
_onMoveMouseUp:function(a){if(!this.hasState("move")){return;
}this.removeState("move");
this.__moveHandle.releaseCapture();
var b=this.__et(a);
this.setLayoutProperties({left:b.left,
top:b.top});
if(this.getUseMoveFrame()){this.__er().exclude();
}},
__eu:function(a){if(!this.hasState("move")){return;
}this.removeState("move");
if(this.getUseMoveFrame()){this.__er().exclude();
}}},
destruct:function(){this._disposeObjects("__moveFrame");
}});
qx.Mixin.define("qx.ui.core.MBlocker",
{properties:{blockerColor:{check:"Color",
init:null,
nullable:true,
apply:"_applyBlockerColor",
themeable:true},
blockerOpacity:{check:"Number",
init:1,
apply:"_applyBlockerOpacity",
themeable:true}},
members:{_applyBlockerColor:function(a,
b){var c=[];
this.__blocker&&c.push(this.__blocker);
this.__contentBlocker&&c.push(this.__contentBlocker);
for(var d=0;d<c.length;d++){blocker.setStlye("backgroundColor",
qx.theme.manager.Color.getInstance().resolve(a));
}},
_applyBlockerOpacity:function(a,
b){var c=[];
this.__blocker&&c.push(this.__blocker);
this.__contentBlocker&&c.push(this.__contentBlocker);
for(var d=0;d<c.length;d++){blocker.setStlye("opacity",
a);
}},
__ev:function(){var a=new qx.html.Element().setStyles({position:"absolute",
width:"100%",
height:"100%",
opacity:this.getBlockerOpacity(),
backgroundColor:qx.theme.manager.Color.getInstance().resolve(this.getBlockerColor())});
return a;
},
_getBlocker:function(){if(!this.__blocker){this.__blocker=this.__ev();
this.getContentElement().add(this.__blocker);
this.__blocker.exclude();
}return this.__blocker;
},
block:function(){if(this.__isBlocked){return;
}this.__isBlocked=true;
this._getBlocker().include();
this.__oldAnonymous=this.getAnonymous();
this.setAnonymous(true);
},
isBlocked:function(){return !!this.__isBlocked;
},
unblock:function(){if(!this.__isBlocked){return;
}this.__isBlocked=false;
this.setAnonymous(this.__oldAnonymous);
this._getBlocker().exclude();
},
_getContentBlocker:function(){if(!this.__contentBlocker){this.__contentBlocker=this.__ev();
this.getContentElement().add(this.__contentBlocker);
this.__contentBlocker.exclude();
}return this.__contentBlocker;
},
blockContent:function(a){var b=this._getContentBlocker();
b.setStyle("zIndex",
a);
if(this.__isContentBlocked){return;
}this.__isContentBlocked=true;
b.include();
},
isContentBlocked:function(){return !!this.__isContentBlocked;
},
unblockContent:function(){if(!this.__isContentBlocked){return;
}this.__isContentBlocked=false;
this._getContentBlocker().exclude();
}}});
qx.Interface.define("qx.ui.window.IWindowManager",
{members:{setDesktop:function(a){this.assertInterface(a,
qx.ui.window.IDesktop);
},
changeActiveWindow:function(a,
b){},
updateStack:function(){},
bringToFront:function(a){this.assertInstance(a,
qx.ui.window.Window);
},
sendToBack:function(a){this.assertInstance(a,
qx.ui.window.Window);
}}});
qx.Class.define("qx.ui.window.WindowManager",
{extend:qx.core.Object,
implement:qx.ui.window.IWindowManager,
members:{setDesktop:function(a){this._desktop=a;
this.updateStack();
},
changeActiveWindow:function(a,
b){this.bringToFront(a);
},
_minZIndex:1e5,
updateStack:function(){this._desktop.unblockContent();
var a=this._desktop.getWindows();
var b=this._minZIndex-1;
var c=false;
var d,
e;
for(var f=0,
g=a.length;f<g;f++){d=a[f];
if(!d.isVisible()){continue;
}b+=2;
d.setZIndex(b);
if(d.getModal()){this._desktop.blockContent(b-1);
}c=c||d.getActive();
e=d;
}
if(!c&&e){e.setActive(true);
}},
bringToFront:function(a){var b=this._desktop.getWindows();
var c=qx.lang.Array.remove(b,
a);
if(c){b.push(a);
this.updateStack();
}},
sendToBack:function(a){var b=this._desktop.getWindows();
var c=qx.lang.Array.remove(_windows,
a);
if(c){b.unshift(a);
this.updateStack();
}}}});
qx.Class.define("qx.ui.window.Window",
{extend:qx.ui.core.Widget,
include:[qx.ui.core.MRemoteChildrenHandling,
qx.ui.core.MRemoteLayoutHandling,
qx.ui.core.MResizable,
qx.ui.core.MMovable,
qx.ui.core.MBlocker],
construct:function(a,
b,
c){arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.VBox());
this._createChildControl("captionbar");
this._createChildControl("pane");
if(b!=null){this.setIcon(b);
}
if(a!=null){this.setCaption(a);
}this._parentWindow=c||null;
this._updateCaptionBar();
this.addListener("mousedown",
this._onWindowEventStop);
this.addListener("mouseup",
this._onWindowEventStop);
this.addListener("click",
this._onWindowEventStop);
this.addListener("mousedown",
this._onWindowMouseDown,
this,
true);
qx.core.Init.getApplication().getRoot().add(this);
qx.ui.core.FocusHandler.getInstance().addRoot(this);
},
statics:{DEFAULT_MANAGER_CLASS:qx.ui.window.WindowManager},
events:{"beforeClose":"qx.event.type.Event",
"close":"qx.event.type.Event",
"beforeMinimize":"qx.event.type.Event",
"minimize":"qx.event.type.Event",
"beforeMaximize":"qx.event.type.Event",
"maximize":"qx.event.type.Event",
"beforeRestore":"qx.event.type.Event",
"restore":"qx.event.type.Event"},
properties:{appearance:{refine:true,
init:"window"},
visibility:{refine:true,
init:"excluded"},
focusable:{refine:true,
init:true},
active:{check:"Boolean",
init:false,
apply:"_applyActive",
event:"changeActive"},
modal:{check:"Boolean",
init:false,
event:"changeModal"},
caption:{apply:"_applyCaption",
event:"changeCaption",
nullable:true},
icon:{check:"String",
nullable:true,
apply:"_applyIcon",
event:"changeIcon",
themeable:true},
status:{check:"String",
nullable:true,
apply:"_applyStatus",
event:"changeStatus"},
showClose:{check:"Boolean",
init:true,
apply:"_applyCaptionBarChange",
themeable:true},
showMaximize:{check:"Boolean",
init:true,
apply:"_applyCaptionBarChange",
themeable:true},
showMinimize:{check:"Boolean",
init:true,
apply:"_applyCaptionBarChange",
themeable:true},
allowClose:{check:"Boolean",
init:true,
apply:"_applyCaptionBarChange"},
allowMaximize:{check:"Boolean",
init:true,
apply:"_applyCaptionBarChange"},
allowMinimize:{check:"Boolean",
init:true,
apply:"_applyCaptionBarChange"},
showStatusbar:{check:"Boolean",
init:false,
apply:"_applyShowStatusbar"}},
members:{getChildrenContainer:function(){return this._getChildControl("pane");
},
_getStyleTarget:function(){return this._getChildControl("pane");
},
_forwardStates:{active:true,
maximized:true},
setLayoutParent:function(a){{a&&this.assertInterface(a,
qx.ui.window.IDesktop,
"Windows can only be added to widgets, which implement the interface "+"qx.ui.window.IDesktop. All root widgets implement this interface.");
};
arguments.callee.base.call(this,
a);
},
_createChildControlImpl:function(a){var b;
switch(a){case "statusbar":b=new qx.ui.container.Composite(new qx.ui.layout.HBox());
this._add(b);
b.add(this._getChildControl("statusbar-text"));
break;
case "statusbar-text":b=new qx.ui.basic.Label();
b.setContent(this.getStatus());
break;
case "pane":b=new qx.ui.container.Composite();
this._add(b,
{flex:1});
break;
case "captionbar":var c=new qx.ui.layout.Grid();
c.setColumnFlex(2,
1);
c.setRowFlex(0,
1);
b=new qx.ui.container.Composite(c);
this._add(b);
b.addListener("dblclick",
this._onCaptionMouseDblClick,
this);
this._activateMoveHandle(b);
break;
case "icon":b=new qx.ui.basic.Image(this.getIcon());
this._getChildControl("captionbar").add(b,
{row:0,
column:0});
break;
case "title":b=new qx.ui.basic.Label(this.getCaption());
this._getChildControl("captionbar").add(b,
{row:0,
column:1});
break;
case "spacer":b=new qx.ui.core.Spacer();
this._getChildControl("captionbar").add(b,
{row:0,
column:2});
break;
case "minimize-button":b=new qx.ui.form.Button();
b.setFocusable(false);
b.addListener("execute",
this._onMinimizeButtonClick,
this);
this._getChildControl("captionbar").add(b,
{row:0,
column:3});
break;
case "restore-button":b=new qx.ui.form.Button();
b.setFocusable(false);
b.addListener("execute",
this._onRestoreButtonClick,
this);
this._getChildControl("captionbar").add(b,
{row:0,
column:4});
break;
case "maximize-button":b=new qx.ui.form.Button();
b.setFocusable(false);
b.addListener("execute",
this._onMaximizeButtonClick,
this);
this._getChildControl("captionbar").add(b,
{row:0,
column:5});
break;
case "close-button":b=new qx.ui.form.Button();
b.setFocusable(false);
b.addListener("execute",
this._onCloseButtonClick,
this);
this._getChildControl("captionbar").add(b,
{row:0,
column:6});
break;
}return b||arguments.callee.base.call(this,
a);
},
_updateCaptionBar:function(){var a;
if(this.getIcon()){this._showChildControl("icon");
}else{this._excludeChildControl("icon");
}
if(this.getCaption()){this._showChildControl("title");
}else{this._excludeChildControl("title");
}
if(this.getShowMinimize()){this._showChildControl("minimize-button");
a=this._getChildControl("minimize-button");
this.getAllowMinimize()?a.resetEnabled():a.setEnabled(false);
}else{this._excludeChildControl("minimize-button");
}
if(this.getShowMaximize()){if(this.hasState("maximized")){this._showChildControl("restore-button");
this._excludeChildControl("maximize-button");
}else{this._showChildControl("maximize-button");
this._excludeChildControl("restore-button");
}a=this._getChildControl("maximize-button");
this.getAllowMaximize()?a.resetEnabled():a.setEnabled(false);
}else{this._excludeChildControl("maximize-button");
this._excludeChildControl("restore-button");
}
if(this.getShowClose()){this._showChildControl("close-button");
a=this._getChildControl("close-button");
this.getAllowClose()?a.resetEnabled():a.setEnabled(false);
}else{this._excludeChildControl("close-button");
}},
close:function(){if(this.fireNonBubblingEvent("beforeClose",
qx.event.type.Event,
[false,
true])){this.hide();
this.fireEvent("close");
}},
open:function(){this.show();
this.setActive(true);
this.focus();
},
maximize:function(){var a=this.getLayoutParent();
if(!a){return;
}
if(a.supportsMaximize()){if(this.fireNonBubblingEvent("beforeMaximize",
qx.event.type.Event,
[false,
true])){var b=this.getLayoutProperties();
this.__restoredLeft=b.left;
this.__restoredTop=b.top;
this.setLayoutProperties({left:null,
top:null,
edge:0});
this.addState("maximized");
this._updateCaptionBar();
this.fireEvent("maximize");
}}},
minimize:function(){if(this.fireNonBubblingEvent("beforeMinimize",
qx.event.type.Event,
[false,
true])){this.hide();
this.fireEvent("minimize");
}},
restore:function(){if(!this.hasState("maximized")){return;
}
if(this.fireNonBubblingEvent("beforeRestore",
qx.event.type.Event,
[false,
true])){var a=this.__restoredLeft;
var b=this.__restoredTop;
this.setLayoutProperties({edge:null,
left:a,
top:b});
this.removeState("maximized");
this._updateCaptionBar();
this.fireEvent("restore");
}},
moveTo:function(a,
b){if(this.hasState("maximized")){return;
}this.setLayoutProperties({left:a,
top:b});
},
getParentWindow:function(){return this._parentWindow;
},
_applyActive:function(a,
b){if(b){this.removeState("active");
}else{this.addState("active");
}},
_applyShowStatusbar:function(a,
b){if(a){this._showChildControl("statusbar");
}else{this._excludeChildControl("statusbar");
}},
_applyCaptionBarChange:function(a,
b){this._updateCaptionBar();
},
_applyStatus:function(a,
b){var c=this._getChildControl("statusbar-text",
true);
if(c){c.setContent(a);
}},
_applyCaption:function(a,
b){this._getChildControl("title").setContent(a);
},
_applyIcon:function(a,
b){this._getChildControl("icon").setSource(a);
},
_onWindowEventStop:function(a){a.stopPropagation();
},
_onWindowMouseDown:function(a){this.setActive(true);
},
_onCaptionMouseDblClick:function(a){if(this.getAllowMaximize()){this.hasState("maximized")?this.restore():this.maximize();
}},
_onMinimizeButtonClick:function(a){this.minimize();
this._getChildControl("minimize-button").reset();
},
_onRestoreButtonClick:function(a){this.restore();
this._getChildControl("restore-button").reset();
},
_onMaximizeButtonClick:function(a){this.maximize();
this._getChildControl("maximize-button").reset();
},
_onCloseButtonClick:function(a){this.close();
this._getChildControl("close-button").reset();
}}});
qx.Interface.define("qx.ui.window.IDesktop",
{members:{setWindowManager:function(a){this.assertInterface(a,
qx.ui.window.IWindowManager);
},
getWindows:function(){},
supportsMaximize:function(){},
blockContent:function(a){this.assertInteger(a);
},
unblockContent:function(){}}});
qx.Class.define("qx.ui.core.FocusHandler",
{extend:qx.core.Object,
type:"singleton",
construct:function(){arguments.callee.base.call(this);
this.__roots={};
},
members:{connectTo:function(a){a.addListener("keypress",
this._onKeyEvent,
this);
a.addListener("focusin",
this._onFocusIn,
this,
true);
a.addListener("focusout",
this._onFocusOut,
this,
true);
a.addListener("activate",
this._onActivate,
this,
true);
a.addListener("deactivate",
this._onDeactivate,
this,
true);
},
addRoot:function(a){this.__roots[a.$$hash]=a;
},
removeRoot:function(a){delete this.__roots[a.$$hash];
},
isActive:function(a){return this.__activeWidget==a;
},
isFocused:function(a){return this.__focusedWidget==a;
},
isFocusRoot:function(a){!!this.__roots[a.$$hash];
},
_onActivate:function(a){var b=a.getTarget();
this.__activeChild=b;
var c=this.__ew(b);
if(c!=this.__currentRoot){this.__currentRoot=c;
}},
_onDeactivate:function(a){var b=a.getTarget();
if(this.__activeChild==b){this.__activeChild=null;
}},
_onFocusIn:function(a){var b=a.getTarget();
if(b!=this.__focusedChild){this.__focusedChild=b;
b.visualizeFocus();
}},
_onFocusOut:function(a){var b=a.getTarget();
if(b==this.__focusedChild){this.__focusedChild=null;
b.visualizeBlur();
}},
_onKeyEvent:function(a){if(a.getKeyIdentifier()!="Tab"){return;
}
if(!this.__currentRoot){return;
}a.stopPropagation();
a.preventDefault();
var b=this.__focusedChild;
if(!a.isShiftPressed()){var c=b?this.__eA(b):this.__ey();
}else{var c=b?this.__eB(b):this.__ez();
}if(c){c.tabFocus();
}},
__ew:function(a){var b=this.__roots;
while(a){if(b[a.$$hash]){return a;
}a=a.getLayoutParent();
}return null;
},
__ex:function(a,
b){if(a===b){return 0;
}var c=a.getTabIndex()||0;
var d=b.getTabIndex()||0;
if(c!=d){return c-d;
}var e=a.getContainerElement().getDomElement();
var f=b.getContainerElement().getDomElement();
var g=qx.bom.element.Location;
var h=g.get(e);
var i=g.get(f);
if(h.top!=i.top){return h.top-i.top;
}if(h.left!=i.left){return h.left-i.left;
}var j=a.getZIndex();
var k=b.getZIndex();
if(j!=k){return j-k;
}return 0;
},
__ey:function(){return this.__eE(this.__currentRoot,
null);
},
__ez:function(){return this.__eF(this.__currentRoot,
null);
},
__eA:function(a){var b=this.__currentRoot;
if(b==a){return this.__ey();
}
while(a&&a.getAnonymous()){a=a.getLayoutParent();
}
if(a==null){return [];
}var c=[];
this.__eC(b,
a,
c);
c.sort(this.__ex);
var d=c.length;
return d>0?c[0]:this.__ey();
},
__eB:function(a){var b=this.__currentRoot;
if(b==a){return this.__ez();
}
while(a&&a.getAnonymous()){a=a.getLayoutParent();
}
if(a==null){return [];
}var c=[];
this.__eD(b,
a,
c);
c.sort(this.__ex);
var d=c.length;
return d>0?c[d-1]:this.__ez();
},
__eC:function(a,
b,
c){var d=a.getLayoutChildren();
var e;
for(var f=0,
g=d.length;f<g;f++){e=d[f];
if(!(e instanceof qx.ui.core.Widget)){continue;
}
if(!this.isFocusRoot(e)&&e.isEnabled()){if(e.isTabable()&&this.__ex(b,
e)<0){c.push(e);
}this.__eC(e,
b,
c);
}}},
__eD:function(a,
b,
c){var d=a.getLayoutChildren();
var e;
for(var f=0,
g=d.length;f<g;f++){e=d[f];
if(!(e instanceof qx.ui.core.Widget)){continue;
}
if(!this.isFocusRoot(e)&&e.isEnabled()){if(e.isTabable()&&this.__ex(b,
e)>0){c.push(e);
}this.__eD(e,
b,
c);
}}},
__eE:function(a,
b){var c=a.getLayoutChildren();
var d;
for(var e=0,
f=c.length;e<f;e++){d=c[e];
if(!(d instanceof qx.ui.core.Widget)){continue;
}if(!this.isFocusRoot(d)&&d.isEnabled()){if(d.isTabable()){if(b==null||this.__ex(d,
b)<0){b=d;
}}b=this.__eE(d,
b);
}}return b;
},
__eF:function(a,
b){var c=a.getLayoutChildren();
var d;
for(var e=0,
f=c.length;e<f;e++){d=c[e];
if(!(d instanceof qx.ui.core.Widget)){continue;
}if(!this.isFocusRoot(d)&&d.isEnabled()){if(d.isTabable()){if(b==null||this.__ex(d,
b)>0){b=d;
}}b=this.__eF(d,
b);
}}return b;
}},
destruct:function(){this._disposeFields("__roots",
"__focusedChild",
"__activeChild");
}});
qx.Class.define("qx.event.Command",
{extend:qx.core.Object,
construct:function(a){arguments.callee.base.call(this);
this.__modifier={};
this.__key=null;
if(a!=null){this.setShortcut(a);
}{if(this.__modifier.Alt&&this.__key&&this.__key.length==1){if((this.__key>="A"&&this.__key<="Z")||(this.__key>="0"&&this.__key<="9")){this.warn("A shortcut containing Alt and a letter or number will not work under OS X!");
}}};
this.initEnabled();
},
events:{"execute":"qx.event.type.Data"},
properties:{enabled:{init:true,
check:"Boolean",
event:"changeEnabled",
apply:"_applyEnabled"},
shortcut:{check:"String",
apply:"_applyShortcut",
nullable:true}},
members:{execute:function(a){this.fireDataEvent("execute",
a);
},
__eG:function(a){if(this.getEnabled()&&this.matchesKeyEvent(a)){this.execute(a.getTarget());
a.preventDefault();
a.stopPropagation();
}},
_applyEnabled:function(a,
b){if(a){qx.event.Registration.addListener(document.documentElement,
"keydown",
this.__eG,
this);
}else{qx.event.Registration.removeListener(document.documentElement,
"keydown",
this.__eG,
this);
}},
_applyShortcut:function(b,
c){if(b){this.__modifier={};
this.__key=null;
var d=b.split(/[-+\s]+/);
var e=d.length;
for(var f=0;f<e;f++){var g=this.__eI(d[f]);
switch(g){case "Control":case "Shift":case "Meta":case "Alt":this.__modifier[g]=true;
break;
case "Unidentified":var h="Not a valid key name for a command: "+d[f];
this.error(h);
throw h;
default:if(this.__key){var h="You can only specify one non modifier key!";
this.error(h);
throw h;
}this.__key=g;
}}}return true;
},
matchesKeyEvent:function(a){var b=this.__key;
if(!b){return ;
}if((this.__modifier.Shift&&!a.isShiftPressed())||(this.__modifier.Control&&!a.isCtrlPressed())||(this.__modifier.Meta&&!a.isMetaPressed())||(this.__modifier.Alt&&!a.isAltPressed())){return false;
}
if(b==a.getKeyIdentifier()){return true;
}return false;
},
__eH:{esc:"Escape",
ctrl:"Control",
print:"PrintScreen",
del:"Delete",
pageup:"PageUp",
pagedown:"PageDown",
numlock:"NumLock",
numpad_0:"0",
numpad_1:"1",
numpad_2:"2",
numpad_3:"3",
numpad_4:"4",
numpad_5:"5",
numpad_6:"6",
numpad_7:"7",
numpad_8:"8",
numpad_9:"9",
numpad_divide:"/",
numpad_multiply:"*",
numpad_minus:"-",
numpad_plus:"+"},
__eI:function(a){var b=qx.event.handler.Keyboard;
var c="Unidentified";
if(b.isValidKeyIdentifier(a)){return a;
}
if(a.length==1&&a>="a"&&a<="z"){return a.toUpperCase();
}a=a.toLowerCase();
var c=this.__eH[a]||qx.lang.String.firstUp(a);
if(b.isValidKeyIdentifier(c)){return c;
}else{return "Unidentified";
}},
toString:function(){var a=this.__key;
var b=[];
for(var c in this.__modifier){b.push(qx.locale.Key.getKeyName("short",
c));
}
if(a){b.push(qx.locale.Key.getKeyName("short",
a));
}return b.join("+");
}},
destruct:function(){this.setEnabled(false);
this._disposeFields("__modifier",
"__key");
}});
qx.Class.define("qx.locale.Key",
{statics:{getKeyName:function(a,
b,
c){{qx.core.Assert.assertInArray(a,
["short",
"full"]);
};
var d="key_"+a+"_"+b;
var e=qx.locale.Manager.getInstance().translate(d,
[],
c);
if(e==d){return qx.locale.Key._keyNames[d]||b;
}else{return e;
}}},
defer:function(a,
b,
c){var d={};
var e=qx.locale.Manager;
d[e.marktr("key_short_Backspace")]="Backspace";
d[e.marktr("key_short_Tab")]="Tab";
d[e.marktr("key_short_Space")]="Space";
d[e.marktr("key_short_Enter")]="Enter";
d[e.marktr("key_short_Shift")]="Shift";
d[e.marktr("key_short_Control")]="Ctrl";
d[e.marktr("key_short_Alt")]="Alt";
d[e.marktr("key_short_CapsLock")]="Caps";
d[e.marktr("key_short_Meta")]="Meta";
d[e.marktr("key_short_Escape")]="Esc";
d[e.marktr("key_short_Left")]="Left";
d[e.marktr("key_short_Up")]="Up";
d[e.marktr("key_short_Right")]="Right";
d[e.marktr("key_short_Down")]="Down";
d[e.marktr("key_short_PageUp")]="PgUp";
d[e.marktr("key_short_PageDown")]="PgDn";
d[e.marktr("key_short_End")]="End";
d[e.marktr("key_short_Home")]="Home";
d[e.marktr("key_short_Insert")]="Ins";
d[e.marktr("key_short_Delete")]="Del";
d[e.marktr("key_short_NumLock")]="Num";
d[e.marktr("key_short_PrintScreen")]="Print";
d[e.marktr("key_short_Scroll")]="Scroll";
d[e.marktr("key_short_Pause")]="Pause";
d[e.marktr("key_short_Win")]="Win";
d[e.marktr("key_short_Apps")]="Apps";
d[e.marktr("key_full_Backspace")]="Backspace";
d[e.marktr("key_full_Tab")]="Tabulator";
d[e.marktr("key_full_Space")]="Space";
d[e.marktr("key_full_Enter")]="Enter";
d[e.marktr("key_full_Shift")]="Shift";
d[e.marktr("key_full_Control")]="Control";
d[e.marktr("key_full_Alt")]="Alt";
d[e.marktr("key_full_CapsLock")]="CapsLock";
d[e.marktr("key_full_Meta")]="Meta";
d[e.marktr("key_full_Escape")]="Escape";
d[e.marktr("key_full_Left")]="Left";
d[e.marktr("key_full_Up")]="Up";
d[e.marktr("key_full_Right")]="Right";
d[e.marktr("key_full_Down")]="Down";
d[e.marktr("key_full_PageUp")]="PageUp";
d[e.marktr("key_full_PageDown")]="PageDown";
d[e.marktr("key_full_End")]="End";
d[e.marktr("key_full_Home")]="Home";
d[e.marktr("key_full_Insert")]="Insert";
d[e.marktr("key_full_Delete")]="Delete";
d[e.marktr("key_full_NumLock")]="NumLock";
d[e.marktr("key_full_PrintScreen")]="PrintScreen";
d[e.marktr("key_full_Scroll")]="Scroll";
d[e.marktr("key_full_Pause")]="Pause";
d[e.marktr("key_full_Win")]="Win";
d[e.marktr("key_full_Apps")]="Apps";
a._keyNames=d;
}});
qx.Class.define("qx.ui.form.SplitButton",
{extend:qx.ui.core.Widget,
include:qx.ui.core.MExecutable,
implement:qx.ui.form.IFormElement,
construct:function(a,
b,
c,
d){arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.HBox);
this._createChildControl("arrow");
this.addListener("mouseover",
this._onMouseOver,
this,
true);
this.addListener("mouseout",
this._onMouseOut,
this,
true);
this.addListener("keydown",
this._onKeyDown);
this.addListener("keyup",
this._onKeyUp);
if(a!=null){this.setLabel(a);
}
if(b!=null){this.setIcon(b);
}
if(c!=null){this.setMenu(c);
}
if(d!=null){this.setCommand(null);
}},
properties:{appearance:{refine:true,
init:"splitbutton"},
name:{check:"String",
nullable:true,
event:"changeName"},
value:{check:"String",
nullable:true,
event:"changeValue"},
focusable:{refine:true,
init:true},
label:{apply:"_applyLabel",
nullable:true,
dispose:true,
check:"String"},
icon:{check:"String",
apply:"_applyIcon",
nullable:true,
themeable:true},
show:{init:"both",
check:["both",
"label",
"icon"],
themeable:true,
nullable:true,
inheritable:true,
apply:"_applyShow",
event:"changeShow"},
menu:{check:"qx.ui.menu.Menu",
nullable:true,
apply:"_applyMenu",
event:"changeMenu"}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "button":b=new qx.ui.form.Button;
b.addListener("execute",
this._onButtonExecute,
this);
b.setFocusable(false);
this._addAt(b,
0);
break;
case "arrow":b=new qx.ui.form.MenuButton;
b.setFocusable(false);
this._addAt(b,
1);
break;
}return b||arguments.callee.base.call(this,
a);
},
_forwardStates:{hovered:1,
focused:1},
_applyLabel:function(a,
b){var c=this._getChildControl("button");
a==null?c.resetLabel():c.setLabel(a);
},
_applyIcon:function(a,
b){var c=this._getChildControl("button");
a==null?c.resetIcon():c.setIcon(a);
},
_applyMenu:function(a,
b){var c=this._getChildControl("arrow");
c.setEnabled(!!a);
if(a){c.setEnabled(true);
c.setMenu(a);
a.setOpener(this);
a.addListener("changeVisibility",
this._onChangeMenuVisibility,
this);
}else{c.setEnabled(false);
c.resetMenu();
}
if(b){b.removeListener("changeVisibility",
this._onChangeMenuVisibility,
this);
b.resetOpener();
}},
_applyShow:function(a,
b){},
_onMouseOver:function(a){a.stopPropagation();
this.addState("hovered");
delete this._cursorIsOut;
},
_onMouseOut:function(a){a.stopPropagation();
if(!this.hasState("hovered")){return;
}var b=a.getRelatedTarget();
if(qx.ui.core.Widget.contains(this,
b)){return;
}var c=this.getMenu();
if(c&&c.isVisible()){this._cursorIsOut=true;
return;
}this.removeState("hovered");
},
_onKeyDown:function(a){var b=this._getChildControl("button");
switch(a.getKeyIdentifier()){case "Enter":case "Space":b.removeState("abandoned");
b.addState("pressed");
}},
_onKeyUp:function(a){var b=this._getChildControl("button");
switch(a.getKeyIdentifier()){case "Enter":case "Space":if(b.hasState("pressed")){b.removeState("abandoned");
b.removeState("pressed");
b.execute();
}}},
_onButtonExecute:function(a){this.execute();
},
_onChangeMenuVisibility:function(a){if(!this.getMenu().isVisible()&&this._cursorIsOut){this.removeState("hovered");
}}}});
qx.Class.define("qx.ui.toolbar.SplitButton",
{extend:qx.ui.form.SplitButton,
construct:function(a,
b,
c,
d){arguments.callee.base.call(this,
a,
b,
c,
d);
this.removeListener("keydown",
this._onKeyDown);
this.removeListener("keyup",
this._onKeyUp);
},
properties:{appearance:{refine:true,
init:"toolbar-splitbutton"},
focusable:{refine:true,
init:false}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "button":b=new qx.ui.toolbar.Button;
b.addListener("execute",
this._onButtonExecute,
this);
this._addAt(b,
0);
break;
case "arrow":b=new qx.ui.toolbar.MenuButton;
this._addAt(b,
1);
break;
}return b||arguments.callee.base.call(this,
a);
}}});
qx.Class.define("qx.ui.toolbar.Button",
{extend:qx.ui.form.Button,
construct:function(a,
b,
c){arguments.callee.base.call(this,
a,
b,
c);
this.removeListener("keydown",
this._onKeyDown);
this.removeListener("keyup",
this._onKeyUp);
},
properties:{appearance:{refine:true,
init:"toolbar-button"},
show:{refine:true,
init:"inherit"},
focusable:{refine:true,
init:false}}});
qx.Class.define("qx.bom.element.Class",
{statics:{add:function(a,
b){if(!this.has(a,
b)){a.className+=(a.className?" ":"")+b;
}return b;
},
get:function(a){return a.className;
},
has:function(a,
b){var c=new RegExp("(^|\\s)"+b+"(\\s|$)");
return c.test(a.className);
},
remove:function(a,
b){var c=new RegExp("(^|\\s)"+b+"(\\s|$)");
a.className=a.className.replace(c,
"$2");
return b;
},
replace:function(a,
b,
c){this.remove(a,
b);
return this.add(a,
c);
},
toggle:function(a,
b){this.has(a,
b)?this.remove(a,
b):this.add(a,
b);
return b;
}}});
qx.Class.define("qx.ui.table.headerrenderer.HeaderCell",
{extend:qx.ui.container.Composite,
construct:function(){arguments.callee.base.call(this);
var a=new qx.ui.layout.Grid();
a.setColumnFlex(1,
1);
this.setLayout(a);
this.setMinWidth(30);
},
properties:{appearance:{refine:true,
init:"table-header-cell"},
label:{check:"String",
init:null,
nullable:true,
apply:"_applyLabel"},
sortIcon:{check:"String",
init:null,
nullable:true,
apply:"_applySortIcon",
themeable:true},
icon:{check:"String",
init:null,
nullable:true,
apply:"_applyIcon"}},
members:{_applyLabel:function(a,
b){if(a){this._showChildControl("label").setContent(a);
}else{this._excludeChildControl("label");
}},
_applySortIcon:function(a,
b){if(a){this._showChildControl("sort-icon").setSource(a);
}else{this._excludeChildControl("sort-icon");
}},
_applyIcon:function(a,
b){if(a){this._showChildControl("icon").setSource(a);
}else{this._excludeChildControl("icon");
}},
_createChildControlImpl:function(a){var b;
switch(a){case "label":b=new qx.ui.basic.Label(this.getLabel());
b.setAnonymous(true);
this._add(b,
{row:0,
column:1});
break;
case "sort-icon":b=new qx.ui.basic.Image(this.getSortIcon());
b.setAnonymous(true);
this._add(b,
{row:0,
column:0});
break;
case "icon":b=new qx.ui.basic.Image(this.getIcon());
b.setAnonymous(true);
this._add(b,
{row:0,
column:2});
break;
}return b||arguments.callee.base.call(this,
a);
}}});
qx.Class.define("qx.dev.unit.TestFunction",
{extend:qx.core.Object,
construct:function(a,
b,
c){if(c){this.setTestFunction(c);
}else{this.setTestFunction(function(){var d=new a;
if(typeof (d.setUp)=="function"){d.setUp();
}
try{d[b]();
}catch(e){throw e;
}finally{if(typeof (d.tearDown)=="function"){d.tearDown();
}}});
}
if(a){this.setClassName(a.classname);
}this.setName(b);
},
properties:{testFunction:{check:"Function"},
name:{check:"String"},
className:{check:"String",
init:""}},
members:{run:function(a){a.run(this,
this.getTestFunction());
},
getFullName:function(){return [this.getClassName(),
this.getName()].join(":");
}}});
qx.Interface.define("qx.ui.table.ITableModel",
{events:{"dataChanged":"qx.event.type.DataEvent",
"metaDataChanged":"qx.event.type.DataEvent"},
statics:{EVENT_TYPE_DATA_CHANGED:"dataChanged",
EVENT_TYPE_META_DATA_CHANGED:"metaDataChanged"},
members:{getRowCount:function(){return true;
},
getRowData:function(a){return true;
},
getColumnCount:function(){return true;
},
getColumnId:function(a){return true;
},
getColumnIndexById:function(a){return true;
},
getColumnName:function(a){return true;
},
isColumnEditable:function(a){return true;
},
isColumnSortable:function(a){return true;
},
sortByColumn:function(a,
b){return true;
},
getSortColumnIndex:function(){return true;
},
isSortAscending:function(){return true;
},
prefetchRows:function(a,
b){return true;
},
getValue:function(a,
b){return true;
},
getValueById:function(a,
b){return true;
},
setValue:function(a,
b,
c){return true;
},
setValueById:function(a,
b,
c){return true;
}}});
qx.Class.define("qx.dev.unit.TestSuite",
{extend:qx.core.Object,
construct:function(a){arguments.callee.base.call(this);
this.__tests=[];
if(a){this.add(a);
}},
members:{add:function(a){if(typeof (a)=="string"){var b=eval(a);
if(!b){this.addFail(a,
"The class/namespace '"+a+"' is undefined!");
}a=b;
}
if(typeof (a)=="function"){this.addTestClass(a);
}else if(typeof (a)=="object"){this.addTestNamespace(a);
}else{this.addFail("exsitsCheck",
"Unkown test class '"+a+"'!");
return;
}},
addTestNamespace:function(a){if(typeof (a)=="function"&&a.classname){if(qx.Class.isSubClassOf(a,
qx.dev.unit.TestCase)){this.addTestClass(a);
return;
}}else if(typeof (a)=="object"&&!(a instanceof Array)){for(var b in a){this.addTestNamespace(a[b]);
}}},
addTestFunction:function(a,
b){this.__tests.push(new qx.dev.unit.TestFunction(null,
a,
b));
},
addTestMethod:function(a,
b){this.__tests.push(new qx.dev.unit.TestFunction(a,
b));
},
addTestClass:function(a){this.__tests.push(new qx.dev.unit.run.TestClass(a));
},
addFail:function(a,
b){this.addTestFunction(a,
function(){this.fail(b);
});
},
run:function(a){for(var b=0;b<this.__tests.length;b++){(this.__tests[b]).run(a);
}},
getTestClasses:function(){var a=[];
for(var b=0;b<this.__tests.length;b++){var c=this.__tests[b];
if(c instanceof qx.dev.unit.run.TestClass){a.push(c);
}}return a;
},
getTestMethods:function(){var a=[];
for(var b=0;b<this.__tests.length;b++){var c=this.__tests[b];
if(c instanceof qx.dev.unit.TestFunction){a.push(c);
}}return a;
},
addPollutionCheck:function(){},
__eJ:function(){var a=qx.lang.Object.getKeys(this.__tests);
qx.lang.Array.append(qx.dev.Pollution.ignore.window,
a);
qx.lang.Array.append(qx.dev.Pollution.ignore.window,
["jsUnitSetOnLoad",
"newOnLoadEvent",
"jsUnitGetParm",
"setJsUnitTracer",
"JsUnitException",
"parseErrorStack",
"getStackTrace",
"tearDown",
"setUp",
"assertContains",
"assertRoughlyEquals",
"assertHashEquals",
"assertHTMLEquals",
"assertEvaluatesToFalse",
"assertEvaluatesToTrue",
"assertArrayEquals",
"assertObjectEquals",
"assertNotNaN",
"assertNaN",
"assertNotUndefined",
"assertUndefined",
"assertNotNull",
"assertNull",
"assertNotEquals",
"assertEquals",
"assertFalse",
"assertTrue",
"assert",
"_assert",
"_validateArguments",
"nonCommentArg",
"commentArg",
"argumentsIncludeComments",
"error",
"fail",
"_displayStringForValue",
"_trueTypeOf",
"jsUnitFixTop",
"isTestPageLoaded",
"JSUNIT_VERSION",
"standardizeHTML",
"isLoaded",
"getFunctionName",
"warn",
"info",
"inform",
"debug",
"trim",
"push",
"pop",
"isBlank"]);
qx.lang.Array.append(qx.dev.Pollution.ignore.window,
this.__testClassNames.map(function(b){return b.split(".")[0];
}));
qx.lang.Array.append(qx.dev.Pollution.ignore.window,
["exposeTestFunctionNames"]);
var c=qx.dev.Pollution.extract("window");
new qx.dev.unit.TestCase().assertJsonEquals([],
c);
}}});
qx.Class.define("qx.dev.unit.TestClass",
{extend:qx.dev.unit.TestSuite,
construct:function(a){arguments.callee.base.call(this);
if(!a){this.addFail("exsitsCheck"+this.__testClassNames.length,
"Unkown test class!");
return;
}
if(!qx.Class.isSubClassOf(a,
qx.dev.unit.TestCase)){this.addFail("Sub class check.",
"The test class '"+a.classname+"'is not a sub class of 'qx.dev.unit.TestCase'");
return;
}var b=a.prototype;
for(var c in b){if(b.hasOwnProperty(c)){if(typeof (b[c])=="function"&&c.indexOf("test")==0){this.addTestMethod(a,
c);
}}}this.setName(a.classname);
},
properties:{name:{check:"String"}}});
qx.Class.define("qx.dev.unit.TestCase",
{extend:qx.core.Object,
include:[qx.core.MAssert],
members:{isDebugOn:function(){return true;
}}});
qx.Class.define("qx.dev.Pollution",
{statics:{names:{"window":window,
"document":document,
"body":document.body},
ignore:{"window":["qx",
"java",
"sun",
"Packages",
"__firebug__",
"Components",
"controllers",
"sessionStorage",
"globalStorage",
"console",
"event",
"offscreenBuffering",
"clipboardData",
"clientInformation",
"Option",
"Image",
"external",
"screenTop",
"screenLeft",
"length",
"window",
"document",
"location",
"navigator",
"netscape",
"parent",
"frames",
"top",
"scrollbars",
"name",
"scrollX",
"scrollY",
"self",
"screen",
"history",
"content",
"menubar",
"toolbar",
"locationbar",
"personalbar",
"statusbar",
"directories",
"closed",
"crypto",
"pkcs11",
"opener",
"status",
"defaultStatus",
"innerWidth",
"innerHeight",
"outerWidth",
"outerHeight",
"screenX",
"screenY",
"pageXOffset",
"pageYOffset",
"scrollMaxX",
"scrollMaxY",
"fullScreen",
"frameElement",
"XMLHttpRequest"],
"document":["domConfig",
"location",
"compatMode",
"implementation",
"defaultView",
"title",
"body",
"styleSheets",
"documentElement",
"nodeName",
"nodeType",
"firstChild",
"lastChild",
"doctype",
"images",
"applets",
"links",
"forms",
"anchors",
"cookie",
"embeds",
"plugins",
"designMode",
"childNodes"],
"body":["textContent",
"innerHTML",
"outerHTML",
"innerText",
"outerText",
"scopeName",
"parentElement",
"tagName",
"filters",
"contentEditable",
"document",
"currentStyle",
"isMultiLine",
"clientHeight",
"clientWidth",
"lastChild",
"firstChild",
"offsetTop",
"offsetLeft",
"offsetWidth",
"offsetHeight",
"tabIndex",
"className",
"attributes",
"previousSibling",
"nextSibling",
"ownerDocument",
"localName",
"childNodes",
"parentNode",
"nodeType",
"nodeName",
"style",
"scrollTop",
"scrollLeft",
"scrollWidth",
"scrollHeight"]},
getInfo:function(a){var b=qx.dev.Pollution.getTextList(a||"window");
if(b){return "Global namespace is polluted by the following unknown objects:\n\n"+b;
}else{return "Global namespace is not polluted by any unknown objects.";
}},
extract:function(a){var b=[];
var c=qx.dev.Pollution.ignore[a];
if(qx.core.Variant.isSet("qx.client",
"mshtml")){if(a=="window"){c=c.slice();
for(var d=0;d<window.length;d++){c.push(""+d);
}}}var e=qx.dev.Pollution.names[a];
for(var f in e){try{if(qx.core.Variant.isSet("qx.client",
"mshtml|opera")){if(a=="window"&&f=="external"){continue;
}}if(typeof e[f]=="undefined"||e[f]===null){continue;
}if(typeof e[f]=="function"&&e[f].toString().indexOf("[native code]")!=-1){continue;
}if(typeof e[f].constructor=="function"){if((e[f].constructor.toString().indexOf("[native code]")!=-1)||(e[f].constructor.toString().indexOf("[function]")!=-1)){continue;
}}if(qx.lang.Array.contains(c,
f)){continue;
}}catch(ex){continue;
}b.push({"key":f,
"value":e[f]});
}return b;
},
getHtmlTable:function(a){var b=[];
var c="<tr style='vertical-align:top'><td>";
var d="</td><td>";
var e="</td></tr>";
b.push("<table>");
var f=this.extract(a);
for(var g=0;g<f.length;g++){b.push(c+f[g].key+d+f[g].value+e);
}b.push("</table>");
return b.join("");
},
getTextList:function(a){var b=[];
var c=": ";
var d="\n";
var e=this.extract(a);
for(var f=0;f<e.length;f++){b.push(e[f].key+c+e[f].value+d);
}return b.join("");
}}});
qx.Class.define("qx.ui.control.DateChooser",
{extend:qx.ui.core.Widget,
include:qx.ui.core.MExecutable,
implement:qx.ui.form.IFormElement,
construct:function(a){arguments.callee.base.call(this);
var b=new qx.ui.layout.VBox();
this._setLayout(b);
this._createChildControl("navigation-bar");
this._createChildControl("date-pane");
this.addListener("keypress",
this._onkeypress);
var c=(a!=null)?a:new Date();
this.showMonth(c.getMonth(),
c.getFullYear());
qx.locale.Manager.getInstance().addListener("changeLocale",
this._updateDatePane,
this);
this.addListener("mousedown",
this._onMouseUpDown,
this);
this.addListener("mouseup",
this._onMouseUpDown,
this);
},
statics:{MONTH_YEAR_FORMAT:qx.locale.Date.getDateTimeFormat("yyyyMMMM",
"MMMM yyyy")},
events:{changeValue:"qx.event.type.Data"},
properties:{appearance:{refine:true,
init:"datechooser"},
width:{refine:true,
init:200},
height:{refine:true,
init:150},
shownMonth:{check:"Integer",
init:null,
nullable:true,
event:"changeShownMonth"},
shownYear:{check:"Integer",
init:null,
nullable:true,
event:"changeShownYear"},
date:{check:"Date",
init:null,
nullable:true,
apply:"_applyDate",
event:"changeDate",
transform:"_checkDate"},
name:{check:"String",
nullable:true,
event:"changeName"}},
members:{setValue:function(a){this.assertType(a,
"string");
this.setDate(new Date(a));
return a;
},
getValue:function(){return this.getDate().toString();
},
_createChildControlImpl:function(a){var b;
switch(a){case "navigation-bar":b=new qx.ui.container.Composite(new qx.ui.layout.HBox());
b.add(this._getChildControl("last-year-button"));
b.add(this._getChildControl("last-month-button"));
b.add(this._getChildControl("month-year-label"),
{flex:1});
b.add(this._getChildControl("next-month-button"));
b.add(this._getChildControl("next-year-button"));
this._add(b);
break;
case "last-year-button":b=new qx.ui.form.Button();
b.addState("lastYear");
b.setFocusable(false);
b.setToolTip(new qx.ui.tooltip.ToolTip("Last year"));
b.addListener("click",
this._onNavButtonClicked,
this);
break;
case "last-month-button":b=new qx.ui.toolbar.Button();
b.addState("lastMonth");
b.setFocusable(false);
b.setToolTip(new qx.ui.tooltip.ToolTip("Last month"));
b.addListener("click",
this._onNavButtonClicked,
this);
break;
case "next-month-button":b=new qx.ui.toolbar.Button();
b.addState("nextMonth");
b.setFocusable(false);
b.setToolTip(new qx.ui.tooltip.ToolTip("Next month"));
b.addListener("click",
this._onNavButtonClicked,
this);
break;
case "next-year-button":b=new qx.ui.toolbar.Button();
b.addState("nextYear");
b.setFocusable(false);
b.setToolTip(new qx.ui.tooltip.ToolTip("Next year"));
b.addListener("click",
this._onNavButtonClicked,
this);
break;
case "month-year-label":b=new qx.ui.basic.Label();
b.setAllowGrowX(true);
b.setAnonymous(true);
break;
case "date-pane":var c=new qx.ui.layout.Grid();
b=new qx.ui.container.Composite(c);
for(var d=0;d<8;d++){c.setColumnFlex(d,
1);
}
for(var d=0;d<7;d++){c.setRowFlex(d,
1);
}var e=new qx.ui.basic.Label();
e.setAllowGrowX(true);
e.setAppearance("datechooser-week");
e.setAnonymous(true);
e.addState("header");
b.add(e,
{column:0,
row:0});
this._weekdayLabelArr=[];
for(var d=0;d<7;d++){var e=new qx.ui.basic.Label();
e.setAllowGrowX(true);
e.setAllowGrowY(true);
e.setAppearance("datechooser-weekday");
e.setSelectable(false);
e.setAnonymous(true);
e.setCursor("default");
b.add(e,
{column:d+1,
row:0});
this._weekdayLabelArr.push(e);
}this._dayLabelArr=[];
this._weekLabelArr=[];
for(var f=0;f<6;f++){var e=new qx.ui.basic.Label();
e.setAllowGrowX(true);
e.setAllowGrowY(true);
e.setAppearance("datechooser-week");
e.setAnonymous(true);
e.setSelectable(false);
e.setCursor("default");
b.add(e,
{column:0,
row:f+1});
this._weekLabelArr.push(e);
for(var g=0;g<7;g++){var e=new qx.ui.basic.Label();
e.setAllowGrowX(true);
e.setAllowGrowY(true);
e.setAppearance("datechooser-day");
e.setSelectable(false);
e.setCursor("default");
e.addListener("mousedown",
this._onDayClicked,
this);
e.addListener("dblclick",
this._onDayDblClicked,
this);
b.add(e,
{column:g+1,
row:f+1});
this._dayLabelArr.push(e);
}}this._add(b);
break;
}return b||arguments.callee.base.call(this,
a);
},
_checkDate:function(a){return (a==null)?null:new Date(a.getTime());
},
_applyDate:function(a,
b){this.fireDataEvent("changeValue",
a==null?"":a.toString());
if((a!=null)&&(this.getShownMonth()!=a.getMonth()||this.getShownYear()!=a.getFullYear())){this.showMonth(a.getMonth(),
a.getFullYear());
}else{var c=(a==null)?-1:a.getDate();
for(var d=0;d<6*7;d++){var e=this._dayLabelArr[d];
if(e.hasState("otherMonth")){if(e.hasState("selected")){e.removeState("selected");
}}else{var f=parseInt(e.getContent());
if(f==c){e.addState("selected");
}else if(e.hasState("selected")){e.removeState("selected");
}}}}},
_onMouseUpDown:function(a){var b=a.getTarget();
if(b==this._getChildControl("navigation-bar")||b==this._getChildControl("date-pane")){a.stopPropagation();
return;
}},
_onNavButtonClicked:function(a){var b=this.getShownYear();
var c=this.getShownMonth();
switch(a.getCurrentTarget()){case this._getChildControl("last-year-button"):b--;
break;
case this._getChildControl("last-month-button"):c--;
if(c<0){c=11;
b--;
}break;
case this._getChildControl("next-month-button"):c++;
if(c>=12){c=0;
b++;
}break;
case this._getChildControl("next-year-button"):b++;
break;
}this.showMonth(c,
b);
},
_onDayClicked:function(a){var b=a.getCurrentTarget().dateTime;
this.setDate(new Date(b));
},
_onDayDblClicked:function(){this.execute();
},
_onkeypress:function(a){var b=null;
var c=null;
var d=null;
if(a.getModifiers()==0){switch(a.getKeyIdentifier()){case "Left":b=-1;
break;
case "Right":b=1;
break;
case "Up":b=-7;
break;
case "Down":b=7;
break;
case "PageUp":c=-1;
break;
case "PageDown":c=1;
break;
case "Escape":if(this.getDate()!=null){this.setDate(null);
return true;
}break;
case "Enter":case "Space":if(this.getDate()!=null){this.execute();
}return;
}}else if(a.isShiftPressed()){switch(a.getKeyIdentifier()){case "PageUp":d=-1;
break;
case "PageDown":d=1;
break;
}}
if(b!=null||c!=null||d!=null){var e=this.getDate();
if(e!=null){e=new Date(e.getTime());
}
if(e==null){e=new Date();
}else{if(b!=null)e.setDate(e.getDate()+b);
if(c!=null)e.setMonth(e.getMonth()+c);
if(d!=null)e.setFullYear(e.getFullYear()+d);
}this.setDate(e);
}},
showMonth:function(a,
b){if((a!=null&&a!=this.getShownMonth())||(b!=null&&b!=this.getShownYear())){if(a!=null){this.setShownMonth(a);
}
if(b!=null){this.setShownYear(b);
}this._updateDatePane();
}},
handleKeyPress:function(a){this._onkeypress(a);
},
_updateDatePane:function(){var a=qx.ui.control.DateChooser;
var b=new Date();
var c=b.getFullYear();
var d=b.getMonth();
var e=b.getDate();
var f=this.getDate();
var g=(f==null)?-1:f.getFullYear();
var h=(f==null)?-1:f.getMonth();
var j=(f==null)?-1:f.getDate();
var k=this.getShownMonth();
var l=this.getShownYear();
var m=qx.locale.Date.getWeekStart();
var n=new Date(this.getShownYear(),
this.getShownMonth(),
1);
this._getChildControl("month-year-label").setContent((new qx.util.format.DateFormat(a.MONTH_YEAR_FORMAT)).format(n));
var o=n.getDay();
var p=(1+7-o)%7;
var q=new qx.util.format.DateFormat("EE");
for(var r=0;r<7;r++){var s=(r+m)%7;
var t=this._weekdayLabelArr[r];
n.setDate(p+s);
t.setContent(q.format(n));
if(qx.locale.Date.isWeekend(s)){t.addState("weekend");
}else{t.removeState("weekend");
}}n=new Date(l,
k,
1);
var u=(7+o-m)%7;
n.setDate(n.getDate()-u);
var v=new qx.util.format.DateFormat("ww");
for(var w=0;w<6;w++){this._weekLabelArr[w].setContent(v.format(n));
for(var r=0;r<7;r++){var t=this._dayLabelArr[w*7+r];
var x=n.getFullYear();
var y=n.getMonth();
var z=n.getDate();
var A=(g==x&&h==y&&j==z);
if(A){t.addState("selected");
}else{t.removeState("selected");
}
if(y!=k){t.addState("otherMonth");
}else{t.removeState("otherMonth");
}var B=(x==c&&y==d&&z==e);
if(B){t.addState("today");
}else{t.removeState("today");
}t.setContent(""+z);
t.dateTime=n.getTime();
n.setDate(n.getDate()+1);
}}}},
destruct:function(){qx.locale.Manager.getInstance().removeEventListener("changeLocale",
this._updateDatePane,
this);
this._disposeObjectDeep("_weekdayLabelArr",
1);
this._disposeObjectDeep("_dayLabelArr",
1);
this._disposeObjectDeep("_weekLabelArr",
1);
}});
qx.Class.define("qx.ui.tooltip.ToolTip",
{extend:qx.ui.popup.Popup,
construct:function(a,
b){arguments.callee.base.call(this);
qx.ui.tooltip.Manager.getInstance();
this.setLayout(new qx.ui.layout.Grow);
this._createChildControl("atom");
if(a!=null){this.setLabel(a);
}
if(b!=null){this.setIcon(b);
}},
properties:{appearance:{refine:true,
init:"tooltip"},
showTimeout:{check:"Integer",
init:1000,
themeable:true},
hideTimeout:{check:"Integer",
init:4000,
themeable:true},
label:{check:"String",
nullable:true,
apply:"_applyLabel"},
icon:{check:"String",
nullable:true,
apply:"_applyIcon",
themeable:true}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "atom":b=new qx.ui.basic.Atom;
this._add(b);
break;
}return b||arguments.callee.base.call(this,
a);
},
_applyIcon:function(a,
b){var c=this._getChildControl("atom");
a==null?c.resetIcon:c.setIcon(a);
},
_applyLabel:function(a,
b){var c=this._getChildControl("atom");
a==null?c.resetLabel():c.setLabel(a);
}}});
qx.Class.define("qx.ui.tooltip.Manager",
{type:"singleton",
extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
var a=qx.core.Init.getApplication().getRoot();
a.addListener("mouseover",
this.__eN,
this,
true);
a.addListener("focusin",
this.__eP,
this,
true);
this.__showTimer=new qx.event.Timer();
this.__showTimer.addListener("interval",
this.__eK,
this);
this.__hideTimer=new qx.event.Timer();
this.__hideTimer.addListener("interval",
this.__eL,
this);
this.__mousePosition={left:0,
top:0};
},
properties:{current:{check:"qx.ui.tooltip.ToolTip",
nullable:true,
apply:"_applyCurrent"}},
members:{_applyCurrent:function(a,
b){if(b&&qx.ui.core.Widget.contains(b,
a)){return;
}if(b){b.exclude();
this.__showTimer.stop();
this.__hideTimer.stop();
}var c=qx.core.Init.getApplication().getRoot();
if(a){this.__showTimer.startWith(a.getShowTimeout());
c.addListener("mouseout",
this.__eO,
this,
true);
c.addListener("focusout",
this.__eQ,
this,
true);
c.addListener("mousemove",
this.__eM,
this,
true);
}else{c.removeListener("mouseout",
this.__eO,
this,
true);
c.removeListener("focusout",
this.__eQ,
this,
true);
c.removeListener("mousemove",
this.__eM,
this,
true);
}},
__eK:function(a){var b=this.getCurrent();
if(b){this.__hideTimer.startWith(b.getHideTimeout());
b.alignToPoint(this.__mousePosition);
b.show();
}this.__showTimer.stop();
},
__eL:function(a){var b=this.getCurrent();
if(b){b.exclude();
}this.__hideTimer.stop();
this.resetCurrent();
},
__eM:function(a){var b=this.__mousePosition;
b.left=a.getDocumentLeft();
b.top=a.getDocumentTop();
},
__eN:function(a){var b=a.getTarget();
var c;
while(b!=null){var c=b.getToolTip();
if(c){break;
}b=b.getLayoutParent();
}if(c){this.setCurrent(c);
}},
__eO:function(a){var b=a.getTarget();
var c=a.getRelatedTarget();
var d=this.getCurrent();
if(d&&(c==d||qx.ui.core.Widget.contains(d,
c))){return;
}if(c&&b&&qx.ui.core.Widget.contains(b,
c)){return;
}if(d&&!c){this.setCurrent(null);
}else{this.resetCurrent();
}},
__eP:function(a){var b=a.getTarget();
var c=b.getToolTip();
if(c!=null){this.setCurrent(c);
}},
__eQ:function(a){var b=a.getTarget();
if(!b){return;
}var c=this.getCurrent();
if(c&&c==b.getToolTip()){this.setCurrent(null);
}}},
destruct:function(){this._disposeObjects("__showTimer",
"__hideTimer");
this._disposeFields("__mousePosition");
}});
qx.Class.define("qx.fx.effect.core.Fade",
{extend:qx.fx.Base,
properties:{modifyDisplay:{init:true,
check:"Boolean"},
from:{init:1.0,
refine:true},
to:{init:0.0,
refine:true}},
members:{update:function(a){arguments.callee.base.call(this);
qx.bom.element.Opacity.set(this._element,
a);
},
beforeSetup:function(){arguments.callee.base.call(this);
if((this.getModifyDisplay())&&(this.getTo()>0)){qx.bom.element.Style.set(this._element,
"display",
"block");
}qx.bom.element.Opacity.set(this._element,
this.getFrom());
},
afterFinishInternal:function(){if((this.getModifyDisplay())&&(this.getTo()==0)){qx.bom.element.Style.set(this._element,
"display",
"none");
}}}});
qx.Class.define("qx.ui.table.cellrenderer.Default",
{extend:qx.ui.table.cellrenderer.Abstract,
statics:{STYLEFLAG_ALIGN_RIGHT:1,
STYLEFLAG_BOLD:2,
STYLEFLAG_ITALIC:4},
properties:{useAutoAlign:{check:"Boolean",
init:true}},
members:{_getStyleFlags:function(a){if(this.getUseAutoAlign()){if(typeof a.value=="number"){return qx.ui.table.cellrenderer.Default.STYLEFLAG_ALIGN_RIGHT;
}}},
_getCellClass:function(a){var b=arguments.callee.base.call(this,
a);
if(!b){return "";
}var c=this._getStyleFlags(a);
if(c&qx.ui.table.cellrenderer.Default.STYLEFLAG_ALIGN_RIGHT){b+=" qooxdoo-table-cell-right";
}
if(c&qx.ui.table.cellrenderer.Default.STYLEFLAG_BOLD){b+=" qooxdoo-table-cell-bold";
}
if(c&qx.ui.table.cellrenderer.Default.STYLEFLAG_ITALIC){b+=" qooxdoo-table-cell-italic";
}return b;
},
_getContentHtml:function(a){return qx.bom.String.escape(this._formatValue(a));
},
_formatValue:function(a){var b=a.value;
if(b==null){return "";
}
if(typeof b=="string"){return b;
}else if(typeof b=="number"){if(!qx.ui.table.cellrenderer.Default._numberFormat){qx.ui.table.cellrenderer.Default._numberFormat=new qx.util.format.NumberFormat();
qx.ui.table.cellrenderer.Default._numberFormat.setMaximumFractionDigits(2);
}var c=qx.ui.table.cellrenderer.Default._numberFormat.format(b);
}else if(b instanceof Date){c=qx.util.format.DateFormat.getDateInstance().format(b);
}else{c=b;
}return c;
}}});
qx.Class.define("qx.ui.table.cellrenderer.Conditional",
{extend:qx.ui.table.cellrenderer.Default,
construct:function(a,
b,
c,
d){arguments.callee.base.call(this);
this.numericAllowed=["==",
"!=",
">",
"<",
">=",
"<="];
this.betweenAllowed=["between",
"!between"];
this.conditions=[];
this._defaultTextAlign=a||"";
this._defaultColor=b||"";
this._defaultFontStyle=c||"";
this._defaultFontWeight=d||"";
},
members:{__eR:function(a,
b){if(a[1]!=null){b["text-align"]=a[1];
}
if(a[2]!=null){b["color"]=a[2];
}
if(a[3]!=null){b["font-style"]=a[3];
}
if(a[4]!=null){b["font-weight"]=a[4];
}},
addNumericCondition:function(a,
b,
c,
d,
e,
f,
g){var h=null;
if(qx.lang.Array.contains(this.numericAllowed,
a)){if(b!=null){h=[a,
c,
d,
e,
f,
b,
g];
}}
if(h!=null){this.conditions.push(h);
}else{throw new Error("Condition not recognized or value is null!");
}},
addBetweenCondition:function(a,
b,
c,
d,
e,
f,
g,
h){if(qx.lang.Array.contains(this.betweenAllowed,
a)){if(b!=null&&c!=null){var i=[a,
d,
e,
f,
g,
b,
c,
h];
}}
if(i!=null){this.conditions.push(i);
}else{throw new Error("Condition not recognized or value1/value2 is null!");
}},
addRegex:function(a,
b,
c,
d,
e,
f){if(a!=null){var g=["regex",
b,
c,
d,
e,
a,
f];
}
if(g!=null){this.conditions.push(g);
}else{throw new Error("regex cannot be null!");
}},
_getCellStyle:function(a){if(!this.conditions.length){return a.style||"";
}var b=a.table.getTableModel();
var c;
var d;
var e;
var f={"text-align":this._defaultTextAlign,
"color":this._defaultColor,
"font-style":this._defaultFontStyle,
"font-weight":this._defaultFontWeight};
for(c in this.conditions){d=false;
if(qx.lang.Array.contains(this.numericAllowed,
this.conditions[c][0])){if(this.conditions[c][6]==null){e=a.value;
}else{e=b.getValueById(this.conditions[c][6],
a.row);
}
switch(this.conditions[c][0]){case "==":if(e==this.conditions[c][5]){d=true;
}break;
case "!=":if(e!=this.conditions[c][5]){d=true;
}break;
case ">":if(e>this.conditions[c][5]){d=true;
}break;
case "<":if(e<this.conditions[c][5]){d=true;
}break;
case ">=":if(e>=this.conditions[c][5]){d=true;
}break;
case "<=":if(e<=this.conditions[c][5]){d=true;
}break;
}}else if(qx.lang.Array.contains(this.betweenAllowed,
this.conditions[c][0])){if(this.conditions[c][7]==null){e=a.value;
}else{e=b.getValueById(this.conditions[c][7],
a.row);
}
switch(this.conditions[c][0]){case "between":if(e>=this.conditions[c][5]&&e<=this.conditions[c][6]){d=true;
}break;
case "!between":if(e<this.conditions[c][5]&&e>this.conditions[c][6]){d=true;
}break;
}}else if(this.conditions[c][0]=="regex"){if(this.conditions[c][6]==null){e=a.value;
}else{e=b.getValueById(this.conditions[c][6],
a.row);
}var g=new RegExp(this.conditions[c][5],
'g');
d=g.test(e);
}if(d==true){this.__eR(this.conditions[c],
f);
}}var h=[];
for(var j in f){if(f[j]){h.push(j,
":",
f[j],
";");
}}return h.join("");
}}});
qx.Class.define("qx.ui.table.cellrenderer.Date",
{extend:qx.ui.table.cellrenderer.Conditional,
construct:function(a,
b,
c,
d){arguments.callee.base.call(this,
a,
b,
c,
d);
this.initDateFormat();
},
properties:{dateFormat:{check:"qx.util.format.DateFormat",
init:null,
apply:"_applyDateFormat"}},
members:{_applyDateFormat:function(a,
b){var c;
if(a){c=function(d){if(d.value){return qx.bom.String.escape(a.format(d.value));
}else{return "";
}};
}else{c=function(d){return d.value||"";
};
}this._getContentHtml=c;
},
_getCellClass:function(a){return "qooxdoo-table-cell";
}}});
qx.Class.define("qx.fx.effect.combination.Puff",
{extend:qx.fx.Base,
construct:function(a){arguments.callee.base.call(this,
a);
this._scaleEffect=new qx.fx.effect.core.Scale(this._element);
this._fadeEffect=new qx.fx.effect.core.Fade(this._element);
this._mainEffect=new qx.fx.effect.core.Parallel(this._scaleEffect,
this._fadeEffect);
},
properties:{modifyDisplay:{init:true,
check:"Boolean"}},
members:{afterFinishInternal:function(){if(this.getModifyDisplay()){qx.bom.element.Style.set(this._element,
"display",
"none");
}},
start:function(){if(!arguments.callee.base.call(this)){return;
}var a={opacity:qx.bom.element.Style.get(this._element,
"opacity")};
this._fadeEffect.afterFinishInternal=function(){for(var b in a){qx.bom.element.Style.set(this._element,
b,
a[b]);
}};
this._scaleEffect.set({scaleTo:200,
sync:true,
scaleFromCenter:true,
scaleContent:true,
restoreAfterFinish:true});
this._fadeEffect.set({sync:true,
to:0.0,
modifyDisplay:false});
this._mainEffect.start();
}},
destruct:function(){this._disposeArray("_effects");
this._disposeObjects("_mainEffect");
}});
qx.Class.define("qx.core.Package",
{statics:{loadPart:function(a,
b,
c){window.qxloader.loadPart(a,
b,
c);
},
loadScript:function(a,
b,
c){window.qxloader.loadScript(a,
b,
c);
}}});
qx.Class.define("qx.log.appender.Console",
{statics:{init:function(){var a=['.qxconsole{z-index:10000;width:600px;height:300px;top:0px;right:0px;position:absolute;border-left:1px solid black;color:black;border-bottom:1px solid black;color:black;font-family:Consolas,Monaco,monospace;font-size:11px;line-height:1.2;}',
'.qxconsole .control{background:#cdcdcd;border-bottom:1px solid black;padding:4px 8px;}',
'.qxconsole .control a{text-decoration:none;color:black;}',
'.qxconsole .messages{background:white;height:100%;width:100%;overflow:auto;}',
'.qxconsole .messages div{padding:0px 4px;}',
'.qxconsole .messages .user-command{color:blue}',
'.qxconsole .messages .user-result{background:white}',
'.qxconsole .messages .user-error{background:#FFE2D5}',
'.qxconsole .messages .level-debug{background:white}',
'.qxconsole .messages .level-info{background:#DEEDFA}',
'.qxconsole .messages .level-warn{background:#FFF7D5}',
'.qxconsole .messages .level-error{background:#FFE2D5}',
'.qxconsole .messages .level-user{background:#E3EFE9}',
'.qxconsole .messages .type-string{color:black;font-weight:normal;}',
'.qxconsole .messages .type-number{color:#155791;font-weight:normal;}',
'.qxconsole .messages .type-boolean{color:#15BC91;font-weight:normal;}',
'.qxconsole .messages .type-array{color:#CC3E8A;font-weight:bold;}',
'.qxconsole .messages .type-map{color:#CC3E8A;font-weight:bold;}',
'.qxconsole .messages .type-key{color:#565656;font-style:italic}',
'.qxconsole .messages .type-class{color:#5F3E8A;font-weight:bold}',
'.qxconsole .messages .type-instance{color:#565656;font-weight:bold}',
'.qxconsole .messages .type-stringify{color:#565656;font-weight:bold}',
'.qxconsole .command{background:white;padding:2px 4px;border-top:1px solid black;}',
'.qxconsole .command input{width:100%;border:0 none;font-family:Consolas,Monaco,monospace;font-size:11px;line-height:1.2;}',
'.qxconsole .command input:focus{outline:none;}'];
qx.bom.Stylesheet.createElement(a.join(""));
var b=['<div class="qxconsole">',
'<div class="control"><a href="javascript:qx.log.appender.Console.clear()">Clear</a> | <a href="javascript:qx.log.appender.Console.toggle()">Hide</a></div>',
'<div class="messages">',
'</div>',
'<div class="command">',
'<input type="text"/>',
'</div>',
'</div>'];
var c=document.createElement("DIV");
c.innerHTML=b.join("");
var d=c.firstChild;
document.body.appendChild(c.firstChild);
this.__main=d;
this.__log=d.childNodes[1];
this.__cmd=d.childNodes[2].firstChild;
this.__eV();
qx.log.Logger.register(this);
qx.core.ObjectRegistry.register(this);
},
dispose:function(){qx.event.Registration.removeListener(document.documentElement,
"keydown",
this.__eW,
this);
qx.log.Logger.unregister(this);
},
clear:function(){this.__log.innerHTML="";
},
process:function(a){this.__log.appendChild(qx.log.appender.Util.toHtml(a));
this.__eS();
},
__eS:function(){this.__log.scrollTop=this.__log.scrollHeight;
},
__eT:true,
toggle:function(){if(!this.__main){this.init();
}else if(this.__main.style.display=="none"){this.__main.style.display="block";
this.__log.scrollTop=this.__log.scrollHeight;
}else{this.__main.style.display="none";
}},
__eU:[],
execute:function(){var a=this.__cmd.value;
if(a==""){return;
}
if(a=="clear"){return this.clear();
}var b=document.createElement("div");
b.innerHTML=qx.log.appender.Util.escapeHTML(">>> "+a);
b.className="user-command";
this.__eU.push(a);
this.__lastCommand=this.__eU.length;
this.__log.appendChild(b);
this.__eS();
try{var c=window.eval(a);
}catch(ex){qx.log.Logger.error(ex);
}
if(c!==undefined){qx.log.Logger.debug(c);
}},
__eV:function(a){this.__log.style.height=(this.__main.clientHeight-this.__main.firstChild.offsetHeight-this.__main.lastChild.offsetHeight)+"px";
},
__eW:function(a){var b=a.getKeyIdentifier();
if((b=="F7")||(b=="D"&&a.isCtrlPressed())){this.toggle();
a.preventDefault();
}if(!this.__main){return;
}if(!qx.dom.Hierarchy.contains(this.__main,
a.getTarget())){return;
}if(b=="Enter"&&this.__cmd.value!=""){this.execute();
this.__cmd.value="";
}if(b=="Up"||b=="Down"){this.__lastCommand+=b=="Up"?-1:1;
this.__lastCommand=Math.min(Math.max(0,
this.__lastCommand),
this.__eU.length);
var c=this.__eU[this.__lastCommand];
this.__cmd.value=c||"";
this.__cmd.select();
}}},
defer:function(a){qx.event.Registration.addListener(document.documentElement,
"keydown",
a.__eW,
a);
}});
qx.Class.define("qx.log.appender.Util",
{statics:{toHtml:function(a){var b=[];
var c,
d,
e,
f;
b.push("<span class='offset'>",
this.formatOffset(a.offset),
"</span> ");
if(a.object){var g=qx.core.ObjectRegistry.fromHashCode(a.object);
if(g){b.push("<span class='object' title='Object instance with hash code: "+g.$$hash+"'>",
g.classname,
"[",
g.$$hash,
"]</span>: ");
}}else if(a.clazz){b.push("<span class='object'>"+a.clazz.classname,
"</span>: ");
}var h=a.items;
for(var k=0,
l=h.length;k<l;k++){c=h[k];
d=c.text;
if(d instanceof Array){var f=[];
for(var m=0,
n=d.length;m<n;m++){e=d[m];
if(typeof e==="string"){f.push("<span>"+this.escapeHTML(e)+"</span>");
}else if(e.key){f.push("<span class='type-key'>"+e.key+"</span>:<span class='type-"+e.type+"'>"+this.escapeHTML(e.text)+"</span>");
}else{f.push("<span class='type-"+e.type+"'>"+this.escapeHTML(e.text)+"</span>");
}}b.push("<span class='type-"+c.type+"'>");
if(c.type==="map"){b.push("{",
f.join(", "),
"}");
}else{b.push("[",
f.join(", "),
"]");
}b.push("</span>");
}else{b.push("<span class='type-"+c.type+"'>"+this.escapeHTML(d)+"</span> ");
}}var o=document.createElement("DIV");
o.innerHTML=b.join("");
o.className="level-"+a.level;
return o;
},
formatOffset:function(a,
b){var c=a.toString();
var d=(b||6)-c.length;
var e="";
for(var f=0;f<d;f++){e+="0";
}return e+c;
},
escapeHTML:function(a){return String(a).replace(/[<>&"']/g,
this.__eX);
},
__eX:function(a){var b={"<":"&lt;",
">":"&gt;",
"&":"&amp;",
"'":"&#39;",
'"':"&quot;"};
return b[a]||"?";
}}});
qx.Interface.define("qx.ui.form.IRadioItem",
{extend:qx.ui.form.IFormElement,
events:{"changeChecked":"qx.event.type.Data"},
members:{setChecked:function(a){this.assertType(a,
"boolean");
},
getChecked:function(){},
setGroup:function(a){this.assertInstance(a,
qx.ui.form.RadioGroup);
},
getGroup:function(){}}});
qx.Class.define("qx.ui.groupbox.RadioGroupBox",
{extend:qx.ui.groupbox.GroupBox,
implement:qx.ui.form.IRadioItem,
properties:{appearance:{refine:true,
init:"radio-groupbox"}},
events:{"changeChecked":"qx.event.type.Data",
"changeName":"qx.event.type.Data",
"changeValue":"qx.event.type.Data"},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "legend":b=new qx.ui.form.RadioButton;
b.setChecked(true);
b.addListener("changeChecked",
this._onRadioChangeChecked,
this);
b.addListener("changeName",
this._onRadioChangeName,
this);
b.addListener("changeValue",
this._onRadioChangeValue,
this);
this._add(b);
}return b||arguments.callee.base.call(this,
a);
},
_onRadioChangeChecked:function(a){var b=a.getData();
this.getChildrenContainer().setEnabled(b);
this.fireDataEvent("changeChecked",
b);
},
_onRadioChangeName:function(a){this.fireDataEvent("changeName",
a.getData());
},
_onRadioChangeValue:function(a){this.fireDataEvent("changeValue",
a.getData());
},
getGroup:function(){return this._getChildControl("legend").getGroup();
},
setGroup:function(a){var b=this._getChildControl("legend");
return a?b.setGroup(a):b.resetGroup();
},
getName:function(){return this._getChildControl("legend").getName();
},
setName:function(a){var b=this._getChildControl("legend");
return a?b.setName(a):b.resetName();
},
getValue:function(){return this._getChildControl("legend").getValue();
},
setValue:function(a){var b=this._getChildControl("legend");
return a?b.setValue(a):b.resetValue();
},
getChecked:function(){return this._getChildControl("legend").getChecked();
},
setChecked:function(a){var b=this._getChildControl("legend");
return a?b.setChecked(a):b.resetChecked();
},
getLabel:function(){return this._getChildControl("legend").getLabel();
}}});
qx.Class.define("qx.ui.form.RadioButton",
{extend:qx.ui.form.Button,
implement:qx.ui.form.IRadioItem,
construct:function(a){{this.assertArgumentsCount(arguments,
0,
1);
};
arguments.callee.base.call(this,
a);
this.addListener("execute",
this._onExecute);
this.addListener("keypress",
this._onKeyPress);
},
properties:{group:{check:"qx.ui.form.RadioGroup",
nullable:true,
apply:"_applyGroup"},
checked:{check:"Boolean",
init:false,
apply:"_applyChecked",
event:"changeChecked"},
appearance:{refine:true,
init:"radiobutton"},
allowGrowX:{refine:true,
init:false}},
members:{isTabable:function(){return this.isFocusable()&&this.isChecked();
},
_applyChecked:function(a,
b){a?this.addState("checked"):this.removeState("checked");
},
_applyGroup:function(a,
b){if(b){b.remove(this);
}
if(a){a.add(this);
}},
_onExecute:function(a){this.setChecked(true);
},
_onKeyPress:function(a){var b=this.getGroup();
if(!b){return;
}
switch(a.getKeyIdentifier()){case "Left":case "Up":b.selectPrevious(this);
break;
case "Right":case "Down":b.selectNext(this);
break;
}}}});
qx.Class.define("qx.util.ExtendedColor",
{statics:{EXTENDED:{transparent:[-1,
-1,
-1],
aliceblue:[240,
248,
255],
antiquewhite:[250,
235,
215],
aqua:[0,
255,
255],
aquamarine:[127,
255,
212],
azure:[240,
255,
255],
beige:[245,
245,
220],
bisque:[255,
228,
196],
black:[0,
0,
0],
blanchedalmond:[255,
235,
205],
blue:[0,
0,
255],
blueviolet:[138,
43,
226],
brown:[165,
42,
42],
burlywood:[222,
184,
135],
cadetblue:[95,
158,
160],
chartreuse:[127,
255,
0],
chocolate:[210,
105,
30],
coral:[255,
127,
80],
cornflowerblue:[100,
149,
237],
cornsilk:[255,
248,
220],
crimson:[220,
20,
60],
cyan:[0,
255,
255],
darkblue:[0,
0,
139],
darkcyan:[0,
139,
139],
darkgoldenrod:[184,
134,
11],
darkgray:[169,
169,
169],
darkgreen:[0,
100,
0],
darkgrey:[169,
169,
169],
darkkhaki:[189,
183,
107],
darkmagenta:[139,
0,
139],
darkolivegreen:[85,
107,
47],
darkorange:[255,
140,
0],
darkorchid:[153,
50,
204],
darkred:[139,
0,
0],
darksalmon:[233,
150,
122],
darkseagreen:[143,
188,
143],
darkslateblue:[72,
61,
139],
darkslategray:[47,
79,
79],
darkslategrey:[47,
79,
79],
darkturquoise:[0,
206,
209],
darkviolet:[148,
0,
211],
deeppink:[255,
20,
147],
deepskyblue:[0,
191,
255],
dimgray:[105,
105,
105],
dimgrey:[105,
105,
105],
dodgerblue:[30,
144,
255],
firebrick:[178,
34,
34],
floralwhite:[255,
250,
240],
forestgreen:[34,
139,
34],
fuchsia:[255,
0,
255],
gainsboro:[220,
220,
220],
ghostwhite:[248,
248,
255],
gold:[255,
215,
0],
goldenrod:[218,
165,
32],
gray:[128,
128,
128],
green:[0,
128,
0],
greenyellow:[173,
255,
47],
grey:[128,
128,
128],
honeydew:[240,
255,
240],
hotpink:[255,
105,
180],
indianred:[205,
92,
92],
indigo:[75,
0,
130],
ivory:[255,
255,
240],
khaki:[240,
230,
140],
lavender:[230,
230,
250],
lavenderblush:[255,
240,
245],
lawngreen:[124,
252,
0],
lemonchiffon:[255,
250,
205],
lightblue:[173,
216,
230],
lightcoral:[240,
128,
128],
lightcyan:[224,
255,
255],
lightgoldenrodyellow:[250,
250,
210],
lightgray:[211,
211,
211],
lightgreen:[144,
238,
144],
lightgrey:[211,
211,
211],
lightpink:[255,
182,
193],
lightsalmon:[255,
160,
122],
lightseagreen:[32,
178,
170],
lightskyblue:[135,
206,
250],
lightslategray:[119,
136,
153],
lightslategrey:[119,
136,
153],
lightsteelblue:[176,
196,
222],
lightyellow:[255,
255,
224],
lime:[0,
255,
0],
limegreen:[50,
205,
50],
linen:[250,
240,
230],
magenta:[255,
0,
255],
maroon:[128,
0,
0],
mediumaquamarine:[102,
205,
170],
mediumblue:[0,
0,
205],
mediumorchid:[186,
85,
211],
mediumpurple:[147,
112,
219],
mediumseagreen:[60,
179,
113],
mediumslateblue:[123,
104,
238],
mediumspringgreen:[0,
250,
154],
mediumturquoise:[72,
209,
204],
mediumvioletred:[199,
21,
133],
midnightblue:[25,
25,
112],
mintcream:[245,
255,
250],
mistyrose:[255,
228,
225],
moccasin:[255,
228,
181],
navajowhite:[255,
222,
173],
navy:[0,
0,
128],
oldlace:[253,
245,
230],
olive:[128,
128,
0],
olivedrab:[107,
142,
35],
orange:[255,
165,
0],
orangered:[255,
69,
0],
orchid:[218,
112,
214],
palegoldenrod:[238,
232,
170],
palegreen:[152,
251,
152],
paleturquoise:[175,
238,
238],
palevioletred:[219,
112,
147],
papayawhip:[255,
239,
213],
peachpuff:[255,
218,
185],
peru:[205,
133,
63],
pink:[255,
192,
203],
plum:[221,
160,
221],
powderblue:[176,
224,
230],
purple:[128,
0,
128],
red:[255,
0,
0],
rosybrown:[188,
143,
143],
royalblue:[65,
105,
225],
saddlebrown:[139,
69,
19],
salmon:[250,
128,
114],
sandybrown:[244,
164,
96],
seagreen:[46,
139,
87],
seashell:[255,
245,
238],
sienna:[160,
82,
45],
silver:[192,
192,
192],
skyblue:[135,
206,
235],
slateblue:[106,
90,
205],
slategray:[112,
128,
144],
slategrey:[112,
128,
144],
snow:[255,
250,
250],
springgreen:[0,
255,
127],
steelblue:[70,
130,
180],
tan:[210,
180,
140],
teal:[0,
128,
128],
thistle:[216,
191,
216],
tomato:[255,
99,
71],
turquoise:[64,
224,
208],
violet:[238,
130,
238],
wheat:[245,
222,
179],
white:[255,
255,
255],
whitesmoke:[245,
245,
245],
yellow:[255,
255,
0],
yellowgreen:[154,
205,
50]},
isExtendedColor:function(a){return this.EXTENDED[a]!==undefined;
},
toRgb:function(a){var b=this.EXTENDED[a];
if(b){return b;
}throw new Error("Could not convert other than extended colors to RGB: "+a);
},
toRgbString:function(a){return qx.util.ColorUtil.rgbToRgbString(this.toRgb(a));
}}});
qx.Class.define("qx.ui.tree.SelectionManager",
{extend:qx.ui.core.selection.ScrollArea,
members:{_getSelectableLocationY:function(a){var b=a.getBounds();
if(b){var c=this._widget.getItemOffset(a);
return {top:c,
bottom:c+b.height};
}},
_isSelectable:function(a){return a instanceof qx.ui.tree.AbstractTreeItem;
},
_getSelectableFromTarget:function(a){return this._widget.getTreeItem(a);
},
_getSelectables:function(){return this._widget.getRoot().getItems(true,
false,
this._widget.getHideRoot());
},
_getSelectableRange:function(a,
b){if(a===b){return [a];
}var c=this._getSelectables();
var d=c.indexOf(a);
var e=c.indexOf(b);
if(d<0||e<0){return [];
}
if(d<e){return c.slice(d,
e+1);
}else{return c.slice(e,
d+1);
}},
_getFirstSelectable:function(){return this._getSelectables()[0]||null;
},
_getLastSelectable:function(){var a=this._getSelectables();
if(a.length>0){return a[a.length-1];
}else{return null;
}},
_getRelatedSelectable:function(a,
b){switch(b){case "above":return this._widget.getPreviousSiblingOf(a,
false);
case "under":return this._widget.getNextSiblingOf(a,
false);
case "left":if(a.isOpenable()&&a.isOpen()){a.setOpen(false);
}break;
case "right":if(a.isOpenable()&&!a.isOpen()){a.setOpen(true);
}break;
}return null;
}}});
qx.Class.define("qx.ui.tree.AbstractTreeItem",
{extend:qx.ui.core.Widget,
type:"abstract",
construct:function(){arguments.callee.base.call(this);
this._children=[];
this._setLayout(new qx.ui.layout.HBox());
this._addWidgets();
this.initOpen();
},
properties:{open:{check:"Boolean",
init:false,
event:"changeOpen",
apply:"_applyOpen"},
openSymbolMode:{check:["always",
"never",
"auto"],
init:"auto",
event:"changeOpenSymbolMode",
apply:"_applyOpenSymbolMode"},
indent:{check:"Integer",
init:19,
apply:"_applyIndent",
themeable:true},
parent:{check:"qx.ui.tree.AbstractTreeItem",
nullable:true},
icon:{check:"String",
apply:"_applyIcon",
nullable:true,
themeable:true},
iconOpened:{check:"String",
apply:"_applyIcon",
nullable:true,
themeable:true},
label:{check:"String",
apply:"_applyLabel",
init:"",
dispose:true}},
members:{_addWidgets:function(){throw new Error("Abstract method call.");
},
getLabelObject:function(){if(!this._label){this._label=new qx.ui.basic.Label().set({appearance:this.getAppearance()+"-label",
alignY:"middle"});
}return this._label;
},
getIconObject:function(){if(!this._icon){this._icon=new qx.ui.basic.Image().set({appearance:this.getAppearance()+"-icon",
alignY:"middle"});
this.__eY();
}return this._icon;
},
getTree:function(){var a=this;
while(a.getParent()){a=a.getParent();
}var b=a.getLayoutParent()?a.getLayoutParent().getLayoutParent():0;
if(b&&b instanceof qx.ui.core.ScrollPane){return b.getLayoutParent();
}return null;
},
addWidget:function(a,
b){this._add(a,
b);
},
addSpacer:function(){if(!this._spacer){this._spacer=new qx.ui.core.Spacer();
}else{this._remove(this._spacer);
}this._add(this._spacer);
},
addOpenButton:function(){if(!this._open){this._open=new qx.ui.tree.FolderOpenButton().set({alignY:"middle"});
this._open.addListener("changeOpen",
this._onChangeOpen,
this);
this._open.addListener("resize",
this._updateIndent,
this);
}else{this._remove(this._open);
}this._add(this._open);
},
_onChangeOpen:function(a){if(this.isOpenable()){this.setOpen(a.getData());
}},
addIcon:function(){var a=this.getIconObject();
if(this._iconAdded){this._remove(a);
}this._add(a);
this._iconAdded=true;
},
addLabel:function(a){var b=this.getLabelObject();
if(this._labelAdded){this._remove(b);
}
if(a){this.setLabel(a);
}else{b.setContent(this.getLabel());
}this._add(b);
this._labelAdded=true;
},
addState:function(a){arguments.callee.base.call(this,
a);
var b=this._getChildren();
for(var c=0,
d=b.length;c<d;c++){var e=b[c];
if(e.addState){b[c].addState(a);
}}},
removeState:function(a){arguments.callee.base.call(this,
a);
var b=this._getChildren();
for(var c=0,
d=b.length;c<d;c++){var e=b[c];
if(e.addState){b[c].removeState(a);
}}},
__eY:function(){var a=this.getIconObject();
if(this.isOpen()&&this.getIconOpened()){a.setSource(this.getIconOpened());
}else{a.setSource(this.getIcon());
}},
_applyIcon:function(a,
b){this.__eY();
},
_applyLabel:function(a,
b){this.getLabelObject().setContent(a);
},
_applyOpen:function(a,
b){if(this.hasChildren()){this.getChildrenContainer().setVisibility(a?"visible":"excluded");
}
if(this._open){this._open.setOpen(a);
}this.__eY();
a?this.addState("opened"):this.removeState("opened");
},
isOpenable:function(){var a=this.getOpenSymbolMode();
return (a==="always"||a==="auto"&&this.hasChildren());
},
_shouldShowOpenSymbol:function(){if(!this._open){return false;
}var a=this.getTree();
if(!a.getRootOpenClose()){if(a.getHideRoot()){if(a.getRoot()==this.getParent()){return false;
}}else{if(a.getRoot()==this){return false;
}}}return this.isOpenable();
},
_applyOpenSymbolMode:function(a,
b){this._updateIndent();
},
_updateIndent:function(){if(!this.getTree()){return;
}var a=0;
if(this._open){if(this._shouldShowOpenSymbol()){this._open.show();
a=this._open.getSizeHint().width;
}else{this._open.exclude();
}}this._spacer.setWidth((this.getLevel()+1)*this.getIndent()-a);
},
_applyIndent:function(a,
b){this._updateIndent();
},
getLevel:function(){var a=this.getTree();
if(!a){return;
}var b=this;
var c=-1;
while(b){b=b.getParent();
c+=1;
}if(a.getHideRoot()){c-=1;
}
if(!a.getRootOpenClose()){c-=1;
}return c;
},
syncWidget:function(){this._updateIndent();
},
getChildrenContainer:function(){if(!this._childrenContainer){this._childrenContainer=new qx.ui.container.Composite(new qx.ui.layout.VBox()).set({visibility:this.isOpen()?"visible":"excluded"});
}return this._childrenContainer;
},
getParentChildrenContainer:function(){if(this.getParent()){return this.getParent().getChildrenContainer();
}else if(this.getLayoutParent()){return this.getLayoutParent();
}else{return null;
}},
getChildren:function(){return this._children;
},
hasChildren:function(){return this._children?this._children.length>0:false;
},
getItems:function(a,
b,
c){if(c!==false){var d=[];
}else{var d=[this];
}var e=this.hasChildren()&&(b!==false||this.isOpen());
if(e){var f=this.getChildren();
if(a===false){d=d.concat(f);
}else{for(var g=0,
h=f.length;g<h;g++){d=d.concat(f[g].getItems(a,
b,
false));
}}}return d;
},
recursiveAddToWidgetQueue:function(){var a=this.getItems(true,
true,
false);
for(var b=0,
c=a.length;b<c;b++){qx.ui.core.queue.Widget.add(a[b]);
}},
__fa:function(){if(this.getParentChildrenContainer()){this.getParentChildrenContainer()._addAfter(this.getChildrenContainer(),
this);
}},
add:function(a){var b=this.getChildrenContainer();
var c=this.getTree();
for(var d=0,
e=arguments.length;d<e;d++){var f=arguments[d];
var g=f.getParent();
if(g){g.remove(f);
}f.setParent(this);
var h=this.hasChildren();
b.add(f);
if(f.hasChildren()){b.add(f.getChildrenContainer());
}this._children.push(f);
if(!h){this.__fa();
}
if(c){f.recursiveAddToWidgetQueue();
c.fireNonBubblingEvent("addItem",
qx.event.type.Data,
[f]);
}}
if(c){qx.ui.core.queue.Widget.add(this);
}},
addAt:function(a,
b){{this.assert(b<=this._children.length&&b>=0,
"Invalid child index: "+b);
};
if(b==this._children.length){this.add(a);
return;
}var c=a.getParent();
if(c){c.remove(a);
}var d=this.getChildrenContainer();
a.setParent(this);
var e=this.hasChildren();
var f=this._children[b];
d.addBefore(a,
f);
if(a.hasChildren()){d.addAfter(a.getChildrenContainer(),
a);
}qx.lang.Array.insertAt(this._children,
a,
b);
if(!e){this.__fa();
}
if(this.getTree()){a.recursiveAddToWidgetQueue();
qx.ui.core.queue.Widget.add(this);
}},
addBefore:function(a,
b){{this.assert(this._children.indexOf(b)>=0);
};
this.addAt(a,
this._children.indexOf(b));
},
addAfter:function(a,
b){{this.assert(this._children.indexOf(b)>=0);
};
this.addAt(a,
this._children.indexOf(b)+1);
},
addAtBegin:function(a){this.addAt(a,
0);
},
remove:function(a){for(var b=0,
c=arguments.length;b<c;b++){var d=arguments[b];
if(this._children.indexOf(d)==-1){this.warn("Cannot remove treeitem '"+d+"'. It is not a child of this tree item.");
return;
}var e=this.getChildrenContainer();
if(d.hasChildren()){e.remove(d.getChildrenContainer());
}qx.lang.Array.remove(this._children,
d);
d.setParent(null);
e.remove(d);
}var f=this.getTree();
if(f){f.fireNonBubblingEvent("addItem",
qx.event.type.Data,
[d]);
}qx.ui.core.queue.Widget.add(this);
},
removeAt:function(a){var b=this._children[a];
if(b){this.remove(b);
}},
removeAll:function(){for(var a=this._children.length-1;a>=0;a--){this.remove(this._children[a]);
}}}});
qx.Class.define("qx.ui.tree.FolderOpenButton",
{extend:qx.ui.basic.Image,
include:qx.ui.core.MExecutable,
construct:function(){arguments.callee.base.call(this);
this.initOpen();
this.addListener("keydown",
this._onKeydown);
this.addListener("click",
this._onClick);
this.addListener("mousedown",
this._stopPropagation,
this);
this.addListener("mouseup",
this._stopPropagation,
this);
},
properties:{open:{check:"Boolean",
init:false,
event:"changeOpen",
apply:"_applyOpen"},
appearance:{refine:true,
init:"folder-open-button"}},
members:{_applyOpen:function(a,
b){a?this.addState("opened"):this.removeState("opened");
this.execute();
},
_onKeydown:function(a){switch(a.getKeyIdentifier()){case "Enter":case "Space":this.toggleOpen();
a.stopPropagation();
}},
_stopPropagation:function(a){a.stopPropagation();
},
_onClick:function(a){this.toggleOpen();
a.stopPropagation();
}}});
qx.Class.define("qx.theme.manager.Icon",
{type:"singleton",
extend:qx.core.Object,
properties:{theme:{check:"Theme",
nullable:true,
apply:"_applyTheme",
event:"changeTheme"}},
members:{_applyTheme:function(a,
b){var c=qx.util.AliasManager.getInstance();
a?c.add("icon",
a.resource):c.remove("icon");
}}});
qx.Class.define("qx.ui.table.cellrenderer.Replace",
{extend:qx.ui.table.cellrenderer.Default,
properties:{replaceMap:{check:"Object",
nullable:true,
init:null},
replaceFunction:{check:"Function",
nullable:true,
init:null}},
members:{_getContentHtml:function(a){var b=a.value;
var c=this.getReplaceMap();
var d=this.getReplaceFunction();
var e;
if(c){e=c[b];
if(typeof e!="undefined"){a.value=e;
return qx.bom.String.escape(this._formatValue(a));
}}if(d){a.value=d(b);
}return qx.bom.String.escape(this._formatValue(a));
},
addReversedReplaceMap:function(){var a=this.getReplaceMap();
for(var b in a){var c=a[b];
a[c]=b;
}return true;
}}});
qx.Class.define("qx.ui.table.cellrenderer.AbstractImage",
{extend:qx.ui.table.cellrenderer.Abstract,
type:"abstract",
construct:function(){arguments.callee.base.call(this);
var a=arguments.callee.self;
if(!a.stylesheet){a.stylesheet=qx.bom.Stylesheet.createElement(".qooxdoo-table-cell-icon {"+"  text-align:center;"+"  padding-top:1px;"+"}");
}},
members:{_insetY:2,
_identifyImage:function(a){throw new Error("_identifyImage is abstract");
},
_getImageInfos:function(a){var b=this._identifyImage(a);
if(b==null||typeof b=="string"){b={url:b,
tooltip:null};
}return b;
},
_getCellClass:function(a){return arguments.callee.base.call(this)+" qooxdoo-table-cell-icon";
},
_getContentHtml:function(a){var b=['<div style="display:-moz-inline-box;display:inline-block;vertical-align:top;'];
var c=this._getImageInfos(a);
if(c.url){b.push(qx.bom.element.Background.compile(c.url,
"no-repeat"));
}if(c.imageWidth&&c.imageHeight){b.push('width:',
c.imageWidth,
'px;height:',
c.imageHeight,
'px"');
}var d=c.tooltip;
if(d!=null){b.push('title="',
d,
'" ');
}b.push("></div>");
return b.join("");
}}});
qx.Class.define("qx.ui.table.cellrenderer.Boolean",
{extend:qx.ui.table.cellrenderer.AbstractImage,
construct:function(){arguments.callee.base.call(this);
var a=qx.util.AliasManager.getInstance();
var b=qx.util.ResourceManager;
this._iconUrlTrue=b.toUri(a.resolve("decoration/table/boolean-true.png"));
this._iconUrlFalse=b.toUri(a.resolve("decoration/table/boolean-false.png"));
},
members:{_insetY:5,
_getCellStyle:function(a){return arguments.callee.base.call(this,
a)+";padding-top:4px;";
},
_identifyImage:function(a){var b={imageWidth:11,
imageHeight:11};
switch(a.value){case true:b.url=this._iconUrlTrue;
break;
case false:b.url=this._iconUrlFalse;
break;
default:b.url=null;
break;
}return b;
}}});
qx.Mixin.define("qx.ui.core.MNativeOverflow",
{properties:{overflowX:{check:["hidden",
"visible",
"scroll"],
nullable:true,
apply:"_applyOverflowX"},
overflowY:{check:["hidden",
"visible",
"scroll"],
nullable:true,
apply:"_applyOverflowY"}},
members:{_applyOverflowX:function(a){this.getContentElement().setStyle("overflowX",
a);
},
_applyOverflowY:function(a){this.getContentElement().setStyle("overflowY",
a);
}}});
qx.Interface.define("qx.ui.table.IHeaderRenderer",
{members:{createHeaderCell:function(a){return true;
},
updateHeaderCell:function(a,
b){return true;
}}});
qx.Class.define("qx.ui.table.headerrenderer.Default",
{extend:qx.core.Object,
implement:qx.ui.table.IHeaderRenderer,
statics:{STATE_SORTED:"sorted",
STATE_SORTED_ASCENDING:"sortedAscending"},
properties:{toolTip:{check:"String",
init:null,
nullable:true}},
members:{createHeaderCell:function(a){var b=new qx.ui.table.headerrenderer.HeaderCell();
this.updateHeaderCell(a,
b);
return b;
},
updateHeaderCell:function(a,
b){var c=qx.ui.table.headerrenderer.Default;
b.setLabel(a.name);
var d=b.getToolTip();
if(this.getToolTip()!=null){if(d==null){d=new qx.ui.tooltip.ToolTip(this.getToolTip());
b.setToolTip(d);
}else{d.setLabel(this.getToolTip());
}}a.sorted?b.addState(c.STATE_SORTED):b.removeState(c.STATE_SORTED);
a.sortedAscending?b.addState(c.STATE_SORTED_ASCENDING):b.removeState(c.STATE_SORTED_ASCENDING);
}}});
qx.Class.define("qx.ui.table.headerrenderer.Icon",
{extend:qx.ui.table.headerrenderer.Default,
construct:function(a,
b){arguments.callee.base.call(this);
if(a==null){a="";
}this.setIconUrl(a);
if(b){this.setToolTip(b);
}},
properties:{iconUrl:{check:"String",
init:""}},
members:{updateHeaderCell:function(a,
b){arguments.callee.base.call(this,
a,
b);
b.setIcon(this.getIconUrl());
}}});
qx.Class.define("qx.log.appender.Element",
{extend:qx.core.Object,
construct:function(a){arguments.callee.base.call(this);
var b=['.qxappender .level-debug{background:white}',
'.qxappender .level-info{background:#DEEDFA}',
'.qxappender .level-warn{background:#FFF7D5}',
'.qxappender .level-error{background:#FFE2D5}',
'.qxappender .level-user{background:#E3EFE9}',
'.qxappender .type-string{color:black;font-weight:normal;}',
'.qxappender .type-number{color:#155791;font-weight:normal;}',
'.qxappender .type-boolean{color:#15BC91;font-weight:normal;}',
'.qxappender .type-array{color:#CC3E8A;font-weight:bold;}',
'.qxappender .type-map{color:#CC3E8A;font-weight:bold;}',
'.qxappender .type-key{color:#565656;font-style:italic}',
'.qxappender .type-class{color:#5F3E8A;font-weight:bold}',
'.qxappender .type-instance{color:#565656;font-weight:bold}',
'.qxappender .type-stringify{color:#565656;font-weight:bold}'];
qx.bom.Stylesheet.createElement(b.join(""));
qx.log.Logger.register(this);
},
members:{setElement:function(a){this.clear();
if(a){qx.bom.element.Class.add(a,
"qxappender");
}this.__element=a;
},
clear:function(){var a=this.__element;
if(a){a.innerHTML="";
}},
process:function(a){var b=this.__element;
if(!b){return;
}b.appendChild(qx.log.appender.Util.toHtml(a));
b.scrollTop=b.scrollHeight;
}},
destruct:function(){this._disposeFields("__element");
}});
qx.Class.define("qx.theme.manager.Meta",
{type:"singleton",
extend:qx.core.Object,
properties:{theme:{check:"Theme",
nullable:true,
apply:"_applyTheme",
event:"changeTheme"},
autoSync:{check:"Boolean",
init:true}},
members:{_applyTheme:function(a,
b){var c=null;
var d=null;
var e=null;
var f=null;
var g=null;
if(a){c=a.meta.color||null;
d=a.meta.decoration||null;
e=a.meta.font||null;
f=a.meta.icon||null;
g=a.meta.appearance||null;
}var h=qx.theme.manager.Color.getInstance();
var i=qx.theme.manager.Decoration.getInstance();
var j=qx.theme.manager.Font.getInstance();
var k=qx.theme.manager.Icon.getInstance();
var l=qx.theme.manager.Appearance.getInstance();
h.setTheme(c);
i.setTheme(d);
j.setTheme(e);
k.setTheme(f);
l.setAppearanceTheme(g);
},
initialize:function(){var a=qx.core.Setting;
var b,
c;
b=a.get("qx.theme");
if(b){c=qx.Theme.getByName(b);
if(!c){throw new Error("The meta theme to use is not available: "+b);
}this.setTheme(c);
}b=a.get("qx.colorTheme");
if(b){c=qx.Theme.getByName(b);
if(!c){throw new Error("The color theme to use is not available: "+b);
}qx.theme.manager.Color.getInstance().setTheme(c);
}b=a.get("qx.decorationTheme");
if(b){c=qx.Theme.getByName(b);
if(!c){throw new Error("The decoration theme to use is not available: "+b);
}qx.theme.manager.Decoration.getInstance().setTheme(c);
}b=a.get("qx.fontTheme");
if(b){c=qx.Theme.getByName(b);
if(!c){throw new Error("The font theme to use is not available: "+b);
}qx.theme.manager.Font.getInstance().setTheme(c);
}b=a.get("qx.iconTheme");
if(b){c=qx.Theme.getByName(b);
if(!c){throw new Error("The icon theme to use is not available: "+b);
}qx.theme.manager.Icon.getInstance().setTheme(c);
}b=a.get("qx.appearanceTheme");
if(b){c=qx.Theme.getByName(b);
if(!c){throw new Error("The appearance theme to use is not available: "+b);
}qx.theme.manager.Appearance.getInstance().setAppearanceTheme(c);
}},
__fb:function(a){var b=qx.Theme.getAll();
var c;
var d=[];
for(var e in b){c=b[e];
if(c[a]){d.push(c);
}}return d;
},
getMetaThemes:function(){return this.__fb("meta");
},
getColorThemes:function(){return this.__fb("colors");
},
getDecorationThemes:function(){return this.__fb("decorations");
},
getFontThemes:function(){return this.__fb("fonts");
},
getIconThemes:function(){return this.__fb("icons");
},
getAppearanceThemes:function(){return this.__fb("appearances");
}},
settings:{"qx.theme":"qx.theme.Classic",
"qx.colorTheme":null,
"qx.decorationTheme":null,
"qx.fontTheme":null,
"qx.appearanceTheme":null,
"qx.iconTheme":null}});
qx.Class.define("qx.ui.menu.RadioButton",
{extend:qx.ui.menu.AbstractButton,
implement:qx.ui.form.IRadioItem,
construct:function(a,
b){arguments.callee.base.call(this);
if(a!=null){this.setLabel(a);
}
if(b!=null){this.setMenu(b);
}},
properties:{appearance:{refine:true,
init:"menu-radiobutton"},
value:{check:"String",
nullable:true,
event:"changeValue"},
name:{check:"String",
nullable:true,
event:"changeName"},
group:{check:"qx.ui.form.RadioGroup",
nullable:true,
apply:"_applyGroup"},
checked:{check:"Boolean",
init:false,
apply:"_applyChecked",
event:"changeChecked"}},
members:{_applyChecked:function(a,
b){a?this.addState("checked"):this.removeState("checked");
},
_applyGroup:function(a,
b){if(b){b.remove(this);
}
if(a){a.add(this);
}},
_onMouseUp:function(a){if(a.isLeftPressed()){this.setChecked(true);
}},
_onKeyPress:function(a){this.setChecked(true);
}}});
qx.Class.define("qx.ui.tabview.TabView",
{extend:qx.ui.core.Widget,
construct:function(a){arguments.callee.base.call(this);
this._createChildControl("bar");
this._createChildControl("pane");
var b=this._radioGroup=new qx.ui.form.RadioGroup;
b.setWrap(false);
b.addListener("changeValue",
this._onRadioChangeValue,
this);
if(a==null||a==="top"){this.initBarPosition();
}else if(a){this.setBarPosition(a);
}},
properties:{appearance:{refine:true,
init:"tabview"},
barPosition:{check:["left",
"right",
"top",
"bottom"],
init:"top",
apply:"_applyBarPosition"},
selected:{check:"qx.ui.tabview.Page",
apply:"_applySelected",
event:"changeSelected",
nullable:true}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "bar":b=new qx.ui.container.SlideBar();
b.setZIndex(10);
this._add(b);
break;
case "pane":b=new qx.ui.container.Stack;
b.setZIndex(5);
this._add(b,
{flex:1});
break;
}return b||arguments.callee.base.call(this,
a);
},
add:function(a){{if(!(a instanceof qx.ui.tabview.Page)){throw new Error("Incompatible child for TabView: "+a);
}};
var b=a.getButton();
var c=this._getChildControl("bar");
var d=this._getChildControl("pane");
a.exclude();
this._radioGroup.add(b);
c.add(b);
d.add(a);
a.addState(this.__fc[this.getBarPosition()]);
a.addState("lastTab");
var e=this.getChildren();
if(e[0]==a){a.addState("firstTab");
}else{e[e.length-2].removeState("lastTab");
}},
remove:function(a){var b=this._getChildControl("pane");
var c=this._getChildControl("bar");
var d=a.getButton();
var e=b.getChildren();
if(this.getSelected()==a){var f=e.indexOf(a);
if(f==0){if(e[1]){this.setSelected(e[1]);
}else{this.resetSelected();
}}else{this.setSelected(e[f-1]);
}}c.remove(d);
b.remove(a);
this._radioGroup.remove(d);
a.removeState(this.__fc[this.getBarPosition()]);
if(a.hasState("firstTab")){a.removeState("firstTab");
if(e[0]){e[0].addState("firstTab");
}}
if(a.hasState("lastTab")){a.removeState("lastTab");
if(e.length>0){e[e.length-1].addState("lastTab");
}}},
getChildren:function(){return this._getChildControl("pane").getChildren();
},
indexOf:function(a){return this._getChildControl("pane").indexOf(a);
},
__fc:{top:"barTop",
right:"barRight",
bottom:"barBottom",
left:"barLeft"},
_applyBarPosition:function(a,
b){var c=this._getChildControl("bar");
var d=this._getChildControl("pane");
var e=a=="left"||a=="right";
var f=a=="right"||a=="bottom";
var g=e?qx.ui.layout.HBox:qx.ui.layout.VBox;
var h=this._getLayout();
if(h&&h instanceof g){}else{this._setLayout(h=new g);
}h.setReversed(f);
c.setOrientation(e?"vertical":"horizontal");
var j=this.getChildren();
if(b){var k=this.__fc[b];
c.removeState(k);
for(var m=0,
n=j.length;m<n;m++){j[m].removeState(k);
}}
if(a){var o=this.__fc[a];
c.addState(o);
for(var m=0,
n=j.length;m<n;m++){j[m].addState(o);
}}},
_applySelected:function(a,
b){if(a){this._getChildControl("pane").setSelected(a);
this._radioGroup.setSelected(a.getButton());
}else{this._getChildControl("pane").resetSelected();
this._radioGroup.resetSelected();
}},
_onRadioChangeValue:function(a){this.setSelected(qx.core.ObjectRegistry.fromHashCode(a.getData()));
}}});
qx.Class.define("qx.ui.container.SlideBar",
{extend:qx.ui.core.Widget,
include:[qx.ui.core.MRemoteChildrenHandling,
qx.ui.core.MRemoteLayoutHandling],
construct:function(a){arguments.callee.base.call(this);
var b=this._getChildControl("scrollpane");
if(a!=null){this.setOrientation(a);
}else{this.initOrientation();
}this._add(b,
{flex:1});
},
properties:{appearance:{refine:true,
init:"slidebar"},
orientation:{check:["horizontal",
"vertical"],
init:"horizontal",
apply:"_applyOrientation"}},
members:{getChildrenContainer:function(){return this._getChildControl("content");
},
_getStyleTarget:function(){return this._getChildControl("content");
},
_createChildControlImpl:function(a){var b;
switch(a){case "button-forward":b=new qx.ui.form.RepeatButton;
b.addListener("execute",
this._onExecuteForward,
this);
b.setFocusable(false);
this._add(b);
break;
case "button-backward":b=new qx.ui.form.RepeatButton;
b.addListener("execute",
this._onExecuteBackward,
this);
b.setFocusable(false);
this._addAt(b,
0);
break;
case "content":b=new qx.ui.container.Composite();
this._getChildControl("scrollpane").add(b);
break;
case "scrollpane":b=new qx.ui.core.ScrollPane();
b.addListener("update",
this._onResize,
this);
break;
}return b||arguments.callee.base.call(this,
a);
},
scrollBy:function(a){var b=this._getChildControl("scrollpane");
if(this._isHorizontal){b.scrollByX(a);
}else{b.scrollByY(a);
}},
scrollTo:function(a){var b=this._getChildControl("scrollpane");
if(this._isHorizontal){b.scrollToX(a);
}else{b.scrollToY(a);
}},
_applyOrientation:function(a,
b){if(a=="horizontal"){this._setLayout(new qx.ui.layout.HBox());
this.setLayout(new qx.ui.layout.HBox());
this._isHorizontal=true;
}else{this._setLayout(new qx.ui.layout.VBox());
this.setLayout(new qx.ui.layout.VBox());
this._isHorizontal=false;
}},
_onResize:function(a){var b=this._getChildControl("scrollpane").getChild();
if(!b){return;
}var c=this.getInnerSize();
var d=b.getBounds();
var f=this._isHorizontal?d.width>c.width:d.height>c.height;
f?this._showArrows():this._hideArrows();
},
_onExecuteBackward:function(){this.scrollBy(-20);
},
_onExecuteForward:function(){this.scrollBy(20);
},
_showArrows:function(){this._showChildControl("button-forward");
this._showChildControl("button-backward");
},
_hideArrows:function(){this._excludeChildControl("button-forward");
this._excludeChildControl("button-backward");
this.scrollTo(0);
}}});
qx.Class.define("qx.ui.container.Stack",
{extend:qx.ui.core.Widget,
construct:function(){arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.Grow);
},
properties:{dynamic:{check:"Boolean",
init:false,
apply:"_applyDynamic"},
selected:{check:"qx.ui.core.Widget",
apply:"_applySelected",
event:"change",
nullable:true}},
members:{_applyDynamic:function(a){var b=this._getChildren();
var c=this.getSelected();
var d;
for(var e=0,
f=b.length;e<f;e++){d=b[e];
if(d!=c){if(a){b[e].exclude();
}else{b[e].hide();
}}}},
_applySelected:function(a,
b){if(b){if(this.isDynamic()){b.exclude();
}else{b.hide();
}}
if(a){a.show();
}},
add:function(a){this._add(a);
var b=this.getSelected();
if(!b){this.setSelected(a);
}else if(b!==a){if(this.isDynamic()){a.exclude();
}else{a.hide();
}}},
remove:function(a){this._remove(a);
if(this.getSelected()===a){var b=this._getChildren()[0];
if(b){this.setSelected(b);
}else{this.resetSelected();
}}},
indexOf:function(a){return this._indexOf(a);
},
getChildren:function(){return this._getChildren();
},
previous:function(){var a=this.getSelected();
var b=this._indexOf(a)-1;
var c=this._getChildren();
if(b<0){b=c.length-1;
}var d=c[b];
this.setSelected(d);
},
next:function(){var a=this.getSelected();
var b=this._indexOf(a)+1;
var c=this._getChildren();
var d=c[b]||c[0];
this.setSelected(d);
}}});
qx.Class.define("qx.ui.tabview.Page",
{extend:qx.ui.container.Composite,
construct:function(a,
b){arguments.callee.base.call(this);
this._createChildControl("button");
if(a!=null){this.setLabel(a);
}
if(b!=null){this.setIcon(b);
}},
properties:{appearance:{refine:true,
init:"tabview-page"},
label:{check:"String",
init:"",
apply:"_applyLabel"},
icon:{check:"String",
init:"",
apply:"_applyIcon"}},
members:{_forwardStates:{barTop:1,
barRight:1,
barBottom:1,
barLeft:1,
firstTab:1,
lastTab:1},
_applyIcon:function(a,
b){this._getChildControl("button").setIcon(a);
},
_applyLabel:function(a,
b){this._getChildControl("button").setLabel(a);
},
_applyEnabled:function(a,
b){arguments.callee.base.call(this,
a,
b);
var c=this._getChildControl("button");
a==null?c.resetEnabled():c.setEnabled(a);
},
_createChildControlImpl:function(a){var b;
switch(a){case "button":b=new qx.ui.form.RadioButton;
b.setAllowGrowX(true);
b.setAllowGrowY(true);
b.setValue(this.toHashCode());
this._add(b);
break;
}return b||arguments.callee.base.call(this,
a);
},
getButton:function(){return this._getChildControl("button");
}}});
qx.Class.define("qx.ui.decoration.Single",
{extend:qx.ui.decoration.Abstract,
construct:function(a,
b,
c){arguments.callee.base.call(this);
if(a!==undefined){this.setWidth(a);
}
if(b!==undefined){this.setStyle(b);
}
if(c!==undefined){this.setColor(c);
}},
properties:{widthTop:{check:"Number",
init:0},
widthRight:{check:"Number",
init:0},
widthBottom:{check:"Number",
init:0},
widthLeft:{check:"Number",
init:0},
styleTop:{nullable:true,
check:["solid",
"dotted",
"dashed",
"double"],
init:"solid"},
styleRight:{nullable:true,
check:["solid",
"dotted",
"dashed",
"double"],
init:"solid"},
styleBottom:{nullable:true,
check:["solid",
"dotted",
"dashed",
"double"],
init:"solid"},
styleLeft:{nullable:true,
check:["solid",
"dotted",
"dashed",
"double"],
init:"solid"},
colorTop:{nullable:true,
check:"Color"},
colorRight:{nullable:true,
check:"Color"},
colorBottom:{nullable:true,
check:"Color"},
colorLeft:{nullable:true,
check:"Color"},
backgroundColor:{nullable:true,
check:"Color"},
backgroundImage:{check:"String",
nullable:true},
backgroundRepeat:{check:["repeat",
"repeat-x",
"repeat-y",
"no-repeat",
"scale"],
init:"repeat"},
stretchedImage:{check:"String",
nullable:true},
left:{group:["widthLeft",
"styleLeft",
"colorLeft"]},
right:{group:["widthRight",
"styleRight",
"colorRight"]},
top:{group:["widthTop",
"styleTop",
"colorTop"]},
bottom:{group:["widthBottom",
"styleBottom",
"colorBottom"]},
width:{group:["widthTop",
"widthRight",
"widthBottom",
"widthLeft"],
mode:"shorthand"},
style:{group:["styleTop",
"styleRight",
"styleBottom",
"styleLeft"],
mode:"shorthand"},
color:{group:["colorTop",
"colorRight",
"colorBottom",
"colorLeft"],
mode:"shorthand"}},
members:{_getStyles:function(a,
b){var c=this.getBackgroundRepeat();
var d=null;
if(c==="scale"){c=null;
}else{d=qx.util.ResourceManager.toUri(qx.util.AliasManager.getInstance().resolve(this.getBackgroundImage()));
}var e={"borderTopWidth":this.getWidthTop()+"px",
"borderTopStyle":this.getStyleTop()||"none",
"borderTopColor":this._resolveColor(this.getColorTop()),
"borderRightWidth":this.getWidthRight()+"px",
"borderRightStyle":this.getStyleRight()||"none",
"borderRightColor":this._resolveColor(this.getColorRight()),
"borderBottomWidth":this.getWidthBottom()+"px",
"borderBottomStyle":this.getStyleBottom()||"none",
"borderBottomColor":this._resolveColor(this.getColorBottom()),
"borderLeftWidth":this.getWidthLeft()+"px",
"borderLeftStyle":this.getStyleLeft()||"none",
"borderLeftColor":this._resolveColor(this.getColorLeft()),
"backgroundImage":d?"url("+d+")":null,
"backgroundRepeat":c};
return e;
},
_updateScaledImage:function(a,
b,
c){var d=qx.util.ResourceManager.toUri(qx.util.AliasManager.getInstance().resolve(this.getBackgroundImage()));
if(!d||this.getBackgroundRepeat()!=="scale"){a.removeAll();
return;
}var e=a.getChild(0);
if(!e){e=new qx.html.Image();
a.add(e);
}e.setSource(d);
e.setStyle("height",
"100%");
e.setStyle("width",
"100%");
},
render:function(a,
b,
c,
d,
e){if(e.style||e.init){a.setStyles(this._getStyles());
this._updateScaledImage(a,
b,
c);
}
if(e.bgcolor||e.init){a.setStyle("backgroundColor",
this._resolveColor(d||this.getBackgroundColor())||null);
}
if(e.size||e.init){qx.ui.decoration.Util.updateSize(a,
b,
c,
this.getWidthLeft()+this.getWidthRight(),
this.getWidthTop()+this.getWidthBottom());
}},
_emptyStyles:{borderTopWidth:null,
borderTopStyle:null,
borderTopColor:null,
borderRightWidth:null,
borderRightStyle:null,
borderRightColor:null,
borderBottomWidth:null,
borderBottomStyle:null,
borderBottomColor:null,
borderLeftWidth:null,
borderLeftStyle:null,
borderLeftColor:null,
backgroundColor:null,
backgroundImage:null,
backgroundRepeat:null},
reset:function(a){a.setStyles(this._emptyStyles);
a.removeAll();
},
getInsets:function(){return {top:this.getWidthTop(),
right:this.getWidthRight(),
bottom:this.getWidthBottom(),
left:this.getWidthLeft()};
}}});
qx.Class.define("qx.ui.decoration.Double",
{extend:qx.ui.decoration.Single,
properties:{innerWidthTop:{check:"Number",
init:0},
innerWidthRight:{check:"Number",
init:0},
innerWidthBottom:{check:"Number",
init:0},
innerWidthLeft:{check:"Number",
init:0},
innerWidth:{group:["innerWidthTop",
"innerWidthRight",
"innerWidthBottom",
"innerWidthLeft"],
mode:"shorthand"},
innerColorTop:{nullable:true,
check:"Color"},
innerColorRight:{nullable:true,
check:"Color"},
innerColorBottom:{nullable:true,
check:"Color"},
innerColorLeft:{nullable:true,
check:"Color"},
innerColor:{group:["innerColorTop",
"innerColorRight",
"innerColorBottom",
"innerColorLeft"],
mode:"shorthand"}},
members:{_updateScaledImage:function(a,
b,
c){var a=a.getChild(0);
var d=qx.util.ResourceManager.toUri(qx.util.AliasManager.getInstance().resolve(this.getBackgroundImage()));
if(!d||this.getBackgroundRepeat()!=="scale"){a.removeAll();
return;
}var e=a.getChild(0);
if(!e){e=new qx.html.Image();
a.add(e);
}e.setSource(d);
e.setStyle("height",
"100%");
e.setStyle("width",
"100%");
},
_getInnerStyles:function(a,
b){var c={borderTopWidth:this.getInnerWidthTop()+"px",
borderTopColor:this._resolveColor(this.getInnerColorTop()),
borderRightWidth:this.getInnerWidthRight()+"px",
borderRightColor:this._resolveColor(this.getInnerColorRight()),
borderBottomWidth:this.getInnerWidthBottom()+"px",
borderBottomColor:this._resolveColor(this.getInnerColorBottom()),
borderLeftWidth:this.getInnerWidthLeft()+"px",
borderLeftColor:this._resolveColor(this.getInnerColorLeft()),
backgroundColor:this._resolveColor(this.getBackgroundColor()),
borderStyle:"solid"};
return c;
},
render:function(a,
b,
c,
d,
e){var f=a.getChild(0);
if(!f){f=new qx.html.Element();
f.setStyles({position:"absolute",
top:0,
left:0});
a.add(f);
}
if(e.style||e.bgcolor||e.init){f.setStyles(this._getInnerStyles());
}
if(e.size||e.init){var g=b-(this.getWidthLeft()+this.getWidthRight());
var h=this.getInnerWidthLeft()+this.getInnerWidthRight();
var i=c-(this.getWidthTop()+this.getWidthBottom());
var j=this.getInnerWidthTop()+this.getInnerWidthBottom();
qx.ui.decoration.Util.updateSize(f,
g,
i,
h,
j);
}arguments.callee.base.call(this,
a,
b,
c,
d,
e);
},
reset:function(a){var b=a.getChild(0);
if(b){a.removeAt(0);
}arguments.callee.base.call(this,
a);
},
getInsets:function(){return {top:this.getWidthTop()+this.getInnerWidthTop(),
right:this.getWidthRight()+this.getInnerWidthRight(),
bottom:this.getWidthBottom()+this.getInnerWidthBottom(),
left:this.getWidthLeft()+this.getInnerWidthLeft()};
}}});
qx.Class.define("qx.ui.decoration.Grid",
{extend:qx.ui.decoration.Abstract,
construct:function(a){arguments.callee.base.call(this);
if(a){this.setBaseImage(a);
}},
properties:{baseImage:{check:"String",
nullable:true,
apply:"_changeBaseImage"},
topBorder:{check:"Boolean",
init:true,
apply:"_changeBorderVisibility"},
rightBorder:{check:"Boolean",
init:true,
apply:"_changeBorderVisibility"},
bottomBorder:{check:"Boolean",
init:true,
apply:"_changeBorderVisibility"},
leftBorder:{check:"Boolean",
init:true,
apply:"_changeBorderVisibility"},
insetLeft:{check:"Number",
init:0},
insetRight:{check:"Number",
init:0},
insetBottom:{check:"Number",
init:0},
insetTop:{check:"Number",
init:0},
insets:{group:["insetTop",
"insetRight",
"insetBottom",
"insetLeft"],
mode:"shorthand"}},
members:{_changeBaseImage:function(a){this.__markup=null;
this.__images=null;
},
_changeBorderVisibility:function(a){this.__markup=null;
},
__fd:function(){var a=this.__images||this.__fe();
var d=qx.util.ResourceManager;
var e=d.getClipped(a.tl);
var f=d.getClipped(a.t);
var g=d.getClipped(a.tr);
var h=d.getClipped(a.bl);
var i=d.getClipped(a.b);
var j=d.getClipped(a.br);
var k=d.getClipped(a.l);
var m=d.getClipped(a.c);
var n=d.getClipped(a.r);
{if(!(e&&f&&g&&h&&i&&j&&k&&m&&n)){throw new Error("Invalid source for grid decorator: "+this.getBaseImage()+" => "+a.t);
}};
this.__insets={top:f[4],
bottom:i[4],
left:k[3],
right:n[3]};
var o=this.__insets.top;
var p=this.__insets.bottom;
var q=this.__insets.left;
var s=this.__insets.right;
var u=[];
var v=d.getClipped(k[0]);
var w=v?v[3]:k[3];
var x=d.getClipped(n[0]);
var y=x?x[3]:n[3];
u.push('<div style="position:absolute;top:0;left:0;',
'width:',
q,
'px;height:',
o,
"px;",
qx.bom.element.Background.compile(e[0],
"repeat-x",
e[1],
e[2]),
'"></div>');
u.push('<div style="position:absolute;top:0;',
'left:',
q,
'px;height:',
o,
'px;',
qx.bom.element.Background.compile(f[0],
"repeat-x",
f[1],
f[2]),
'"></div>');
u.push('<div style="position:absolute;top:0;right:0;',
'width:',
s,
'px;height:',
o,
"px;",
qx.bom.element.Background.compile(g[0],
"repeat-x",
g[1],
g[2]),
'"></div>');
u.push('<div style="position:absolute;bottom:0;left:0;',
'width:',
q,
'px;height:',
p,
"px;",
qx.bom.element.Background.compile(h[0],
"repeat-x",
h[1],
h[2]),
'"></div>');
u.push('<div style="position:absolute;bottom:0;',
'left:',
q,
'px;height:',
p,
"px;",
qx.bom.element.Background.compile(i[0],
"repeat-x",
i[1],
i[2]),
'"></div>');
u.push('<div style="position:absolute;bottom:0;right:0;',
'width:',
s,
'px;height:',
p,
"px;",
qx.bom.element.Background.compile(j[0],
"repeat-x",
j[1],
j[2]),
'"></div>');
u.push('<img src="',
d.toUri(k[0]),
'" style="position:absolute;left:'+k[1]+'px;',
'top:',
o,
'px;width:',
w,
'px;',
qx.bom.element.Clip.compile({left:-k[1],
width:q}),
'"/>');
u.push('<img src="',
d.toUri(m[0]),
'" style="position:absolute;',
'top:',
o,
'px;left:',
q,
'px;"/>');
u.push('<img src="',
d.toUri(n[0]),
'" style="position:absolute;',
'right:',
s-(y+n[1]),
'px;top:',
o,
'px;width:',
y,
'px;',
qx.bom.element.Clip.compile({left:-n[1],
width:s}),
'"/>');
return this.__markup=u.join("");
},
__fe:function(){var a=qx.util.AliasManager.getInstance().resolve(this.getBaseImage());
var b=/(.*)(\.[a-z]+)$/.exec(a);
var c=b[1];
var d=b[2];
return this.__images={tl:c+"-tl"+d,
t:c+"-t"+d,
tr:c+"-tr"+d,
bl:c+"-bl"+d,
b:c+"-b"+d,
br:c+"-br"+d,
l:c+"-l"+d,
c:c+"-c"+d,
r:c+"-r"+d};
},
__ff:function(){var a=document.createElement("div");
a.innerHTML=this.__markup||this.__fd();
return a;
},
render:function(a,
b,
c,
d,
e){if(e.style||e.init){if(a._element){var f=a._element;
f.innerHTML=this.__markup||this.__fd();
}else{var f=this.__ff();
}}
if(!f){var f=a._element?a._element:this.__ff();
}var g="px";
if(d){a.setStyle("backgroundColor",
this._resolveColor(d));
}a.setStyle("width",
b+g);
a.setStyle("height",
c+g);
a.setStyle("overflow",
"hidden");
var h=b-this.__insets.left-this.__insets.right;
var i=c-this.__insets.top-this.__insets.bottom;
f.childNodes[1].style.width=f.childNodes[4].style.width=f.childNodes[7].style.width=h+g;
f.childNodes[6].style.height=f.childNodes[7].style.height=f.childNodes[8].style.height=i+g;
if(!a._element){a.setAttribute("html",
f.innerHTML);
}},
reset:function(a){a.setAttribute("html",
"");
},
getInsets:function(){var a={left:this.getInsetLeft(),
right:this.getInsetRight(),
bottom:this.getInsetBottom(),
top:this.getInsetTop()};
return a;
}}});
qx.Class.define("qx.ui.decoration.Beveled",
{extend:qx.ui.decoration.Abstract,
construct:function(a,
b){arguments.callee.base.call(this);
if(a){this.setOuterColor(a);
}
if(b){this.setInnerColor(b);
}},
properties:{innerColor:{check:"Color",
nullable:true,
apply:"_applyInnerColor"},
innerOpacity:{check:"Number",
init:1,
apply:"_applyInnerOpacity"},
outerColor:{check:"Color",
nullable:true,
apply:"_applyOuterColor"},
backgroundImage:{check:"String",
nullable:true,
apply:"_applyBackgroundImage"},
backgroundColor:{check:"Color",
nullable:true,
apply:"_applyBackgroundColor"},
topBorder:{check:"Boolean",
init:true,
apply:"_changeBorderVisibility"},
rightBorder:{check:"Boolean",
init:true,
apply:"_changeBorderVisibility"},
bottomBorder:{check:"Boolean",
init:true,
apply:"_changeBorderVisibility"},
leftBorder:{check:"Boolean",
init:true,
apply:"_changeBorderVisibility"}},
members:{_applyInnerColor:function(a,
b){},
_applyOuterColor:function(a,
b){},
_applyBackgroundImage:function(){},
_applyBackgroundColor:function(){},
_applyInnerOpacity:function(){},
_changeBorderVisibility:function(a){},
render:function(a,
b,
c,
d,
e){if(!a.getChild(0)){var f=new qx.html.Element;
var g=new qx.html.Element;
var h=new qx.html.Element;
var i=new qx.html.Image;
var j=new qx.html.Element;
a.add(f,
g,
h);
h.add(i,
j);
f.setStyle("position",
"absolute");
g.setStyle("position",
"absolute");
h.setStyle("position",
"absolute");
i.setStyle("position",
"absolute");
j.setStyle("position",
"absolute");
}var k="px";
var f=a.getChild(0);
var g=a.getChild(1);
var h=a.getChild(2);
var i=h.getChild(0);
var j=h.getChild(1);
var l="1px solid "+this._resolveColor(this.getOuterColor());
var m="1px solid "+this._resolveColor(this.getInnerColor());
var n=qx.util.ResourceManager.toUri(qx.util.AliasManager.getInstance().resolve(this.getBackgroundImage()));
f.setStyle("border",
l);
f.setStyle("opacity",
0.35);
g.setStyle("borderLeft",
l);
g.setStyle("borderRight",
l);
h.setStyle("borderTop",
l);
h.setStyle("borderBottom",
l);
i.setStyle("backgroundColor",
this._resolveColor(d||this.getBackgroundColor())||null);
i.setAttribute("src",
n);
j.setStyle("border",
m);
j.setStyle("opacity",
this.getInnerOpacity());
var o=1;
var p=1;
a.setStyle("width",
b+k);
a.setStyle("height",
c+k);
f.setStyle("width",
(b-(o*2))+k);
f.setStyle("height",
(c-(o*2))+k);
g.setStyle("width",
(b-(o*2))+k);
g.setStyle("height",
(c-(o*2))+k);
g.setStyle("left",
"0px");
g.setStyle("top",
o+k);
h.setStyle("width",
(b-(o*2))+k);
h.setStyle("height",
(c-(o*2))+k);
h.setStyle("left",
o+k);
h.setStyle("top",
"0px");
i.setStyle("width",
(b-(o*2))+k);
i.setStyle("height",
(c-(o*2))+k);
j.setStyle("width",
(b-(o*2)-(p*2))+k);
j.setStyle("height",
(c-(o*2)-(p*2))+k);
},
reset:function(a){a.setStyles({"width":null,
"height":null});
a.removeAll();
},
getInsets:function(){return {top:this.getTopBorder()?2:0,
right:this.getRightBorder()?2:0,
bottom:this.getBottomBorder()?2:0,
left:this.getLeftBorder()?2:0};
}}});
qx.Class.define("qx.ui.decoration.Rounded",
{extend:qx.ui.decoration.Single,
properties:{radiusTopLeft:{check:"Integer",
init:0},
radiusTopRight:{check:"Integer",
init:0},
radiusBottomRight:{check:"Integer",
init:0},
radiusBottomLeft:{check:"Integer",
init:0},
radius:{group:["radiusTopLeft",
"radiusTopRight",
"radiusBottomRight",
"radiusBottomLeft"],
mode:"shorthand"}},
members:{_getStyles:qx.core.Variant.select("qx.client",
{"gecko":function(a,
b){var c=arguments.callee.base.call(this,
a,
b);
c.MozBorderRadiusTopleft=this.getRadiusTopLeft()+"px";
c.MozBorderRadiusTopright=this.getRadiusTopRight()+"px";
c.MozBorderRadiusBottomright=this.getRadiusBottomRight()+"px";
c.MozBorderRadiusBottomleft=this.getRadiusBottomLeft()+"px";
return c;
},
"webkit":function(a,
b){var c=arguments.callee.base.call(this,
a,
b);
c.WebkitBorderTopLeftRadius=this.getRadiusTopLeft()+"px";
c.WebkitBorderTopRightRadius=this.getRadiusTopRight()+"px";
c.WebkitBorderBottomRightRadius=this.getRadiusBottomRight()+"px";
c.WebkitBorderBottomLeftRadius=this.getRadiusBottomLeft()+"px";
return c;
},
"default":function(a,
b){return arguments.callee.base.call(this,
a,
b);
}}),
reset:qx.core.Variant.select("qx.client",
{"gecko":function(a){arguments.callee.base.call(this,
a);
a.setStyles({MozBorderRadiusTopleft:null,
MozBorderRadiusTopright:null,
MozBorderRadiusBottomright:null,
MozBorderRadiusBottomleft:null});
},
"webkit":function(a){arguments.callee.base.call(this,
a);
a.setStyles({WebkitBorderTopRightRadius:null,
WebkitBorderTopLeftRadius:null,
WebkitBorderBottomRightRadius:null,
WebkitBorderBottomLeftRadius:null});
},
"mshtml":function(a){a.setAttribute("html",
null);
},
"default":function(a){return arguments.callee.base.call(this,
a);
}}),
render:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b,
c,
d,
e){qx.bom.Vml;
var f=this._resolveColor(d||this.getBackgroundColor())||"white";
var g=qx.util.ResourceManager.toUri(qx.util.AliasManager.getInstance().resolve(this.getBackgroundImage()));
if(g){var i='<v:fill type="tile" src="'+g+'"/>';
}else{i="";
}var j=this.getWidthTop();
var k=this.getWidthRight();
var l=this.getWidthBottom();
var m=this.getWidthLeft();
var n=this.getRadiusTopLeft();
var o=this.getRadiusTopRight();
var p=this.getRadiusBottomRight();
var q=this.getRadiusBottomLeft();
var r=b;
var s=c;
var t=m;
var u=r-k;
var v=j;
var x=s-l;
var y=Math.min(n-j,
n-m);
var z=Math.min(o-k,
o-j);
var A=Math.min(p-k,
p-l);
var B=Math.min(q-l,
q-m);
var C=n==0&&o==0&&p==0&&q==0;
var D=j==0&&k==0&&l==0&&m==0;
var E=(j==0||k==0||l==0||m==0);
var F=(this.getColorLeft()==this.getColorTop())&&(this.getColorRight()==this.getColorBottom())&&(this.getColorLeft()==this.getColorBottom());
var G=!C?"true":"false";
if((F&&!E)||D){var H=[];
if(z>0){H.push(' l ',
u-z,
',',
v,
' qx ',
u,
',',
v+z);
}else{H.push(' l ',
u,
',',
v);
}if(A>0){H.push(' l ',
u,
',',
x-A,
' qy ',
u-A,
',',
x);
}else{H.push(' l ',
u,
',',
x);
}if(B>0){H.push(' l ',
t+B,
',',
x,
' qx ',
t,
',',
x-B);
}else{H.push(' l ',
t,
',',
x);
}if(y>0){H.push(' l ',
t,
',',
v+y,
' qy ',
t+y,
',',
v);
}else{H.push(' l ',
t,
',',
v);
}var I=['<v:shape fillcolor="',
f,
'" style=";width:',
r,
';height:',
s,
'">',
'<v:path v="m ',
t,
',',
v,
' ns ',
H.join(""),
' x e"/>',
'</v:shape>'];
if(i){I.push('<v:shape style=";width:',
r,
';height:',
s,
'">',
i,
'<v:path v="m ',
t,
',',
v,
' ns ',
H.join(""),
' x e"/>',
'</v:shape>');
}
if(!D){var J=['<v:shape fillcolor="',
this.getColorLeft(),
'" style=";width:',
r,
';height:',
s,
'">',
'<v:path v="',
' m ',
n,
',0',
' ns l ',
r-o,
',0',
' qx ',
r,
',',
o,
' l ',
r,
',',
s-p,
' qy ',
r-p,
',',
s,
' l ',
q,
',',
s,
' qx ',
0,
',',
s-q,
' l 0,',
n,
' qy ',
n,
',',
0,
' x e"/>',
'</v:shape>'];
}else{J=[];
}var K=['<v:group coordorigin="0 0" coordsize="',
r,
' ',
s,
'" style="position:absolute;top:0;left:0;',
'antialias:',
G,
';width:',
r,
';height:',
s,
'">',
J.join(''),
I.join(''),
'</v:group>'];
}else{if(j>0){var L=['<v:shape fillcolor="',
this.getColorTop(),
'" style=";width:',
r,
';height:',
s,
'">',
'<v:path v="'];
if(y<=0){L.push(' m ',
t,
',',
v,
' ns ');
}else{L.push(' m ',
t+y,
',',
v,
' ns at ',
t,
',',
v,
',',
t+(y*2),
',',
v+(y*2),
',',
t+y,
',',
v,
',',
t,
',',
v);
}L.push(' wa 0,0,',
n*2,
',',
n*2,
',0,',
0,
',',
n,
',0',
' wa ',
r-(o*2),
',0,',
r,
',',
o*2,
',',
r-o,
',',
0,
',',
r,
',',
0);
if(z<=0){L.push(' l ',
u,
',',
v);
}else{L.push('at ',
u-(z*2),
',',
v,
',',
u,
',',
v+(z*2),
',',
u,
',',
v,
',',
u-z,
',',
v);
}L.push(' x e"/></v:shape>');
}else{L=[];
}if(k>0){var M=['<v:shape fillcolor="',
this.getColorRight(),
'" style=";width:',
r,
';height:',
s,
'">',
'<v:path v="'];
if(z<=0){M.push(' m ',
u,
',',
v,
' ns ');
}else{M.push(' m ',
u,
',',
v+z,
' ns at ',
u-(z*2),
',',
v,
',',
u,
',',
v+(z*2),
',',
u,
',',
v+z,
',',
u,
',',
v);
}M.push(' wa ',
r-(o*2),
',0,',
r,
',',
o*2,
',',
r,
',',
0,
',',
r,
',',
o,
' wa ',
r-(p*2),
',',
s-(p*2),
',',
r,
',',
s,
', ',
r,
',',
s-p,
', ',
r,
',',
s);
if(A<=0){M.push(' l ',
u,
',',
x);
}else{M.push('at ',
u-(A*2),
',',
x-(A*2),
',',
u,
',',
x,
',',
u,
',',
x,
',',
u,
',',
x-A);
}M.push(' x e"/></v:shape>');
}else{M=[];
}if(l>0){var N=['<v:shape fillcolor="',
this.getColorBottom(),
'" style=";width:',
r,
';height:',
s,
'">',
'<v:path v="'];
if(A<=0){N.push(' m ',
u,
',',
x,
' ns ');
}else{N.push(' m ',
u-A,
',',
x,
' ns at ',
u-(A*2),
',',
x-(A*2),
',',
u,
',',
x,
',',
u-A,
',',
x,
',',
u,
',',
x);
}N.push(' wa ',
r-(p*2),
',',
s-(p*2),
',',
r,
',',
s,
', ',
r,
',',
s,
', ',
r-p,
',',
s,
' wa 0,',
s-(2*q),
',',
q*2,
',',
s,
', ',
q,
',',
s,
', 0,',
s);
if(B<=0){N.push(' l ',
t,
',',
x);
}else{N.push('at ',
t,
',',
x-(B*2),
',',
t+(B*2),
',',
x,
',',
t,
',',
x,
',',
t+B,
',',
x);
}N.push(' x e"/></v:shape>');
}else{N=[];
}if(m>0){var O=['<v:shape fillcolor="',
this.getColorLeft(),
'" style=";width:',
r,
';height:',
s,
'">',
'<v:path v="'];
if(B<=0){O.push(' m ',
t,
',',
x,
' ns ');
}else{O.push(' m ',
t,
',',
x-B);
O.push('ns at ',
t,
',',
x-(B*2),
',',
t+(B*2),
',',
x,
',',
t,
',',
x-B,
',',
t,
',',
x);
}O.push(' wa 0,',
s-(2*q),
',',
q*2,
',',
s,
', 0,',
s,
', 0,',
s-q,
' wa 0,0,',
n*2,
',',
n*2,
',0,',
n,
',',
0,
',0');
if(y<=0){O.push(' l ',
t,
',',
v);
}else{O.push('at ',
t,
',',
v,
',',
t+(y*2),
',',
v+(y*2),
',',
t,
',',
v,
',',
t,
',',
v+y);
}O.push(' x e"/></v:shape>');
}else{O=[];
}var P=j==0?0:1;
var Q=k==0?0:1;
var R=l==0?0:1;
var S=m==0?0:1;
var I=['<v:shape fillcolor="',
f,
'" style=";width:',
r,
';height:',
s,
'">',
'<v:path v="',
' m ',
n,
',',
P,
' ns l ',
r-o,
',',
P,
' qx ',
r-Q,
',',
o,
' l ',
r-Q,
',',
s-p,
' qy ',
r-p,
',',
s-R,
' l ',
q,
',',
s-R,
' qx ',
S,
',',
s-q,
' l ',
S,
',',
n,
' qy ',
n,
',',
P,
' x e"/>',
'</v:shape>'];
var K=['<v:group coordorigin="0 0" coordsize="',
r,
' ',
s,
'" style="position:absolute;top:0;left:0;',
'antialias:',
G,
';width:',
r,
';height:',
s,
'">',
I.join(''),
L.join(''),
M.join(''),
N.join(''),
O.join(''),
'</v:group>'];
}a.setAttribute("html",
K.join(''));
},
"default":function(a,
b,
c,
d,
e){arguments.callee.base.call(this,
a,
b,
c,
d,
e);
}})}});
qx.Theme.define("qx.theme.modern.Decoration",
{title:"Modern",
resource:"qx/decoration/Modern",
decorations:{"black":{decorator:qx.ui.decoration.Uniform,
style:{width:1,
color:"black"}},
"white":{decorator:qx.ui.decoration.Uniform,
style:{width:1,
color:"white"}},
"dark-shadow":{decorator:qx.ui.decoration.Uniform,
style:{width:1,
color:"border-dark-shadow"}},
"light-shadow":{decorator:qx.ui.decoration.Uniform,
style:{width:1,
color:"border-light-shadow"}},
"light":{decorator:qx.ui.decoration.Uniform,
style:{width:1,
color:"border-light"}},
"dark":{decorator:qx.ui.decoration.Uniform,
style:{width:1,
color:"border-dark"}},
"focus-line":{decorator:qx.ui.decoration.Uniform,
style:{width:1,
color:"focus"}},
"line-right":{decorator:qx.ui.decoration.Single,
style:{widthRight:1,
colorRight:"border-dark-shadow"}},
"line-top":{decorator:qx.ui.decoration.Single,
style:{widthTop:1,
colorTop:"border-dark-shadow"}},
"line-bottom":{decorator:qx.ui.decoration.Single,
style:{widthBottom:1,
colorBottom:"border-dark-shadow"}},
"dark-shadow":{decorator:qx.ui.decoration.Uniform,
style:{width:1,
color:"border-dark-shadow"}},
"outset":{decorator:qx.ui.decoration.Double,
style:{width:1,
innerWidth:1,
color:["border-light-shadow",
"border-dark",
"border-dark",
"border-light-shadow"],
innerColor:["border-light",
"border-dark-shadow",
"border-dark-shadow",
"border-light"]}},
"outset-thin":{decorator:qx.ui.decoration.Single,
style:{width:1,
color:["border-light",
"border-dark-shadow",
"border-dark-shadow",
"border-light"]}},
"inset":{decorator:qx.ui.decoration.Double,
style:{width:1,
innerWidth:1,
color:["border-dark-shadow",
"border-light",
"border-light",
"border-dark-shadow"],
innerColor:["border-dark",
"border-light-shadow",
"border-light-shadow",
"border-dark"]}},
"inset-thin":{decorator:qx.ui.decoration.Single,
style:{width:1,
color:["border-dark-shadow",
"border-light",
"border-light",
"border-dark-shadow"]}},
"focused-inset":{decorator:qx.ui.decoration.Double,
style:{width:1,
innerWidth:1,
color:["border-focused-dark-shadow",
"border-focused-light",
"border-focused-light",
"border-focused-dark-shadow"],
innerColor:["border-focused-dark",
"border-focused-light-shadow",
"border-focused-light-shadow",
"border-focused-dark"]}},
"pane":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/pane/pane.png",
insets:[0,
2,
3,
0]}},
"slider-knob-vertical":{decorator:qx.ui.decoration.Beveled,
style:{backgroundImage:"decoration/scrollbar/slider-knob-bg-vertical.png",
outerColor:"#4d4d4d",
innerColor:"#e1e1e1"}},
"slider-knob-horizontal":{decorator:qx.ui.decoration.Beveled,
style:{backgroundImage:"decoration/scrollbar/slider-knob-bg-horizontal.png",
outerColor:"#4d4d4d",
innerColor:"#e1e1e1"}},
"slider-knob-pressed-vertical":{decorator:qx.ui.decoration.Beveled,
style:{backgroundImage:"decoration/scrollbar/scrollbar-bg-pressed-vertical.png",
outerColor:"#192433",
innerColor:"#e9f5ff"}},
"slider-knob-pressed-horizontal":{decorator:qx.ui.decoration.Beveled,
style:{backgroundImage:"decoration/scrollbar/scrollbar-bg-pressed-horizontal.png",
outerColor:"#192433",
innerColor:"#e9f5ff"}},
"button":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/form/button.png",
insets:2}},
"button-focused":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/form/button-focused.png",
insets:2}},
"button-hovered":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/form/button-hovered.png",
insets:2}},
"button-pressed":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/form/button-pressed.png",
insets:2}},
"button-checked":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/form/button-checked.png",
insets:2}},
"button-checked-focused":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/form/button-checked-focused.png",
insets:2}},
"textfield":{decorator:qx.ui.decoration.Beveled,
style:{outerColor:"border",
innerColor:"white",
backgroundImage:"decoration/form/input.png"}},
"textfield-focused":{decorator:qx.ui.decoration.Beveled,
style:{outerColor:"border",
innerColor:"focus"}},
"listitem":{decorator:qx.ui.decoration.Single,
style:{backgroundImage:"decoration/selection.png",
backgroundRepeat:"scale"}},
"scrollbar-horizontal":{decorator:qx.ui.decoration.Uniform,
style:{backgroundImage:"decoration/scrollbar/scrollbar-bg-horizontal.png",
backgroundRepeat:"repeat-x"}},
"scrollbar-vertical":{decorator:qx.ui.decoration.Uniform,
style:{backgroundImage:"decoration/scrollbar/scrollbar-bg-vertical.png",
backgroundRepeat:"repeat-y"}},
"groupbox-frame":{decorator:qx.ui.decoration.Rounded,
style:{backgroundColor:"#ececec",
color:"#c6c6c6",
radius:5,
width:1}},
"toolbar":{decorator:qx.ui.decoration.Double,
style:{width:1,
innerWidthBottom:1,
color:"#c1c1c1",
innerColorBottom:"#8a8a8a",
style:"solid",
backgroundImage:"decoration/toolbar/toolbar-gradient.png",
backgroundRepeat:"scale"}},
"toolbar-button-hovered":{decorator:qx.ui.decoration.Beveled,
style:{outerColor:"#b6b6b6",
innerColor:"#f8f8f8",
backgroundImage:"decoration/form/button-c.png"}},
"toolbar-button-checked":{decorator:qx.ui.decoration.Beveled,
style:{outerColor:"#b6b6b6",
innerColor:"#f8f8f8",
backgroundImage:"decoration/form/button-checked-c.png"}},
"toolbar-separator":{decorator:qx.ui.decoration.Single,
style:{widthLeft:1,
widthRight:1,
colorLeft:"#b8b8b8",
colorRight:"#f4f4f4",
style:"solid"}},
"toolbar-part-handle":{decorator:qx.ui.decoration.Uniform,
style:{width:7,
style:null,
backgroundImage:"decoration/toolbar/toolbar-handle.png",
backgroundRepeat:"no-repeat"}},
"tabview-pane":{decorator:qx.ui.decoration.Rounded,
style:{width:1,
radius:5,
color:"#00204d",
backgroundColor:"#f8f8f8"}},
"tabview-page-button-top-active":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/tabview/tab-button-top-active.png"}},
"tabview-page-button-top-inactive":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/tabview/tab-button-top-inactive.png"}},
"tabview-page-button-bottom-active":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/tabview/tab-button-bottom-active.png"}},
"tabview-page-button-bottom-inactive":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/tabview/tab-button-bottom-inactive.png"}},
"tabview-page-button-left-active":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/tabview/tab-button-left-active.png"}},
"tabview-page-button-left-inactive":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/tabview/tab-button-left-inactive.png"}},
"tabview-page-button-right-active":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/tabview/tab-button-right-active.png"}},
"tabview-page-button-right-inactive":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/tabview/tab-button-right-inactive.png"}},
"tree-folder":{decorator:qx.ui.decoration.Single,
style:{widthBottom:1,
colorBottom:"#F2F2F2"}},
"tree-folder-selected":{decorator:qx.ui.decoration.Single,
style:{backgroundImage:"decoration/selection.png",
backgroundRepeat:"scale",
widthBottom:1,
colorBottom:"#F2F2F2"}},
"tooltip":{decorator:qx.ui.decoration.Single,
style:{width:1,
color:"#d1d1d1",
style:"solid"}},
"iframe":{decorator:qx.ui.decoration.Double,
style:{width:1,
innerWidth:1,
color:"border",
innerColor:"white",
style:"solid"}},
"splitpane-splitter-vertical":{decorator:qx.ui.decoration.Single,
style:{widthTop:1,
colorTop:"#b8b8b8",
style:"solid"}},
"splitpane-splitter-horizontal":{decorator:qx.ui.decoration.Single,
style:{widthLeft:1,
colorLeft:"#b8b8b8",
style:"solid"}},
"window":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/window/shadow.png",
insets:[3,
8,
8,
4]}},
"window-border":{decorator:qx.ui.decoration.Single,
style:{width:1,
color:"#00204D",
styleTop:null}},
"window-captionbar-active":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/window/captionbar-active.png"}},
"window-captionbar-inactive":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/window/captionbar-inactive.png"}},
"window-statusbar":{decorator:qx.ui.decoration.Grid,
style:{baseImage:"decoration/window/statusbar.png"}},
"table":{decorator:qx.ui.decoration.Single,
style:{width:1,
color:"border-dark-shadow",
style:"solid"}},
"table-statusbar":{decorator:qx.ui.decoration.Single,
style:{widthTop:1,
colorTop:"border-dark-shadow",
style:"solid"}},
"table-scroller-header":{decorator:qx.ui.decoration.Single,
style:{backgroundImage:"decoration/table/header-cell.png",
backgroundRepeat:"scale",
widthBottom:1,
colorBottom:"border-dark-shadow",
style:"solid"}},
"table-header-cell":{decorator:qx.ui.decoration.Double,
style:{backgroundImage:"decoration/table/header-cell.png",
backgroundRepeat:"scale",
widthRight:1,
colorRight:"#F2F2F2",
innerWidthRight:1,
innerColorRight:"#A6A6A6",
style:"solid"}},
"table-header-cell-hovered":{decorator:qx.ui.decoration.Double,
style:{backgroundImage:"decoration/table/header-cell.png",
backgroundRepeat:"scale",
widthRight:1,
colorRight:"#F2F2F2",
innerWidthRight:1,
innerColorRight:"#A6A6A6",
widthBottom:1,
colorBottom:"effect",
style:"solid"}},
"table-column-button":{decorator:qx.ui.decoration.Single,
style:{backgroundImage:"decoration/table/header-cell.png",
backgroundRepeat:"scale",
widthBottom:1,
colorBottom:"border-dark-shadow",
style:"solid"}},
"table-scroller-focus-indicator":{decorator:qx.ui.decoration.Single,
style:{width:2,
color:"table-focus-indicator",
style:"solid"}},
"menu":{decorator:qx.ui.decoration.Single,
style:{backgroundImage:"decoration/menu/background.png",
backgroundRepeat:"scale",
width:1,
color:"border-dark-shadow",
style:"solid"}},
"menu-button-selected":{decorator:qx.ui.decoration.Single,
style:{backgroundImage:"decoration/selection.png",
backgroundRepeat:"scale"}},
"menu-separator":{decorator:qx.ui.decoration.Single,
style:{widthTop:1,
colorTop:"#C5C5C5",
widthBottom:1,
colorBottom:"#FAFAFA"}}}});
qx.Class.define("qx.html.Image",
{extend:qx.html.Element,
construct:function(){arguments.callee.base.call(this,
"img");
},
members:{_applyProperty:function(a,
b){arguments.callee.base.call(this,
a,
b);
if(a=="source"){qx.bom.Image.setSource(this._element,
b);
}},
_createDomElement:function(){return qx.bom.Image.create(this._source);
},
setSource:function(a){this._setProperty("source",
a);
return this;
},
getSource:function(){return this._getProperty("source");
}}});
qx.Class.define("qx.bom.Image",
{statics:{create:function(a,
b){if(!b){b=window;
}var c=b.document.createElement("img");
if(a){c.src=a;
}return c;
},
setSource:function(a,
b){a.src=b;
},
getSource:function(a){return a.src;
}}});
qx.Class.define("qx.bom.Vml",
{statics:{create:function(a,
b,
c){var c=c||window;
var d=c.document.createElement("v:"+(a||"shape"));
if(b){for(var e in b){d.setAttribute(e,
b[e]);
}}return d;
},
createImage:function(a,
b,
c,
d,
e,
f,
g){var h=qx.bom.Vml.create("rect",
{"stroked":"False"});
var i=qx.bom.Vml.create("fill",
{"type":"tile"});
h.appendChild(i);
if(a||b||c){this.updateImage(h,
a,
b,
c,
d,
e,
f,
g);
}return h;
},
updateImage:function(a,
b,
c,
d,
e,
f,
g,
h){var i=qx.bom.element.Style;
var j=qx.bom.element.Attribute;
i.set(a,
"width",
c,
false);
i.set(a,
"height",
d,
false);
var k=a.firstChild;
j.set(k,
"src",
b,
false);
var l=e?(-e)/(g):0;
var m=f?(-f)/(h):0;
j.set(k,
"origin",
l.toFixed(2)+","+m,
false);
}},
defer:function(a){if(qx.core.Variant.isSet("qx.client",
"mshtml")){qx.bom.Stylesheet.createElement("v\\: * { behavior:url(#default#VML);display:inline-block; }");
if(!document.namespaces["v"]){document.namespaces.add("v",
"urn:schemas-microsoft-com:vml");
}}}});
qx.Class.define("qx.ui.table.pane.CellEvent",
{extend:qx.event.type.Mouse,
properties:{row:{check:"Integer"},
column:{check:"Integer"}},
members:{init:function(a,
b,
c,
d){b.clone(this);
this._bubbles=false;
if(c!=null){this.setRow(c);
}else{this.setRow(a._getRowForPagePos(this.getDocumentLeft(),
this.getDocumentTop()));
}
if(d!=null){this.setColumn(d);
}else{this.setColumn(a._getColumnForPageX(this.getDocumentLeft()));
}}}});
qx.Class.define("qx.ui.form.SelectBox",
{extend:qx.ui.form.AbstractSelectBox,
implement:qx.ui.form.IFormElement,
construct:function(){arguments.callee.base.call(this);
this._createChildControl("atom");
this._createChildControl("spacer");
this._createChildControl("arrow");
this.addListener("click",
this._onClick,
this);
this.addListener("mousewheel",
this._onMouseWheel,
this);
this.addListener("keyinput",
this._onKeyInput,
this);
},
properties:{appearance:{refine:true,
init:"selectbox"},
focusable:{refine:true,
init:true},
selected:{check:"qx.ui.form.ListItem",
apply:"_applySelected"}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "spacer":b=new qx.ui.core.Spacer();
this._add(b,
{flex:1});
break;
case "atom":b=new qx.ui.basic.Atom(" ");
this._add(b,
{flex:1});
break;
case "arrow":b=new qx.ui.basic.Image();
this._add(b);
break;
}return b||arguments.callee.base.call(this,
a);
},
_forwardStates:{focused:true},
_applySelected:function(a,
b){var c=this._getChildControl("list");
if(c.getSelectedItem()!=a){c.select(a);
}var d=this._getChildControl("atom");
var e=a.getLabel();
e==null?d.resetLabel():d.setLabel(e);
var f=a.getIcon();
f==null?d.resetIcon():d.setIcon(f);
},
setValue:function(a){this._getChildControl("list").setValue(a);
},
getValue:function(){var a=this.getSelected();
return a?a.getFormValue():null;
},
_onClick:function(a){this.toggle();
},
_onMouseWheel:function(a){if(this._getChildControl("popup").isVisible()){return;
}var b=a.getWheelDelta()>0?1:-1;
var c=this.getChildren();
var d=this.getSelected();
if(!d){d=c[0];
}var f=c.indexOf(d)+b;
var g=c.length-1;
if(f<0){f=0;
}else if(f>=g){f=g;
}this.setSelected(c[f]);
},
_onKeyPress:function(a){if(a.getKeyIdentifier()=="Enter"){this.toggle();
}else{arguments.callee.base.call(this,
a);
}},
_onKeyInput:function(a){var b=a.clone();
b.setTarget(this._list);
b.setBubbles(false);
this._getChildControl("list").dispatchEvent(b);
},
_onListChangeSelection:function(a){var b=a.getData();
if(b.length>0){this.setSelected(b[0]);
}},
_onListChangeValue:function(a){this.fireDataEvent("changeValue",
a.getData());
}}});
qx.Class.define("qx.ui.embed.Canvas",
{extend:qx.ui.core.Widget,
construct:function(a,
b){arguments.callee.base.call(this);
this._deferredDraw=new qx.util.DeferredCall(this.__fg,
this);
this.addListener("resize",
this._onResize,
this);
if(a!==undefined){this.setCanvasWidth(a);
}
if(b!==undefined){this.setCanvasHeight(b);
}},
events:{"redraw":"qx.event.type.Data"},
properties:{syncDimension:{check:"Boolean",
init:false},
canvasWidth:{check:"Integer",
init:300,
apply:"_applyCanvasWidth"},
canvasHeight:{check:"Integer",
init:150,
apply:"_applyCanvasHeight"}},
members:{_createContentElement:function(){return new qx.html.Canvas();
},
__fg:function(){var a=this.getContentElement();
var b=a.getHeight();
var c=a.getWidth();
var d=a.getContext2d();
this._draw(c,
b,
d);
this.fireNonBubblingEvent("redraw",
qx.event.type.Data,
[{width:c,
height:b,
context:d}]);
},
_applyCanvasWidth:function(a,
b){this.getContentElement().setWidth(a);
this._deferredDraw.schedule();
},
_applyCanvasHeight:function(a,
b){this.getContentElement().setHeight(a);
this._deferredDraw.schedule();
},
_onResize:function(a){var b=a.getData();
if(this.getSyncDimension()){this.setCanvasHeight(b.height);
this.setCanvasWidth(b.width);
}},
getContext2d:function(){return this.getContentElement().getContext2d();
},
_draw:function(a,
b,
c){}}});
qx.Class.define("qx.html.Canvas",
{extend:qx.html.Element,
construct:function(){arguments.callee.base.call(this,
"canvas");
this.__canvas=document.createElement("canvas");
},
members:{_createDomElement:function(){return this.__canvas;
},
getCanvas:function(){return this.__canvas;
},
setWidth:function(a){this.__canvas.width=a;
},
getWidth:function(){return this.__canvas.width;
},
setHeight:function(a){this.__canvas.height=a;
},
getHeight:function(){return this.__canvas.height;
},
getContext2d:function(){return this.__canvas.getContext("2d");
}}});
qx.Class.define("qx.fx.effect.core.Consecutive",
{extend:qx.fx.Base,
construct:function(){arguments.callee.base.call(this);
this._effects=arguments;
},
members:{},
destruct:function(){this._disposeArray("_effects");
}});
qx.Bootstrap.define("qx.bom.client.System",
{statics:{NAME:"",
SP1:false,
SP2:false,
WIN95:false,
WIN98:false,
WINME:false,
WINNT4:false,
WIN2000:false,
WINXP:false,
WIN2003:false,
WINVISTA:false,
WINCE:false,
LINUX:false,
SUNOS:false,
FREEBSD:false,
NETBSD:false,
OSX:false,
OS9:false,
SYMBIAN:false,
NINTENDODS:false,
PSP:false,
IPHONE:false,
__fh:{"Windows NT 6.0":"winvista",
"Windows NT 5.2":"win2003",
"Windows NT 5.1":"winxp",
"Windows NT 5.0":"win2000",
"Windows 2000":"win2000",
"Windows NT 4.0":"winnt4",
"Win 9x 4.90":"winme",
"Windows CE":"wince",
"Windows 98":"win98",
"Win98":"win98",
"Windows 95":"win95",
"Win95":"win95",
"Linux":"linux",
"FreeBSD":"freebsd",
"NetBSD":"netbsd",
"SunOS":"sunos",
"Symbian System":"symbian",
"Nitro":"nintendods",
"PSP":"sonypsp",
"Mac OS X 10_5":"osx5",
"Mac OS X 10.5":"osx5",
"Mac OS X 10_4":"osx4",
"Mac OS X 10.4":"osx4",
"Mac OS X 10_3":"osx3",
"Mac OS X 10.3":"osx3",
"Mac OS X 10_2":"osx2",
"Mac OS X 10.2":"osx2",
"Mac OS X 10_1":"osx1",
"Mac OS X 10.1":"osx1",
"Mac OS X 10_0":"osx0",
"Mac OS X 10.0":"osx0",
"Mac OS X":"osx",
"Mac OS 9":"os9"},
__fi:function(){var a=navigator.userAgent;
var b=[];
for(var c in this.__fh){b.push(c);
}var d=new RegExp("("+b.join("|").replace(/\./g,
"\.")+")",
"g");
if(!d.test(a)){throw new Error("Could not detect system: "+a);
}
if(qx.bom.client.Engine.WEBKIT&&RegExp(" Mobile/").test(navigator.userAgent)){this.IPHONE=true;
this.NAME="iphone";
}else{this.NAME=this.__fh[RegExp.$1];
this[this.NAME.toUpperCase()]=true;
if(qx.bom.client.Platform.WIN){if(a.indexOf("Windows NT 5.01")!==-1){this.SP1=true;
}else if(qx.bom.client.Engine.MSHTML&&a.indexOf("SV1")!==-1){this.SP2=true;
}}}}},
defer:function(a){a.__fi();
}});
qx.Class.define("qx.fx.effect.combination.Pulsate",
{extend:qx.fx.Base,
construct:function(a){arguments.callee.base.call(this,
a);
var b=this.getDuration()/6;
var c=0;
this._fadeEffects=[new qx.fx.effect.core.Fade(this._element),
new qx.fx.effect.core.Fade(this._element),
new qx.fx.effect.core.Fade(this._element),
new qx.fx.effect.core.Fade(this._element),
new qx.fx.effect.core.Fade(this._element),
new qx.fx.effect.core.Fade(this._element)];
for(var d=0,
e=this._fadeEffects.length;d<e;d++){this._fadeEffects[d].set({duration:b,
to:((c%2)!=0)?1:0,
from:((c%2)!=0)?0:1,
transition:"sinodial",
modifyDisplay:false});
c++;
}},
properties:{duration:{init:2,
refine:true}},
members:{beforeSetup:function(){this._oldValue=qx.bom.element.Style.get(this._element,
"opacity");
},
start:function(){if(!arguments.callee.base.call(this)){return;
}var a=0;
var b=this;
for(var c=0,
d=this._fadeEffects.length;c<d;c++){this._fadeEffects[c].id=a;
if(a<5){this._fadeEffects[c].afterFinishInternal=function(){b._fadeEffects[this.id+1].start();
};
}a++;
}this._fadeEffects[0].start();
},
afterFinish:function(){qx.bom.element.Style.set(this._element,
"opacity",
this._oldValue);
}},
destruct:function(){this._disposeArray("_fadeEffects");
}});
qx.Theme.define("qx.theme.icon.Oxygen",
{title:"Oxygen",
resource:"qx/icon/Oxygen",
icons:{}});
qx.Class.define("qx.fx.effect.combination.Shrink",
{extend:qx.fx.Base,
construct:function(a){arguments.callee.base.call(this,
a);
this._moveEffect=new qx.fx.effect.core.Move(this._element);
this._scaleEffect=new qx.fx.effect.core.Scale(this._element);
this._mainEffect=new qx.fx.effect.core.Parallel(this._moveEffect,
this._scaleEffect);
},
properties:{direction:{init:"center",
check:["top-left",
"top-right",
"bottom-left",
"bottom-right",
"center"]},
moveTransition:{init:"sinodial",
check:["linear",
"easeInQuad",
"easeOutQuad",
"sinodial",
"reverse",
"flicker",
"wobble",
"pulse",
"spring",
"none",
"full"]},
scaleTransition:{init:"sinodial",
check:["linear",
"easeInQuad",
"easeOutQuad",
"sinodial",
"reverse",
"flicker",
"wobble",
"pulse",
"spring",
"none",
"full"]},
modifyDisplay:{init:true,
check:"Boolean"}},
members:{setup:function(){arguments.callee.base.call(this);
qx.bom.element.Style.set(this._element,
"overflow",
"hidden");
},
afterFinishInternal:function(){arguments.callee.base.call(this);
qx.bom.element.Style.set(this._element,
"overflow",
"visible");
var a;
for(var b in this._oldStyle){a=this._oldStyle[b];
if(b!="overflow"){a+="px";
}qx.bom.element.Style.set(this._element,
b,
a);
}
if(this.getModifyDisplay()){qx.bom.element.Style.set(this._element,
"display",
"none");
}},
start:function(){if(!arguments.callee.base.call(this)){return;
}var a,
b;
this._oldStyle={top:qx.bom.element.Location.getTop(this._element,
"scroll"),
left:qx.bom.element.Location.getLeft(this._element,
"scroll"),
width:qx.bom.element.Dimension.getWidth(this._element),
height:qx.bom.element.Dimension.getHeight(this._element),
opacity:qx.bom.element.Style.get(this._element,
"opacity")};
switch(this.getDirection()){case 'top-left':a=b=0;
break;
case 'top-right':a=this._oldStyle.width;
b=0;
break;
case 'bottom-left':a=0;
b=this._oldStyle.height;
break;
case 'bottom-right':a=this._oldStyle.width;
b=this._oldStyle.height;
break;
case 'center':a=this._oldStyle.width/2;
b=this._oldStyle.height/2;
break;
}this._moveEffect.set({x:a,
y:b,
sync:true,
transition:this.getMoveTransition()});
this._scaleEffect.set({scaleTo:0,
sync:true,
transition:this.getScaleTransition(),
restoreAfterFinish:true});
this._mainEffect.start();
}},
destruct:function(){this._disposeObjects("_moveEffect",
"_scaleEffect",
"_mainEffect");
}});
qx.Theme.define("qx.theme.classic.Font",
{title:"Classic",
fonts:{"default":{size:11,
lineHeight:1.4,
family:["Lucida Grande",
"Tahoma",
"Verdana",
"Bitstream Vera Sans",
"Liberation Sans"]},
"small":{size:10,
lineHeight:1.3,
family:["Lucida Grande",
"Tahoma",
"Verdana",
"Bitstream Vera Sans",
"Liberation Sans"]},
"bold":{size:11,
lineHeight:1.4,
family:["Lucida Grande",
"Tahoma",
"Verdana",
"Bitstream Vera Sans",
"Liberation Sans"],
bold:true},
"large":{size:16,
lineHeight:1.4,
family:["Lucida Grande",
"Tahoma",
"Verdana",
"Bitstream Vera Sans",
"Liberation Sans"]},
"monospace":{size:11,
lineHeight:1.4,
family:["Consolas",
"Bitstream Vera Sans Mono",
"Courier New",
"monospace"]}}});
qx.Class.define("qx.ui.progressive.renderer.table.cell.Abstract",
{type:"abstract",
extend:qx.core.Object,
members:{_getCellStyle:function(a){return "";
},
_getCellExtras:function(a){return "";
},
_getContentHtml:function(a){return a.cellData||"";
},
render:function(a){var b=[];
var c=this._getCellStyle(a);
b.push("<div ",
"class='",
a.stylesheet,
"' ");
if(c){b.push("style='",
c,
"'");
}b.push(this._getCellExtras(a),
">",
this._getContentHtml(a),
"</div>");
return b.join("");
}}});
qx.Class.define("qx.ui.progressive.renderer.table.cell.Icon",
{type:"abstract",
extend:qx.ui.progressive.renderer.table.cell.Abstract,
construct:function(){arguments.callee.base.call(this);
this.IMG_BLANK_URL=qx.util.AliasManager.getInstance().resolve("static/image/blank.gif");
},
members:{_identifyImage:function(a){throw new Error("_identifyImage() is abstract");
},
_getCellStyle:function(a){var b=arguments.callee.base.call(this,
a)+"text-align:center;"+"padding-top:1px;";
return b;
},
_getContentHtml:function(a){return qx.html.String.escape(this._formatValue(a.cellData));
},
_getContentHtml:function(a){var b=[];
var c=this.__fj(a);
b.push('<img ');
if(qx.core.Client.getInstance().isMshtml()&&/\.png$/i.test(c.url)){b.push('src="',
this.IMG_BLANK_URL,
'" style="filter:',
"progid:DXImageTransform.Microsoft.AlphaImageLoader(src='",
c.url,
"',sizingMethod='scale')",
'" ');
}else{b.push('src="',
c.url,
'" ');
}if(c.imageWidth){b.push(" width='",
c.imageWidth,
"px'");
}if(c.imageHeight){b.push(" height='",
c.imageHeight,
"px'");
}if(c.tooltip){b.push(" title='",
c.tooltip,
"'");
}if(c.extras){b.push(c.extras);
}b.push(">");
return b.join("");
},
__fj:function(a){var b=this._identifyImage(a);
if(b==null||typeof b=="string"){b={url:b,
tooltip:null};
}if(b.url==null){b.url=this.IMG_BLANK_URL;
}return b;
}},
destruct:function(){this._disposeFields("IMG_BLANK_URL");
}});
qx.Class.define("qx.ui.progressive.renderer.table.cell.Image",
{extend:qx.ui.progressive.renderer.table.cell.Icon,
construct:function(a,
b){arguments.callee.base.call(this);
if(a===undefined){this._imageWidth=a;
}else{this._imageWidth=16;
}
if(b===undefined){this._imageHeight=b;
}else{this._imageHeight=16;
}this._am=qx.util.AliasManager.getInstance();
},
members:{_identifyImage:function(a){var b={imageWidth:this._imageWidth,
imageHeight:this._imageHeight};
var c;
var d;
if(typeof (a.cellData)=="string"){b.url=a.cellData;
}else{b.url=a.cellData.url;
b.tooltip=a.cellData.tooltip;
d=a.cellData.height;
}
if(b.url==""){b.url=this.IMG_BLANK_URL;
}else{b.url=this._am.resolve(b.url);
}if(d){a.height=d;
}return b;
}},
destruct:function(){this._disposeFields("_imageWidth",
"imageHeight");
}});
qx.Class.define("qx.ui.progressive.renderer.Abstract",
{type:"abstract",
extend:qx.core.Object,
members:{render:function(a,
b){throw new Error("render() is abstract");
},
join:function(a,
b){}}});
qx.Class.define("qx.ui.progressive.structure.Abstract",
{type:"abstract",
extend:qx.core.Object,
construct:function(a){if(!a){this.__vBoxLayout=new qx.ui.layout.VBox();
this._pane=this.__vBoxLayout;
}else{this.__vBoxLayout=null;
this._pane=a;
}this._pane.setHeight("1*");
this._pane.setOverflow("auto");
},
members:{applyStructure:function(a){throw new Error("applyStructure() is abstract");
},
getPane:function(){return this._pane;
}},
destruct:function(){if(this.__vBoxLayout){this.__vBoxLayout.dispose();
this.__vBoxLayout=null;
}this._pane=null;
}});
qx.Class.define("qx.ui.progressive.structure.Default",
{extend:qx.ui.progressive.structure.Abstract,
construct:function(a,
b,
c){arguments.callee.base.call(this,
c);
if(!a){this.__nullHeader=new qx.ui.progressive.headfoot.Null();
this._header=this.__nullHeader;
}else{this.__nullHeader=null;
this._header=a;
}if(!b){this.__nullFooter=new qx.ui.progressive.headfoot.Null();
this._footer=this.__nullFooter;
}else{this.__nullFooter=null;
this._footer=b;
}},
members:{applyStructure:function(a){this._header.join(a);
this._footer.join(a);
a.add(this._header,
this._pane,
this._footer);
},
getHeader:function(){return this._header;
},
getFooter:function(){return this._footer;
}},
destruct:function(){if(this.__nullHeader){this.__nullHeader.dispose();
this.__nullHeader=null;
}
if(this.__nullFooter){this.__nullFooter.dispose();
this.__nullFooter=null;
}}});
qx.Class.define("qx.ui.progressive.headfoot.Abstract",
{type:"abstract",
extend:qx.ui.core.Widget,
members:{join:function(a){this._progressive=a;
}}});
qx.Class.define("qx.ui.progressive.headfoot.Null",
{extend:qx.ui.progressive.headfoot.Abstract,
construct:function(){arguments.callee.base.call(this);
this.setDisplay(false);
}});
qx.Class.define("qx.fx.effect.combination.Shake",
{extend:qx.fx.Base,
construct:function(a){arguments.callee.base.call(this,
a);
this._effects=[new qx.fx.effect.core.Move(this._element),
new qx.fx.effect.core.Move(this._element),
new qx.fx.effect.core.Move(this._element),
new qx.fx.effect.core.Move(this._element),
new qx.fx.effect.core.Move(this._element),
new qx.fx.effect.core.Move(this._element)];
},
properties:{direction:{init:"horizontal",
check:["horizontal",
"vertical"]},
duration:{init:0.5,
refine:true},
distance:{init:20,
check:"Number"}},
members:{start:function(){if(!arguments.callee.base.call(this)){return;
}var a={top:qx.bom.element.Location.getTop(this._element),
left:qx.bom.element.Location.getLeft(this._element)};
var b=parseFloat(this.getDistance());
var c=parseFloat(this.getDuration())/10.0;
if(this.getDirection()=="horizontal"){this._effects[0].set({x:b,
y:0,
duration:c});
this._effects[1].set({x:-b*2,
y:0,
duration:c*2});
this._effects[2].set({x:b*2,
y:0,
duration:c*2});
this._effects[3].set({x:-b*2,
y:0,
duration:c*2});
this._effects[4].set({x:b*2,
y:0,
duration:c*2});
this._effects[5].set({x:-b,
y:0,
duration:c*2});
}else if(this.getDirection()=="vertical"){this._effects[0].set({y:b,
x:0,
duration:c});
this._effects[1].set({y:-b*2,
x:0,
duration:c*2});
this._effects[2].set({y:b*2,
x:0,
duration:c*2});
this._effects[3].set({y:-b*2,
x:0,
duration:c*2});
this._effects[4].set({y:b*2,
x:0,
duration:c*2});
this._effects[5].set({y:-b,
x:0,
duration:c*2});
}var d=this._effects;
for(var e=0,
f=this._effects.length;e<f;e++){this._effects[e].id=e;
if(e<5){this._effects[e].afterFinishInternal=function(){d[this.id+1].start();
};
}else{this._effects[e].afterFinishInternal=function(){for(var g in a){qx.bom.element.Style.set(this._element,
g,
(a[g]+"px"));
}};
}}this._effects[0].start();
}},
destruct:function(){this._disposeArray("_effects");
}});
qx.Theme.define("qx.theme.modern.Appearance",
{title:"Modern",
appearances:{"widget":{},
"root":{style:function(a){return {backgroundColor:"background",
textColor:"text",
font:"default"};
}},
"label":{style:function(a){return {textColor:a.disabled?"text-disabled":a.focused?"text-focused":"undefined"};
}},
"move-frame":{style:function(a){return {decorator:"dark-shadow"};
}},
"resize-frame":{style:function(a){return {decorator:"dark-shadow"};
}},
"dragdrop-cursor":{style:function(a){var b="nodrop";
if(a.copy){b="copy";
}else if(a.move){b="move";
}else if(a.alias){b="alias";
}return {source:"decoration/cursors/"+b+".gif",
position:"right-top",
offset:[2,
16,
2,
6]};
}},
"image":{style:function(a){return {opacity:!a.replacement&&a.disabled?0.3:1};
}},
"atom":{},
"atom/label":"label",
"atom/icon":"image",
"popup":"widget",
"button":{alias:"atom",
style:function(a){var b,
c;
if(a.checked&&a.focused){b="button-checked-focused";
c="text";
}else if(a.checked){b="button-checked";
c="text";
}else if(a.pressed){b="button-pressed";
c="#001533";
}else if(a.hovered){b="button-hovered";
c="#001533";
}else if(a.preselected&&a.focused){b="button-preselected-focused";
c="#001533";
}else if(a.preselected){b="button-preselected";
c="#001533";
}else if(a.focused){b="button-focused";
c="text";
}else{b="button";
c="text";
}return {padding:2,
textColor:c,
font:"default",
decorator:b};
}},
"splitbutton":{},
"splitbutton/button":"button",
"splitbutton/arrow":{alias:"button",
include:"button",
style:function(a){return {icon:"decoration/arrows/down.gif"};
}},
"checkbox":{alias:"atom",
style:function(a){var b;
if(a.checked&&a.focused){b="checkbox-checked-focused";
}else if(a.checked&&a.disabled){b="checkbox-checked-disabled";
}else if(a.checked&&a.pressed){b="checkbox-checked-pressed";
}else if(a.checked&&a.hovered){b="checkbox-checked-hovered";
}else if(a.checked){b="checkbox-checked";
}else if(a.disabled){b="checkbox-disabled";
}else if(a.focused){b="checkbox-focused";
}else if(a.pressed){b="checkbox-pressed";
}else if(a.hovered){b="checkbox-hovered";
}else{b="checkbox";
}return {icon:"decoration/form/"+b+".png",
gap:6};
}},
"radiobutton":{alias:"atom",
style:function(a){var b;
if(a.checked&&a.focused){b="radiobutton-checked-focused";
}else if(a.checked&&a.disabled){b="radiobutton-checked-disabled";
}else if(a.checked&&a.pressed){b="radiobutton-checked-pressed";
}else if(a.checked&&a.hovered){b="radiobutton-checked-hovered";
}else if(a.checked){b="radiobutton-checked";
}else if(a.disabled){b="radiobutton-disabled";
}else if(a.focused){b="radiobutton-focused";
}else if(a.pressed){b="radiobutton-pressed";
}else if(a.hovered){b="radiobutton-hovered";
}else{b="radiobutton";
}return {icon:"decoration/form/"+b+".png",
gap:6};
}},
"textfield":{style:function(a){return {decorator:a.focused?"textfield-focused":"textfield",
padding:[1,
3],
textColor:a.disabled?"text-disabled":"input-text",
backgroundColor:"white"};
}},
"textarea":"textfield",
"spinner":{style:function(a){return {decorator:a.focused?"textfield-focused":"textfield",
textColor:a.disabled?"text-disabled":"undefined"};
}},
"spinner/textfield":{include:"textfield",
style:function(a){return {decorator:"undefined",
padding:[2,
3]};
}},
"spinner/upbutton":{alias:"button",
include:"button",
style:function(a){return {icon:"decoration/arrows/up-small.png",
padding:a.pressed?[2,
2,
0,
4]:[1,
3,
1,
3],
backgroundColor:a.focused?"background-focused-inner":a.hovered?"button-hovered":"button"};
}},
"spinner/downbutton":{alias:"button",
include:"button",
style:function(a){return {icon:"decoration/arrows/down-small.png",
padding:a.pressed?[2,
2,
0,
4]:[1,
3,
1,
3],
backgroundColor:a.focused?"background-focused-inner":a.hovered?"button-hovered":"button"};
}},
"datefield":"combobox",
"datefield/button":{alias:"combobox/button",
include:"combobox/button",
style:function(a){return {icon:"icon/16/apps/office-calendar.png",
padding:[0,
3],
backgroundColor:a.disabled?"background-disabled":a.focused?"background-focused":"background-field",
decorator:"undefined"};
}},
"datefield/list":{alias:"datechooser",
include:"datechooser",
style:function(a){return {decorator:a.focused?"focused-inset":"inset"};
}},
"groupbox":{style:function(a){return {padding:[4,
10],
legendPosition:"top"};
}},
"groupbox/legend":{alias:"atom",
style:function(a){return {padding:[1,
0,
1,
0],
textColor:"#314a6e",
font:"bold"};
}},
"groupbox/frame":{style:function(a){return {padding:[12,
9],
decorator:"groupbox-frame"};
}},
"check-groupbox":{alias:"groupbox",
include:"groupbox",
style:function(a){return {padding:10};
}},
"check-groupbox/legend":{alias:"checkbox",
include:"checkbox",
style:function(a){return {backgroundColor:"background",
paddingRight:3,
paddingLeft:3,
marginRight:10,
marginLeft:10};
}},
"radio-groupbox":{alias:"groupbox",
include:"groupbox",
style:function(a){return {padding:10};
}},
"radio-groupbox/legend":{alias:"radiobutton",
include:"radiobutton",
style:function(a){return {backgroundColor:"background",
paddingRight:3,
paddingLeft:3,
marginRight:10,
marginLeft:10};
}},
"scrollarea/corner":{style:function(a){return {backgroundColor:"#e4e4e4",
width:0,
height:0};
}},
"scrollarea/pane":"widget",
"scrollarea/scrollbar-x":"scrollbar",
"scrollarea/scrollbar-y":"scrollbar",
"scrollbar":{style:function(a){return {width:a.horizontal?"undefined":16,
height:a.horizontal?16:"undefined",
decorator:a.horizontal?"scrollbar-horizontal":"scrollbar-vertical",
padding:1};
}},
"scrollbar/slider":{alias:"slider",
style:function(a){return {padding:a.horizontal?[0,
1,
0,
1]:[1,
0,
1,
0]};
}},
"scrollbar/button":{alias:"button",
include:"button",
style:function(a){var b="decoration/scrollbar/scrollbar-";
if(a.left){b+="left.png";
}else if(a.right){b+="right.png";
}else if(a.up){b+="up.png";
}else{b+="down.png";
}
if(a.left||a.right){return {padding:[0,
0,
0,
a.left?3:4],
icon:b,
width:15,
height:14,
decorator:a.pressed?"slider-knob-pressed-horizontal":"slider-knob-horizontal"};
}else{return {padding:[0,
0,
0,
2],
icon:b,
width:14,
height:15,
decorator:a.pressed?"slider-knob-pressed-vertical":"slider-knob-vertical"};
}}},
"scrollbar/button-begin":"scrollbar/button",
"scrollbar/button-end":"scrollbar/button",
"slider":{style:function(a){return {};
}},
"slider/knob":{include:"button",
style:function(a){return {decorator:a.horizontal?"slider-knob-horizontal":"slider-knob-vertical",
height:14,
width:14};
}},
"list":{alias:"scrollarea",
style:function(a){return {decorator:a.focused?"focus-line":"black",
backgroundColor:a.focused?"#F0F4FA":"white"};
}},
"list/pane":"widget",
"listitem":{alias:"atom",
style:function(a){return {padding:4,
textColor:a.selected?"text-selected":"undefined",
decorator:a.selected?"listitem":"undefined"};
}},
"slidebar":{},
"slidebar/scrollpane":{},
"slidebar/content":{},
"slidebar/button-forward":{alias:"button",
include:"button",
style:function(a){return {icon:"decoration/arrows/right.png"};
}},
"slidebar/button-backward":{alias:"button",
include:"button",
style:function(a){return {icon:"decoration/arrows/left.png"};
}},
"tabview":{},
"tabview/bar":{alias:"slidebar",
style:function(a){return {zIndex:10,
paddingLeft:(a.barLeft||a.barRight)?0:10,
paddingRight:(a.barLeft||a.barRight)?0:10,
paddingTop:(a.barTop||a.barBottom)?0:10,
paddingBottom:(a.barTop||a.barBottom)?0:10,
marginBottom:a.barTop?-1:0,
marginTop:a.barBottom?-4:0,
marginLeft:a.barRight?-3:0,
marginRight:a.barLeft?-1:0};
}},
"tabview/bar/scrollpane":{},
"tabview/pane":{style:function(a){return {decorator:"pane",
padding:10,
marginBottom:a.barBottom?-1:0,
marginTop:a.barTop?-1:0,
marginLeft:a.barLeft?-1:0,
marginRight:a.barRight?-1:0};
}},
"tabview-page":{},
"tabview-page/button":{alias:"atom",
style:function(a){var b,
c=0,
d=0,
e=0,
f=0,
g=0;
if(a.checked){if(a.barTop){b="tabview-page-button-top-active";
c=[6,
14];
f=a.firstTab?0:-5;
g=a.lastTab?0:-5;
}else if(a.barBottom){b="tabview-page-button-bottom-active";
c=[6,
10];
f=a.firstTab?0:-5;
g=a.lastTab?0:-5;
}else if(a.barRight){b="tabview-page-button-right-active";
c=[6,
10];
d=a.firstTab?0:-6;
e=a.lastTab?0:-6;
}else{b="tabview-page-button-left-active";
c=[6,
10];
d=a.firstTab?0:-6;
e=a.lastTab?0:-6;
}}else{if(a.barTop){b="tabview-page-button-top-inactive";
c=[4,
10];
d=4;
f=a.firstTab?5:1;
g=1;
}else if(a.barBottom){b="tabview-page-button-bottom-inactive";
c=[4,
10];
e=4;
f=a.firstTab?5:1;
g=1;
}else if(a.barRight){b="tabview-page-button-right-inactive";
c=[6,
10];
g=4;
d=1;
e=1;
}else{b="tabview-page-button-left-inactive";
c=[6,
10];
f=4;
d=1;
e=1;
}}return {zIndex:a.checked?10:5,
decorator:b,
padding:c,
marginTop:d,
marginBottom:e,
marginLeft:f,
marginRight:g,
textColor:a.checked?"#26364D":"#404955"};
}},
"toolbar":{style:function(a){return {decorator:"toolbar"};
}},
"toolbar/part":{},
"toolbar/part/container":{},
"toolbar/part/handle":{style:function(a){return {decorator:"toolbar-part-handle",
width:7};
}},
"toolbar-button":{alias:"atom",
style:function(a){return {padding:a.pressed||a.checked?4:a.hovered?4:6,
margin:2,
decorator:a.pressed||a.checked?"toolbar-button-checked":a.hovered?"toolbar-button-hovered":"undefined",
textColor:a.disabled?"text-disabled":"text"};
}},
"toolbar-splitbutton":{},
"toolbar-splitbutton/button":"toolbar-button",
"toolbar-splitbutton/arrow":{alias:"toolbar-button",
include:"toolbar-button",
style:function(a){return {icon:"decoration/arrows/down.gif"};
}},
"toolbar-separator":{style:function(a){return {decorator:"toolbar-separator",
margin:7,
width:0,
height:0};
}},
"tree":"list",
"tree-folder":{style:function(a){return {padding:[4,
3,
3,
3],
textColor:a.selected?"text-selected":"undefined",
decorator:a.selected?"tree-folder-selected":"tree-folder",
icon:"icon/16/places/folder-open.png",
iconOpened:"icon/16/places/folder.png"};
}},
"tree-file":{include:"tree-folder",
style:function(a){return {icon:"icon/16/mimetypes/text-plain.png"};
}},
"tree-folder-icon":{style:function(a){return {padding:[0,
5,
0,
0]};
}},
"tree-folder-label":{style:function(a){return {padding:[1,
0,
0,
0]};
}},
"tree-file-icon":{include:"tree-folder-icon"},
"tree-file-label":{include:"tree-folder-label"},
"folder-open-button":{style:function(a){var b;
if(a.selected&&a.opened){b="decoration/tree/tree-open-selected.png";
}else if(a.selected&&!a.opened){b="decoration/tree/tree-closed-selected.png";
}else if(a.opened){b="decoration/tree/tree-open.png";
}else{b="decoration/tree/tree-closed.png";
}return {padding:[0,
5,
0,
2],
source:b};
}},
"tooltip":{include:"popup",
style:function(a){return {backgroundColor:"#ffffdd",
decorator:"tooltip",
padding:[1,
3,
2,
3],
offset:[1,
1,
20,
1]};
}},
"tooltip/atom":"atom",
"window":{style:function(a){return {decorator:"window"};
}},
"window/pane":{style:function(a){return {backgroundColor:"#f3f3f3",
decorator:"window-border"};
}},
"window/captionbar":{style:function(a){return {decorator:a.active?"window-captionbar-active":"window-captionbar-inactive",
textColor:a.active?"#ffffff":"#4a4a4a",
minHeight:22};
}},
"window/icon":{style:function(a){return {margin:[4,
0,
2,
4]};
}},
"window/title":{style:function(a){return {alignY:"middle",
font:"default",
marginLeft:6};
}},
"window/minimize-button":{alias:"atom",
style:function(a){return {icon:a.active?"decoration/window/minimize-active.png":"decoration/window/minimize-inactive.png",
margin:[4,
6,
2,
0]};
}},
"window/restore-button":{alias:"atom",
style:function(a){return {margin:[4,
6,
2,
0]};
}},
"window/maximize-button":{alias:"atom",
style:function(a){return {icon:a.active?"decoration/window/maximize-active.png":"decoration/window/maximize-inactive.png",
margin:[4,
6,
2,
0]};
}},
"window/close-button":{alias:"atom",
style:function(a){return {icon:a.active?"decoration/window/close-active.png":"decoration/window/close-inactive.png",
margin:[4,
6,
2,
0]};
}},
"window/statusbar":{style:function(a){return {paddingLeft:2,
decorator:"window-statusbar"};
}},
"window/statusbar-text":{style:function(a){return {font:"medium",
textColor:"text"};
}},
"iframe":{style:function(a){return {backgroundColor:"white",
decorator:"iframe"};
}},
"resizer":{style:function(a){return {decorator:"outset"};
}},
"resizer-frame":{style:function(a){return {decorator:"dark-shadow"};
}},
"splitpane":{},
"splitpane/splitter":{style:function(a){return {width:a.horizontal?6:"undefined",
height:a.vertical?6:"undefined",
backgroundColor:"#dfdfdf",
decorator:a.horizontal?"splitpane-splitter-horizontal":"splitpane-splitter-vertical"};
}},
"splitpane/splitter/knob":{style:function(a){return {source:a.horizontal?"decoration/splitpane/knob-horizontal.png":"decoration/splitpane/knob-vertical.png"};
}},
"splitpane/slider":{style:function(a){return {width:a.horizontal?6:"undefined",
height:a.vertical?6:"undefined",
backgroundColor:"#dfdfdf"};
}},
"selectbox":"button",
"selectbox/atom":"atom",
"selectbox/popup":"popup",
"selectbox/list":"list",
"selectbox/arrow":{style:function(a){return {source:"decoration/arrows/down.png",
paddingRight:4,
paddingLeft:5};
}},
"datechooser":{},
"datechooser/navigation-bar":{style:function(a){return {backgroundColor:"date-chooser",
padding:[2,
10]};
}},
"datechooser/last-year-button":"datechooser/button",
"datechooser/last-month-button":"datechooser/button",
"datechooser/next-year-button":"datechooser/button",
"datechooser/next-month-button":"datechooser/button",
"datechooser/button/icon":{},
"datechooser/button":{style:function(a){var b={width:17,
show:"icon"};
if(a.lastYear){b.icon="decoration/arrows/rewind.gif";
}else if(a.lastMonth){b.icon="decoration/arrows/left.gif";
}else if(a.nextYear){b.icon="decoration/arrows/forward.gif";
}else if(a.nextMonth){b.icon="decoration/arrows/right.gif";
}
if(a.pressed||a.checked||a.abandoned){b.decorator="inset-thin";
}else if(a.hovered){b.decorator="outset-thin";
}else{b.decorator="undefined";
}
if(a.pressed||a.checked||a.abandoned){b.padding=[2,
0,
0,
2];
}else if(a.hovered){b.padding=1;
}else{b.padding=2;
}return b;
}},
"datechooser/month-year-label":{style:function(a){return {font:"bold",
textAlign:"center"};
}},
"datechooser/date-pane":{style:function(a){return {decorator:new qx.ui.decoration.Single().set({top:[1,
"solid",
"gray"]}),
backgroundColor:"date-chooser"};
}},
"datechooser-weekday":{style:function(a){var b=new qx.ui.decoration.Single().set({bottom:[1,
"solid",
"gray"]});
return {decorator:b,
font:"bold",
textAlign:"center",
textColor:a.weekend?"date-chooser-title":"date-chooser",
backgroundColor:a.weekend?"date-chooser":"date-chooser-title"};
}},
"datechooser-day":{style:function(a){return {textAlign:"center",
decorator:a.today?"black":"undefined",
textColor:a.selected?"text-selected":a.otherMonth?"text-disabled":"undefined",
backgroundColor:a.selected?"date-chooser-selected":"undefined",
padding:[2,
4]};
}},
"datechooser-week":{style:function(a){if(a.header){var b=new qx.ui.decoration.Single().set({right:[1,
"solid",
"gray"],
bottom:[1,
"solid",
"gray"]});
}else{var b=new qx.ui.decoration.Single().set({right:[1,
"solid",
"gray"]});
}return {textAlign:"center",
textColor:"date-chooser-title",
padding:[2,
4],
decorator:b};
}},
"combobox":{style:function(a){return {decorator:a.focused?"textfield-focused":"textfield",
backgroundColor:"white"};
}},
"combobox/popup":"popup",
"combobox/list":"list",
"combobox/button":{include:"button",
alias:"button",
style:function(a){return {icon:"decoration/arrows/down.png"};
}},
"combobox/textfield":{include:"textfield",
style:function(a){return {decorator:null,
padding:[2,
3],
textColor:a.disabled?"text-disabled":"input-text"};
}},
"menu":{style:function(a){var b={decorator:"menu",
spacingX:6,
spacingY:1,
iconColumnWidth:16,
arrowColumnWidth:4};
if(a.submenu){b.position="right-top";
b.offset=[-2,
-3];
}return b;
}},
"menu-separator":{style:function(a){return {height:0,
decorator:"menu-separator",
margin:[4,
2]};
}},
"menu-button":{alias:"atom",
style:function(a){return {decorator:a.selected?"menu-button-selected":"undefined",
textColor:a.selected?"text-selected":"undefined",
padding:[4,
6]};
}},
"menu-button/icon":{include:"image",
style:function(a){return {alignY:"middle"};
}},
"menu-button/label":{include:"label",
style:function(a){return {alignY:"middle",
padding:1};
}},
"menu-button/shortcut":{include:"label",
style:function(a){return {alignY:"middle",
marginLeft:14,
padding:1};
}},
"menu-button/arrow":{style:function(a){return {source:a.selected?"decoration/arrows/right-invert.png":"decoration/arrows/right.png",
alignY:"middle"};
}},
"menu-checkbox":{alias:"menu-button",
include:"menu-button",
style:function(a){return {icon:!a.checked?"undefined":a.selected?"decoration/menu/checkbox-invert.gif":"decoration/menu/checkbox.gif"};
}},
"menu-radiobutton":{alias:"menu-button",
include:"menu-button",
style:function(a){return {icon:!a.checked?"undefined":a.selected?"decoration/menu/radiobutton-invert.gif":"decoration/menu/radiobutton.gif"};
}},
"table":{alias:"widget",
style:function(a){return {decorator:"table"};
}},
"table-header":{},
"table/statusbar":{style:function(a){return {decorator:"table-statusbar",
paddingLeft:2,
paddingRight:2};
}},
"table/column-button":{alias:"button",
style:function(a){return {decorator:"table-column-button",
padding:[3,
4],
icon:"decoration/table/select-column-order.png"};
}},
"table-scroller":"widget",
"table-scroller/scrollbar-x":"scrollbar",
"table-scroller/scrollbar-y":"scrollbar",
"table-scroller/header":{style:function(a){return {decorator:"table-scroller-header"};
}},
"table-scroller/pane":{style:function(a){return {backgroundColor:"table-pane"};
}},
"table-scroller/focus-indicator":{style:function(a){return {decorator:"table-scroller-focus-indicator"};
}},
"table-scroller/resize-line":{style:function(a){return {backgroundColor:"#D6D5D9",
width:3};
}},
"table-header-cell":{alias:"atom",
style:function(a){return {padding:[3,
4],
marginBottom:a.hovered?0:1,
decorator:a.hovered?"table-header-cell-hovered":"table-header-cell",
sortIcon:a.sorted?(a.sortedAscending?"decoration/table/ascending.png":"decoration/table/descending.png"):"undefined"};
}},
"table-header-cell/sort-icon":{style:function(a){return {alignY:"middle"};
}},
"table-editor-textfield":{include:"textfield",
style:function(a){return {decorator:"undefined",
padding:[2,
2]};
}},
"table-editor-selectbox":{include:"selectbox",
alias:"selectbox",
style:function(a){return {padding:[0,
2]};
}},
"table-editor-combobox":{include:"combobox",
alias:"combobox",
style:function(a){return {decorator:"undefined"};
}}}});
qx.Class.define("qx.dev.unit.TestResult",
{extend:qx.core.Object,
events:{startTest:"qx.event.type.Data",
endTest:"qx.event.type.Data",
error:"qx.event.type.Data",
failure:"qx.event.type.Data"},
statics:{run:function(a,
b,
c){a.run(b,
c);
}},
members:{run:function(a,
b){this.fireDataEvent("startTest",
a);
try{b();
}catch(e){var c=true;
if(e.classname=="qx.core.AssertionError"){this.__fk("failure",
e,
a);
}else{this.__fk("error",
e,
a);
}}
if(!c){this.fireDataEvent("endTest",
a);
}},
__fk:function(a,
b,
c){var d={exception:b,
test:c};
this.fireDataEvent(a,
d);
this.fireDataEvent("endTest",
c);
}}});
qx.Class.define("qx.io.remote.Request",
{extend:qx.core.Object,
construct:function(a,
b,
c){arguments.callee.base.call(this);
this._requestHeaders={};
this._parameters={};
this._formFields={};
if(a!==undefined){this.setUrl(a);
}
if(b!==undefined){this.setMethod(b);
}
if(c!==undefined){this.setResponseType(c);
}this.setProhibitCaching(true);
this._seqNum=++qx.io.remote.Request._seqNum;
},
events:{"created":"qx.event.type.Event",
"configured":"qx.event.type.Event",
"sending":"qx.event.type.Event",
"receiving":"qx.event.type.Event",
"completed":"qx.io.remote.Response",
"aborted":"qx.io.remote.Response",
"failed":"qx.io.remote.Response",
"timeout":"qx.io.remote.Response"},
statics:{_seqNum:0},
properties:{url:{check:"String",
init:""},
method:{check:["GET",
"POST",
"PUT",
"HEAD",
"DELETE"],
apply:"_applyMethod",
init:"GET"},
asynchronous:{check:"Boolean",
init:true},
data:{check:"String",
nullable:true},
username:{check:"String",
nullable:true},
password:{check:"String",
nullable:true},
state:{check:["configured",
"queued",
"sending",
"receiving",
"completed",
"aborted",
"timeout",
"failed"],
init:"configured",
apply:"_applyState",
event:"changeState"},
responseType:{check:["text/plain",
"text/javascript",
"application/json",
"application/xml",
"text/html"],
init:"text/plain",
apply:"_applyResponseType"},
timeout:{check:"Integer",
nullable:true},
prohibitCaching:{check:"Boolean",
init:true,
apply:"_applyProhibitCaching"},
crossDomain:{check:"Boolean",
init:false},
fileUpload:{check:"Boolean",
init:false},
transport:{check:"qx.io.remote.Exchange",
nullable:true},
useBasicHttpAuth:{check:"Boolean",
init:false}},
members:{send:function(){qx.io.remote.RequestQueue.getInstance().add(this);
},
abort:function(){qx.io.remote.RequestQueue.getInstance().abort(this);
},
reset:function(){switch(this.getState()){case "sending":case "receiving":this.error("Aborting already sent request!");
case "queued":this.abort();
break;
}},
isConfigured:function(){return this.getState()==="configured";
},
isQueued:function(){return this.getState()==="queued";
},
isSending:function(){return this.getState()==="sending";
},
isReceiving:function(){return this.getState()==="receiving";
},
isCompleted:function(){return this.getState()==="completed";
},
isAborted:function(){return this.getState()==="aborted";
},
isTimeout:function(){return this.getState()==="timeout";
},
isFailed:function(){return this.getState()==="failed";
},
__fl:function(a){var b=a.clone();
b.setTarget(this);
this.dispatchEvent(b);
},
_onqueued:function(a){this.setState("queued");
this.__fl(a);
},
_onsending:function(a){this.setState("sending");
this.__fl(a);
},
_onreceiving:function(a){this.setState("receiving");
this.__fl(a);
},
_oncompleted:function(a){this.setState("completed");
this.__fl(a);
this.dispose();
},
_onaborted:function(a){this.setState("aborted");
this.__fl(a);
this.dispose();
},
_ontimeout:function(a){this.setState("timeout");
this.__fl(a);
this.dispose();
},
_onfailed:function(a){this.setState("failed");
this.__fl(a);
this.dispose();
},
_applyState:function(a,
b){{if(qx.core.Setting.get("qx.ioRemoteDebug")){this.debug("State: "+a);
}};
},
_applyProhibitCaching:function(a,
b){if(a){this.setParameter("nocache",
new Date().valueOf());
this.setRequestHeader("Pragma",
"no-cache");
this.setRequestHeader("Cache-Control",
"no-cache");
}else{this.removeParameter("nocache");
this.removeRequestHeader("Pragma");
this.removeRequestHeader("Cache-Control");
}},
_applyMethod:function(a,
b){if(a==="POST"){this.setRequestHeader("Content-Type",
"application/x-www-form-urlencoded");
}else{this.removeRequestHeader("Content-Type");
}},
_applyResponseType:function(a,
b){this.setRequestHeader("X-Qooxdoo-Response-Type",
a);
},
setRequestHeader:function(a,
b){this._requestHeaders[a]=b;
},
removeRequestHeader:function(a){delete this._requestHeaders[a];
},
getRequestHeader:function(a){return this._requestHeaders[a]||null;
},
getRequestHeaders:function(){return this._requestHeaders;
},
setParameter:function(a,
b){this._parameters[a]=b;
},
removeParameter:function(a){delete this._parameters[a];
},
getParameter:function(a){return this._parameters[a]||null;
},
getParameters:function(){return this._parameters;
},
setFormField:function(a,
b){this._formFields[a]=b;
},
removeFormField:function(a){delete this._formFields[a];
},
getFormField:function(a){return this._formFields[a]||null;
},
getFormFields:function(){return this._formFields;
},
getSequenceNumber:function(){return this._seqNum;
}},
destruct:function(){this.setTransport(null);
this._disposeFields("_requestHeaders",
"_parameters",
"_formFields");
}});
qx.Class.define("qx.io.remote.RequestQueue",
{type:"singleton",
extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
this._queue=[];
this._active=[];
this._totalRequests=0;
this._timer=new qx.event.Timer(500);
this._timer.addListener("interval",
this._oninterval,
this);
},
properties:{enabled:{init:true,
check:"Boolean",
apply:"_applyEnabled"},
maxTotalRequests:{check:"Integer",
nullable:true},
maxConcurrentRequests:{check:"Integer",
init:3},
defaultTimeout:{check:"Integer",
init:5000}},
members:{_debug:function(){{if(qx.core.Setting.get("qx.ioRemoteDebug")){var a=this._active.length+"/"+(this._queue.length+this._active.length);
this.debug("Progress: "+a);
window.status="Request-Queue Progress: "+a;
}};
},
_check:function(){this._debug();
if(this._active.length==0&&this._queue.length==0){this._timer.stop();
}if(!this.getEnabled()){return;
}if(this._active.length>=this.getMaxConcurrentRequests()||this._queue.length==0){return;
}if(this.getMaxTotalRequests()!=null&&this._totalRequests>=this.getMaxTotalRequests()){return;
}var a=this._queue.shift();
var b=new qx.io.remote.Exchange(a);
this._totalRequests++;
this._active.push(b);
this._debug();
b.addListener("sending",
a._onsending,
a);
b.addListener("receiving",
a._onreceiving,
a);
b.addListener("completed",
a._oncompleted,
a);
b.addListener("aborted",
a._onaborted,
a);
b.addListener("timeout",
a._ontimeout,
a);
b.addListener("failed",
a._onfailed,
a);
b.addListener("sending",
this._onsending,
this);
b.addListener("completed",
this._oncompleted,
this);
b.addListener("aborted",
this._oncompleted,
this);
b.addListener("timeout",
this._oncompleted,
this);
b.addListener("failed",
this._oncompleted,
this);
b._start=(new Date).valueOf();
b.send();
if(this._queue.length>0){this._check();
}},
_remove:function(a){qx.lang.Array.remove(this._active,
a);
a.dispose();
this._check();
},
_activeCount:0,
_onsending:function(a){{if(qx.core.Setting.get("qx.ioRemoteDebug")){this._activeCount++;
a.getTarget()._counted=true;
this.debug("ActiveCount: "+this._activeCount);
}};
},
_oncompleted:function(a){{if(qx.core.Setting.get("qx.ioRemoteDebug")){if(a.getTarget()._counted){this._activeCount--;
this.debug("ActiveCount: "+this._activeCount);
}}};
this._remove(a.getTarget());
},
_oninterval:function(a){var b=this._active;
if(b.length==0){this._timer.stop();
return;
}var c=(new Date).valueOf();
var d;
var f;
var g=this.getDefaultTimeout();
var h;
var j;
for(var k=b.length-1;k>=0;k--){d=b[k];
f=d.getRequest();
if(f.isAsynchronous()){h=f.getTimeout();
if(h==0){continue;
}
if(h==null){h=g;
}j=c-d._start;
if(j>h){this.warn("Timeout: transport "+d.toHashCode());
this.warn(j+"ms > "+h+"ms");
d.timeout();
}}}},
_applyEnabled:function(a,
b){if(a){this._check();
}this._timer.setEnabled(a);
},
add:function(a){a.setState("queued");
this._queue.push(a);
this._check();
if(this.getEnabled()){this._timer.start();
}},
abort:function(a){var b=a.getTransport();
if(b){b.abort();
}else if(qx.lang.Array.contains(this._queue,
a)){qx.lang.Array.remove(this._queue,
a);
}}},
destruct:function(){this._disposeArray("_active");
this._disposeObjects("_timer");
this._disposeFields("_queue");
}});
qx.Class.define("qx.ui.container.Scroll",
{extend:qx.ui.core.ScrollArea,
construct:function(a){arguments.callee.base.call(this);
if(a){this.add(a);
}},
members:{add:function(a){this._getChildControl("pane").add(a);
},
remove:function(a){this._getChildControl("pane").remove(a);
},
getChild:function(){return this._getChildControl("pane").getChild();
}}});
qx.Class.define("qx.fx.effect.combination.Switch",
{extend:qx.fx.Base,
construct:function(a){arguments.callee.base.call(this,
a);
this.setTransition("flicker");
var b=this._scaleEffect=new qx.fx.effect.core.Scale(this._element);
this._scaleEffect.beforeSetup=function(){qx.bom.element.Style.set(this._element,
"overflow",
"hidden");
};
this._appearEffect=new qx.fx.effect.core.Fade(this._element);
this._appearEffect.afterFinishInternal=function(){b.start();
};
},
properties:{duration:{init:0.5,
refine:true},
from:{init:0.0,
refine:true},
to:{init:1.0,
refine:true},
modifyDisplay:{init:true,
check:"Boolean"},
mode:{init:"off",
check:["off"]}},
members:{setup:function(){arguments.callee.base.call(this);
var a=qx.bom.element.Style.get(this._element,
"overflow");
this._scaleEffect.afterFinishInternal=function(){qx.bom.element.Style.set(this._element,
"overflow",
a);
};
},
afterFinish:function(){if(this.getModifyDisplay()&&(this.getMode()=="off")){qx.bom.element.Style.set(this._element,
"display",
"none");
}},
start:function(){if(!arguments.callee.base.call(this)){return;
}
if(this.getMode()=="off"){this._scaleEffect.set({scaleTo:1.0,
duration:this.getDuration()/2,
scaleFromCenter:true,
scaleX:false,
scaleContent:false,
restoreAfterFinish:true});
this._appearEffect.set({duration:this.getDuration()/2,
from:this.getFrom(),
to:1});
}else{}this._appearEffect.start();
},
_applyDuration:function(a,
b){this._scaleEffect.setDuration(a/2);
this._appearEffect.setDuration(a/2);
}},
destruct:function(){this._disposeObjects("_appearEffect",
"_scaleEffect");
}});
qx.Class.define("qx.io.remote.Rpc",
{extend:qx.core.Object,
construct:function(a,
b){arguments.callee.base.call(this);
if(a!==undefined){this.setUrl(a);
}
if(b!=null){this.setServiceName(b);
}this._previousServerSuffix=null;
this._currentServerSuffix=null;
if(qx.core.ServerSettings){this._currentServerSuffix=qx.core.ServerSettings.serverPathSuffix;
}},
events:{"completed":"qx.event.type.Event",
"aborted":"qx.event.type.Event",
"failed":"qx.event.type.Event",
"timeout":"qx.event.type.Event"},
statics:{origin:{server:1,
application:2,
transport:3,
local:4},
localError:{timeout:1,
abort:2},
makeServerURL:function(a){var b=null;
if(qx.core.ServerSettings){b=qx.core.ServerSettings.serverPathPrefix+"/.qxrpc"+qx.core.ServerSettings.serverPathSuffix;
if(a!=null){b+="?instanceId="+a;
}}return b;
}},
properties:{timeout:{check:"Integer",
nullable:true},
crossDomain:{check:"Boolean",
init:false},
url:{check:"String",
nullable:true},
serviceName:{check:"String",
nullable:true},
serverData:{check:"Object",
nullable:true},
username:{check:"String",
nullable:true},
password:{check:"String",
nullable:true},
useBasicHttpAuth:{check:"Boolean",
nullable:true}},
members:{_callInternal:function(a,
b,
c){var d=this;
var e=(b==0?0:1);
var f=(c?"refreshSession":a[e]);
var g=a[0];
var h=[];
var j=this;
for(var k=e+1;k<a.length;++k){h.push(a[k]);
}var l=new qx.io.remote.Request(this.getUrl(),
"POST",
"application/json");
var m={"service":(c?null:this.getServiceName()),
"method":f,
"id":l.getSequenceNumber(),
"params":h};
var n=this.getServerData();
if(n!==null){m.server_data=n;
}l.setCrossDomain(this.getCrossDomain());
if(this.getUsername()){l.setUseBasicHttpAuth(this.getUseBasicHttpAuth());
l.setUsername(this.getUsername());
l.setPassword(this.getPassword());
}l.setTimeout(this.getTimeout());
var o=null;
var p=null;
var q=null;
var r=null;
var s=function(t,
j){switch(b){case 0:break;
case 1:g(q,
o,
p);
break;
case 2:if(!o){j.fireDataEvent(t,
r);
}else{o.id=p;
if(a[0]){j.fireDataEvent("failed",
o);
}else{j.fireDataEvent(t,
o);
}}}};
var u=function(v){v.toString=function(){switch(v.origin){case qx.io.remote.Rpc.origin.server:return "Server error "+v.code+": "+v.message;
case qx.io.remote.Rpc.origin.application:return "Application error "+v.code+": "+v.message;
case qx.io.remote.Rpc.origin.transport:return "Transport error "+v.code+": "+v.message;
case qx.io.remote.Rpc.origin.local:return "Local error "+v.code+": "+v.message;
default:return ("UNEXPECTED origin "+v.origin+" error "+v.code+": "+v.message);
}};
};
var w=function(x,
y,
z){var o=new Object();
o.origin=x;
o.code=y;
o.message=z;
u(o);
return o;
};
l.addListener("failed",
function(A){var y=A.getStatusCode();
o=w(qx.io.remote.Rpc.origin.transport,
y,
qx.io.remote.Exchange.statusCodeToString(y));
p=this.getSequenceNumber();
s("failed",
j);
});
l.addListener("timeout",
function(A){this.debug("TIMEOUT OCCURRED");
o=w(qx.io.remote.Rpc.origin.local,
qx.io.remote.Rpc.localError.timeout,
"Local time-out expired");
p=this.getSequenceNumber();
s("timeout",
j);
});
l.addListener("aborted",
function(A){o=w(qx.io.remote.Rpc.origin.local,
qx.io.remote.Rpc.localError.abort,
"Aborted");
p=this.getSequenceNumber();
s("aborted",
j);
});
l.addListener("completed",
function(A){r=A.getContent();
p=r["id"];
if(p!=this.getSequenceNumber()){this.warn("Received id ("+p+") does not match requested id "+"("+this.getSequenceNumber()+")!");
}var B=r["error"];
if(B!=null){q=null;
u(B);
o=B;
}else{q=r["result"];
if(c){q=eval("("+q+")");
var C=qx.core.ServerSettings.serverPathSuffix;
if(d._currentServerSuffix!=C){d._previousServerSuffix=d._currentServerSuffix;
d._currentServerSuffix=C;
}d.setUrl(d.fixUrl(d.getUrl()));
}}s("completed",
j);
});
l.setData(qx.util.Json.stringify(m));
l.setAsynchronous(b>0);
if(l.getCrossDomain()){l.setRequestHeader("Content-Type",
"application/x-www-form-urlencoded");
}else{l.setRequestHeader("Content-Type",
"application/json");
}l.send();
if(b==0){if(o!=null){var D=new Error(o.toString());
D.rpcdetails=o;
throw D;
}return q;
}else{return l;
}},
fixUrl:function(a){if(this._previousServerSuffix==null||this._currentServerSuffix==null||this._previousServerSuffix==""||this._previousServerSuffix==this._currentServerSuffix){return a;
}var b=a.indexOf(this._previousServerSuffix);
if(b==-1){return a;
}return (a.substring(0,
b)+this._currentServerSuffix+a.substring(b+this._previousServerSuffix.length));
},
callSync:function(a){return this._callInternal(arguments,
0);
},
callAsync:function(a,
b){return this._callInternal(arguments,
1);
},
callAsyncListeners:function(a,
b){return this._callInternal(arguments,
2);
},
refreshSession:function(a){if(this.getCrossDomain()){if(qx.core.ServerSettings&&qx.core.ServerSettings.serverPathSuffix){var b=(new Date()).getTime()-qx.core.ServerSettings.lastSessionRefresh;
if(b/1000>(qx.core.ServerSettings.sessionTimeoutInSeconds-30)){this._callInternal([a],
1,
true);
}else{a(true);
}}else{a(false);
}}else{a(true);
}},
abort:function(a){a.abort();
}}});
qx.Class.define("qx.ui.table.pane.FocusIndicator",
{extend:qx.ui.container.Composite,
construct:function(a){arguments.callee.base.call(this);
this._scroller=a;
},
properties:{visibility:{refine:true,
init:"excluded"},
row:{check:"Integer"},
column:{check:"Integer"}},
members:{moveToCell:function(a,
b){if(a==null){this.hide();
this.setRow(-1);
this.setColumn(-1);
}else{var c=this._scroller.getTablePaneModel().getX(a);
if(c==-1){this.hide();
this.setRow(-1);
this.setColumn(-1);
}else{var d=this._scroller.getTable();
var e=d.getTableColumnModel();
var f=this._scroller.getTablePaneModel();
var g=this._scroller.getTablePane().getFirstVisibleRow();
var h=d.getRowHeight();
this.setUserBounds(f.getColumnLeft(a)-2,
(b-g)*h-2,
e.getColumnWidth(a)+3,
h+3);
this.show();
this.setRow(b);
this.setColumn(a);
}}}},
destruct:function(){this._disposeFields("_scroller");
}});
qx.Mixin.define("qx.ui.window.MDesktop",
{properties:{activeWindow:{check:"qx.ui.window.Window",
apply:"_applyActiveWindow"}},
members:{getWindowManager:function(){if(!this.__manager){this.setWindowManager(new qx.ui.window.Window.DEFAULT_MANAGER_CLASS());
}return this.__manager;
},
supportsMaximize:function(){return true;
},
setWindowManager:function(a){if(this.__manager){this.__manager.setDesktop(null);
}a.setDesktop(this);
this.__manager=a;
},
_onChangeActive:function(a){if(a.getData()){this.setActiveWindow(a.getTarget());
}},
_applyActiveWindow:function(a,
b){this.getWindowManager().changeActiveWindow(a,
b);
a.setActive(true);
if(b){b.resetActive();
}},
_onChangeModal:function(a){this.getWindowManager().updateStack();
},
_onChangeVisibility:function(){this.getWindowManager().updateStack();
},
_afterAddChild:function(a){if(qx.Class.isDefined("qx.ui.window.Window")&&a instanceof qx.ui.window.Window){this._addWindow(a);
}},
_addWindow:function(a){this.getWindows().push(a);
a.addListener("changeActive",
this._onChangeActive,
this);
a.addListener("changeModal",
this._onChangeModal,
this);
a.addListener("changeVisibility",
this._onChangeVisibility,
this);
if(a.getActive()){this.setActiveWindow(a);
}this.getWindowManager().updateStack();
},
_afterRemoveChild:function(a){if(qx.Class.isDefined("qx.ui.window.Window")&&a instanceof qx.ui.window.Window){this._removeWindow(a);
}},
_removeWindow:function(a){qx.lang.Array.remove(this.getWindows(),
a);
a.removeListener("changeActive",
this._onChangeActive,
this);
a.removeListener("changeModal",
this._onChangeModal,
this);
a.removeListener("changeVisibility",
this._onChangeVisibility,
this);
this.getWindowManager().updateStack();
},
getWindows:function(){if(!this._windows){this._windows=[];
}return this._windows;
}}});
qx.Class.define("qx.ui.root.Abstract",
{extend:qx.ui.core.Widget,
include:[qx.ui.core.MChildrenHandling,
qx.ui.core.MBlocker,
qx.ui.window.MDesktop],
construct:function(){arguments.callee.base.call(this);
qx.ui.core.FocusHandler.getInstance().addRoot(this);
},
properties:{appearance:{refine:true,
init:"root"},
enabled:{refine:true,
init:true},
focusable:{refine:true,
init:true},
globalCursor:{check:"String",
nullable:true,
themeable:true,
apply:"_applyGlobalCursor",
event:"changeGlobalCursor"}},
members:{isRootWidget:function(){return true;
},
getLayout:function(){return this._getLayout();
},
_applyGlobalCursor:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b){},
"default":function(a,
b){var c=qx.bom.Stylesheet;
var d=this._globalCursorStyleSheet;
if(!d){this._globalCursorStyleSheet=d=c.createElement();
}c.removeAllRules(d);
if(a){c.addRule(d,
"*",
qx.bom.element.Cursor.compile(a).replace(";",
"")+" !important");
}}})},
defer:function(a,
b){qx.ui.core.MChildrenHandling.remap(b);
}});
qx.Class.define("qx.ui.root.Inline",
{extend:qx.ui.root.Abstract,
include:[qx.ui.core.MLayoutHandling],
construct:function(a){this._elem=a;
arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.Basic());
qx.ui.core.queue.Layout.add(this);
},
members:{_createContainerElement:function(){var a=this._elem;
var b=new qx.html.Root(a);
a.style.position="relative";
return b;
}},
defer:function(a,
b){qx.ui.core.MLayoutHandling.remap(b);
},
destruct:function(){this._disposeFields("_elem");
}});
qx.Class.define("qx.ui.layout.Basic",
{extend:qx.ui.layout.Abstract,
members:{verifyLayoutProperty:function(a,
b,
c){this.assert(b=="left"||b=="top",
"The property '"+b+"' is not supported by the canvas layout!");
this.assertInteger(c);
},
renderLayout:function(a,
b){var c=this._getLayoutChildren();
var d,
e,
f,
g,
h;
for(var j=0,
k=c.length;j<k;j++){d=c[j];
e=d.getSizeHint();
f=d.getLayoutProperties();
g=(f.left||0)+d.getMarginLeft();
h=(f.top||0)+d.getMarginTop();
d.renderLayout(g,
h,
e.width,
e.height);
}},
_computeSizeHint:function(){var a=this._getLayoutChildren();
var b,
c,
d;
var e=0,
f=0;
var g,
h;
for(var j=0,
k=a.length;j<k;j++){b=a[j];
c=b.getSizeHint();
d=b.getLayoutProperties();
g=c.width+(d.left||0)+b.getMarginLeft()+b.getMarginRight();
h=c.height+(d.top||0)+b.getMarginTop()+b.getMarginBottom();
if(g>e){e=g;
}
if(h>f){f=h;
}}return {width:e,
height:f};
}}});
qx.Class.define("qx.html.Root",
{extend:qx.html.Element,
construct:function(a){arguments.callee.base.call(this);
if(a!=null){this.useElement(a);
}},
members:{useElement:function(a){if(this._element){throw new Error("Elements could not be replaced!");
}a.$$hash=this.$$hash;
this._element=a;
this._root=true;
qx.html.Element._modified[this.$$hash]=this;
}}});
qx.Class.define("qx.ui.table.cellrenderer.Html",
{extend:qx.ui.table.cellrenderer.Conditional,
members:{_getContentHtml:function(a){return (a.value||"");
},
_getCellClass:function(a){return "qooxdoo-table-cell";
}}});
qx.Interface.define("qx.application.IApplication",
{members:{main:function(){},
finalize:function(){},
terminate:function(){}}});
qx.Class.define("qx.application.Native",
{extend:qx.core.Object,
implement:[qx.application.IApplication],
members:{main:function(){},
finalize:function(){},
terminate:function(){}}});
qx.Class.define("qx.application.Simple",
{extend:qx.application.Native,
members:{main:function(){arguments.callee.base.call(this);
if(window.qxmain){window.qxmain.call(this);
}},
terminate:function(){arguments.callee.base.call(this);
if(window.qxterminate){window.qxterminate.call(this);
}}}});
qx.Bootstrap.define("qx.io2.CssLoader",
{statics:{}});
qx.Class.define("qx.ui.table.pane.Pane",
{extend:qx.ui.core.Widget,
construct:function(a){arguments.callee.base.call(this);
this._paneScroller=a;
this._lastColCount=0;
this._lastRowCount=0;
},
properties:{firstVisibleRow:{check:"Number",
init:0,
apply:"_applyFirstVisibleRow"},
visibleRowCount:{check:"Number",
init:0,
apply:"_applyVisibleRowCount"},
maxCacheLines:{check:"Number",
init:1000,
apply:"_applyMaxCacheLines"},
allowGrowX:{refine:true,
init:false},
allowShrinkX:{refine:true,
init:false},
allowGrowY:{refine:true,
init:false},
allowShrinkY:{refine:true,
init:false}},
members:{_applyFirstVisibleRow:function(a,
b){this._updateContent(false,
a-b);
},
_applyVisibleRowCount:function(a,
b){this._updateContent();
},
getPaneScroller:function(){return this._paneScroller;
},
getTable:function(){return this._paneScroller.getTable();
},
setFocusedCell:function(a,
b,
c){if(a!=this._focusedCol||b!=this._focusedRow){var d=this._focusedRow;
this._focusedCol=a;
this._focusedRow=b;
if(b!=d&&!c){this._updateContent(false,
null,
d,
true);
this._updateContent(false,
null,
b,
true);
}}},
onSelectionChanged:function(){this._updateContent(false,
null,
null,
true);
},
onFocusChanged:function(){this._updateContent(false,
null,
null,
true);
},
setColumnWidth:function(a,
b){this._updateContent(true);
},
onColOrderChanged:function(){this._updateContent(true);
},
onPaneModelChanged:function(){this._updateContent(true);
},
onTableModelDataChanged:function(a,
b,
c,
d){this.__fo();
var e=this.getFirstVisibleRow();
var f=this.getVisibleRowCount();
if(b==-1||b>=e&&a<e+f){this._updateContent();
}},
onTableModelMetaDataChanged:function(){this._updateContent(true);
},
__fm:[],
__fn:0,
_applyMaxCacheLines:function(a,
b){if(this.__fn>=a&&a!==-1){this.__fo();
}},
__fo:function(){this.__fm=[];
this.__fn=0;
},
__fp:function(a,
b,
c){if(!b&&!c&&this.__fm[a]){return this.__fm[a];
}else{return null;
}},
__fq:function(a,
b,
c,
d){if(!c&&!d&&!this.__fm[a]){this._applyMaxCacheLines(this.getMaxCacheLines());
this.__fm[a]=b;
this.__fn+=1;
}},
_updateContent:function(a,
b,
c,
d){if(a){this.__fo();
}if(b&&Math.abs(b)<=Math.min(10,
this.getVisibleRowCount())){this._scrollContent(b);
}else if(d&&!this.getTable().getAlwaysUpdateCells()){this._updateRowStyles(c);
}else{this._updateAllRows();
}},
_updateRowStyles:function(a){var b=this.getContentElement().getDomElement();
if(!b||!b.firstChild){this._updateAllRows();
return;
}var c=this.getTable();
var d=c.getSelectionModel();
var e=c.getTableModel();
var f=c.getDataRowRenderer();
var g=b.firstChild.childNodes;
var h={table:c};
var i=this.getFirstVisibleRow();
var j=0;
var k=g.length;
if(a!=null){var l=a-i;
if(l>=0&&l<k){i=a;
j=l;
k=l+1;
}else{return;
}}
for(;j<k;j++,
i++){h.row=i;
h.selected=d.isSelectedIndex(i);
h.focusedRow=(this._focusedRow==i);
h.rowData=e.getRowData(i);
f.updateDataRowElement(h,
g[j]);
}},
_getRowsHtml:function(a,
b){var c=this.getTable();
var d=c.getSelectionModel();
var e=c.getTableModel();
var f=c.getTableColumnModel();
var g=this.getPaneScroller().getTablePaneModel();
var h=c.getDataRowRenderer();
e.prefetchRows(a,
a+b-1);
var i=c.getRowHeight();
var j=g.getColumnCount();
var k=0;
var l=[];
for(var m=0;m<j;m++){var n=g.getColumnAtX(m);
var o=f.getColumnWidth(n);
l.push({col:n,
xPos:m,
editable:e.isColumnEditable(n),
focusedCol:this._focusedCol==n,
styleLeft:k,
styleWidth:o});
k+=o;
}var p=[];
for(var q=a;q<a+b;q++){var r=d.isSelectedIndex(q);
var s=(this._focusedRow==q);
var t=this.__fp(q,
r,
s);
if(t){p.push(t);
continue;
}var u=[];
var v={table:c};
v.styleHeight=i;
v.row=q;
v.selected=r;
v.focusedRow=s;
v.rowData=e.getRowData(q);
u.push('<div ');
var w=h.getRowClass(v);
if(w){u.push('class="',
w,
'" ');
}var y=h.createRowStyle(v);
y+=";position:relative;height:"+i+"px; width:"+g.getTotalWidth()+"px;";
if(y){u.push('style="',
y,
'" ');
}u.push('>');
for(var m=0;m<j;m++){var z=l[m];
for(var A in z){v[A]=z[A];
}var n=v.col;
v.value=e.getValue(n,
q);
var B=f.getDataCellRenderer(n);
B.createDataCellHtml(v,
u);
}u.push('</div>');
var C=u.join("");
this.__fq(q,
C,
r,
s);
p.push(C);
}return p.join("");
},
_scrollContent:function(a){var b=this.getContentElement().getDomElement();
if(!(b&&b.firstChild)){this._updateAllRows();
return;
}var c=b.firstChild;
var d=c.childNodes;
var e=this.getVisibleRowCount();
var f=this.getFirstVisibleRow();
var g=this.getTable().getTableModel().getRowCount();
if(f+e>g){this._updateAllRows();
return;
}var h=a<0?e+a:0;
var j=a<0?0:e-a;
for(n=Math.abs(a)-1;n>=0;n--){var k=d[h];
try{c.removeChild(k);
}catch(e){break;
}}if(!this._tableContainer){this._tableContainer=document.createElement("div");
}var l='<div>';
l+=this._getRowsHtml(f+j,
Math.abs(a));
l+='</div>';
this._tableContainer.innerHTML=l;
var m=this._tableContainer.firstChild.childNodes;
if(a>0){for(var n=m.length-1;n>=0;n--){var k=m[0];
c.appendChild(k);
}}else{for(var n=m.length-1;n>=0;n--){var k=m[m.length-1];
c.insertBefore(k,
c.firstChild);
}}this._updateRowStyles(this._focusedRow-a);
this._updateRowStyles(this._focusedRow);
},
_updateAllRows:function(){var a=this.getContentElement().getDomElement();
if(!a){return ;
}var b=this.getTable();
var c=b.getTableModel();
var d=this.getPaneScroller().getTablePaneModel();
var e=d.getColumnCount();
var f=b.getRowHeight();
var g=this.getFirstVisibleRow();
var h=this.getVisibleRowCount();
var i=c.getRowCount();
if(g+h>i){h=Math.max(0,
i-g);
}var j=d.getTotalWidth();
var k;
if(h>0){k=["<div style='",
"width: ",
j,
"px;",
(b.getForceLineHeight()?"line-height: "+f+"px;":""),
"overflow: hidden;",
"'>",
this._getRowsHtml(g,
h),
"</div>"];
}else{k=[];
}var l=k.join("");
a.innerHTML=l;
this.setHeight(h*f);
this.setWidth(j);
this._lastColCount=e;
this._lastRowCount=h;
}},
destruct:function(){this._disposeObjects("_paneScroller");
this._disposeFields("_tableContainer");
}});
qx.Class.define("qx.ui.table.columnmodel.resizebehavior.ColumnData",
{extend:qx.ui.core.LayoutItem,
construct:function(){arguments.callee.base.call(this);
this.setColumnWidth("auto");
},
members:{renderLayout:function(a,
b,
c,
d){this._computedWidth=c;
},
getComputedWidth:function(){return this._computedWidth;
},
setColumnWidth:function(a){var b=null;
var c=null;
if(typeof a=="number"){this.setWidth(a);
}else if(typeof a=="string"){if(a=="auto"){b=1;
}else{var d=a.match(/^[0-9]+(?:\.[0-9]+)?([%\*])$/);
if(d){if(d[1]=="*"){b=parseFloat(a);
}else{c=a;
}}}}this.setLayoutProperties({flex:b,
width:c});
}}});
qx.Class.define("qx.ui.table.columnmodel.resizebehavior.Abstract",
{type:"abstract",
extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
this._resizeColumnData=[];
},
members:{_setNumColumns:function(a){throw new Error("_setNumColumns is abstract");
},
onAppear:function(a,
b,
c){throw new Error("onAppear is abstract");
},
onTableWidthChanged:function(a,
b){throw new Error("onTableWidthChanged is abstract");
},
onVerticalScrollBarChanged:function(a,
b){throw new Error("onVerticalScrollBarChanged is abstract");
},
onColumnWidthChanged:function(a,
b){throw new Error("onColumnWidthChanged is abstract");
},
onVisibilityChanged:function(a,
b){throw new Error("onVisibilityChanged is abstract");
},
_getAvailableWidth:function(a){var b=a._table;
var c=b.getBounds().width;
var d=a._table._getPaneScrollerArr();
var e=d[d.length-1];
a._table._updateScrollBarVisibility();
if(a._table.getColumnVisibilityButtonVisible()||e._verScrollBar.isVisible()){return c-e._verScrollBar.getBounds().width-1;
}return c;
}},
destruct:function(){this._disposeFields("_resizeColumnData");
}});
qx.Class.define("qx.ui.table.columnmodel.resizebehavior.Default",
{extend:qx.ui.table.columnmodel.resizebehavior.Abstract,
construct:function(){arguments.callee.base.call(this);
this._layout=new qx.ui.layout.HBox();
this._layout.connectToWidget(this);
},
statics:{MIN_WIDTH:10},
properties:{newResizeBehaviorColumnData:{check:"Function",
init:function(a){return new qx.ui.table.columnmodel.resizebehavior.ColumnData();
}},
initializeWidthsOnEveryAppear:{check:"Boolean",
init:false}},
members:{widthsInitialized:false,
setWidth:function(a,
b){if(a>=this._resizeColumnData.length){throw new Error("Column number out of range");
}this._resizeColumnData[a].setColumnWidth(b);
},
setMinWidth:function(a,
b){if(a>=this._resizeColumnData.length){throw new Error("Column number out of range");
}this._resizeColumnData[a].setMinWidth(b);
},
setMaxWidth:function(a,
b){if(a>=this._resizeColumnData.length){throw new Error("Column number out of range");
}this._resizeColumnData[a].setMaxWidth(b);
},
set:function(a,
b){for(var c in b){switch(c){case "width":this.setWidth(a,
b[c]);
break;
case "minWidth":this.setMinWidth(a,
b[c]);
break;
case "maxWidth":this.setMaxWidth(a,
b[c]);
break;
default:throw new Error("Unknown property: "+c);
}}},
onAppear:function(a,
b,
c){if(c===true||!this.widthsInitialized||this.getInitializeWidthsOnEveryAppear()){this._computeColumnsFlexWidth(a,
b);
this.widthsInitialized=true;
}},
onTableWidthChanged:function(a,
b){this._computeColumnsFlexWidth(a,
b);
},
onVerticalScrollBarChanged:function(a,
b){this._computeColumnsFlexWidth(a,
b);
},
onColumnWidthChanged:function(a,
b){this._extendNextColumn(a,
b);
},
onVisibilityChanged:function(a,
b){var c=b.getData();
if(c.visible){this._computeColumnsFlexWidth(a,
b);
return;
}this._extendLastColumn(a,
b);
},
_setNumColumns:function(a){if(a<=this._resizeColumnData.length){this._resizeColumnData.splice(a,
this._resizeColumnData.length);
return;
}for(var b=this._resizeColumnData.length;b<a;b++){this._resizeColumnData[b]=this.getNewResizeBehaviorColumnData()();
this._resizeColumnData[b]._columnNumber=b;
}},
getLayoutChildren:function(){return this._layoutChildren;
},
_computeColumnsFlexWidth:function(a,
b){{if(qx.core.Setting.get("qx.tableResizeDebug")){this.debug("computeColumnsFlexWidth");
}};
var c=a._visibleColumnArr;
var d=c.length;
var e;
var f=[];
for(e=0;e<d;e++){f.push(this._resizeColumnData[c[e]]);
}this._layoutChildren=f;
var g=this._getAvailableWidth(a);
this._layout.renderLayout(g,
100);
for(e=0,
l=f.length;e<l;e++){var h=f[e].getComputedWidth();
a.setColumnWidth(c[e],
h);
{if(qx.core.Setting.get("qx.tableResizeDebug")){this.debug("col "+f[e]._columnNumber+": width="+h);
}};
}},
_extendNextColumn:function(a,
b){var c=b.getData();
var d=a._visibleColumnArr;
var e=this._getAvailableWidth(a);
var f=d.length;
if(c.newWidth>c.oldWidth){return ;
}var g;
var h;
var j=0;
for(g=0;g<f;g++){j+=a.getColumnWidth(d[g]);
}if(j<e){for(g=0;g<d.length;g++){if(d[g]==c.col){h=d[g+1];
break;
}}
if(h){var k=(e-(j-a.getColumnWidth(h)));
a.setColumnWidth(h,
k);
}}},
_extendLastColumn:function(a,
b){var c=b.getData();
if(c.visible){return;
}var d=a._visibleColumnArr;
var e=this._getAvailableWidth(a);
var f=d.length;
var g;
var h;
var j=0;
for(g=0;g<f;g++){j+=a.getColumnWidth(d[g]);
}if(j<e){h=d[d.length-1];
var k=(e-(j-a.getColumnWidth(h)));
a.setColumnWidth(h,
k);
}}},
destruct:function(){this._disposeFields("_resizeColumnData",
"_width");
this._disposeObjects("_layout");
}});
qx.Class.define("qx.application.AbstractGui",
{extend:qx.core.Object,
implement:[qx.application.IApplication],
include:qx.locale.MTranslation,
members:{__fr:null,
_createRootWidget:function(){throw new Error("Abstract method call");
},
getRoot:function(){return this.__root;
},
main:function(){qx.theme.manager.Meta.getInstance().initialize();
this.__root=this._createRootWidget();
},
finalize:function(){this.render();
},
render:function(){qx.ui.core.queue.Manager.flush();
},
terminate:function(){}}});
qx.Class.define("qx.application.Inline",
{extend:qx.application.AbstractGui,
members:{_createRootWidget:function(){return new qx.ui.root.Page(document);
}}});
qx.Class.define("qx.ui.root.Page",
{extend:qx.ui.root.Abstract,
construct:function(a){this._doc=a;
arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.Basic());
this.setZIndex(10000);
qx.ui.core.queue.Layout.add(this);
this.addListener("resize",
this.__fs,
this);
qx.ui.core.FocusHandler.getInstance().connectTo(this);
},
members:{_createContainerElement:function(){var a=this._doc.createElement("div");
this._doc.body.appendChild(a);
var b=new qx.html.Root(a);
b.setStyle("position",
"absolute");
return b;
},
_createContentElement:function(){return new qx.html.Element("div");
},
_computeSizeHint:function(){var a=qx.bom.Document.getWidth(this._window);
var b=qx.bom.Document.getHeight(this._window);
return {minWidth:a,
width:a,
maxWidth:a,
minHeight:b,
height:b,
maxHeight:b};
},
__fs:function(a){var b=a.getData();
this._containerElement.setStyles({width:0,
height:0});
this._contentElement.setStyles({width:0,
height:0});
if(this.isContentBlocked()){this._getContentBlocker().setStyles({width:b.width,
height:b.height});
}
if(this.isBlocked()){this._getBlocker().setStyles({width:b.width,
height:b.height});
}},
__ft:function(){var a=this._doc.body;
this._getContentBlocker().setStyles({height:a.offsetHeight+"px",
width:a.offsetWidth+"px"});
},
supportsMaximize:function(){return false;
},
unblockContent:function(){if(!this.isContentBlocked()){return;
}arguments.callee.base.call(this);
this.__timer.stop();
},
blockContent:function(a){if(this.isContentBlocked()){arguments.callee.base.call(this,
a);
return;
}arguments.callee.base.call(this,
a);
if(!this.__timer){this.__timer=new qx.event.Timer(300);
this.__timer.addListener("interval",
this.__ft,
this);
}this.__timer.start();
this.__ft();
}},
destruct:function(){this._disposeFields("_doc");
}});
qx.Class.define("qx.ui.progressive.headfoot.TableHeading",
{extend:qx.ui.progressive.headfoot.Abstract,
construct:function(a,
b){arguments.callee.base.call(this);
this._columnWidths=a;
this.setHeight(16);
var c=new qx.ui.decoration.Single(1,
"solid",
"#eeeeee");
c.setWidthTop(0);
c.setWidthLeft(0);
c.setWidthBottom(2);
c.setColorBottom("#aaaaaa");
this._labels=[];
for(var d=0;d<a.length;d++){label=new qx.ui.basic.Atom(b[d]);
label.setWidth(a[d].getWidth());
label.setBorder(c);
this.add(label);
this._labels[d]=label;
}this._layout=new qx.ui.layout.HBox();
this._layout.connectToWidget(this);
},
members:{join:function(a){arguments.callee.base.call(this,
a);
a.addListener("widthChanged",
this._resizeColumns,
this);
},
getLayoutChildren:function(){return this._columnWidths;
},
_resizeColumns:function(a){var b=(!this._progressive.getContainerElement().getDomElement()?0:this._progressive.getInnerWidth())-qx.bom.element.Overflow.getScrollbarSize();
this._layout.renderLayout(b,
100);
for(var c=0;c<data.length;c++){this._labels[c].setWidth(this._columnWidths[c].getComputedWidth());
}}}});
qx.Class.define("qx.ui.table.celleditor.TextField",
{extend:qx.core.Object,
implement:qx.ui.table.ICellEditorFactory,
construct:function(){arguments.callee.base.call(this);
},
properties:{validationFunction:{check:"Function",
nullable:true,
init:null}},
members:{createCellEditor:function(a){var b=new qx.ui.form.TextField;
b.setAppearance("table-editor-textfield");
b.originalValue=a.value;
if(a.value===null){a.value="";
}b.setValue(""+a.value);
b.addListener("appear",
function(){b.selectAll();
});
return b;
},
getCellEditorValue:function(a){var b=a.getValue();
var c=this.getValidationFunction();
if(!this._done&&c){b=c(b,
a.originalValue);
this._done=true;
}
if(typeof a.originalValue=="number"){b=parseFloat(b);
}return b;
}}});
qx.Class.define("qx.ui.table.columnmodel.Basic",
{extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
},
events:{"widthChanged":"qx.event.type.DataEvent",
"visibilityChangedPre":"qx.event.type.DataEvent",
"visibilityChanged":"qx.event.type.DataEvent",
"orderChanged":"qx.event.type.DataEvent"},
statics:{DEFAULT_WIDTH:100,
DEFAULT_HEADER_RENDERER:new qx.ui.table.headerrenderer.Default(),
DEFAULT_DATA_RENDERER:new qx.ui.table.cellrenderer.Default(),
DEFAULT_EDITOR_FACTORY:new qx.ui.table.celleditor.TextField()},
members:{init:function(a){this._columnDataArr=[];
var b=qx.ui.table.columnmodel.Basic.DEFAULT_WIDTH;
var c=qx.ui.table.columnmodel.Basic.DEFAULT_HEADER_RENDERER;
var d=qx.ui.table.columnmodel.Basic.DEFAULT_DATA_RENDERER;
var e=qx.ui.table.columnmodel.Basic.DEFAULT_EDITOR_FACTORY;
this._overallColumnArr=[];
this._visibleColumnArr=[];
for(var f=0;f<a;f++){this._columnDataArr[f]={width:b,
headerRenderer:c,
dataRenderer:d,
editorFactory:e};
this._overallColumnArr[f]=f;
this._visibleColumnArr[f]=f;
}this._colToXPosMap=null;
},
setColumnWidth:function(a,
b){var c=this._columnDataArr[a].width;
if(c!=b){this._columnDataArr[a].width=b;
var d={col:a,
newWidth:b,
oldWidth:c};
this.fireDataEvent("widthChanged",
d);
}},
getColumnWidth:function(a){return this._columnDataArr[a].width;
},
setHeaderCellRenderer:function(a,
b){this._columnDataArr[a].headerRenderer=b;
},
getHeaderCellRenderer:function(a){return this._columnDataArr[a].headerRenderer;
},
setDataCellRenderer:function(a,
b){this._columnDataArr[a].dataRenderer=b;
},
getDataCellRenderer:function(a){return this._columnDataArr[a].dataRenderer;
},
setCellEditorFactory:function(a,
b){this._columnDataArr[a].editorFactory=b;
},
getCellEditorFactory:function(a){return this._columnDataArr[a].editorFactory;
},
_getColToXPosMap:function(){if(this._colToXPosMap==null){this._colToXPosMap={};
for(var a=0;a<this._overallColumnArr.length;a++){var b=this._overallColumnArr[a];
this._colToXPosMap[b]={overX:a};
}
for(var c=0;c<this._visibleColumnArr.length;c++){var b=this._visibleColumnArr[c];
this._colToXPosMap[b].visX=c;
}}return this._colToXPosMap;
},
getVisibleColumnCount:function(){return this._visibleColumnArr.length;
},
getVisibleColumnAtX:function(a){return this._visibleColumnArr[a];
},
getVisibleX:function(a){return this._getColToXPosMap()[a].visX;
},
getOverallColumnCount:function(){return this._overallColumnArr.length;
},
getOverallColumnAtX:function(a){return this._overallColumnArr[a];
},
getOverallX:function(a){return this._getColToXPosMap()[a].overX;
},
isColumnVisible:function(a){return (this._getColToXPosMap()[a].visX!=null);
},
setColumnVisible:function(a,
b){if(b!=this.isColumnVisible(a)){if(b){var c=this._getColToXPosMap();
var d=c[a].overX;
if(d==null){throw new Error("Showing column failed: "+a+". The column is not added to this TablePaneModel.");
}var e;
for(var f=d+1;f<this._overallColumnArr.length;f++){var g=this._overallColumnArr[f];
var h=c[g].visX;
if(h!=null){e=h;
break;
}}if(e==null){e=this._visibleColumnArr.length;
}this._visibleColumnArr.splice(e,
0,
a);
}else{var i=this.getVisibleX(a);
this._visibleColumnArr.splice(i,
1);
}this._colToXPosMap=null;
if(!this._internalChange){var j={col:a,
visible:b};
this.fireDataEvent("visibilityChangedPre",
j);
this.fireDataEvent("visibilityChanged",
j);
}}},
moveColumn:function(a,
b){this._internalChange=true;
var c=this._overallColumnArr[a];
var d=this.isColumnVisible(c);
if(d){this.setColumnVisible(c,
false);
}this._overallColumnArr.splice(a,
1);
this._overallColumnArr.splice(b,
0,
c);
this._colToXPosMap=null;
if(d){this.setColumnVisible(c,
true);
}this._internalChange=false;
var e={col:c,
fromOverXPos:a,
toOverXPos:b};
this.fireDataEvent("orderChanged",
e);
}},
destruct:function(){this._disposeFields("_overallColumnArr",
"_visibleColumnArr",
"_columnDataArr",
"_colToXPosMap");
}});
qx.Class.define("qx.ui.progressive.model.Abstract",
{type:"abstract",
extend:qx.core.Object,
events:{"dataAvailable":"qx.event.type.Data"},
members:{getElementCount:function(){throw new Error("getElementCount() is abstract");
},
getNextElement:function(){throw new Error("getNextElement() is abstract");
}}});
qx.Class.define("qx.ui.table.selection.Manager",
{extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
},
properties:{selectionModel:{}},
members:{handleMouseDown:function(a,
b){if(b.isLeftPressed()){var c=this.getSelectionModel();
if(!c.isSelectedIndex(a)){this._handleSelectEvent(a,
b);
this._lastMouseDownHandled=true;
}else{this._lastMouseDownHandled=false;
}}else if(b.isRightPressed()&&b.getModifiers()==0){var c=this.getSelectionModel();
if(!c.isSelectedIndex(a)){c.setSelectionInterval(a,
a);
}}},
handleMouseUp:function(a,
b){if(b.isLeftPressed()&&!this._lastMouseDownHandled){this._handleSelectEvent(a,
b);
}},
handleClick:function(a,
b){},
handleSelectKeyDown:function(a,
b){this._handleSelectEvent(a,
b);
},
handleMoveKeyDown:function(a,
b){var c=this.getSelectionModel();
switch(b.getModifiers()){case 0:c.setSelectionInterval(a,
a);
break;
case qx.event.type.Dom.SHIFT_MASK:var d=c.getAnchorSelectionIndex();
if(d==-1){c.setSelectionInterval(a,
a);
}else{c.setSelectionInterval(d,
a);
}break;
}},
_handleSelectEvent:function(a,
b){var c=this.getSelectionModel();
var d=c.getLeadSelectionIndex();
var e=c.getAnchorSelectionIndex();
if(b.isShiftPressed()){if(a!=d||c.isSelectionEmpty()){if(e==-1){e=a;
}
if(b.isCtrlOrCommandPressed()){c.addSelectionInterval(e,
a);
}else{c.setSelectionInterval(e,
a);
}}}else if(b.isCtrlOrCommandPressed()){if(c.isSelectedIndex(a)){c.removeSelectionInterval(a,
a);
}else{c.addSelectionInterval(a,
a);
}}else{if(!(e==d&&e==a&&c.getSelectedCount()==1)){c.setSelectionInterval(a,
a);
}}}}});
qx.Class.define("qx.fx.effect.combination.Drop",
{extend:qx.fx.Base,
construct:function(a){arguments.callee.base.call(this,
a);
this._moveEffect=new qx.fx.effect.core.Move(this._element);
this._fadeEffect=new qx.fx.effect.core.Fade(this._element);
this._mainEffect=new qx.fx.effect.core.Parallel(this._moveEffect,
this._fadeEffect);
},
properties:{direction:{init:"south",
check:["south",
"west",
"east",
"north",
"south-west",
"south-east",
"north-east",
"north-west"]},
xAmount:{init:100,
check:"Number"},
yAmount:{init:100,
check:"Number"},
mode:{init:"out",
check:["in",
"out"]},
modifyDisplay:{init:true,
check:"Boolean"}},
members:{start:function(){arguments.callee.base.call(this);
qx.bom.element.Style.set(this._element,
"display",
"block");
var a=this.getXAmount();
var b=this.getYAmount();
var c={top:qx.bom.element.Location.getTop(this._element),
left:qx.bom.element.Location.getLeft(this._element)};
var d={x:a,
y:b,
sync:true};
switch(this.getDirection()){case "south":d.x=0;
d.y=b;
break;
case "north":d.x=0;
d.y=-b;
break;
case "west":d.x=-a;
d.y=0;
break;
case "east":d.x=a;
d.y=0;
break;
case "south-west":d.x=-a;
d.y=b;
break;
case "south-east":d.x=a;
d.y=b;
break;
case "north-east":d.x=a;
d.y=-b;
break;
case "north-west":d.x=-a;
d.y=-b;
break;
}
if(this.getMode()=="in"){qx.bom.element.Style.set(this._element,
"top",
(c.top-d.y)+"px");
qx.bom.element.Style.set(this._element,
"left",
(c.left-d.x)+"px");
}this._moveEffect.set(d);
this._fadeEffect.afterFinishInternal=function(){for(var e in c){qx.bom.element.Style.set(this._element,
e,
c[e]+"px");
}};
this._fadeEffect.set({duration:0.5,
sync:true,
from:(this.getMode()=="out")?1:0,
to:(this.getMode()=="out")?0:1,
modifyDisplay:true});
this._mainEffect.start();
}},
destruct:function(){this._disposeObjects("_moveEffect",
"_fadeEffect",
"_mainEffect");
}});
qx.Interface.define("qx.util.range.IRange",
{properties:{value:{},
min:{},
max:{},
wrap:{}},
members:{limit:function(a){return true;
}}});
qx.Class.define("qx.util.range.Range",
{extend:qx.core.Object,
implement:[qx.util.range.IRange],
events:{"change":"qx.event.type.Event"},
properties:{value:{check:"!isNaN(value)&&value>=this.getMin()&&value<=this.getMax()",
nullable:true,
init:0,
event:"change"},
precision:{check:"Integer",
nullable:true,
event:"change",
init:0},
min:{check:"Number",
apply:"_applyMin",
event:"change",
init:0},
max:{check:"Number",
apply:"_applyMax",
event:"change",
init:100},
wrap:{check:"Boolean",
init:false}},
members:{_applyMax:function(a,
b){this.setValue(Math.min(this.getValue(),
a));
},
_applyMin:function(a,
b){this.setValue(Math.max(this.getValue(),
a));
},
limit:function(a){var b=this.getPrecision();
if(b!=null){var c=Math.pow(10,
b);
}
if(this.getWrap()){if(b!=null){var a=Math.round(a*c)/c;
}
if(a<this.getMin()){return (this.getMax()-(this.getMin()-a))+1;
}
if(a>this.getMax()){return (this.getMin()+(a-this.getMax()))-1;
}}
if(a<this.getMin()){return this.getMin();
}
if(a>this.getMax()){return this.getMax();
}
if(b!=null){return Math.round(a*c)/c;
}else{return a;
}}}});
qx.Class.define("qx.bom.History",
{type:"singleton",
extend:qx.core.Object,
construct:qx.core.Variant.select("qx.client",
{"mshtml":function(){arguments.callee.base.call(this);
this._iframe=document.createElement("iframe");
this._iframe.style.visibility="hidden";
this._iframe.style.position="absolute";
this._iframe.style.left="-1000px";
this._iframe.style.top="-1000px";
this._iframe.src=qx.util.ResourceManager.toUri("qx/static/html/blank.html");
document.body.appendChild(this._iframe);
this._titles={};
this._state=decodeURIComponent(this.__fw());
this._locationState=decodeURIComponent(this.__fw());
this.__fz(function(){this.__fy(this._state);
this.__fv();
},
this);
},
"default":function(){arguments.callee.base.call(this);
this._titles={};
this._state=this.__fx();
this.__fv();
}}),
events:{"request":"qx.event.type.Data"},
properties:{timeoutInterval:{check:"Number",
init:100,
apply:"_applyTimeoutInterval"}},
members:{addToHistory:function(a,
b){if(b!=null){document.title=b;
this._titles[a]=b;
}
if(a!=this._state){top.location.hash="#"+encodeURIComponent(a);
this.__fy(a);
}},
getState:function(){return this._state;
},
navigateBack:function(){qx.event.Timer.once(function(){history.back();
},
0);
},
navigateForward:function(){qx.event.Timer.once(function(){history.forward();
},
0);
},
_applyTimeoutInterval:function(a){this._timer.setInterval(a);
},
__fu:function(a){this._state=a;
this.fireDataEvent("request",
a);
if(this._titles[a]!=null){document.title=this._titles[a];
}},
__fv:function(){this._timer=new qx.event.Timer(this.getTimeoutInterval());
this._timer.addListener("interval",
function(a){var b=this.__fx();
if(b!=this._state){this.__fu(b);
}},
this);
this._timer.start();
},
__fw:function(){var a=top.location.href;
var b=a.indexOf("#");
return b>=0?a.substring(b+1):"";
},
__fx:qx.core.Variant.select("qx.client",
{"mshtml":function(){var a=decodeURIComponent(this.__fw());
if(a!=this._locationState){this._locationState=a;
this.__fy(a);
return a;
}var b=this._iframe.contentWindow.document;
var c=b.getElementById("state");
var d=c?decodeURIComponent(c.innerText):"";
return d;
},
"default":function(){return decodeURIComponent(this.__fw());
}}),
__fy:qx.core.Variant.select("qx.client",
{"mshtml":function(a){var b='<html><body><div id="state">'+encodeURIComponent(a)+'</div></body></html>';
try{var c=this._iframe.contentWindow.document;
c.open();
c.write(b);
c.close();
}catch(e){return false;
}return true;
},
"default":function(a){qx.event.Timer.once(function(){top.location.hash="#"+encodeURIComponent(a);
},
this,
0);
return true;
}}),
__fz:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b){if(!this._iframe.contentWindow||!this._iframe.contentWindow.document){qx.event.Timer.once(function(){this.__fz(a,
b);
},
this,
10);
return;
}a.call(b||window);
},
"default":null})},
destruct:function(){this._timer.stop();
this._disposeObjects("_timer");
this._disposeFields("_iframe",
"_titles");
}});
qx.Class.define("qx.html.Iframe",
{extend:qx.html.Element,
construct:function(){arguments.callee.base.call(this,
"iframe");
},
events:{"load":"qx.event.type.Event"},
members:{_applyProperty:function(a,
b){arguments.callee.base.call(this,
a,
b);
if(a=="source"){qx.bom.Iframe.setSource(this._element,
b);
}},
_createDomElement:function(){return qx.bom.Iframe.create(this._content);
},
getWindow:function(){if(this._element){return qx.bom.Iframe.getWindow(this._element);
}else{return null;
}},
getDocument:function(){if(this._element){return qx.bom.Iframe.getDocument(this._element);
}else{return null;
}},
getBody:function(){if(this._element){return qx.bom.Iframe.getBody(this._element);
}else{return null;
}},
setSource:function(a){this._setProperty("source",
a);
return this;
},
getSource:function(){return this._getProperty("source");
},
setName:function(a){this.setAttribute("name",
a);
return this;
},
getName:function(){return this.setAttribute("name");
},
reload:function(){if(this._element){var a=this.getSource();
this.setSource(null);
this.setSource(a);
}}}});
qx.Class.define("qx.util.fsm.State",
{extend:qx.core.Object,
construct:function(a,
b){arguments.callee.base.call(this);
this.setName(a);
if(typeof (b)!="object"){throw new Error("State info must be an object");
}for(var c in b){switch(c){case "onentry":this.setOnentry(b[c]);
break;
case "onexit":this.setOnexit(b[c]);
break;
case "autoActionsBeforeOnentry":this.setAutoActionsBeforeOnentry(b[c]);
break;
case "autoActionsAfterOnentry":this.setAutoActionsAfterOnentry(b[c]);
break;
case "autoActionsBeforeOnexit":this.setAutoActionsBeforeOnexit(b[c]);
break;
case "autoActionsAfterOnexit":this.setAutoActionsAfterOnexit(b[c]);
break;
case "events":this.setEvents(b[c]);
break;
default:this.setUserData(c,
b[c]);
this.debug("State "+a+": "+"Adding user-provided field to state: "+c);
break;
}}if(!this.getEvents()){throw new Error("The events object must be provided in new state info");
}this.transitions={};
},
statics:{_commonTransformAutoActions:function(b,
c){if(typeof (c)!="object"){throw new Error("Invalid "+b+" value: "+typeof (c));
}var d;
var e="try"+"{";
var h;
var k;
for(var l in c){var m=c[l];
if(!m instanceof Array){throw new Error("Invalid function request type: "+"expected array, found "+typeof (m));
}for(var n=0;n<m.length;n++){k=m[n];
if(typeof (k)!="object"){throw new Error("Invalid function request parameter type: "+"expected object, found "+typeof (m[h]));
}var o=k["parameters"];
if(!o){o=[];
}else{if(!o instanceof Array){throw new Error("Invalid function parameters: "+"expected array, found "+typeof (o));
}}d=l+"(";
for(var p=0;p<o.length;p++){if(p!=0){d+=",";
}
if(typeof (o[p])=="function"){d+="("+o[p]+")(fsm)";
}else if(typeof (o[p])=="string"){d+='"'+o[p]+'"';
}else{d+=o[p];
}}d+=")";
var q=k["objects"];
if(!q){q=[];
}else if(!q instanceof Array){throw new Error("Invalid 'objects' list: expected array, got "+typeof (q));
}
for(var p=0;p<q.length;p++){if(typeof (q[p])!="string"){throw new Error("Invalid friendly name in 'objects' list: "+q[p]);
}e+=" fsm.getObject('"+q[p]+"')."+d+";";
}var r=k["groups"];
if(r){if(!r instanceof Array){throw new Error("Invalid 'groups' list: expected array, got "+typeof (r));
}
for(p=0;p<r.length;p++){e+="  var groupObjects = "+"    fsm.getGroupObjects('"+r[p]+"');"+"  for (var i = 0; i < groupObjects.length; i++)"+"  {"+"    var objName = groupObjects[i];"+"    fsm.getObject(objName)."+d+";"+"  }";
}}}}e+="}"+"catch(e)"+"{"+"  fsm.debug(e);"+"}";
return new Function("fsm",
e);
}},
properties:{name:{transform:"__fA",
nullable:true},
onentry:{transform:"__fB",
nullable:true,
init:function(a,
b){}},
onexit:{transform:"__fC",
nullable:true,
init:function(a,
b){}},
autoActionsBeforeOnentry:{transform:"__fE",
nullable:true,
init:function(a,
b){}},
autoActionsAfterOnentry:{transform:"__fF",
nullable:true,
init:function(a,
b){}},
autoActionsBeforeOnexit:{transform:"__fG",
nullable:true,
init:function(a,
b){}},
autoActionsAfterOnexit:{transform:"__fH",
nullable:true,
init:function(a,
b){}},
events:{transform:"__fD",
nullable:true}},
members:{__fA:function(a){if(typeof (a)!="string"||a.length<1){throw new Error("Invalid state name");
}return a;
},
__fB:function(a){switch(typeof (a)){case "undefined":return function(b,
c){};
case "function":return a;
default:throw new Error("Invalid onentry type: "+typeof (a));
return null;
}},
__fC:function(a){switch(typeof (a)){case "undefined":return function(b,
c){};
case "function":return a;
default:throw new Error("Invalid onexit type: "+typeof (a));
return null;
}},
__fD:function(a){if(typeof (a)!="object"){throw new Error("events must be an object");
}for(var b in a){var c=a[b];
if(typeof (c)=="number"&&c!=qx.util.fsm.FiniteStateMachine.EventHandling.PREDICATE&&c!=qx.util.fsm.FiniteStateMachine.EventHandling.BLOCKED){throw new Error("Invalid numeric value in events object: "+b+": "+c);
}else if(typeof (c)=="object"){for(var d in c){if(typeof (c[d])=="number"&&c[d]!=qx.util.fsm.FiniteStateMachine.EventHandling.PREDICATE&&c[d]!=qx.util.fsm.FiniteStateMachine.EventHandling.BLOCKED){throw new Error("Invalid numeric value in events object "+"("+b+"): "+d+": "+c[d]);
}else if(typeof (c[d])!="string"&&typeof (c[d])!="number"){throw new Error("Invalid value in events object "+"("+b+"): "+d+": "+c[d]);
}}}else if(typeof (c)!="string"&&typeof (c)!="number"){throw new Error("Invalid value in events object: "+b+": "+a[b]);
}}return a;
},
__fE:function(a){return qx.util.fsm.State._commonTransformAutoActions("autoActionsBeforeOnentry",
a);
},
__fF:function(a){return qx.util.fsm.State._commonTransformAutoActions("autoActionsAfterOnentry",
a);
},
__fG:function(a){return qx.util.fsm.State._commonTransformAutoActions("autoActionsBeforeOnexit",
a);
},
__fH:function(a){return qx.util.fsm.State._commonTransformAutoActions("autoActionsAfterOnexit",
a);
},
addTransition:function(a){if(!a instanceof qx.util.fsm.Transition){throw new Error("Invalid transition: not an instance of "+"qx.util.fsm.Transition");
}this.transitions[a.getName()]=a;
}}});
qx.Class.define("qx.util.fsm.FiniteStateMachine",
{extend:qx.core.Object,
construct:function(a){arguments.callee.base.call(this);
this.setName(a);
this._states={};
this._startState=null;
this._savedStates=[];
this._eventQueue=[];
this._blockedEvents=[];
this._friendlyToObject={};
this._friendlyToHash={};
this._hashToFriendly={};
this._groupToFriendly={};
this._friendlyToGroups={};
},
statics:{StateChange:{CURRENT_STATE:1,
POP_STATE_STACK:2,
TERMINATE:3},
EventHandling:{PREDICATE:1,
BLOCKED:2},
DebugFlags:{EVENTS:1,
TRANSITIONS:2,
FUNCTION_DETAIL:4,
OBJECT_NOT_FOUND:8}},
properties:{name:{check:"String",
nullable:true},
state:{check:"String",
nullable:true},
previousState:{check:"String",
nullable:true},
nextState:{check:"String",
nullable:true},
maxSavedStates:{check:"Number",
init:2},
debugFlags:{check:"Number",
init:7}},
members:{addState:function(a){if(!a instanceof qx.util.fsm.State){throw new Error("Invalid state: not an instance of "+"qx.util.fsm.State");
}var b=a.getName();
if(b in this._states){throw new Error("State "+b+" already exists");
}if(this._startState==null){this._startState=b;
}this._states[b]=a;
},
replaceState:function(a,
b){if(!a instanceof qx.util.fsm.State){throw new Error("Invalid state: not an instance of "+"qx.util.fsm.State");
}var c=a.getName();
var d=this._states[c];
this._states[c]=a;
if(b){d._bNeedDispose=true;
}return d;
},
addObject:function(a,
b,
c){var d=b.toHashCode();
this._friendlyToHash[a]=d;
this._hashToFriendly[d]=a;
this._friendlyToObject[a]=b;
if(!c){return;
}if(typeof (c)=="string"){c=[c];
}for(var e=0;e<c.length;e++){var f=c[e];
if(!this._groupToFriendly[f]){this._groupToFriendly[f]={};
}this._groupToFriendly[f][a]=true;
if(!this._friendlyToGroups[a]){this._friendlyToGroups[a]=[];
}this._friendlyToGroups[a]=this._friendlyToGroups[a].concat(c);
}},
removeObject:function(a){var b=this._friendlyToHash[a];
if(this._friendlyToGroups[a]){for(var c in this._friendlyToGroups[a]){delete this._groupToFriendly[c];
}delete this._friendlyToGroups[a];
}delete this._hashToFriendly[b];
delete this._friendlyToHash[a];
delete this._friendlyToObject[a];
},
getObject:function(a){return this._friendlyToObject[a];
},
getFriendlyName:function(a){var b=a.toHashCode();
return b?this._hashToFriendly[b]:null;
},
getGroupObjects:function(b){var c=[];
for(var d in this._groupToFriendly[b]){c.push(d);
}return c;
},
displayAllObjects:function(){for(var a in this._friendlyToHash){var b=this._friendlyToHash[a];
var c=this.getObject(a);
this.debug(a+" => "+b);
this.debug("  "+b+" => "+this._hashToFriendly[b]);
this.debug("  "+a+" => "+this.getObject(a));
this.debug("  "+this.getObject(a)+" => "+this.getFriendlyName(c));
}},
start:function(){var a=this._startState;
if(a==null){throw new Error("Machine started with no available states");
}this.setState(a);
this.setPreviousState(null);
this.setNextState(null);
var b=(this.getDebugFlags()&qx.util.fsm.FiniteStateMachine.DebugFlags.FUNCTION_DETAIL);
if(b){this.debug(this.getName()+"#"+a+"#actionsBeforeOnentry");
}this._states[a].getAutoActionsBeforeOnentry()(this);
if(b){this.debug(this.getName()+"#"+a+"#entry");
}this._states[a].getOnentry()(this,
null);
if(b){this.debug(this.getName()+"#"+a+"#actionsAfterOnentry");
}this._states[a].getAutoActionsAfterOnentry()(this);
},
pushState:function(a){if(this._savedStates.length>=this.getMaxSavedStates()){throw new Error("Saved-state stack is full");
}
if(a){this._savedStates.push(this.getState());
}else{this._savedStates.push(this.getPreviousState());
}},
postponeEvent:function(a){this._blockedEvents.unshift(a);
},
copyEvent:function(a){var b={};
for(var c in a){b[c]=a[c];
}return b;
},
enqueueEvent:function(a,
b){if(b){this._eventQueue.push(a);
}else{this._eventQueue.unshift(a);
}
if(this.getDebugFlags()&qx.util.fsm.FiniteStateMachine.DebugFlags.EVENTS){if(b){this.debug(this.getName()+": Pushed event: "+a.getType());
}else{this.debug(this.getName()+": Queued event: "+a.getType());
}}},
eventListener:function(a){var b=this.copyEvent(a);
this.enqueueEvent(b,
false);
this.__fI();
},
__fI:function(){if(this._eventProcessingInProgress){return ;
}this._eventProcessingInProgress=true;
while(this._eventQueue.length>0){var a=this._eventQueue.pop();
var b=this.__fJ(a);
if(b){a.dispose();
}}this._eventProcessingInProgress=false;
},
__fJ:function(a){var b;
var c;
var d;
var f;
var g;
var h;
var j;
var k=this.getDebugFlags();
var l=k&qx.util.fsm.FiniteStateMachine.DebugFlags.EVENTS;
var m=k&qx.util.fsm.FiniteStateMachine.DebugFlags.TRANSITIONS;
var n=k&qx.util.fsm.FiniteStateMachine.DebugFlags.FUNCTION_DETAIL;
var o=k&qx.util.fsm.FiniteStateMachine.DebugFlags.OBJECT_NOT_FOUND;
if(l){this.debug(this.getName()+": Process event: "+a.getType());
}b=this.getState();
f=this._states[b];
g=f.transitions;
h=f.getEvents()[a.getType()];
if(!h){if(l){this.debug(this.getName()+": Event '"+a.getType()+"'"+" not handled.  Ignoring.");
}return true;
}if(typeof (h)=="object"){var p=this.getFriendlyName(a.getTarget());
if(!p){if(o){this.debug(this.getName()+": Could not find friendly name for '"+a.getType()+"' on '"+a.getTarget()+"'");
}return true;
}j=h[p];
if(!j){if(l){this.debug(this.getName()+": Event '"+a.getType()+"'"+" not handled for target "+p+".  Ignoring.");
}return true;
}}else{j=h;
}
switch(j){case qx.util.fsm.FiniteStateMachine.EventHandling.PREDICATE:break;
case qx.util.fsm.FiniteStateMachine.EventHandling.BLOCKED:if(l){this.debug(this.getName()+": Event '"+a.getType()+"'"+" blocked.  Re-queuing.");
}this._blockedEvents.unshift(a);
return false;
default:if(typeof (j)=="string"){if(g[j]){var q=g[j];
g={};
g[j]=q;
}else{throw new Error("Explicit transition "+j+" does not exist");
}break;
}}for(var r in g){var q=g[r];
switch(q.getPredicate()(this,
a)){case true:break;
case false:continue;
case null:return true;
default:throw new Error("Transition "+b+":"+r+" returned a value other than "+"true, false, or null.");
}c=q.getNextState();
if(typeof (c)=="string"){if(!c in this._states){throw new Error("Attempt to transition to nonexistent state "+c);
}this.setNextState(c);
}else{switch(c){case qx.util.fsm.FiniteStateMachine.StateChange.CURRENT_STATE:c=b;
this.setNextState(c);
break;
case qx.util.fsm.FiniteStateMachine.StateChange.POP_STATE_STACK:if(this._savedStates.length==0){throw new Error("Attempt to transition to POP_STATE_STACK "+"while state stack is empty.");
}c=this._savedStates.pop();
this.setNextState(c);
break;
default:throw new Error("Internal error: invalid nextState");
break;
}}if(n){this.debug(this.getName()+"#"+b+"#"+r+"#autoActionsBeforeOntransition");
}q.getAutoActionsBeforeOntransition()(this);
if(n){this.debug(this.getName()+"#"+b+"#"+r+"#ontransition");
}q.getOntransition()(this,
a);
if(n){this.debug(this.getName()+"#"+b+"#"+r+"#autoActionsAfterOntransition");
}q.getAutoActionsAfterOntransition()(this);
if(n){this.debug(this.getName()+"#"+b+"#autoActionsBeforeOnexit");
}f.getAutoActionsBeforeOnexit()(this);
if(n){this.debug(this.getName()+"#"+b+"#exit");
}f.getOnexit()(this,
a);
if(n){this.debug(this.getName()+"#"+b+"#autoActionsAfterOnexit");
}f.getAutoActionsAfterOnexit()(this);
if(f._bNeedDispose){f.dispose();
}f=this._states[this.getNextState()];
this.setPreviousState(b);
this.setState(this.getNextState());
this.setNextState(null);
d=b;
b=c;
c=undefined;
if(n){this.debug(this.getName()+"#"+b+"#autoActionsBeforeOnentry");
}f.getAutoActionsBeforeOnentry()(this);
if(n){this.debug(this.getName()+"#"+b+"#entry");
}f.getOnentry()(this,
a);
if(n){this.debug(this.getName()+"#"+b+"#autoActionsAfterOnentry");
}f.getAutoActionsAfterOnentry()(this);
var h;
for(var s=0;s<this._blockedEvents.length;s++){h=this._blockedEvents.pop();
this._eventQueue.unshift(h);
}
if(m){this.debug(this.getName()+"#"+d+" => "+this.getName()+"#"+b);
}return true;
}
if(m){this.debug(this.getName()+"#"+b+": event '"+a.getType()+"'"+": no transition found.  No state change.");
}return true;
}},
destruct:function(){this._disposeArray("_eventQueue");
this._disposeArray("_blockedEvents");
this._disposeFields("_savedStates",
"_states");
}});
qx.Class.define("qx.util.fsm.Transition",
{extend:qx.core.Object,
construct:function(a,
b){arguments.callee.base.call(this);
this.setName(a);
for(var c in b){switch(c){case "predicate":this.setPredicate(b[c]);
break;
case "nextState":this.setNextState(b[c]);
break;
case "autoActionsBeforeOntransition":this.setAutoActionsBeforeOntransition(b[c]);
break;
case "autoActionsAfterOntransition":this.setAutoActionsAfterOntransition(b[c]);
break;
case "ontransition":this.setOntransition(b[c]);
break;
default:this.setUserData(c,
b[c]);
this.debug("Transition "+a+": "+"Adding user-provided field to transition: "+c);
break;
}}},
properties:{name:{check:"String",
nullable:true},
predicate:{init:function(a,
b){return true;
},
transform:"__fK"},
nextState:{init:qx.util.fsm.FiniteStateMachine.StateChange.CURRENT_STATE,
transform:"__fL"},
autoActionsBeforeOntransition:{init:function(a,
b){}},
autoActionsAfterOntransition:{init:function(a,
b){}},
ontransition:{init:function(a,
b){},
transform:"__fM"}},
members:{__fK:function(a){switch(typeof (a)){case "undefined":return function(b,
c){return true;
};
case "boolean":return function(b,
c){return a;
};
case "function":return a;
default:throw new Error("Invalid transition predicate type: "+typeof (a));
break;
}},
__fL:function(a){switch(typeof (a)){case "string":return a;
case "number":switch(a){case qx.util.fsm.FiniteStateMachine.StateChange.CURRENT_STATE:case qx.util.fsm.FiniteStateMachine.StateChange.POP_STATE_STACK:case qx.util.fsm.FiniteStateMachine.StateChange.TERMINATE:return a;
default:throw new Error("Invalid transition nextState value: "+a+": "+"nextState must be an explicit state name, "+"or one of the Fsm.StateChange constants");
}break;
default:throw new Error("Invalid transition nextState type: "+typeof (a));
break;
}},
__fM:function(a){switch(typeof (a)){case "undefined":return function(b,
c){};
case "function":return a;
default:throw new Error("Invalid ontransition type: "+typeof (a));
break;
}}}});
qx.Class.define("qx.ui.table.model.Abstract",
{type:"abstract",
extend:qx.core.Object,
implement:qx.ui.table.ITableModel,
events:{"dataChanged":"qx.event.type.DataEvent",
"metaDataChanged":"qx.event.type.DataEvent"},
construct:function(){arguments.callee.base.call(this);
this._columnIdArr=[];
this._columnNameArr=[];
this._columnIndexMap={};
},
members:{getRowCount:function(){throw new Error("getRowCount is abstract");
},
getRowData:function(a){return null;
},
isColumnEditable:function(a){return false;
},
isColumnSortable:function(a){return false;
},
sortByColumn:function(a,
b){},
getSortColumnIndex:function(){return -1;
},
isSortAscending:function(){return true;
},
prefetchRows:function(a,
b){},
getValue:function(a,
b){throw new Error("getValue is abstract");
},
getValueById:function(a,
b){return this.getValue(this.getColumnIndexById(a),
b);
},
setValue:function(a,
b,
c){throw new Error("setValue is abstract");
},
setValueById:function(a,
b,
c){return this.setValue(this.getColumnIndexById(a),
b,
c);
},
getColumnCount:function(){return this._columnIdArr.length;
},
getColumnIndexById:function(a){return this._columnIndexMap[a];
},
getColumnId:function(a){return this._columnIdArr[a];
},
getColumnName:function(a){return this._columnNameArr[a];
},
setColumnIds:function(a){this._columnIdArr=a;
this._columnIndexMap={};
for(var b=0;b<a.length;b++){this._columnIndexMap[a[b]]=b;
}this._columnNameArr=new Array(a.length);
if(!this._internalChange){this.fireEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
}},
setColumnNamesByIndex:function(a){if(this._columnIdArr.length!=a.length){throw new Error("this._columnIdArr and columnNameArr have different length: "+this._columnIdArr.length+" != "+a.length);
}this._columnNameArr=a;
this.fireEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
},
setColumnNamesById:function(a){this._columnNameArr=new Array(this._columnIdArr.length);
for(var b=0;b<this._columnIdArr.length;++b){this._columnNameArr[b]=a[this._columnIdArr[b]];
}},
setColumns:function(a,
b){if(b==null){b=a;
}
if(b.length!=a.length){throw new Error("columnIdArr and columnNameArr have different length: "+b.length+" != "+a.length);
}this._internalChange=true;
this.setColumnIds(b);
this._internalChange=false;
this.setColumnNamesByIndex(a);
}},
destruct:function(){this._disposeFields("_columnIdArr",
"_columnNameArr",
"_columnIndexMap");
}});
qx.Class.define("qx.ui.table.model.Remote",
{extend:qx.ui.table.model.Abstract,
construct:function(){arguments.callee.base.call(this);
this._sortColumnIndex=-1;
this._sortAscending=true;
this._rowCount=-1;
this._lruCounter=0;
this._firstLoadingBlock=-1;
this._firstRowToLoad=-1;
this._lastRowToLoad=-1;
this._ignoreCurrentRequest=false;
this._rowBlockCache={};
this._rowBlockCount=0;
this._sortableColArr=null;
this._editableColArr=null;
},
properties:{blockSize:{check:"Integer",
init:50},
maxCachedBlockCount:{check:"Integer",
init:15},
clearCacheOnRemove:{check:"Boolean",
init:false}},
members:{getRowCount:function(){if(this._rowCount==-1){this._loadRowCount();
return (this._rowCount==-1)?0:this._rowCount;
}else{return this._rowCount;
}},
_loadRowCount:function(){throw new Error("_loadRowCount is abstract");
},
_onRowCountLoaded:function(a){if(a==null||a<0){a=0;
}this._rowCount=a;
var b={firstRow:0,
lastRow:a-1,
firstColumn:0,
lastColumn:this.getColumnCount()-1};
this.fireDataEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
b);
},
reloadData:function(){this.clearCache();
if(this._firstLoadingBlock!=-1){var a=this._cancelCurrentRequest();
if(a){this._firstLoadingBlock=-1;
this._ignoreCurrentRequest=false;
}else{this._ignoreCurrentRequest=true;
}}this._firstRowToLoad=-1;
this._lastRowToLoad=-1;
this._loadRowCount();
},
clearCache:function(){this._rowBlockCache={};
this._rowBlockCount=0;
},
getCacheContent:function(){return {sortColumnIndex:this._sortColumnIndex,
sortAscending:this._sortAscending,
rowCount:this._rowCount,
lruCounter:this._lruCounter,
rowBlockCache:this._rowBlockCache,
rowBlockCount:this._rowBlockCount};
},
restoreCacheContent:function(a){if(this._firstLoadingBlock!=-1){var b=this._cancelCurrentRequest();
if(b){this._firstLoadingBlock=-1;
this._ignoreCurrentRequest=false;
}else{this._ignoreCurrentRequest=true;
}}this._sortColumnIndex=a.sortColumnIndex;
this._sortAscending=a.sortAscending;
this._rowCount=a.rowCount;
this._lruCounter=a.lruCounter;
this._rowBlockCache=a.rowBlockCache;
this._rowBlockCount=a.rowBlockCount;
var c={firstRow:0,
lastRow:this._rowCount-1,
firstColumn:0,
lastColumn:this.getColumnCount()-1};
this.dispatchEvent(new qx.event.type.DataEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
c),
true);
},
_cancelCurrentRequest:function(){return false;
},
iterateCachedRows:function(a,
b){var c=this.getBlockSize();
var d=Math.ceil(this.getRowCount()/c);
for(var e=0;e<=d;e++){var f=this._rowBlockCache[e];
if(f!=null){var g=e*c;
var h=f.rowDataArr;
for(var i=0;i<h.length;i++){var j=h[i];
var k=a.call(b,
g+i,
j);
if(k!=null){h[i]=k;
}}}}},
prefetchRows:function(a,
b){if(this._firstLoadingBlock==-1){var c=this.getBlockSize();
var d=Math.ceil(this._rowCount/c);
var e=parseInt(a/c)-1;
if(e<0){e=0;
}var f=parseInt(b/c)+1;
if(f>=d){f=d-1;
}var g=-1;
var h=-1;
for(var i=e;i<=f;i++){if(this._rowBlockCache[i]==null||this._rowBlockCache[i].isDirty){if(g==-1){g=i;
}h=i;
}}if(g!=-1){this._firstRowToLoad=-1;
this._lastRowToLoad=-1;
this._firstLoadingBlock=g;
this._loadRowData(g*c,
(h+1)*c-1);
}}else{this._firstRowToLoad=a;
this._lastRowToLoad=b;
}},
_loadRowData:function(a,
b){throw new Error("_loadRowCount is abstract");
},
_onRowDataLoaded:function(a){if(a!=null&&!this._ignoreCurrentRequest){var b=this.getBlockSize();
var c=Math.ceil(a.length/b);
if(c==1){this._setRowBlockData(this._firstLoadingBlock,
a);
}else{for(var d=0;d<c;d++){var e=d*b;
var f=[];
var g=Math.min(b,
a.length-e);
for(var h=0;h<g;h++){f.push(a[e+h]);
}this._setRowBlockData(this._firstLoadingBlock+d,
f);
}}var j={firstRow:this._firstLoadingBlock*b,
lastRow:(this._firstLoadingBlock+c+1)*b-1,
firstColumn:0,
lastColumn:this.getColumnCount()-1};
this.fireDataEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
j);
}this._firstLoadingBlock=-1;
this._ignoreCurrentRequest=false;
if(this._firstRowToLoad!=-1){this.prefetchRows(this._firstRowToLoad,
this._lastRowToLoad);
}},
_setRowBlockData:function(a,
b){if(this._rowBlockCache[a]==null){this._rowBlockCount++;
while(this._rowBlockCount>this.getMaxCachedBlockCount()){var c;
var d=this._lruCounter;
for(var e in this._rowBlockCache){var f=this._rowBlockCache[e].lru;
if(f<d&&e>1){d=f;
c=e;
}}delete this._rowBlockCache[c];
this._rowBlockCount--;
}}this._rowBlockCache[a]={lru:++this._lruCounter,
rowDataArr:b};
},
removeRow:function(a){if(this.getClearCacheOnRemove()){this.clearCache();
var b={firstRow:0,
lastRow:this.getRowCount()-1,
firstColumn:0,
lastColumn:this.getColumnCount()-1};
this.fireDataEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
b);
}else{var c=this.getBlockSize();
var d=Math.ceil(this.getRowCount()/c);
var e=parseInt(a/c);
for(var f=e;f<=d;f++){var g=this._rowBlockCache[f];
if(g!=null){var h=0;
if(f==e){h=a-f*c;
}g.rowDataArr.splice(h,
1);
if(f==d-1){if(g.rowDataArr.length==0){delete this._rowBlockCache[f];
}}else{var i=this._rowBlockCache[f+1];
if(i!=null){g.rowDataArr.push(i.rowDataArr[0]);
}else{g.isDirty=true;
}}}}
if(this._rowCount!=-1){this._rowCount--;
}if(this.hasListener(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED)){var b={firstRow:a,
lastRow:this.getRowCount()-1,
firstColumn:0,
lastColumn:this.getColumnCount()-1};
this.fireDataEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
b);
}}},
getRowData:function(a){var b=this.getBlockSize();
var c=parseInt(a/b);
var d=this._rowBlockCache[c];
if(d==null){return null;
}else{var e=d.rowDataArr[a-(c*b)];
if(d.lru!=this._lruCounter){d.lru=++this._lruCounter;
}return e;
}},
getValue:function(a,
b){var c=this.getRowData(b);
if(c==null){return null;
}else{var d=this.getColumnId(a);
return c[d];
}},
setValue:function(a,
b,
c){var d=this.getRowData(b);
if(d==null){return null;
}else{var e=this.getColumnId(a);
d[e]=c;
if(this.hasListener(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED)){var f={firstRow:b,
lastRow:b,
firstColumn:a,
lastColumn:a};
this.fireDataEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
f);
}}},
setEditable:function(a){this._editableColArr=[];
for(var b=0;b<this.getColumnCount();b++){this._editableColArr[b]=a;
}this.fireEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
},
setColumnEditable:function(a,
b){if(b!=this.isColumnEditable(a)){if(this._editableColArr==null){this._editableColArr=[];
}this._editableColArr[a]=b;
this.fireEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
}},
isColumnEditable:function(a){return (this._editableColArr?(this._editableColArr[a]==true):false);
},
setColumnSortable:function(a,
b){if(b!=this.isColumnSortable(a)){if(this._sortableColArr==null){this._sortableColArr=[];
}this._sortableColArr[a]=b;
this.fireEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
}},
isColumnSortable:function(a){return (this._sortableColArr?(this._sortableColArr[a]==true):false);
},
sortByColumn:function(a,
b){if(this._sortColumnIndex!=a||this._sortAscending!=b){this._sortColumnIndex=a;
this._sortAscending=b;
this.clearCache();
this.fireEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
}},
getSortColumnIndex:function(){return this._sortColumnIndex;
},
isSortAscending:function(){return this._sortAscending;
}},
destruct:function(){this._disposeFields("_sortableColArr",
"_editableColArr");
}});
qx.Class.define("qx.ui.progressive.Progressive",
{extend:qx.ui.layout.VBox,
construct:function(a){arguments.callee.base.call(this);
this._renderer={};
this.set({left:20,
top:20,
right:20,
bottom:20,
spacing:0,
border:new qx.ui.decoration.Single(1,
"solid",
"#dddddd"),
overflow:"hidden",
backgroundColor:"white"});
this.addListener("appear",
function(b){this.fireEvent("widthChanged");
});
if(!a){a=new qx.ui.progressive.structure.Default();
}this._structure=a;
a.applyStructure(this);
this.__bInitialRenderComplete=false;
this.__bRendering=false;
this.__initialNumElements=0;
},
events:{"renderStart":"qx.event.type.Data",
"renderEnd":"qx.event.type.Data",
"progress":"qx.event.type.Data",
"progressDetail":"qx.event.type.Data",
"widthChanged":"qx.event.type.Event"},
properties:{dataModel:{apply:"_applyDataModel"},
batchSize:{init:20}},
members:{addRenderer:function(a,
b){this._renderer[a]=b;
b.join(this,
a);
},
removeRenderer:function(a){if(!this._renderers[a]){throw new Error("No existing renderer named "+a);
}delete this._renderer[a];
},
render:function(){if(this.__bRendering){return;
}this.__bRendering=true;
var a;
var b;
var c=new qx.ui.progressive.State({progressive:this,
model:this.getDataModel(),
pane:this._structure.getPane(),
batchSize:this.getBatchSize(),
rendererData:this.__fO(),
userData:{}});
this.__t1=new Date();
if(this.__bInitialRenderComplete){this.__initialNumElements=c.getModel().getElementCount();
this.fireDataEvent("renderStart",
{state:c,
initial:this.__initialNumElements});
this.__fN(c);
}else{qx.event.Timer.once(function(){this.__initialNumElements=c.getModel().getElementCount();
this.fireDataEvent("renderStart",
{state:c,
initial:this.__initialNumElements});
this.__fN(c);
this.__bInitialRenderComplete=true;
},
this,
10);
}},
_changeInnerWidth:function(a,
b){arguments.callee.base.call(this,
a,
b);
this.fireEvent("widthChanged");
},
_applyDataModel:function(a,
b){if(b){b.removeListener("dataAvailable",
this.__fP,
this);
b.dispose();
}a.addListener("dataAvailable",
this.__fP,
this);
},
__fN:function(a){var b;
var c;
for(var d=a.getBatchSize();d>0;d--){b=a.getModel().getNextElement();
if(!b){this.debug("Render time: "+(new Date()-this.__t1)+"ms");
this.__bRendering=false;
this.fireDataEvent("renderEnd",
a);
a.dispose();
return ;
}c=b.element;
renderer=this._renderer[c.renderer];
renderer.render(a,
c);
this.fireDataEvent("progressDetail",
{initial:this.__initialNumElements,
remaining:b.remaining,
element:c});
}this.fireDataEvent("progress",
{initial:this.__initialNumElements,
remaining:b.remaining});
qx.event.Timer.once(function(){this.__fN(a);
},
this,
0);
},
__fO:function(){var a={};
for(var b in this._renderer){a[b]={};
}return a;
},
__fP:function(a){this.__initialNumElements=a.getData();
this.render();
}},
destruct:function(){for(var a in this._renderer){this._renderer[a].dispose();
}this._disposeFields("_renderer");
}});
qx.Class.define("qx.ui.progressive.State",
{extend:qx.core.Object,
construct:function(a){arguments.callee.base.call(this);
this.setProgressive(a.progressive);
this.setModel(a.model);
this.setPane(a.pane);
this.setBatchSize(a.batchSize);
this.setRendererData(a.rendererData);
this.setUserData(a.userData);
},
properties:{progressive:{nullable:true},
model:{nullable:true},
pane:{nullable:true},
batchSize:{},
rendererData:{},
userData:{}},
destruct:function(){this.setProgressive(null);
this.setModel(null);
this.setPane(null);
}});
qx.Class.define("qx.locale.String",
{statics:{getQuotationStart:function(a){return qx.locale.Manager.getInstance().translate("cldr_quotationStart",
[],
a);
},
getQuotationEnd:function(a){return qx.locale.Manager.getInstance().translate("cldr_quotationEnd",
[],
a);
},
getAlternateQuotationStart:function(a){return qx.locale.Manager.getInstance().translate("cldr_alternateQuotationStart",
[],
a);
},
getAlternateQuotationEnd:function(a){return qx.locale.Manager.getInstance().translate("cldr_alternateQuotationEnd",
[],
a);
}}});
qx.Class.define("qx.ui.form.CheckBox",
{extend:qx.ui.form.ToggleButton,
construct:function(a){{this.assertArgumentsCount(arguments,
0,
1);
};
arguments.callee.base.call(this,
a);
},
properties:{appearance:{refine:true,
init:"checkbox"},
allowGrowX:{refine:true,
init:false}}});
qx.Class.define("qx.ui.progressive.renderer.table.Row",
{extend:qx.ui.progressive.renderer.Abstract,
construct:function(a){arguments.callee.base.call(this);
this._columnWidths=a;
this._renderers={};
this._defaultCellRenderer=new qx.ui.progressive.renderer.table.cell.Default();
this._progressive=null;
this._layout=new qx.ui.layout.HBox();
this._layout.connectToWidget(this);
},
statics:{BACKGROUND_COLOR:["rgb(238, 255, 255)",
"rgb(255, 255, 255)"],
__fQ:null,
__fR:"  position: absolute;"+"  top: 0px;"+"  height: 100%;"+"  overflow:hidden;"+"  text-overflow:ellipsis;"+"  -o-text-overflow: ellipsis;"+"  white-space:nowrap;"+"  border-right:1px solid #eeeeee;"+"  border-bottom:1px solid #eeeeee;"+"  padding : 0px 6px;"+"  cursor:default;"+"  font-size: 11px;"+"  font-family: 'Segoe UI', Corbel, Calibri, Tahoma, 'Lucida Sans Unicode', sans-serif;"+(qx.core.Variant.isSet("qx.client",
"mshtml")?'':';-moz-user-select:none;')},
properties:{defaultRowHeight:{init:16}},
members:{join:function(a,
b){if(this._progressive){throw new Error("Renderer is already joined to a Progressive.");
}this._progressive=a;
this._name=b;
a.addListener("widthChanged",
this._resizeColumns,
this);
var c=qx.ui.progressive.renderer.table.Row;
if(!c.__fQ){c.__fQ={};
}var d=a.toHashCode();
if(!c.__fQ[d]){c.__fQ[d]={rowstylesheet:null,
cellstylesheet:[]};
var e=".qx-progressive-"+d+"-row {"+"  width : '100%';"+"}";
c.__fQ[d].rowstylesheet=qx.html.StyleSheet.createElement(e);
for(var f=0;f<this._columnWidths.getData().length;f++){var e=".qx-progressive-"+d+"-cell-"+f+" {"+c.__fR+"}";
c.__fQ[d].cellstylesheet[f]=qx.html.StyleSheet.createElement(e);
}this._hash=d;
a.addListener("widthChanged",
this._resizeColumns,
this);
}},
addRenderer:function(a,
b){if(a<0||a>=this._columnWidths.length){throw new Error("Column "+a+" out of range (max: "+(this._columnWidths.length-1)+")");
}this._renderers[a]=b;
},
removeRenderer:function(a){if(a<0||a>=this._columnWidths.length){throw new Error("Column "+a+" out of range (max: "+(this._columnWidths.length-1)+")");
}
if(!this._renderers[a]){throw new Error("No existing renderer for column "+a);
}delete this._renderers[a];
},
render:function(a,
b){var c=b.data;
var d=[];
var e;
var f;
var g=0;
if(a.getRendererData()[this._name]===undefined){a.getRendererData()[this._name]={end:0,
start:1,
rows:0};
}var h=document.createElement("div");
for(i=0;i<c.length;i++){var i="qx-progressive-"+this._hash+"-cell-"+i;
f=this._renderers[i]||this._defaultCellRenderer;
e={state:a,
rowDiv:h,
stylesheet:i,
element:b,
dataIndex:i,
cellData:c[i],
height:g};
d.push(f.render(e));
if(e.height>g){g=e.height;
}}h.style.position="relative";
h.style.height=g>0?g:this.getDefaultRowHeight();
h.className="qx-progressive-"+this._hash+"-row";
h.innerHTML=d.join("");
var j=a.getRendererData()[this._name];
switch(b.location){case "end":var k=a.getRendererData()[this._name].end;
h.style.backgroundColor=qx.ui.progressive.renderer.table.Row.BACKGROUND_COLOR[k];
j.end=(k==0?1:0);
a.getPane().getContainerElement().getDomElement().appendChild(h);
break;
case "start":var l=a.getPane().getContainerElement().getDomElement();
var m=l.childNodes;
if(m.length>0){var k=j.start;
h.style.backgroundColor=qx.ui.progressive.renderer.table.Row.BACKGROUND_COLOR[k];
j.start=(k==0?1:0);
l.insertBefore(h,
m[0]);
break;
}else{l.appendChild(h);
}break;
default:throw new Error("Invalid location: "+b.location);
}++j.rows;
},
getLayoutChildren:function(){return this._columnWidths;
},
_resizeColumns:function(a){var b=(!this._progressive.getContainerElement().getDomElement()?0:this._progressive.getInnerWidth())-qx.bom.element.Overflow.getScrollbarSize();
var c=".qx-progressive-"+this._hash+"-row";
var d=qx.ui.progressive.renderer.table.Row;
qx.html.StyleSheet.removeRule(d.__fQ[this._hash].rowstylesheet,
c);
var f="width: "+b+";";
qx.html.StyleSheet.addRule(d.__fQ[this._hash].rowstylesheet,
c,
f);
this._layout.renderLayout(b,
100);
for(var g=0,
h=0;g<this._columnWidths.length;g++,
h+=b){var c=".qx-progressive-"+this._hash+"-cell-"+g;
var d=qx.ui.progressive.renderer.table.Row;
qx.html.StyleSheet.removeRule(d.__fQ[this._hash].cellstylesheet[g],
c);
b=this._columnWidths[g].getComputedWidth();
{if(qx.core.Setting.get("qx.tableResizeDebug")){this.debug("col "+g+": width="+b);
}};
var f=d.__fR+"left: "+h+";"+"width: "+b+";";
qx.html.StyleSheet.addRule(d.__fQ[this._hash].cellstylesheet[g],
c,
f);
}}},
destruct:function(){var a;
this._disposeFields("_name");
this._disposeObjects("_defaultCellRenderer",
"_columnData");
for(a in this._renderers){this._renderers[a]=null;
}var b=qx.ui.progressive.renderer.table.Row;
var c=this._progressive.toHashCode();
if(b.__fQ&&b.__fQ[c]){if(b.__fQ[c].rowstylesheet){var d=".qx-progressive-"+this._hash+"-row";
var b=qx.ui.progressive.renderer.table.Row;
qx.html.StyleSheet.removeRule(b.__fQ[this._hash].rowstylesheet,
d);
}if(b.__fQ[c].cellstylesheet){for(var e=b.__fQ[c].cellstylesheet.length-1;e>=0;e--){var d=".qx-progressive-"+this._hash+"-cell-"+e;
var f=b.__fQ[this._hash].cellstylesheet[e];
var b=qx.ui.progressive.renderer.table.Row;
qx.html.StyleSheet.removeRule(f,
d);
}}}this._renderers=null;
this._progressive=null;
}});
qx.Class.define("qx.ui.progressive.renderer.table.cell.Default",
{extend:qx.ui.progressive.renderer.table.cell.Abstract,
construct:function(){arguments.callee.base.call(this);
},
members:{_getContentHtml:function(a){return qx.html.String.escape(this._formatValue(a.cellData));
},
_formatValue:function(a){var b;
if(a==null){return "";
}
if(typeof a=="string"){return a;
}else if(typeof a=="number"){if(!qx.ui.progressive.renderer.table.Row._numberFormat){var c=new qx.util.format.NumberFormat();
c.setMaximumFractionDigits(2);
qx.ui.progressive.renderer.table.Row._numberFormat=c;
}b=qx.ui.progressive.renderer.table.Row._numberFormat.format(a);
}else if(a instanceof Date){b=qx.util.format.DateFormat.getDateInstance().format(a);
}else{b=a;
}return b;
}}});
qx.Class.define("qx.ui.table.selection.Model",
{extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
this._selectedRangeArr=[];
this._anchorSelectionIndex=-1;
this._leadSelectionIndex=-1;
this.hasBatchModeRefCount=0;
this._hadChangeEventInBatchMode=false;
},
events:{"changeSelection":"qx.event.type.Event"},
statics:{NO_SELECTION:1,
SINGLE_SELECTION:2,
SINGLE_INTERVAL_SELECTION:3,
MULTIPLE_INTERVAL_SELECTION:4,
MULTIPLE_INTERVAL_SELECTION_TOGGLE:5},
properties:{selectionMode:{init:2,
check:[1,
2,
3,
4,
5],
apply:"_applySelectionMode"}},
members:{_applySelectionMode:function(a){if(a==qx.ui.table.selection.Model.NO_SELECTION){this.clearSelection();
}},
setBatchMode:function(a){if(a){this.hasBatchModeRefCount+=1;
}else{if(this.hasBatchModeRefCount==0){throw new Error("Try to turn off batch mode althoug it was not turned on.");
}this.hasBatchModeRefCount-=1;
if(this._hadChangeEventInBatchMode){this._hadChangeEventInBatchMode=false;
this._fireChangeSelection();
}}return this.hasBatchMode();
},
hasBatchMode:function(){return this.hasBatchModeRefCount>0;
},
getAnchorSelectionIndex:function(){return this._anchorSelectionIndex;
},
getLeadSelectionIndex:function(){return this._leadSelectionIndex;
},
clearSelection:function(){if(!this.isSelectionEmpty()){this._clearSelection();
this._fireChangeSelection();
}},
isSelectionEmpty:function(){return this._selectedRangeArr.length==0;
},
getSelectedCount:function(){var a=0;
for(var b=0;b<this._selectedRangeArr.length;b++){var c=this._selectedRangeArr[b];
a+=c.maxIndex-c.minIndex+1;
}return a;
},
isSelectedIndex:function(a){for(var b=0;b<this._selectedRangeArr.length;b++){var c=this._selectedRangeArr[b];
if(a>=c.minIndex&&a<=c.maxIndex){return true;
}}return false;
},
getSelectedRanges:function(){var a=[];
for(var b=0;b<this._selectedRangeArr.length;b++){a.push({minIndex:this._selectedRangeArr[b].minIndex,
maxIndex:this._selectedRangeArr[b].maxIndex});
}return a;
},
iterateSelection:function(a,
b){for(var c=0;c<this._selectedRangeArr.length;c++){for(var d=this._selectedRangeArr[c].minIndex;d<=this._selectedRangeArr[c].maxIndex;d++){a.call(b,
d);
}}},
setSelectionInterval:function(a,
b){var c=arguments.callee.self;
switch(this.getSelectionMode()){case c.NO_SELECTION:return;
case c.SINGLE_SELECTION:a=b;
break;
case c.MULTIPLE_INTERVAL_SELECTION_TOGGLE:this.setBatchMode(true);
try{for(var d=a;d<=b;d++){if(!this.isSelectedIndex(d)){this._addSelectionInterval(d,
d);
}else{this.removeSelectionInterval(d,
d);
}}}finally{this.setBatchMode(false);
}this._fireChangeSelection();
return;
}this._clearSelection();
this._addSelectionInterval(a,
b);
this._fireChangeSelection();
},
addSelectionInterval:function(a,
b){var c=qx.ui.table.selection.Model;
switch(this.getSelectionMode()){case c.NO_SELECTION:return;
case c.MULTIPLE_INTERVAL_SELECTION:case c.MULTIPLE_INTERVAL_SELECTION_TOGGLE:this._addSelectionInterval(a,
b);
this._fireChangeSelection();
break;
default:this.setSelectionInterval(a,
b);
break;
}},
removeSelectionInterval:function(a,
b){this._anchorSelectionIndex=a;
this._leadSelectionIndex=b;
var c=Math.min(a,
b);
var d=Math.max(a,
b);
for(var e=0;e<this._selectedRangeArr.length;e++){var f=this._selectedRangeArr[e];
if(f.minIndex>d){break;
}else if(f.maxIndex>=c){var g=(f.minIndex>=c)&&(f.minIndex<=d);
var h=(f.maxIndex>=c)&&(f.maxIndex<=d);
if(g&&h){this._selectedRangeArr.splice(e,
1);
e--;
}else if(g){f.minIndex=d+1;
}else if(h){f.maxIndex=c-1;
}else{var j={minIndex:d+1,
maxIndex:f.maxIndex};
this._selectedRangeArr.splice(e+1,
0,
j);
f.maxIndex=c-1;
break;
}}}this._fireChangeSelection();
},
_clearSelection:function(){this._selectedRangeArr=[];
this._anchorSelectionIndex=-1;
this._leadSelectionIndex=-1;
},
_addSelectionInterval:function(a,
b){this._anchorSelectionIndex=a;
this._leadSelectionIndex=b;
var c=Math.min(a,
b);
var d=Math.max(a,
b);
var e=0;
for(;e<this._selectedRangeArr.length;e++){var f=this._selectedRangeArr[e];
if(f.minIndex>c){break;
}}this._selectedRangeArr.splice(e,
0,
{minIndex:c,
maxIndex:d});
var g=this._selectedRangeArr[0];
for(var h=1;h<this._selectedRangeArr.length;h++){var f=this._selectedRangeArr[h];
if(g.maxIndex+1>=f.minIndex){g.maxIndex=Math.max(g.maxIndex,
f.maxIndex);
this._selectedRangeArr.splice(h,
1);
h--;
}else{g=f;
}}},
_dumpRanges:function(){var a="Ranges:";
for(var b=0;b<this._selectedRangeArr.length;b++){var c=this._selectedRangeArr[b];
a+=" ["+c.minIndex+".."+c.maxIndex+"]";
}this.debug(a);
},
_fireChangeSelection:function(){if(this.hasBatchMode()){this._hadChangeEventInBatchMode=true;
}this.fireEvent("changeSelection");
}},
destruct:function(){this._disposeFields("_selectedRangeArr");
}});
qx.Class.define("qx.ui.form.DateField",
{extend:qx.ui.form.ComboBox,
construct:function(){arguments.callee.base.call(this);
var a=qx.locale.Date.getDateFormat("short").toString();
this.setDateFormat(new qx.util.format.DateFormat(a));
},
properties:{appearance:{refine:true,
init:"datefield"},
dateFormat:{check:"qx.util.format.DateFormat",
apply:"_applyDateFormat"}},
members:{setDate:function(a){var b=this._getChildControl("textfield");
b.setValue(this.getDateFormat().format(a));
var c=this._getChildControl("list");
c.setDate(a);
},
getDate:function(){var a=this._getChildControl("textfield").getValue();
try{return this.getDateFormat().parse(a);
}catch(e){return null;
}},
setValue:function(a){var b=this._getChildControl("textfield");
if(b.getValue()==a){return;
}b.setValue(a);
try{var c=this.getDateFormat().parse(a);
this._getChildControl("list").setDate(c);
}catch(e){this._getChildControl("list").setDate(null);
}},
getValue:function(){return this._getChildControl("textfield").getValue();
},
_applyDateFormat:function(a,
b){try{var c=this._getChildControl("textfield");
var d=b.parse(c.getValue());
c.setValue(a.format(d));
}catch(e){}},
_createChildControlImpl:function(a){var b;
switch(a){case "list":b=new qx.ui.control.DateChooser();
b.setFocusable(false);
b.setKeepFocus(true);
b.addListener("execute",
this._onChangeDate,
this);
break;
case "popup":b=new qx.ui.popup.Popup(new qx.ui.layout.VBox);
b.setAutoHide(false);
b.add(this._getChildControl("list"));
b.addListener("activate",
this._onActivateList,
this);
b.addListener("mouseup",
this._onChangeDate,
this);
break;
}return b||arguments.callee.base.call(this,
a);
},
_onChangeDate:function(a){var b=this._getChildControl("textfield");
var c=this._getChildControl("list").getDate();
b.setValue(this.getDateFormat().format(c));
this.close();
},
_onKeyPress:function(a){var b=this._getChildControl("popup");
if(b.getVisibility()=="hidden"){return;
}var c=a.getKeyIdentifier();
if(c=="Escape"){this.close();
a.stopPropagation();
return;
}this._getChildControl("list").handleKeyPress(a);
}}});
qx.Class.define("qx.ui.table.model.Simple",
{extend:qx.ui.table.model.Abstract,
construct:function(){arguments.callee.base.call(this);
this._rowArr=[];
this._sortColumnIndex=-1;
this._sortAscending;
this._sortMethods=[];
this._editableColArr=null;
},
properties:{caseSensitiveSorting:{check:"Boolean",
init:true}},
statics:{_defaultSortComparatorAscending:function(a,
b){var c=a[arguments.callee.columnIndex];
var d=b[arguments.callee.columnIndex];
return (c>d)?1:((c==d)?0:-1);
},
_defaultSortComparatorInsensitiveAscending:function(a,
b){var c=(isNaN(a[arguments.callee.columnIndex])?a[arguments.callee.columnIndex].toLowerCase():a[arguments.callee.columnIndex]);
var d=(isNaN(b[arguments.callee.columnIndex])?b[arguments.callee.columnIndex].toLowerCase():b[arguments.callee.columnIndex]);
return (c>d)?1:((c==d)?0:-1);
},
_defaultSortComparatorDescending:function(a,
b){var c=a[arguments.callee.columnIndex];
var d=b[arguments.callee.columnIndex];
return (c<d)?1:((c==d)?0:-1);
},
_defaultSortComparatorInsensitiveDescending:function(a,
b){var c=(isNaN(a[arguments.callee.columnIndex])?a[arguments.callee.columnIndex].toLowerCase():a[arguments.callee.columnIndex]);
var d=(isNaN(b[arguments.callee.columnIndex])?b[arguments.callee.columnIndex].toLowerCase():b[arguments.callee.columnIndex]);
return (c<d)?1:((c==d)?0:-1);
}},
members:{getRowData:function(a){var b=this._rowArr[a];
if(b==null||b.originalData==null){return b;
}else{return b.originalData;
}},
getRowDataAsMap:function(a){var b=this._rowArr[a];
var c={};
for(var d=0;d<this.getColumnCount();d++){c[this.getColumnId(d)]=b[d];
}return c;
},
setEditable:function(a){this._editableColArr=[];
for(var b=0;b<this.getColumnCount();b++){this._editableColArr[b]=a;
}this.fireEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
},
setColumnEditable:function(a,
b){if(b!=this.isColumnEditable(a)){if(this._editableColArr==null){this._editableColArr=[];
}this._editableColArr[a]=b;
this.fireEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
}},
isColumnEditable:function(a){return this._editableColArr?(this._editableColArr[a]==true):false;
},
setColumnSortable:function(a,
b){if(b!=this.isColumnSortable(a)){if(this._sortableColArr==null){this._sortableColArr=[];
}this._sortableColArr[a]=b;
this.fireEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
}},
isColumnSortable:function(a){return this._sortableColArr?(this._sortableColArr[a]==true):true;
},
sortByColumn:function(a,
b){var c;
var d=this._sortMethods[a];
if(d){c=(b?d.ascending:d.descending);
}else{if(this.getCaseSensitiveSorting()){c=(b?qx.ui.table.model.Simple._defaultSortComparatorAscending:qx.ui.table.model.Simple._defaultSortComparatorDescending);
}else{c=(b?qx.ui.table.model.Simple._defaultSortComparatorInsensitiveAscending:qx.ui.table.model.Simple._defaultSortComparatorInsensitiveDescending);
}}c.columnIndex=a;
this._rowArr.sort(c);
this._sortColumnIndex=a;
this._sortAscending=b;
this.fireEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
},
setSortMethods:function(a,
b){this._sortMethods[a]=b;
},
_clearSorting:function(){if(this._sortColumnIndex!=-1){this._sortColumnIndex=-1;
this._sortAscending=true;
this.fireEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
}},
getSortColumnIndex:function(){return this._sortColumnIndex;
},
isSortAscending:function(){return this._sortAscending;
},
getRowCount:function(){return this._rowArr.length;
},
getValue:function(a,
b){if(b<0||b>=this._rowArr.length){throw new Error("this._rowArr out of bounds: "+b+" (0.."+this._rowArr.length+")");
}return this._rowArr[b][a];
},
setValue:function(a,
b,
c){if(this._rowArr[b][a]!=c){this._rowArr[b][a]=c;
if(this.hasListener(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED)){var d={firstRow:b,
lastRow:b,
firstColumn:a,
lastColumn:a};
this.fireDataEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
d);
}
if(a==this._sortColumnIndex){this._clearSorting();
}}},
setData:function(a,
b){this._rowArr=a;
var c={firstRow:0,
lastRow:a.length-1,
firstColumn:0,
lastColumn:this.getColumnCount()-1};
if(this.hasListener(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED)){this.fireDataEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
c);
}
if(b){this._clearSorting();
}},
getData:function(){return this._rowArr;
},
setDataAsMapArray:function(a,
b,
c){this.setData(this._mapArray2RowArr(a,
b),
c);
},
addRows:function(a,
b){if(b==null){b=this._rowArr.length;
}a.splice(0,
0,
b,
0);
Array.prototype.splice.apply(this._rowArr,
a);
var c={firstRow:b,
lastRow:this._rowArr.length-1,
firstColumn:0,
lastColumn:this.getColumnCount()-1};
this.fireDataEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
c);
this._clearSorting();
},
addRowsAsMapArray:function(a,
b,
c){this.addRows(this._mapArray2RowArr(a,
c),
b);
},
removeRows:function(a,
b){this._rowArr.splice(a,
b);
var c={firstRow:a,
lastRow:this._rowArr.length-1,
firstColumn:0,
lastColumn:this.getColumnCount()-1};
this.fireDataEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
c);
this._clearSorting();
},
_mapArray2RowArr:function(a,
b){var c=a.length;
var d=this.getColumnCount();
var e=new Array(c);
var f;
for(var g=0;g<c;++g){f=[];
if(b){f.originalData=a[g];
}
for(var h=0;h<d;++h){f[h]=a[g][this.getColumnId(h)];
}e[g]=f;
}return e;
}},
destruct:function(){this._disposeFields("_rowArr",
"_editableColArr",
"_sortMethods");
}});
qx.Class.define("qx.ui.table.model.Filtered",
{extend:qx.ui.table.model.Simple,
construct:function(){arguments.callee.base.call(this);
this.numericAllowed=new Array("==",
"!=",
">",
"<",
">=",
"<=");
this.betweenAllowed=new Array("between",
"!between");
this._applyingFilters=false;
this.Filters=new Array();
},
members:{_js_in_array:function(a,
b){var c=b.toString();
if(c==''){return false;
}var d=new RegExp(a,
'g');
var e=d.test(b);
return e;
},
addBetweenFilter:function(a,
b,
c,
d){if(this._js_in_array(a,
this.betweenAllowed)&&d!=null){if(b!=null&&c!=null){var e=new Array(a,
b,
c,
d);
}}
if(e!=null){this.Filters.push(e);
}else{throw new Error("Filter not recognized or value1/value2 is null!");
}},
addNumericFilter:function(a,
b,
c){var d=null;
if(this._js_in_array(a,
this.numericAllowed)&&c!=null){if(b!=null){d=[a,
b,
c];
}}
if(d!=null){this.Filters.push(d);
}else{throw new Error("Filter not recognized: value or target is null!");
}},
addRegex:function(a,
b){if(a!=null&&b!=null){var c=new Array("regex",
a,
b);
}
if(c!=null){this.Filters.push(c);
}else{throw new Error("regex cannot be null!");
}},
applyFilters:function(){var a;
var b;
var c;
var d=this._rowArr.length;
for(var e=0;e<d;e++){b=false;
for(a in this.Filters){if(this._js_in_array(this.Filters[a][0],
this.numericAllowed)&&b==false){c=this.getValueById(this.Filters[a][2],
e);
switch(this.Filters[a][0]){case "==":if(c==this.Filters[a][1]){b=true;
}break;
case "!=":if(c!=this.Filters[a][1]){b=true;
}break;
case ">":if(c>this.Filters[a][1]){b=true;
}break;
case "<":if(c<this.Filters[a][1]){b=true;
}break;
case ">=":if(c>=this.Filters[a][1]){b=true;
}break;
case "<=":if(c<=this.Filters[a][1]){b=true;
}break;
}}else if(this._js_in_array(this.Filters[a][0],
this.betweenAllowed)&&b==false){c=this.getValueById(this.Filters[a][3],
e);
switch(this.Filters[a][0]){case "between":if(c>=this.Filters[a][1]&&c<=this.Filters[a][2]){b=true;
}break;
case "!between":if(c<this.Filters[a][1]&&c>this.Filters[a][2]){b=true;
}break;
}}else if(this.Filters[a][0]=="regex"&&b==false){c=this.getValueById(this.Filters[a][2],
e);
var f=new RegExp(this.Filters[a][1],
'g');
b=f.test(c);
}}if(b==true){this.hideRows(e,
1,
false);
e--;
d--;
}}var g={firstRow:0,
lastRow:this._rowArr-1,
firstColumn:0,
lastColumn:this.getColumnCount()-1};
this.fireDataEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
g);
},
hideRows:function(a,
b,
c){c=(c!=null?c:true);
if(!this._applyingFilters){this._fullArr=this._rowArr.slice();
this._applyingFilters=true;
}
if(b==null||b<1){b=1;
}
for(var d=a;d<(this._rowArr.length-b);d++){this._rowArr[d]=this._rowArr[d+b];
}this.removeRows(d,
b);
if(c){var e={firstRow:0,
lastRow:this._rowArr.length-1,
firstColumn:0,
lastColumn:this.getColumnCount()-1};
this.fireDataEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
e);
}},
resetHiddenRows:function(){if(!this._fullArr){return ;
}this.Filters=new Array();
this._rowArr=this._fullArr.slice();
var a={firstRow:0,
lastRow:this._rowArr.length-1,
firstColumn:0,
lastColumn:this.getColumnCount()-1};
this.fireDataEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
a);
}},
destruct:function(){this._disposeFields("_rowArr",
"_fullArr",
"numericAllowed",
"betweenAllowed",
"Filters");
}});
qx.Class.define("qx.fx.effect.core.Scroll",
{extend:qx.fx.Base,
properties:{mode:{init:"relative",
check:["relative",
"absolute"]},
x:{init:0,
check:"Number"},
y:{init:0,
check:"Number"}},
members:{start:function(){if(!arguments.callee.base.call(this)){return;
}this._startOffsets={x:this._element.scrollLeft,
y:this._element.scrollTop};
if(this._atEndPosition(this._startOffsets.x,
this._startOffsets.y)){return;
}
if(this.getMode()=="absolute"){this._deltaOffsets={left:this.getX()-this._startOffsets.x,
top:this.getY()-this._startOffsets.y};
}},
update:function(a){arguments.callee.base.call(this);
if(this.getMode()=="relative"){if(this.getX()!=0){this._element.scrollLeft=this._startOffsets.x+(this.getX()*a);
}
if(this.getY()!=0){this._element.scrollTop=this._startOffsets.y+(this.getY()*a);
}}else{this._element.scrollLeft=this._startOffsets.x+(this._deltaOffsets.left*a);
this._element.scrollTop=this._startOffsets.y+(this._deltaOffsets.top*a);
}},
_atEndPosition:function(a,
b){var c=this._element;
var d=this.getX();
var e=this.getY();
return (((d<0)&&(a==0))||((d>0)&&(a==(c.scrollWidth-c.clientWidth))))&&
(((e<0)&&(b==0))||((e>0)&&(b==(c.scrollHeight-c.clientHeight))));
}}});
qx.Class.define("qx.ui.progressive.headfoot.Progress",
{extend:qx.ui.progressive.headfoot.Abstract,
construct:function(a,
b){arguments.callee.base.call(this);
this._columnWidths=a;
this.setHeight(16);
this._decorator=new qx.ui.decoration.Single(1,
"solid",
"#cccccc");
this._decorator.set({widthTop:1,
widthRight:0,
widthBottom:0});
this.setDecorator(this._decorator);
this.setPadding(0);
this._percentDone=new qx.ui.basic.Atom("");
this.add(this._percentDone);
this.setDisplay(false);
this._layout=new qx.ui.layout.HBox();
this._layout.connectToWidget(this);
},
members:{join:function(a){arguments.callee.base.call(this,
a);
a.addListener("renderStart",
function(b){this.__total=b.getData().initial;
this.setDisplay(true);
},
this);
a.addListener("progress",
function(b){var c=1.0-(b.getData().remaining/this.__total);
var d=Math.floor(this.getWidth()*c);
if(!isNaN(d)){var f=Math.floor(c*100)+"%";
this._percentDone.setLabel(f);
this._decorator.set({widthLeft:d});
}},
this);
a.addListener("renderEnd",
function(b){this.setDisplay(false);
},
this);
a.addListener("widthChanged",
this._resizeColumns,
this);
},
getLayoutChildren:function(){return this._columnWidths;
},
_resizeColumns:function(a){var b=(!this._progressive.getContainerElement().getDomElement()?0:this._progressive.getInnerWidth())-qx.bom.element.Overflow.getScrollbarSize();
this._layout.renderLayout(b,
100);
var b=0;
for(var c=0;c<this._columnWidths.length;c++){b+=this._columnWidths[c].getComputedWidth();
}this.setWidth(b);
}}});
qx.Class.define("qx.ui.table.cellrenderer.String",
{extend:qx.ui.table.cellrenderer.Conditional,
members:{_getContentHtml:function(a){return qx.bom.String.escape(a.value||"");
},
_getCellClass:function(a){return "qooxdoo-table-cell";
}}});
qx.Theme.define("qx.theme.modern.Color",
{title:"Modern",
colors:{"background":"#dfdfdf",
"background-light":"#F2F2F2",
"background-disabled":"#F4F4F4",
"background-selected":"#3E6CA8",
"background-field":"white",
"text":"#1a1a1a",
"text-disabled":[107,
106,
110],
"text-selected":"#fffefe",
"text-focused":"#1a1a1a",
"input-text":"black",
"border":"#2D405A",
"border-light":"white",
"border-light-shadow":"#DCDFE4",
"border-dark-shadow":"#4d4d4d",
"border-dark":"#85878C",
"border-focused-light":"#BCCEE5",
"border-focused-light-shadow":"#A5BDDE",
"border-focused-dark-shadow":"#7CA0CF",
"border-focused-dark":"#3E6CA8",
"focus":"#92B1DC",
"pane":"#ededed",
"selected":"#00439d",
"selected-inactive":"#7a9bc8",
"button":"#EBE9ED",
"button-hovered":"#F6F5F7",
"button-abandoned":"#F9F8E9",
"button-checked":"#F3F0F5",
"date-chooser":"white",
"date-chooser-title":[116,
116,
116],
"date-chooser-selected":[52,
52,
52],
"table-pane":"white",
"table-focus-indicator":"#0073FF",
"table-row-background-focused-selected":"#084CA6",
"table-row-background-focused":"#0053DD",
"table-row-background-selected":"#084CA6",
"table-row-background-even":"#F4F4F4",
"table-row-background-odd":"#E4E4E4",
"table-row-selected":"white",
"table-row":"#1a1a1a",
"effect":[254,
200,
60],
"table-header":[242,
242,
242],
"table-header-border":[214,
213,
217],
"table-header-cell":[235,
234,
219],
"table-header-cell-hover":[255,
255,
255]}});
qx.Theme.define("qx.theme.modern.Font",
{title:"Modern",
fonts:{"default":{size:11,
lineHeight:1.4,
family:["Lucida Grande",
"Tahoma",
"Verdana",
"Bitstream Vera Sans",
"Liberation Sans"]},
"small":{size:10,
lineHeight:1.3,
family:["Lucida Grande",
"Tahoma",
"Verdana",
"Bitstream Vera Sans",
"Liberation Sans"]},
"bold":{size:11,
lineHeight:1.4,
family:["Lucida Grande",
"Tahoma",
"Verdana",
"Bitstream Vera Sans",
"Liberation Sans"],
bold:true},
"medium":{size:10,
lineHeight:1.4,
family:["Lucida Grande",
"Tahoma",
"Verdana",
"Bitstream Vera Sans",
"Liberation Sans"]},
"large":{size:16,
lineHeight:1.4,
family:["Lucida Grande",
"Tahoma",
"Verdana",
"Bitstream Vera Sans",
"Liberation Sans"]},
"monospace":{size:11,
lineHeight:1.4,
family:["Consolas",
"Bitstream Vera Sans Mono",
"Courier New",
"monospace"]}}});
qx.Theme.define("qx.theme.icon.Tango",
{title:"Tango",
resource:"qx/icon/Tango",
icons:{}});
qx.Theme.define("qx.theme.Modern",
{title:"Modern",
meta:{color:qx.theme.modern.Color,
decoration:qx.theme.modern.Decoration,
font:qx.theme.modern.Font,
appearance:qx.theme.modern.Appearance,
icon:qx.theme.icon.Tango}});
qx.Class.define("qx.fx.effect.combination.Fold",
{extend:qx.fx.Base,
construct:function(a){arguments.callee.base.call(this,
a);
},
properties:{modifyDisplay:{init:true,
check:"Boolean"},
mode:{init:"in",
check:["in",
"out"]}},
members:{afterFinish:function(){if((this.getModifyDisplay())&&(this.getMode()=="in")){qx.bom.element.Style.set(this._element,
"display",
"block");
}},
start:function(){if(!arguments.callee.base.call(this)){return;
}var a=this;
this._outerScaleEffect=new qx.fx.effect.core.Scale(this._element);
this._innerScaleEffect=new qx.fx.effect.core.Scale(this._element);
this._outerScaleEffect.afterFinishInternal=function(){a._innerScaleEffect.start();
};
this._innerScaleEffect.afterFinishInternal=function(){a._cleanUp();
};
this._oldStyle=this._getStyle();
qx.bom.element.Style.set(this._element,
"overflow",
"hidden");
if(this.getMode()=="in"){this._outerScaleEffect.set({scaleTo:5,
scaleContent:false,
scaleX:false,
duration:this.getDuration()/2,
scaleFrom:100,
scaleFromCenter:true,
alternateDimensions:[]});
this._innerScaleEffect.set({scaleTo:5,
scaleContent:false,
scaleY:false,
duration:this.getDuration()/2,
scaleFrom:100,
scaleFromCenter:true,
alternateDimensions:[]});
}else{this._outerScaleEffect.set({scaleTo:100,
scaleContent:false,
scaleY:false,
duration:this.getDuration()/2,
scaleFrom:0,
scaleFromCenter:true,
alternateDimensions:[this._oldStyle.width,
this._oldStyle.height]});
this._innerScaleEffect.set({scaleTo:100,
scaleContent:false,
scaleX:false,
duration:this.getDuration()/2,
scaleFrom:0,
scaleFromCenter:false,
alternateDimensions:[this._oldStyle.width,
this._oldStyle.height]});
qx.bom.element.Style.set(this._element,
"display",
"block");
qx.bom.element.Style.set(this._element,
"height",
"0px");
qx.bom.element.Style.set(this._element,
"width",
"0px");
}this._outerScaleEffect.start();
},
_cleanUp:function(){var a;
if((this.getMode()=="in")&&(this.getModifyDisplay())){qx.bom.element.Style.set(this._element,
"display",
"none");
}
for(var b in this._oldStyle){a=this._oldStyle[b];
if(b!="overflow"){a+="px";
}qx.bom.element.Style.set(this._element,
b,
a);
}qx.bom.element.Style.set(this._element,
"overflow",
"visible");
},
_getStyle:function(){var a=(qx.bom.element.Style.get(this._element,
"display")=="none");
if(a){qx.bom.element.Style.set(this._element,
"visiblity",
"hidden");
qx.bom.element.Style.set(this._element,
"display",
"block");
}var b={overflow:qx.bom.element.Style.get(this._element,
"overflow"),
top:qx.bom.element.Location.getTop(this._element),
left:qx.bom.element.Location.getLeft(this._element),
width:qx.bom.element.Dimension.getWidth(this._element),
height:qx.bom.element.Dimension.getHeight(this._element)};
if(a){qx.bom.element.Style.set(this._element,
"display",
"none");
qx.bom.element.Style.set(this._element,
"visiblity",
"visible");
}return b;
}},
destruct:function(){this._disposeObjects("_outerScaleEffect",
"_innerScaleEffect");
}});
qx.Class.define("qx.ui.tree.Tree",
{extend:qx.ui.core.ScrollArea,
include:[qx.ui.core.MSelectionHandling],
construct:function(){arguments.callee.base.call(this);
this.__content=new qx.ui.container.Composite(new qx.ui.layout.VBox()).set({allowShrinkY:false,
allowGrowX:true});
this._getChildControl("pane").add(this.__content);
this.initOpenMode();
this.initRootOpenClose();
},
events:{addItem:"qx.event.type.Data",
removeItem:"qx.event.type.Data"},
properties:{openMode:{check:["click",
"dblclick",
"none"],
init:"dblclick",
apply:"_applyOpenMode",
event:"changeOpenMode",
themeable:true},
root:{check:"qx.ui.tree.AbstractTreeItem",
init:null,
nullable:true,
event:"changeRoot",
apply:"_applyRoot"},
hideRoot:{check:"Boolean",
init:false,
apply:"_applyHideRoot"},
rootOpenClose:{check:"Boolean",
init:false,
apply:"_applyRootOpenClose"},
contentPadding:{check:"Array",
nullable:true,
init:null,
apply:"_applyContentPadding",
themeable:true},
appearance:{refine:true,
init:"tree"},
focusable:{refine:true,
init:true}},
members:{SELECTION_MANAGER:qx.ui.tree.SelectionManager,
getChildrenContainer:function(){return this.__content;
},
_applyRoot:function(a,
b){var c=this.getChildrenContainer();
if(b){c.remove(b);
if(b.hasChildren()){c.remove(b.getChildrenContainer());
}}
if(a){c.add(a);
if(a.hasChildren()){c.add(a.getChildrenContainer());
}a.setVisibility(this.getHideRoot()?"excluded":"visible");
a.recursiveAddToWidgetQueue();
}},
_applyHideRoot:function(a,
b){var c=this.getRoot();
if(!c){return;
}c.setVisibility(a?"excluded":"visible");
c.recursiveAddToWidgetQueue();
},
_applyRootOpenClose:function(a,
b){var c=this.getRoot();
if(!c){return;
}c.recursiveAddToWidgetQueue();
},
_applyContentPadding:function(a,
b){if(a){this.__content.setPadding(a);
}},
getNextSiblingOf:function(a,
b){if((b!==false||a.isOpen())&&a.hasChildren()){return a.getChildren()[0];
}
while(a){var c=a.getParent();
if(!c){return null;
}var d=c.getChildren();
var e=d.indexOf(a);
if(e>-1&&e<d.length-1){return d[e+1];
}a=c;
}return null;
},
getPreviousSiblingOf:function(a,
b){var c=a.getParent();
if(!c){return null;
}
if(this.getHideRoot()){if(c==this.getRoot()){if(c.getChildren()[0]==a){return null;
}}}else{if(a==this.getRoot()){return null;
}}var d=c.getChildren();
var e=d.indexOf(a);
if(e>0){var f=d[e-1];
while((b!==false||f.isOpen())&&f.hasChildren()){var g=f.getChildren();
f=g[g.length-1];
}return f;
}else{return c;
}},
getItems:function(a,
b){return this.getRoot().getItems(a,
b,
this.getHideRoot());
},
scrollChildIntoViewY:function(a,
b){if(!this.getNextSiblingOf(a,
false)){this.scrollToY(1000000);
}else{arguments.callee.base.call(this,
a,
b);
}},
getTreeItem:function(a){while(a){if(a==this){return null;
}
if(a instanceof qx.ui.tree.AbstractTreeItem){return a;
}a=a.getLayoutParent();
}return null;
},
_applyOpenMode:function(a,
b){if(b=="click"){this.removeListener("click",
this._onOpen,
this);
}else if(b=="dblclick"){this.removeListener("dblclick",
this._onOpen,
this);
}
if(a=="click"){this.addListener("click",
this._onOpen,
this);
}else if(a=="dblclick"){this.addListener("dblclick",
this._onOpen,
this);
}},
_onOpen:function(a){var b=this.getTreeItem(a.getTarget());
if(!b||!b.isOpenable()){return;
}b.setOpen(!b.isOpen());
a.stopPropagation();
}}});
qx.Class.define("qx.ui.table.columnmodel.Resize",
{extend:qx.ui.table.columnmodel.Basic,
construct:function(){arguments.callee.base.call(this);
this._bInProgress=false;
this._bAppeared=false;
},
properties:{behavior:{check:"qx.ui.table.columnmodel.resizebehavior.Abstract",
init:null,
nullable:true,
apply:"_applyBehavior",
event:"changeBehavior"}},
members:{_applyBehavior:function(a,
b){if(b!=null){b.dispose();
b=null;
}a._setNumColumns(this._columnDataArr.length);
},
init:function(a,
b){arguments.callee.base.call(this,
a);
if(this.getBehavior()==null){this.setBehavior(new qx.ui.table.columnmodel.resizebehavior.Default());
}this._table=b;
b.addListener("appear",
this._onappear,
this);
b.addListener("tableWidthChanged",
this._onTableWidthChanged,
this);
b.addListener("verticalScrollBarChanged",
this._onverticalscrollbarchanged,
this);
this.addListener("widthChanged",
this._oncolumnwidthchanged,
this);
this.addListener("visibilityChanged",
this._onvisibilitychanged,
this);
this._table.addListener("columnVisibilityMenuCreateEnd",
this._addResetColumnWidthButton,
this);
this.getBehavior()._setNumColumns(a);
},
_addResetColumnWidthButton:function(a){var b=a.getData();
var c=b.menu;
var d;
d=new qx.ui.menu.Separator();
c.add(d);
d=new qx.ui.menu.Button("Reset column widths").set({appearance:"table-column-reset-button"});
c.add(d);
d.addListener("execute",
this._onappear,
this);
},
_onappear:function(a){if(this._bInProgress){return ;
}this._bInProgress=true;
{if(qx.core.Setting.get("qx.tableResizeDebug")){this.debug("onappear");
}};
this.getBehavior().onAppear(this,
a,
a.getType()!=="appear");
this._table._updateScrollerWidths();
this._table._updateScrollBarVisibility();
this._bInProgress=false;
this._bAppeared=true;
},
_onTableWidthChanged:function(a){if(this._bInProgress||!this._bAppeared){return ;
}this._bInProgress=true;
{if(qx.core.Setting.get("qx.tableResizeDebug")){this.debug("ontablewidthchanged");
}};
this.getBehavior().onTableWidthChanged(this,
a);
this._bInProgress=false;
},
_onverticalscrollbarchanged:function(a){if(this._bInProgress||!this._bAppeared){return ;
}this._bInProgress=true;
{if(qx.core.Setting.get("qx.tableResizeDebug")){this.debug("onverticalscrollbarchanged");
}};
this.getBehavior().onVerticalScrollBarChanged(this,
a);
qx.event.Timer.once(function(){if(this._table&&!this._table.isDisposed()){this._table._updateScrollerWidths();
this._table._updateScrollBarVisibility();
}},
this,
0);
this._bInProgress=false;
},
_oncolumnwidthchanged:function(a){if(this._bInProgress||!this._bAppeared){return ;
}this._bInProgress=true;
{if(qx.core.Setting.get("qx.tableResizeDebug")){this.debug("oncolumnwidthchanged");
}};
this.getBehavior().onColumnWidthChanged(this,
a);
this._bInProgress=false;
},
_onvisibilitychanged:function(a){if(this._bInProgress||!this._bAppeared){return ;
}this._bInProgress=true;
{if(qx.core.Setting.get("qx.tableResizeDebug")){this.debug("onvisibilitychanged");
}};
this.getBehavior().onVisibilityChanged(this,
a);
this._bInProgress=false;
}},
settings:{"qx.tableResizeDebug":false},
destruct:function(){this._disposeFields("_table");
}});
qx.Class.define("qx.ui.progressive.renderer.table.cell.String",
{extend:qx.ui.progressive.renderer.table.cell.Abstract,
construct:function(){arguments.callee.base.call(this);
},
members:{_getContentHtml:function(a){return qx.html.String.escape(a.cellData);
}}});
qx.Theme.define("qx.theme.classic.Appearance",
{title:"Classic",
appearances:{"widget":{},
"label":{style:function(a){return {textColor:a.disabled?"text-disabled":"undefined"};
}},
"image":{style:function(a){return {opacity:!a.replacement&&a.disabled?0.3:"undefined"};
}},
"atom":{},
"atom/label":"label",
"atom/icon":"image",
"root":{style:function(a){return {backgroundColor:"background",
textColor:"text",
font:"default"};
}},
"popup":"widget",
"tooltip":{include:"popup",
style:function(a){return {backgroundColor:"tooltip",
textColor:"tooltip-text",
decorator:"tooltip",
padding:[1,
3,
2,
3],
offset:[1,
1,
20,
1]};
}},
"tooltip/atom":"atom",
"iframe":{style:function(a){return {backgroundColor:"white",
decorator:"inset"};
}},
"move-frame":{style:function(a){return {decorator:"dark-shadow"};
}},
"resize-frame":{style:function(a){return {decorator:"dark-shadow"};
}},
"dragdrop-cursor":{style:function(a){var b="nodrop";
if(a.copy){b="copy";
}else if(a.move){b="move";
}else if(a.alias){b="alias";
}return {source:"decoration/cursors/"+b+".gif",
position:"right-top",
offset:[2,
16,
2,
6]};
}},
"button":{alias:"atom",
style:function(a){if(a.pressed||a.abandoned||a.checked){var b=!a.inner&&a.focused?"focused-inset":"inset";
}else{var b=!a.inner&&a.focused?"focused-outset":"outset";
}
if(a.pressed||a.abandoned||a.checked){var c=[4,
3,
2,
5];
}else{var c=[3,
4];
}return {backgroundColor:a.abandoned?"button-abandoned":a.hovered?"button-hovered":a.checked?"button-checked":"button",
decorator:b,
padding:c};
}},
"splitbutton":{},
"splitbutton/button":"button",
"splitbutton/arrow":{alias:"button",
include:"button",
style:function(a){return {icon:"decoration/arrows/down.gif"};
}},
"scrollarea/corner":{style:function(){return {backgroundColor:"background",
width:0,
height:0};
}},
"scrollarea":"widget",
"scrollarea/pane":"widget",
"scrollarea/scrollbar-x":"scrollbar",
"scrollarea/scrollbar-y":"scrollbar",
"list":{alias:"scrollarea",
style:function(a){return {decorator:a.focused?"focused-inset":"inset",
backgroundColor:a.focused?"background-focused":"white"};
}},
"listitem":{alias:"atom",
style:function(a){return {gap:4,
padding:a.lead?[2,
4]:[3,
5],
backgroundColor:a.selected?"background-selected":"undefined",
textColor:a.selected?"text-selected":"undefined",
decorator:a.lead?"lead-item":"undefined"};
}},
"textfield":{style:function(a){return {decorator:a.focused?"focused-inset":"inset",
padding:[2,
3],
textColor:a.disabled?"text-disabled":"undefined",
backgroundColor:a.disabled?"background-disabled":a.focused?"background-focused":"background-field"};
}},
"textarea":"textfield",
"checkbox":{alias:"atom",
style:function(a){var b;
if(a.checked&&a.focused){b="checkbox-checked-focused";
}else if(a.checked&&a.disabled){b="checkbox-checked-disabled";
}else if(a.checked&&a.pressed){b="checkbox-checked-pressed";
}else if(a.checked&&a.hovered){b="checkbox-checked-hovered";
}else if(a.checked){b="checkbox-checked";
}else if(a.disabled){b="checkbox-disabled";
}else if(a.focused){b="checkbox-focused";
}else if(a.pressed){b="checkbox-pressed";
}else if(a.hovered){b="checkbox-hovered";
}else{b="checkbox";
}return {icon:"decoration/form/"+b+".png",
gap:6};
}},
"radiobutton":{alias:"checkbox",
include:"checkbox",
style:function(a){var b;
if(a.checked&&a.focused){b="radiobutton-checked-focused";
}else if(a.checked&&a.disabled){b="radiobutton-checked-disabled";
}else if(a.checked&&a.pressed){b="radiobutton-checked-pressed";
}else if(a.checked&&a.hovered){b="radiobutton-checked-hovered";
}else if(a.checked){b="radiobutton-checked";
}else if(a.disabled){b="radiobutton-disabled";
}else if(a.focused){b="radiobutton-focused";
}else if(a.pressed){b="radiobutton-pressed";
}else if(a.hovered){b="radiobutton-hovered";
}else{b="radiobutton";
}return {icon:"decoration/form/"+b+".png"};
}},
"spinner":{style:function(a){return {decorator:a.focused?"focused-inset":"inset",
textColor:a.disabled?"text-disabled":"undefined"};
}},
"spinner/textfield":{include:"textfield",
style:function(a){return {decorator:"undefined",
padding:[2,
3]};
}},
"spinner/upbutton":{alias:"button",
include:"button",
style:function(a){return {icon:"decoration/arrows/up-small.gif",
padding:a.pressed?[2,
2,
0,
4]:[1,
3,
1,
3],
backgroundColor:a.hovered?"button-hovered":"button"};
}},
"spinner/downbutton":{alias:"button",
include:"button",
style:function(a){return {icon:"decoration/arrows/down-small.gif",
padding:a.pressed?[2,
2,
0,
4]:[1,
3,
1,
3],
backgroundColor:a.hovered?"button-hovered":"button"};
}},
"datefield":"combobox",
"datefield/button":{alias:"combobox/button",
include:"combobox/button",
style:function(a){return {icon:"icon/16/apps/office-calendar.png",
padding:[0,
3],
backgroundColor:a.disabled?"background-disabled":a.focused?"background-focused":"background-field",
decorator:"undefined"};
}},
"datefield/list":{alias:"datechooser",
include:"datechooser",
style:function(a){return {decorator:a.focused?"focused-inset":"inset"};
}},
"groupbox":{style:function(a){return {backgroundColor:"background"};
}},
"groupbox/legend":{alias:"atom",
style:function(a){return {backgroundColor:"background",
paddingRight:4,
paddingLeft:4,
marginRight:10,
marginLeft:10};
}},
"groupbox/frame":{style:function(a){return {padding:[12,
9],
decorator:"groove"};
}},
"check-groupbox":"groupbox",
"check-groupbox/legend":{alias:"checkbox",
include:"checkbox",
style:function(a){return {backgroundColor:"background",
paddingRight:3,
paddingLeft:3,
marginRight:10,
marginLeft:10};
}},
"radio-groupbox":"groupbox",
"radio-groupbox/legend":{alias:"radiobutton",
include:"radiobutton",
style:function(a){return {backgroundColor:"background",
paddingRight:3,
paddingLeft:3,
marginRight:10,
marginLeft:10};
}},
"toolbar":{style:function(a){return {decorator:"outset-thin",
backgroundColor:"background"};
}},
"toolbar/part":{},
"toolbar/part/container":{},
"toolbar/part/handle":{style:function(a){return {decorator:"toolbar-part-handle",
width:4,
margin:[3,
2]};
}},
"toolbar-separator":{style:function(a){return {width:1,
margin:[3,
2],
decorator:"divider-horizontal"};
}},
"toolbar-button":{alias:"atom",
style:function(a){if(a.pressed||a.checked||a.abandoned){var b="inset-thin";
var c=[3,
2,
1,
4];
}else if(a.hovered){var b="outset-thin";
var c=[2,
3];
}else{var b="undefined";
var c=[3,
4];
}return {cursor:"default",
decorator:b,
padding:c,
backgroundColor:a.abandoned?"button-abandoned":a.checked?"background-light":"button"};
}},
"toolbar-splitbutton":{},
"toolbar-splitbutton/button":"toolbar-button",
"toolbar-splitbutton/arrow":{alias:"toolbar-button",
include:"toolbar-button",
style:function(a){return {icon:"decoration/arrows/down.gif"};
}},
"slidebar":{},
"slidebar/scrollpane":{},
"slidebar/content":{},
"slidebar/button-forward":{alias:"button",
include:"button",
style:function(a){return {icon:"decoration/arrows/next.gif"};
}},
"slidebar/button-backward":{alias:"button",
include:"button",
style:function(a){return {icon:"decoration/arrows/left.gif"};
}},
"tabview":{},
"tabview/bar":{alias:"slidebar",
style:function(a){var b=0,
c=0,
d=0,
e=0;
if(a.barTop){d=-2;
}else if(a.barBottom){b=-2;
}else if(a.barRight){e=-2;
}else{c=-2;
}return {marginBottom:d,
marginTop:b,
marginLeft:e,
marginRight:c};
}},
"tabview/pane":{style:function(a){return {backgroundColor:"background",
decorator:"outset",
padding:10};
}},
"tabview-page":{},
"tabview-page/button":{alias:"button",
style:function(a){var b=new qx.ui.decoration.Double;
b.setWidth(1);
b.setInnerWidth(1);
b.setColor(["border-light-shadow",
"border-dark",
"border-dark",
"border-light-shadow"]);
b.setInnerColor(["border-light",
"border-dark-shadow",
"border-dark-shadow",
"border-light"]);
var c=0,
d=0,
e=0,
f=0;
if(a.barTop||a.barBottom){var g=2,
h=2,
i=6,
j=6;
}else{var g=6,
h=6,
i=6,
j=6;
}
if(a.barTop){b.setWidthBottom(0);
b.setInnerWidthBottom(0);
}else if(a.barRight){b.setWidthLeft(0);
b.setInnerWidthLeft(0);
}else if(a.barBottom){b.setWidthTop(0);
b.setInnerWidthTop(0);
}else{b.setWidthRight(0);
b.setInnerWidthRight(0);
}
if(a.checked){if(a.barTop||a.barBottom){i+=2;
j+=2;
}else{g+=2;
h+=2;
}}else{if(a.barTop||a.barBottom){e+=2;
c+=2;
}else if(a.barLeft||a.barRight){d+=2;
f+=2;
}}
if(a.checked){if(!a.firstTab){if(a.barTop||a.barBottom){f=-4;
}else{c=-4;
}}
if(!a.lastTab){if(a.barTop||a.barBottom){d=-4;
}else{e=-4;
}}}return {zIndex:a.checked?10:5,
backgroundColor:"background",
decorator:b,
iconPosition:a.barLeft||a.barRight?"top":"left",
padding:[g,
j,
h,
i],
margin:[c,
d,
e,
f]};
}},
"scrollbar":{},
"scrollbar/slider":{alias:"slider",
style:function(a){return {backgroundColor:"background-light"};
}},
"scrollbar/button":{alias:"button",
include:"button",
style:function(a){var b;
if(a.up||a.down){if(a.pressed||a.abandoned||a.checked){b=[5,
2,
3,
4];
}else{b=[4,
3];
}}else{if(a.pressed||a.abandoned||a.checked){b=[4,
3,
2,
5];
}else{b=[3,
4];
}}var c="decoration/arrows/";
if(a.left){c+="left.gif";
}else if(a.right){c+="right.gif";
}else if(a.up){c+="up.gif";
}else{c+="down.gif";
}return {padding:b,
icon:c};
}},
"scrollbar/button-begin":"scrollbar/button",
"scrollbar/button-end":"scrollbar/button",
"slider":{style:function(a){return {backgroundColor:"background-light",
decorator:a.focused?"focused-inset":"inset"};
}},
"slider/knob":{include:"button",
style:function(a){return {width:14,
height:14,
decorator:"outset"};
}},
"folder-open-button":{style:function(a){return {source:a.opened?"decoration/tree/minus.gif":"decoration/tree/plus.gif"};
}},
"tree-folder":{style:function(a){return {padding:[2,
3,
2,
0],
icon:"icon/16/places/folder-open.png",
iconOpened:"icon/16/places/folder.png"};
}},
"tree-folder-icon":{style:function(a){return {padding:[0,
4,
0,
0]};
}},
"tree-folder-label":{style:function(a){return {padding:[1,
2],
backgroundColor:a.selected?"background-selected":"undefined",
textColor:a.selected?"text-selected":"undefined"};
}},
"tree-file":{include:"tree-folder",
style:function(a){return {icon:"icon/16/mimetypes/text-plain.png"};
}},
"tree-file-icon":"tree-folder-icon",
"tree-file-label":"tree-folder-label",
"tree":{include:"list",
alias:"list",
style:function(a){return {contentPadding:[4,
4,
4,
4]};
}},
"window":{style:function(a){return {backgroundColor:"background",
decorator:a.maximized?"undefined":"outset"};
}},
"window/pane":{},
"window/captionbar":{style:function(a){return {padding:1,
backgroundColor:a.active?"window-active-caption":"window-inactive-caption",
textColor:a.active?"window-active-caption-text":"window-inactive-caption-text"};
}},
"window/icon":{style:function(a){return {marginRight:4};
}},
"window/title":{style:function(a){return {cursor:"default",
font:"bold",
marginRight:20,
alignY:"middle"};
}},
"window/minimize-button":{include:"button",
alias:"button",
style:function(a){return {icon:"decoration/window/minimize.gif",
padding:a.pressed||a.abandoned?[2,
1,
0,
3]:[1,
2]};
}},
"window/restore-button":{include:"button",
alias:"button",
style:function(a){return {icon:"decoration/window/restore.gif",
padding:a.pressed||a.abandoned?[2,
1,
0,
3]:[1,
2]};
}},
"window/maximize-button":{include:"button",
alias:"button",
style:function(a){return {icon:"decoration/window/maximize.gif",
padding:a.pressed||a.abandoned?[2,
1,
0,
3]:[1,
2]};
}},
"window/close-button":{include:"button",
alias:"button",
style:function(a){return {marginLeft:2,
icon:"decoration/window/close.gif",
padding:a.pressed||a.abandoned?[2,
1,
0,
3]:[1,
2]};
}},
"window/statusbar":{style:function(a){return {decorator:"inset-thin",
padding:[2,
6]};
}},
"window/statusbar-text":"label",
"resizer":{style:function(a){return {decorator:"outset"};
}},
"splitpane":{},
"splitpane/splitter":{style:function(a){return {backgroundColor:"background"};
}},
"splitpane/splitter/knob":{style:function(a){return {source:a.horizontal?"decoration/splitpane/knob-horizontal.png":"decoration/splitpane/knob-vertical.png",
padding:2};
}},
"splitpane/slider":{style:function(a){return {backgroundColor:"border-dark",
opacity:0.3};
}},
"selectbox":"button",
"selectbox/atom":"atom",
"selectbox/popup":"popup",
"selectbox/list":"list",
"selectbox/arrow":{style:function(a){return {source:"decoration/arrows/down.gif",
paddingRight:4,
paddingLeft:5};
}},
"datechooser":{},
"datechooser/navigation-bar":{style:function(a){return {backgroundColor:"date-chooser",
padding:[2,
10]};
}},
"datechooser/last-year-button":"datechooser/button",
"datechooser/last-month-button":"datechooser/button",
"datechooser/next-year-button":"datechooser/button",
"datechooser/next-month-button":"datechooser/button",
"datechooser/button/icon":{},
"datechooser/button":{style:function(a){var b={width:17,
show:"icon"};
if(a.lastYear){b.icon="decoration/arrows/rewind.gif";
}else if(a.lastMonth){b.icon="decoration/arrows/left.gif";
}else if(a.nextYear){b.icon="decoration/arrows/forward.gif";
}else if(a.nextMonth){b.icon="decoration/arrows/right.gif";
}
if(a.pressed||a.checked||a.abandoned){b.decorator="inset-thin";
}else if(a.hovered){b.decorator="outset-thin";
}else{b.decorator="undefined";
}
if(a.pressed||a.checked||a.abandoned){b.padding=[2,
0,
0,
2];
}else if(a.hovered){b.padding=1;
}else{b.padding=2;
}return b;
}},
"datechooser/month-year-label":{style:function(a){return {font:"bold",
textAlign:"center"};
}},
"datechooser/date-pane":{style:function(a){return {decorator:new qx.ui.decoration.Single().set({top:[1,
"solid",
"gray"]}),
backgroundColor:"date-chooser"};
}},
"datechooser-weekday":{style:function(a){var b=new qx.ui.decoration.Single().set({bottom:[1,
"solid",
"gray"]});
return {decorator:b,
font:"bold",
textAlign:"center",
textColor:a.weekend?"date-chooser-title":"date-chooser",
backgroundColor:a.weekend?"date-chooser":"date-chooser-title"};
}},
"datechooser-day":{style:function(a){return {textAlign:"center",
decorator:a.today?"black":"undefined",
textColor:a.selected?"text-selected":a.otherMonth?"text-disabled":"undefined",
backgroundColor:a.selected?"date-chooser-selected":"undefined",
padding:[2,
4]};
}},
"datechooser-week":{style:function(a){if(a.header){var b=new qx.ui.decoration.Single().set({right:[1,
"solid",
"gray"],
bottom:[1,
"solid",
"gray"]});
}else{var b=new qx.ui.decoration.Single().set({right:[1,
"solid",
"gray"]});
}return {textAlign:"center",
textColor:"date-chooser-title",
padding:[2,
4],
decorator:b};
}},
"combobox":{style:function(a){return {decorator:a.focused?"focused-inset":"inset",
textColor:a.disabled?"text-disabled":"undefined",
backgroundColor:"background-field"};
}},
"combobox/button":{alias:"button",
include:"button",
style:function(a){return {icon:"decoration/arrows/down.gif",
backgroundColor:a.hovered?"button-hovered":"button"};
}},
"combobox/popup":"popup",
"combobox/list":"list",
"combobox/textfield":{include:"textfield",
style:function(a){return {decorator:"undefined",
padding:[2,
3]};
}},
"menu":{style:function(a){var b={backgroundColor:"background",
decorator:"outset",
spacingX:6,
spacingY:1,
iconColumnWidth:16,
arrowColumnWidth:4,
padding:1};
if(a.submenu){b.position="right-top";
b.offset=[-2,
-3];
}return b;
}},
"menu-separator":{style:function(a){return {height:0,
decorator:"menu-separator",
marginTop:4,
marginBottom:4,
marginLeft:2,
marginRight:2};
}},
"menu-button":{alias:"atom",
style:function(a){return {backgroundColor:a.selected?"background-selected":"undefined",
textColor:a.selected?"text-selected":"undefined",
padding:[2,
6]};
}},
"menu-button/icon":{include:"image",
style:function(a){return {alignY:"middle"};
}},
"menu-button/label":{include:"label",
style:function(a){return {alignY:"middle",
padding:1};
}},
"menu-button/shortcut":{include:"label",
style:function(a){return {alignY:"middle",
marginLeft:14,
padding:1};
}},
"menu-button/arrow":{style:function(a){return {source:a.selected?"decoration/arrows/right-invert.gif":"decoration/arrows/right.gif",
alignY:"middle"};
}},
"menu-checkbox":{alias:"menu-button",
include:"menu-button",
style:function(a){return {icon:!a.checked?"undefined":a.selected?"decoration/menu/checkbox-invert.gif":"decoration/menu/checkbox.gif"};
}},
"menu-radiobutton":{alias:"menu-button",
include:"menu-button",
style:function(a){return {icon:!a.checked?"undefined":a.selected?"decoration/menu/radiobutton-invert.gif":"decoration/menu/radiobutton.gif"};
}},
"colorselector":"widget",
"colorselector/cancle-button":"button",
"colorselector/ok-button":"button",
"colorselector/control-bar":"widget",
"colorselector/preset-field-set":"groupbox",
"colorselector/input-field-set":"groupbox",
"colorselector/preview-field-set":"groupbox",
"colorselector/hex-field":"textfield",
"colorselector/rgb-spinner-red":"spinner",
"colorselector/rgb-spinner-green":"spinner",
"colorselector/rgb-spinner-blue":"spinner",
"colorselector/hsb-spinner-hue":"spinner",
"colorselector/hsb-spinner-saturation":"spinner",
"colorselector/hsb-spinner-brightness":"spinner",
"table":"widget",
"table/statusbar":{style:function(a){return {decorator:new qx.ui.decoration.Single().set({top:[1,
"solid",
"border-dark-shadow"]}),
paddingLeft:2,
paddingRight:2};
}},
"table/column-button":{alias:"button",
style:function(a){var b,
c;
if(a.pressed||a.checked||a.abandoned){b="inset-thin";
c=[3,
2,
1,
4];
}else if(a.hovered){b="outset-thin";
c=[2,
3];
}else{b="undefined";
c=[3,
4];
}return {decorator:b,
padding:c,
backgroundColor:a.abandoned?"button-abandoned":"button",
icon:"decoration/table/select-column-order.png"};
}},
"table-column-reset-button":{extend:"menu-button",
alias:"menu-button",
style:function(){return {icon:"icon/16/actions/view-refresh.png"};
}},
"table-scroller/scrollbar-x":"scrollbar",
"table-scroller/scrollbar-y":"scrollbar",
"table-scroller":"widget",
"table-scroller/header":{style:function(a){return {decorator:new qx.ui.decoration.Single().set({bottom:[1,
"solid",
"table-header-border"]}),
backgroundColor:"table-header"};
}},
"table-scroller/pane":{style:function(a){return {backgroundColor:"table-pane"};
}},
"table-scroller/focus-indicator":{style:function(a){return {decorator:new qx.ui.decoration.Single(2,
"solid",
"table-focus-indicator")};
}},
"table-scroller/resize-line":{style:function(a){return {backgroundColor:"#D6D5D9",
width:3};
}},
"table-header-cell":{alias:"atom",
style:function(a){if(a.hovered){deco=new qx.ui.decoration.Single().set({right:[1,
"solid",
"table-header-border"],
bottom:[2,
"solid",
"effect"]});
paddingBottom=0;
backgroundColor="table-header-cell-hover";
}else{deco=new qx.ui.decoration.Single().set({right:[1,
"solid",
"table-header-border"]});
paddingBottom=2;
backgroundColor="table-header-cell";
}return {paddingLeft:2,
paddingRight:2,
paddingBottom:paddingBottom,
decorator:deco,
backgroundColor:backgroundColor,
sortIcon:a.sorted?(a.sortedAscending?"decoration/table/ascending.png":"decoration/table/descending.png"):"undefined"};
}},
"table-header-cell/sort-icon":{style:function(a){return {alignY:"middle"};
}},
"table-editor-textfield":{include:"textfield",
style:function(a){return {decorator:"undefined",
padding:[2,
2]};
}},
"table-editor-selectbox":{include:"selectbox",
alias:"selectbox",
style:function(a){return {padding:[0,
2]};
}},
"table-editor-combobox":{include:"combobox",
alias:"combobox",
style:function(a){return {decorator:"undefined"};
}}}});
qx.Bootstrap.define("qx.xml.String",
{statics:{TO_CHARCODE:{"quot":34,
"amp":38,
"lt":60,
"gt":62,
"apos":39},
FROM_CHARCODE:{34:"quot",
38:"amp",
60:"lt",
62:"gt",
39:"apos"},
escape:function(a){return qx.util.StringEscape.escape(a,
this.FROM_CHARCODE);
},
unescape:function(a){return qx.util.StringEscape.unescape(a,
this.TO_CHARCODE);
}}});
qx.Class.define("qx.ui.table.pane.Clipper",
{extend:qx.ui.container.Composite,
construct:function(){arguments.callee.base.call(this,
new qx.ui.layout.Grow());
},
members:{scrollToX:function(a){this._contentElement.scrollToX(a,
false);
},
scrollToY:function(a){this._contentElement.scrollToY(a,
true);
}}});
qx.Theme.define("qx.theme.classic.Color",
{title:"Windows Classic",
colors:{"background":"#EBE9ED",
"background-light":"#F3F0F5",
"background-focused":"#F3F8FD",
"background-focused-inner":"#DBEAF9",
"background-disabled":"#F4F4F4",
"background-selected":"#3E6CA8",
"background-field":"white",
"border-lead":"#888888",
"border-light":"white",
"border-light-shadow":"#DCDFE4",
"border-dark-shadow":"#A7A6AA",
"border-dark":"#85878C",
"border-focused-light":"#BCCEE5",
"border-focused-light-shadow":"#A5BDDE",
"border-focused-dark-shadow":"#7CA0CF",
"border-focused-dark":"#3E6CA8",
"text":"black",
"text-disabled":"#A7A6AA",
"text-selected":"white",
"text-focused":"#3E5B97",
"tooltip":"#FFFFE1",
"tooltip-text":"black",
"button":"#EBE9ED",
"button-hovered":"#F6F5F7",
"button-abandoned":"#F9F8E9",
"button-checked":"#F3F0F5",
"window-active-caption-text":[255,
255,
255],
"window-inactive-caption-text":[255,
255,
255],
"window-active-caption":[51,
94,
168],
"window-inactive-caption":[111,
161,
217],
"date-chooser":"white",
"date-chooser-title":[116,
116,
116],
"date-chooser-selected":[52,
52,
52],
"effect":[254,
200,
60],
"table-pane":"white",
"table-header":[242,
242,
242],
"table-header-border":[214,
213,
217],
"table-header-cell":[235,
234,
219],
"table-header-cell-hover":[255,
255,
255],
"table-focus-indicator":[179,
217,
255],
"table-row-background-focused-selected":[90,
138,
211],
"table-row-background-focused":[221,
238,
255],
"table-row-background-selected":[51,
94,
168],
"table-row-background-even":[250,
248,
243],
"table-row-background-odd":[255,
255,
255],
"table-row-selected":[255,
255,
255],
"table-row":[0,
0,
0]}});
qx.Theme.define("qx.theme.classic.Decoration",
{title:"Classic",
resource:"qx/decoration/Classic",
decorations:{"black":{decorator:qx.ui.decoration.Uniform,
style:{width:1,
color:"black"}},
"white":{decorator:qx.ui.decoration.Uniform,
style:{width:1,
color:"white"}},
"dark-shadow":{decorator:qx.ui.decoration.Uniform,
style:{width:1,
color:"border-dark-shadow"}},
"light-shadow":{decorator:qx.ui.decoration.Uniform,
style:{width:1,
color:"border-light-shadow"}},
"light":{decorator:qx.ui.decoration.Uniform,
style:{width:1,
color:"border-light"}},
"dark":{decorator:qx.ui.decoration.Uniform,
style:{width:1,
color:"border-dark"}},
"inset":{decorator:qx.ui.decoration.Double,
style:{width:1,
innerWidth:1,
color:["border-dark-shadow",
"border-light",
"border-light",
"border-dark-shadow"],
innerColor:["border-dark",
"border-light-shadow",
"border-light-shadow",
"border-dark"]}},
"outset":{decorator:qx.ui.decoration.Double,
style:{width:1,
innerWidth:1,
color:["border-light-shadow",
"border-dark",
"border-dark",
"border-light-shadow"],
innerColor:["border-light",
"border-dark-shadow",
"border-dark-shadow",
"border-light"]}},
"groove":{decorator:qx.ui.decoration.Double,
style:{width:1,
innerWidth:1,
color:["border-dark-shadow",
"border-light",
"border-light",
"border-dark-shadow"],
innerColor:["border-light",
"border-dark-shadow",
"border-dark-shadow",
"border-light"]}},
"ridge":{decorator:qx.ui.decoration.Double,
style:{width:1,
innerWidth:1,
color:["border-light",
"border-dark-shadow",
"border-dark-shadow",
"border-light"],
innerColor:["border-dark-shadow",
"border-light",
"border-light",
"border-dark-shadow"]}},
"inset-thin":{decorator:qx.ui.decoration.Single,
style:{width:1,
color:["border-dark-shadow",
"border-light",
"border-light",
"border-dark-shadow"]}},
"outset-thin":{decorator:qx.ui.decoration.Single,
style:{width:1,
color:["border-light",
"border-dark-shadow",
"border-dark-shadow",
"border-light"]}},
"line-left":{decorator:qx.ui.decoration.Single,
style:{widthLeft:1,
colorLeft:"border-dark-shadow"}},
"line-right":{decorator:qx.ui.decoration.Single,
style:{widthRight:1,
colorRight:"border-dark-shadow"}},
"line-top":{decorator:qx.ui.decoration.Single,
style:{widthTop:1,
colorTop:"border-dark-shadow"}},
"line-bottom":{decorator:qx.ui.decoration.Single,
style:{widthBottom:1,
colorBottom:"border-dark-shadow"}},
"divider-vertical":{decorator:qx.ui.decoration.Single,
style:{widthTop:1,
colorTop:"border-dark-shadow"}},
"divider-horizontal":{decorator:qx.ui.decoration.Single,
style:{widthLeft:1,
colorLeft:"border-dark-shadow"}},
"focused-inset":{decorator:qx.ui.decoration.Double,
style:{width:1,
innerWidth:1,
color:["border-focused-dark-shadow",
"border-focused-light",
"border-focused-light",
"border-focused-dark-shadow"],
innerColor:["border-focused-dark",
"border-focused-light-shadow",
"border-focused-light-shadow",
"border-focused-dark"]}},
"focused-outset":{decorator:qx.ui.decoration.Double,
style:{width:1,
innerWidth:1,
color:["border-focused-light-shadow",
"border-focused-dark",
"border-focused-dark",
"border-focused-light-shadow"],
innerColor:["border-focused-light",
"border-focused-dark-shadow",
"border-focused-dark-shadow",
"border-focused-light"]}},
"lead-item":{decorator:qx.ui.decoration.Double,
style:{width:1,
style:"dotted",
color:"border-lead"}},
"tooltip":{decorator:qx.ui.decoration.Uniform,
style:{width:1,
color:"tooltip-text"}},
"toolbar-part-handle":{decorator:qx.ui.decoration.Single,
style:{width:1,
backgroundColor:"background",
style:"solid",
colorTop:"#ffffff",
colorLeft:"#ffffff",
colorRight:"#a7a6aa",
colorBottom:"#a7a6aa"}},
"menu-separator":{decorator:qx.ui.decoration.Single,
style:{width:1,
widthLeft:0,
widthRight:0,
colorTop:"border-dark",
colorBottom:"border-light"}}}});
qx.Theme.define("qx.theme.Classic",
{title:"Classic Windows",
meta:{color:qx.theme.classic.Color,
decoration:qx.theme.classic.Decoration,
font:qx.theme.classic.Font,
appearance:qx.theme.classic.Appearance,
icon:qx.theme.icon.Oxygen}});
qx.Bootstrap.define("qx.List",
{statics:{define:function(a,
b){if(!b){var b={};
}{this.__fT(a,
b);
};
if(qx.core.Variant.isSet("qx.client",
"mshtml")){var c=new ActiveXObject("htmlfile");
c.open();
c.write("<html><script><"+"/script></html>");
c.close();
var d=c.parentWindow.Array;
d.__html=c;
}else{var d=function(){Array.call(this);
this.push.apply(this,
arguments);
};
d.prototype=new Array;
}var e=qx.Bootstrap.createNamespace(a,
d,
false);
var f=d.prototype;
d.classname=a;
f.basename=d.basename=e;
d.toString=this.genericToString;
var g=b.statics;
if(g){for(var h in g){d[h]=g[h];
}}var i=b.members;
if(i){for(var h in i){f[h]=i[h];
}}if(b.defer){b.defer.self=d;
b.defer(d,
f);
}this.$$registry[a]=d;
},
genericToString:function(){return "[List "+this.classname+"]";
},
$$registry:qx.Bootstrap.$$registry,
__fS:{"statics":"object",
"members":"object",
"defer":"function"},
__fT:function(a,
b){var c=this.__fS;
for(var d in b){if(c[d]===undefined){throw new Error('The configuration key "'+d+'" in theme "'+a+'" is not allowed!');
}
if(b[d]==null){throw new Error('Invalid key "'+d+'" in theme "'+a+'"! The value is undefined/null!');
}
if(c[d]!==null&&typeof b[d]!==c[d]){throw new Error('Invalid type of key "'+d+'" in theme "'+a+'"! The type of the key must be "'+c[d]+'"!');
}}}}});
qx.List.define("qx.util.StringBuilder",
{members:{clear:function(){this.length=0;
},
get:function(){return this.join("");
},
add:null,
isEmpty:function(){return this.length===0;
}},
defer:function(a,
b){b.add=b.push;
b.toString=b.get;
}});
qx.Class.define("qx.ui.embed.Iframe",
{extend:qx.ui.core.Widget,
include:qx.ui.core.MNativeOverflow,
construct:function(a){if(a!=null){this._source=a;
}arguments.callee.base.call(this);
qx.event.Registration.addListener(document.body,
"mousedown",
this.block,
this,
true);
qx.event.Registration.addListener(document.body,
"mouseup",
this.release,
this,
true);
this._blockerElement=this._createBlockerElement();
this._containerElement.add(this._blockerElement);
},
events:{"load":"qx.event.type.Event"},
properties:{appearance:{refine:true,
init:"iframe"},
source:{check:"String",
apply:"_applySource",
nullable:true},
frameName:{check:"String",
init:"",
apply:"_applyFrameName"}},
members:{renderLayout:function(a,
b,
c,
d){arguments.callee.base.call(this,
a,
b,
c,
d);
var e="px";
var f=this.getInsets();
this._blockerElement.setStyle("left",
f.left+e);
this._blockerElement.setStyle("top",
f.top+e);
this._blockerElement.setStyle("width",
(c-f.left-f.right)+e);
this._blockerElement.setStyle("height",
(d-f.top-f.bottom)+e);
},
_createContentElement:function(){var a=new qx.html.Iframe(this._source);
a.addListener("load",
this._onIframeLoad,
this);
return a;
},
_createBlockerElement:function(){var a=new qx.html.Element("div");
a.setStyle("zIndex",
20);
a.setStyle("position",
"absolute");
a.setStyle("display",
"none");
if(qx.bom.client.Engine.MSHTML){a.setStyle("backgroundColor",
"white");
a.setStyle("filter",
"Alpha(Opacity=0)");
}return a;
},
_onIframeLoad:function(a){this.fireNonBubblingEvent("load");
},
getWindow:function(){return this.getContentElement().getWindow();
},
getDocument:function(){return this.getContentElement().getDocument();
},
getBody:function(){return this.getContentElement().getBody();
},
getName:function(){return this.getContentElement().getName();
},
block:function(){this._blockerElement.setStyle("display",
"block");
},
release:function(){this._blockerElement.setStyle("display",
"none");
},
reload:function(){this.getContentElement().reload();
},
_applySource:function(a,
b){this.getContentElement().setSource(a);
},
_applyFrameName:function(a,
b){this.getContentElement().setAttribute("name",
a);
}},
destruct:function(){this._disposeObjects("_blockerElement");
}});
qx.Bootstrap.define("qx.bom.Request",
{construct:function(){this.__headers={};
this.__xmlhttp=this.__fX();
},
statics:{UNSENT:0,
OPENED:1,
HEADERS_RECEIVED:2,
LOADING:3,
DONE:4},
members:{readyState:0,
responseText:"",
responseXML:null,
status:0,
statusText:"",
timeout:0,
onreadystatechange:function(){},
ontimeout:function(){},
onload:function(){},
onerror:function(){},
onabort:function(){},
open:function(a,
b,
c,
d,
e){this.__async=c;
this.__stateListener=qx.lang.Function.bind(this.__fU,
this);
this.__xmlhttp.onreadystatechange=this.__stateListener;
this.__timeoutListener=qx.lang.Function.bind(this.__fV,
this);
this.__xmlhttp.ontimeout=this.__timeoutListener;
if(this.timeout!=null&&this.timeout>0){this.__xmlhttp.timeout=this.timeout;
}this.__xmlhttp.open(a,
b,
c,
d,
e);
if(qx.core.Variant.isSet("qx.client",
"gecko")){if(!c){this.readyState=qx.bom.Request.OPENED;
this.__fY();
}}},
send:function(a){var b=this.__headers;
if(a&&a.nodeType){a=window.XMLSerializer?new XMLSerializer().serializeToString(a):a.xml;
if(!b["Content-Type"]){b["Content-Type"]="application/xml";
}}for(var c in b){this.__xmlhttp.setRequestHeader(c,
b[c]);
}if(this.timeout!=null&&this.timeout>0){this.__timeoutHandle=window.setTimeout(this.__timeoutListener,
this.timeout);
}this.__xmlhttp.send(a);
if(qx.core.Variant.isSet("qx.client",
"gecko")){if(!this.__async){this.readyState=qx.bom.Request.OPENED;
this.__gb(this);
while(this.readyState<qx.bom.Request.DONE){this.readyState++;
this.__fY();
if(this.__aborted){return;
}}}}},
isSuccessful:function(){var a=this.status;
return a===304||(a>=200&&a<300);
},
abort:function(){this.__fW();
this.onabort();
},
__fU:function(){if(qx.core.Variant.isSet("qx.client",
"gecko")){if(!this.__async){return;
}}this.readyState=this.__xmlhttp.readyState;
this.__gb();
if(this.__aborted){this.readyState=qx.bom.Request.UNSENT;
return ;
}this.__fY();
if(this.readyState==qx.bom.Request.DONE){this.__gc();
}},
__fV:function(){this.__fW();
this.ontimeout();
},
getAllResponseHeaders:function(){try{return this.__xmlhttp.getAllResponseHeaders();
}catch(ex){return null;
}},
getResponseHeader:function(a){try{return this.__xmlhttp.getResponseHeader(a);
}catch(ex){return null;
}},
setRequestHeader:function(a,
b){if(b==null){delete this.__headers[a];
}else{this.__headers[a]=b;
}},
removeRequestHeader:function(a,
b){delete this.__headers[a];
},
getRequestHeader:function(a){return this.__headers[a]||null;
},
__fW:function(){this.__gb();
if(this.readyState>qx.bom.Request.UNSENT){this.__aborted=true;
}this.__xmlhttp.abort();
this.__gc();
},
__fX:qx.core.Variant.select("qx.client",
{"default":function(){return new XMLHttpRequest;
},
"mshtml":function(){if(window.ActiveXObject&&qx.xml.Document.XMLHTTP){return new ActiveXObject(qx.xml.Document.XMLHTTP);
}
if(window.XMLHttpRequest){return new XMLHttpRequest;
}}}),
__fY:function(){if(this.__lastFired===this.readyState){return;
}this.onreadystatechange();
this.__lastFired=this.readyState;
if(this.readyState===4){if(this.isSuccessful()){this.onload();
}else{this.onerror();
}}},
__ga:function(){var a=this.__xmlhttp.responseXML;
if(qx.core.Variant.isSet("qx.client",
"mshtml")){if(a&&!a.documentElement&&this.__xmlhttp.getResponseHeader("Content-Type").match(/[^\/]+\/[^\+]+\+xml/)){a=new ActiveXObject(qx.xml.Document.DOMDOC);
a.loadXML(this.__xmlhttp.responseText);
}if(a&&a.parseError!=0){return null;
}}else if(a&&a.documentElement&&a.documentElement.tagName=="parsererror"){return null;
}return a;
},
__gb:function(){var a=this.__xmlhttp;
try{this.responseText=a.responseText;
}catch(e){}
try{this.responseXML=this.__ga();
}catch(e){}
try{this.status=a.status;
}catch(e){}
try{this.statusText=a.statusText;
}catch(e){}if(qx.core.Variant.isSet("qx.client",
"mshtml")){if(this.status===1223){this.status=204;
}}if(!this.status&&location.protocol==="file:"){this.status=204;
}},
__gc:function(){if(this.__timeoutHandle){window.clearTimeout(this.__timeoutHandle);
}if(this.__xmlhttp){this.__xmlhttp.onreadystatechange=this.__gd;
this.__xmlhttp.ontimeout=this.__gd;
}delete this.onreadystatechange;
delete this.ontimeout;
delete this.onload;
delete this.onerror;
delete this.onabort;
delete this.__timeoutHandle;
delete this.__stateListener;
delete this.__timeoutListener;
delete this.__xmlhttp;
delete this.__headers;
},
__gd:function(){}}});
qx.Class.define("qx.ui.table.cellrenderer.Image",
{extend:qx.ui.table.cellrenderer.AbstractImage,
construct:function(a,
b){arguments.callee.base.call(this);
if(a){this._imageWidth=a;
}else{this._imageWidth=16;
}
if(b){this._imageHeight=b;
}else{this._imageHeight=16;
}this._am=qx.util.AliasManager.getInstance();
this._rm=qx.util.ResourceManager;
},
members:{_identifyImage:function(a){var b={imageWidth:this._imageWidth,
imageHeight:this._imageHeight};
if(a.value==""){b.url=null;
}else{b.url=this._rm.toUri(this._am.resolve(a.value));
}return b;
}}});
qx.Interface.define("qx.ui.table.IRowRenderer",
{members:{updateDataRowElement:function(a,
b){return true;
},
createRowStyle:function(a){return true;
},
getRowClass:function(a){return true;
}}});
qx.Bootstrap.define("qx.io2.ScriptLoader",
{construct:function(){this.__oneventWrapped=qx.lang.Function.bind(this.__gg,
this);
this.__elem=document.createElement("script");
},
statics:{__ge:[],
get:function(){return this.__ge.pop()||new qx.io2.ScriptLoader;
},
pool:function(a){this.__ge.push(a);
},
load:function(a,
b,
c){var d=this.get();
d.load(a,
function(e){b.call(c||window,
e);
this.pool(d);
},
this);
}},
members:{load:function(a,
b,
c){if(this.__running){throw new Error("Another request is still running!");
}this.__running=true;
var d=document.getElementsByTagName("head")[0];
var e=this.__elem;
this.__callback=b||null;
this.__context=c||window;
e.type="text/javascript";
e.onerror=e.onload=e.onreadystatechange=this.__oneventWrapped;
e.src=a;
d.appendChild(e);
},
abort:function(){if(this.__running){this.__gf("abort");
}},
__gf:function(a){var b=this.__elem;
b.onerror=b.onload=b.onreadystatechange=null;
document.getElementsByTagName("head")[0].removeChild(b);
delete this.__running;
this.__callback.call(this.__context,
a);
},
__gg:function(a){if(typeof a==="string"||a.type==="error"){this.__gf("fail");
}else if(a.type==="load"){this.__gf("success");
}else if(a.type==="readystatechange"&&(a.target.readyState==="complete"||a.target.readyState==="loaded")){this.__gf("success");
}else{return;
}}}});
qx.Class.define("qx.ui.container.Resizer",
{extend:qx.ui.container.Composite,
include:qx.ui.core.MResizable,
properties:{appearance:{refine:true,
init:"resizer"}}});
qx.Class.define("qx.ui.progressive.model.Default",
{extend:qx.ui.progressive.model.Abstract,
construct:function(){arguments.callee.base.call(this);
this._elements=[];
},
members:{addElements:function(a){this._elements=this._elements.concat(a);
this.fireDataEvent("dataAvailable",
this._elements.length);
},
addElement:function(a){this._elements.push(a);
this.fireDataEvent("dataAvailable",
this._elements.length);
},
getElementCount:function(){return this._elements.length;
},
getNextElement:function(){if(this._elements.length>0){return ({element:this._elements.shift(),
remaining:this._elements.length});
}return null;
}},
destruct:function(){this._disposeFields("_elements");
}});
qx.Class.define("qx.ui.form.Slider",
{extend:qx.ui.form.AbstractSlider,
construct:function(a){arguments.callee.base.call(this,
a);
this.addListener("keypress",
this._onKeyPress);
this.addListener("mousewheel",
this._onMouseWheel);
},
properties:{appearance:{refine:true,
init:"slider"},
focusable:{refine:true,
init:true}},
members:{_onMouseWheel:function(a){var b=a.getWheelDelta()>0?1:-1;
this.slideBy(b*this.getSingleStep());
a.stop();
},
_onKeyPress:function(a){var b=this.getOrientation()==="horizontal";
var c=b?"Left":"Up";
var d=b?"Right":"Down";
switch(a.getKeyIdentifier()){case d:this.slideForward();
break;
case c:this.slideBack();
break;
case "PageDown":this.slidePageForward();
break;
case "PageUp":this.slidePageBack();
break;
case "Home":this.slideToBegin();
break;
case "End":this.slideToEnd();
break;
default:return;
}a.stop();
}}});
qx.Class.define("qx.ui.progressive.renderer.table.cell.Boolean",
{extend:qx.ui.progressive.renderer.table.cell.Icon,
construct:function(){arguments.callee.base.call(this);
this._iconUrlTrue=qx.util.AliasManager.getInstance().resolve("widget/table/boolean-true.png");
this._iconUrlFalse=qx.util.AliasManager.getInstance().resolve("widget/table/boolean-false.png");
this._iconUrlNull=qx.util.AliasManager.getInstance().resolve("static/image/blank.gif");
},
properties:{allowToggle:{init:false}},
members:{_identifyImage:function(a){var b={imageWidth:11,
imageHeight:11};
switch(a.cellData){case true:b.url=this._iconUrlTrue;
b.extras="celldata='1'";
break;
case false:b.url=this._iconUrlFalse;
b.extras="celldata='0' ";
break;
default:b.url=this._iconUrlNull;
break;
}
if(this.getAllowToggle()){b.extras+="onclick=\""+"var node = this.attributes.getNamedItem('celldata'); "+"var value = node.nodeValue; "+"if (value == '0') "+"{"+"  this.src='"+this._iconUrlTrue+"'; "+"  node.nodeValue='1'; "+"}"+"else "+"{"+"  this.src='"+this._iconUrlFalse+"'; "+"  node.nodeValue='0'; "+"}"+"this.attributes.setNamedItem(node); "+"\"";
}return b;
},
_getCellStyle:function(a){var b=arguments.callee.base.call(this,
a)+"padding-top:4px;";
return b;
}},
destruct:function(){this._disposeFields("_iconUrlTrue",
"_iconUrlFalse",
"_iconUrlNull");
}});
qx.Class.define("qx.ui.progressive.renderer.table.cell.Html",
{extend:qx.ui.progressive.renderer.table.cell.Abstract});
qx.Class.define("qx.ui.progressive.renderer.table.cell.Conditional",
{extend:qx.ui.progressive.renderer.table.cell.Abstract,
construct:function(a,
b,
c,
d){arguments.callee.base.call(this);
this.numericAllowed=["==",
"!=",
">",
"<",
">=",
"<="];
this.betweenAllowed=["between",
"!between"];
this.conditions=[];
this._defaultTextAlign=a||"";
this._defaultColor=b||"";
this._defaultFontStyle=c||"";
this._defaultFontWeight=d||"";
},
members:{__gh:function(a,
b){if(a.align){b["text-align"]=a.align;
}
if(a.color){b["color"]=a.color;
}
if(a.style){b["font-style"]=a.style;
}
if(a.weight){b["font-weight"]=a.weight;
}},
addNumericCondition:function(a,
b,
c,
d,
e,
f,
g){if(!qx.lang.Array.contains(this.numericAllowed,
a)||b==null){throw new Error("Condition not recognized or value is null!");
}this.conditions.push({condition:a,
align:c,
color:d,
style:e,
weight:f,
value1:b,
target:g});
},
addBetweenCondition:function(a,
b,
c,
d,
e,
f,
g,
h){if(!qx.lang.Array.contains(this.betweenAllowed,
a)||b==null||c==null){throw new Error("Condition not recognized or value1/value2 is null!");
}this.conditions.push({condition:a,
align:d,
color:e,
style:f,
weight:g,
value1:b,
value2:c,
target:h});
},
addRegex:function(a,
b,
c,
d,
e,
f){if(!a){throw new Error("regex cannot be null!");
}this.conditions.push({condition:"regex",
align:b,
color:c,
style:d,
weight:e,
regex:a,
target:f});
},
_getCellStyle:function(a){if(this.conditions.length==0){return a.style||"";
}var b;
var c;
var d;
var e={"text-align":this._defaultTextAlign,
"color":this._defaultColor,
"font-style":this._defaultFontStyle,
"font-weight":this._defaultFontWeight};
for(b=0;b<this.conditions.length;b++){var f=this.conditions[b];
c=false;
if(qx.lang.Array.contains(this.numericAllowed,
f.condition)){if(f.target==null){d=a.cellData;
}else{d=a.element.data[f.target];
}
switch(f.condition){case "==":if(d==f.value1){c=true;
}break;
case "!=":if(d!=f.value1){c=true;
}break;
case ">":if(d>f.value1){c=true;
}break;
case "<":if(d<f.value1){c=true;
}break;
case ">=":if(d>=f.value1){c=true;
}break;
case "<=":if(d<=f.value1){c=true;
}break;
}}else if(qx.lang.Array.contains(this.betweenAllowed,
f.condition)){if(f.target==null){d=a.cellData;
}else{d=a.element.data[f.target];
}
switch(f.condition){case "between":if(d>=f.value1&&d<=f.value2){c=true;
}break;
case "!between":if(d<f.value1&&d>f.value2){c=true;
}break;
}}else if(f.condition=="regex"){if(f.target==null){d=a.cellData;
}else{d=a.element.data[f.target];
}var g=new RegExp(f.value1,
'g');
c=g.test(d);
}if(c){this.__gh(f,
e);
}var h=[];
for(var j in e){if(e[j]){h.push(j,
":",
e[j],
";");
}}}return h.join("");
}},
destruct:function(){this._disposeFields("numericAllowed",
"betweenAllowed",
"conditions",
"_defaultTextAlign",
"_defaultColor",
"_defaultFontStyle",
"_defaultFontWeight");
}});
qx.Class.define("qx.ui.toolbar.CheckBox",
{extend:qx.ui.form.ToggleButton,
properties:{appearance:{refine:true,
init:"toolbar-button"},
show:{refine:true,
init:"inherit"},
focusable:{refine:true,
init:false}}});
qx.Class.define("qx.ui.toolbar.RadioButton",
{extend:qx.ui.toolbar.CheckBox,
implement:qx.ui.form.IRadioItem,
properties:{group:{check:"qx.ui.form.RadioGroup",
apply:"_applyGroup",
nullable:true}},
members:{_applyChecked:function(a,
b){arguments.callee.base.call(this,
a,
b);
if(a){var c=this.getGroup();
if(c){c.select(this);
}}},
_applyGroup:function(a,
b){if(b){b.remove(this);
}
if(a){a.add(this);
}}}});
qx.Class.define("qx.ui.layout.Dock",
{extend:qx.ui.layout.Abstract,
construct:function(a,
b){arguments.callee.base.call(this);
if(a){this.setSpacingX(a);
}
if(b){this.setSpacingY(b);
}},
properties:{sort:{check:["auto",
"y",
"x"],
init:"auto",
apply:"_applySort"},
spacingX:{check:"Integer",
init:0,
apply:"_applyLayoutChange"},
spacingY:{check:"Integer",
init:0,
apply:"_applyLayoutChange"}},
members:{verifyLayoutProperty:function(a,
b,
c){this.assertInArray(b,
["flex",
"edge",
"height",
"width"],
"The property '"+b+"' is not supported by the dock layout!");
if(b==="edge"){this.assertInArray(c,
["north",
"south",
"west",
"east",
"center"]);
}else if(b==="flex"){this.assertNumber(c);
this.assert(c>=0);
}else{this.assertMatch(c,
qx.ui.layout.Util.PERCENT_VALUE);
}},
_applySort:function(){this._invalidChildrenCache=true;
this._applyLayoutChange();
},
__gi:{north:1,
south:2,
west:3,
east:4,
center:5},
__gj:{1:"top",
2:"bottom",
3:"left",
4:"right"},
__gk:function(){var a=this._getLayoutChildren();
var b,
c;
var d=a.length;
var e=[];
var f=[];
var g=[];
var h=this.getSort()==="y";
var j=this.getSort()==="x";
for(var k=0;k<d;k++){b=a[k];
g=b.getLayoutProperties().edge;
if(g==="center"){if(c){throw new Error("It is not allowed to have more than one child aligned to 'center'!");
}c=b;
}else if(j||h){if(g==="north"||g==="south"){h?e.push(b):f.push(b);
}else if(g==="west"||g==="east"){h?f.push(b):e.push(b);
}}else{e.push(b);
}}var l=e.concat(f);
if(c){l.push(c);
}this.__children=l;
var m=[];
for(var k=0;k<d;k++){g=l[k].getLayoutProperties().edge;
m[k]=this.__gi[g]||5;
}this.__edges=m;
delete this._invalidChildrenCache;
},
renderLayout:function(a,
b){if(this._invalidChildrenCache){this.__gk();
}var c=qx.ui.layout.Util;
var d=this.__children;
var e=this.__edges;
var f=d.length;
var g,
h,
j,
k,
l,
m,
n,
o,
p;
var q=[];
var r=[];
var s=this.getSpacingX();
var t=this.getSpacingY();
var u=-s;
var v=-t;
for(var w=0;w<f;w++){h=d[w];
k=h.getLayoutProperties();
j=h.getSizeHint();
n=j.width;
o=j.height;
if(k.width!=null){n=Math.floor(a*parseFloat(k.width)/100);
if(n<j.minWidth){n=j.minWidth;
}else if(n>j.maxWidth){n=j.maxWidth;
}}
if(k.height!=null){o=Math.floor(b*parseFloat(k.height)/100);
if(o<j.minHeight){o=j.minHeight;
}else if(o>j.maxHeight){o=j.maxHeight;
}}q[w]=n;
r[w]=o;
switch(e[w]){case 1:case 2:v+=o+h.getMarginTop()+h.getMarginBottom();
break;
case 3:case 4:u+=n+h.getMarginLeft()+h.getMarginRight();
break;
default:u+=n+h.getMarginLeft()+h.getMarginRight();
v+=o+h.getMarginTop()+h.getMarginBottom();
}}if(u!=a){g={};
m=u<a;
for(var w=0;w<f;w++){h=d[w];
switch(e[w]){case 3:case 4:case 5:l=h.getLayoutProperties().flex;
if(l==null&&e[w]==5){l=1;
}
if(l>0){j=h.getSizeHint();
g[w]={min:j.minWidth,
value:q[w],
max:j.maxWidth,
flex:l};
}}}var x=c.computeFlexOffsets(g,
a,
u);
for(var w in x){p=x[w].offset;
q[w]+=p;
u+=p;
}}if(v!=b){g=[];
m=v<b;
for(var w=0;w<f;w++){h=d[w];
switch(e[w]){case 1:case 2:case 5:l=h.getLayoutProperties().flex;
if(l==null&&e[w]==5){l=1;
}
if(l>0){j=h.getSizeHint();
g[w]={min:j.minHeight,
value:r[w],
max:j.maxHeight,
flex:l};
}}}var x=c.computeFlexOffsets(g,
b,
v);
for(var w in x){p=x[w].offset;
r[w]+=p;
v+=p;
}}var y=0,
z=0,
A=0,
B=0;
var C,
D,
n,
o,
E,
F;
var G,
H,
I,
J;
var K=this.__gj;
for(var w=0;w<f;w++){h=d[w];
F=e[w];
j=h.getSizeHint();
G=h.getMarginTop();
H=h.getMarginBottom();
I=h.getMarginLeft();
J=h.getMarginRight();
switch(F){case 1:case 2:n=a-I-J;
if(n<j.minWidth){n=j.minWidth;
}else if(n>j.maxWidth){n=j.maxWidth;
}o=r[w];
D=y+c.computeVerticalAlignOffset(K[F],
o,
b,
G,
H);
C=z+c.computeHorizontalAlignOffset(h.getAlignX()||"left",
n,
a,
I,
J);
E=o+G+H+t;
b-=E;
if(F==1){y+=E;
}else{A+=E;
}break;
case 3:case 4:o=b-G-H;
if(o<j.minHeight){o=j.minHeight;
}else if(o>j.maxHeight){o=j.maxHeight;
}n=q[w];
C=z+c.computeHorizontalAlignOffset(K[F],
n,
a,
I,
J);
D=y+c.computeVerticalAlignOffset(h.getAlignY()||"top",
o,
b,
G,
H);
E=n+I+J+s;
a-=E;
if(F==3){z+=E;
}else{B+=E;
}break;
default:n=a-I-J;
o=b-G-H;
if(n<j.minWidth){n=j.minWidth;
}else if(n>j.maxWidth){n=j.maxWidth;
}if(o<j.minHeight){o=j.minHeight;
}else if(o>j.maxHeight){o=j.maxHeight;
}C=z+c.computeHorizontalAlignOffset(h.getAlignX()||"left",
n,
a,
I,
J);
D=y+c.computeVerticalAlignOffset(h.getAlignY()||"top",
o,
b,
G,
H);
}h.renderLayout(C,
D,
n,
o);
}},
_computeSizeHint:function(){if(this._invalidChildrenCache){this.__gk();
}var a=this.__children;
var b=this.__edges;
var c=a.length;
var d,
e;
var f,
g;
var h=0,
j=0;
var k=0,
l=0;
var m=0,
n=0;
var o=0,
p=0;
var q=this.getSpacingX(),
r=this.getSpacingY();
var s=-q,
t=-r;
for(var u=0;u<c;u++){e=a[u];
d=e.getSizeHint();
f=e.getMarginLeft()+e.getMarginRight();
g=e.getMarginTop()+e.getMarginBottom();
switch(b[u]){case 1:case 2:m=Math.max(m,
d.width+h+f);
n=Math.max(n,
d.minWidth+j+f);
o+=d.height+g;
p+=d.minHeight+g;
t+=r;
break;
case 3:case 4:k=Math.max(k,
d.height+o+g);
l=Math.max(l,
d.minHeight+p+g);
h+=d.width+f;
j+=d.minWidth+f;
s+=q;
break;
default:h+=d.width+f;
j+=d.minWidth+f;
o+=d.height+g;
p+=d.minHeight+g;
s+=q;
t+=r;
}}var v=Math.max(j,
n)+s;
var w=Math.max(h,
m)+s;
var x=Math.max(l,
p)+t;
var y=Math.max(k,
o)+t;
return {minWidth:v,
width:w,
minHeight:x,
height:y};
}}});
qx.Class.define("qx.util.EditDistance",
{statics:{OPERATION_DELETE:1,
OPERATION_INSERT:2,
OPERATION_REPLACE:3,
__gl:function(a,
b){var c=[];
var d,
e,
f;
for(d=0;d<=a.length;d++){c[d]=[];
c[d][0]=d;
}
for(e=1;e<=b.length;e++){c[0][e]=e;
}
for(d=1;d<=a.length;d++){for(e=1;e<=b.length;e++){f=a[d-1]===b[e-1]?0:1;
if(c[d]===undefined){c[d]=[];
}c[d][e]=Math.min(c[d-1][e]+1,
c[d][e-1]+1,
c[d-1][e-1]+
f);
}}return c;
},
__gm:function(a,
b,
c){var d=[];
var e=b.length;
var f=c.length;
if(e===0){for(var g=0;g<f;g++){d.push({operation:this.OPERATION_INSERT,
pos:g,
old:null,
value:c[g]});
}return d;
}
if(f===0){for(var g=e-1;g>=0;g--){d.push({operation:this.OPERATION_DELETE,
pos:g,
old:b[g],
value:null});
}return d;
}
while(e!==0||f!==0){if(e!=0&&a[e][f]==a[e-1][f]+1){d.push({operation:this.OPERATION_DELETE,
pos:e-1,
old:b[e-1],
value:null});
e-=1;
}else if(f!=0&&a[e][f]==a[e][f-1]+1){d.push({operation:this.OPERATION_INSERT,
pos:e,
old:null,
value:c[f-1]});
f-=1;
}else{if(b[e-1]!==c[f-1]){d.push({operation:this.OPERATION_REPLACE,
pos:e-1,
old:b[e-1],
value:c[f-1]});
}e-=1;
f-=1;
}}return d;
},
getEditOperations:function(a,
b){var c=this.__gl(a,
b);
var d=this.__gm(c,
a,
b);
return d;
}}});
qx.Class.define("qx.ui.table.cellrenderer.Number",
{extend:qx.ui.table.cellrenderer.Conditional,
construct:function(a,
b,
c,
d){arguments.callee.base.call(this,
a,
b,
c,
d);
this.initNumberFormat();
},
properties:{numberFormat:{check:"qx.util.format.NumberFormat",
init:null,
apply:"_applyNumberFormat"}},
members:{_applyNumberFormat:function(a,
b){var c;
if(a){c=function(d){if(d.value||d.value==0){return a.format(d.value);
}else{return "";
}};
}else{c=function(d){return d.value==0?"0":(d.value||"");
};
}this._getContentHtml=c;
},
_getCellClass:function(a){return "qooxdoo-table-cell qooxdoo-table-cell-right";
}}});
qx.Class.define("qx.application.Standalone",
{extend:qx.application.AbstractGui,
members:{_createRootWidget:function(){return new qx.ui.root.Application(document);
}}});
qx.Class.define("qx.ui.root.Application",
{extend:qx.ui.root.Abstract,
construct:function(a){this._window=qx.dom.Node.getWindow(a);
this._doc=a;
arguments.callee.base.call(this);
qx.event.Registration.addListener(this._window,
"resize",
this._onResize,
this);
this._setLayout(new qx.ui.layout.Canvas());
qx.ui.core.queue.Layout.add(this);
qx.ui.core.FocusHandler.getInstance().connectTo(this);
},
members:{_createContainerElement:function(){var a=this._doc;
var b=a.documentElement.style;
var c=a.body.style;
b.overflow=c.overflow="hidden";
b.padding=b.margin=c.padding=c.margin="0px";
b.width=b.height=c.width=c.height="100%";
var d=a.createElement("div");
a.body.appendChild(d);
var e=new qx.html.Root(d);
e.setStyle("position",
"absolute");
return e;
},
_onResize:function(a){qx.ui.core.queue.Layout.add(this);
},
_computeSizeHint:function(){var a=qx.bom.Viewport.getWidth(this._window);
var b=qx.bom.Viewport.getHeight(this._window);
return {minWidth:a,
width:a,
maxWidth:a,
minHeight:b,
height:b,
maxHeight:b};
}},
destruct:function(){this._disposeFields("_window",
"_doc");
}});
qx.Class.define("qx.ui.table.pane.Scroller",
{extend:qx.ui.core.Widget,
construct:function(a){arguments.callee.base.call(this);
this._table=a;
var b=new qx.ui.layout.Grid();
b.setColumnFlex(0,
1);
b.setRowFlex(1,
1);
this._setLayout(b);
this._horScrollBar=this._showChildControl("scrollbar-x");
this._verScrollBar=this._showChildControl("scrollbar-y");
this._header=this._showChildControl("header");
this._tablePane=this._showChildControl("pane");
this._headerClipper=new qx.ui.table.pane.Clipper();
this._headerClipper.add(this._header);
this._headerClipper.addListener("losecapture",
this._onChangeCaptureHeader,
this);
this._headerClipper.addListener("mousemove",
this._onMousemoveHeader,
this);
this._headerClipper.addListener("mousedown",
this._onMousedownHeader,
this);
this._headerClipper.addListener("mouseup",
this._onMouseupHeader,
this);
this._headerClipper.addListener("click",
this._onClickHeader,
this);
this._add(this._headerClipper,
{row:0,
column:0});
this._paneClipper=new qx.ui.table.pane.Clipper();
this._paneClipper.add(this._tablePane);
this._paneClipper.addListener("mousewheel",
this._onMousewheel,
this);
this._paneClipper.addListener("mousemove",
this._onMousemovePane,
this);
this._paneClipper.addListener("mousedown",
this._onMousedownPane,
this);
this._paneClipper.addListener("mouseup",
this._onMouseupPane,
this);
this._paneClipper.addListener("click",
this._onClickPane,
this);
this._paneClipper.addListener("contextmenu",
this._onContextMenu,
this);
this._paneClipper.addListener("dblclick",
this._onDblclickPane,
this);
this._paneClipper.addListener("resize",
this._onResizePane,
this);
this._add(this._paneClipper,
{row:1,
column:0});
this._focusIndicator=this._getChildControl("focus-indicator");
this._getChildControl("resize-line");
this._excludeChildControl("resize-line");
this.addListener("mouseout",
this._onMouseout,
this);
this.addListener("appear",
this._onAppear,
this);
this.addListener("disappear",
this._onDisappear,
this);
if(!this._onintervalWrapper){this._onintervalWrapper=qx.lang.Function.bind(this._oninterval,
this);
}this.initScrollTimeout();
},
statics:{MIN_COLUMN_WIDTH:10,
RESIZE_REGION_RADIUS:5,
CLICK_TOLERANCE:5,
HORIZONTAL_SCROLLBAR:1,
VERTICAL_SCROLLBAR:2},
events:{"changeScrollY":"qx.event.type.ChangeEvent",
"changeScrollX":"qx.event.type.ChangeEvent",
"cellClick":"qx.ui.table.pane.CellEvent",
"cellDblclick":"qx.ui.table.pane.CellEvent",
"cellContextmenu":"qx.ui.table.pane.CellEvent"},
properties:{horizontalScrollBarVisible:{check:"Boolean",
init:true,
apply:"_applyHorizontalScrollBarVisible",
event:"changeHorizontalScrollBarVisible"},
verticalScrollBarVisible:{check:"Boolean",
init:true,
apply:"_applyVerticalScrollBarVisible",
event:"changeVerticalScrollBarVisible"},
tablePaneModel:{check:"qx.ui.table.pane.Model",
apply:"_applyTablePaneModel",
event:"changeTablePaneModel"},
liveResize:{check:"Boolean",
init:false},
focusCellOnMouseMove:{check:"Boolean",
init:false},
selectBeforeFocus:{check:"Boolean",
init:false},
showCellFocusIndicator:{check:"Boolean",
init:true,
apply:"_applyShowCellFocusIndicator"},
scrollTimeout:{check:"Integer",
init:100,
apply:"_applyScrollTimeout"},
appearance:{refine:true,
init:"table-scroller"}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "header":b=this.getTable().getNewTablePaneHeader()(this);
break;
case "pane":b=this.getTable().getNewTablePane()(this);
break;
case "focus-indicator":b=new qx.ui.table.pane.FocusIndicator(this);
b.setUserBounds(0,
0,
0,
0);
b.setZIndex(1000);
b.addListener("mouseup",
this._onMouseupFocusIndicator,
this);
this._paneClipper.add(b);
b.exclude();
break;
case "resize-line":b=new qx.ui.core.Widget();
b.setUserBounds(0,
0,
0,
0);
b.setZIndex(1000);
this._paneClipper.add(b);
break;
case "scrollbar-x":b=new qx.ui.core.ScrollBar("horizontal").set({minWidth:0,
alignY:"bottom"});
b.addListener("scroll",
this._onScrollX,
this);
this._add(b,
{row:2,
column:0});
break;
case "scrollbar-y":b=new qx.ui.core.ScrollBar("vertical").set({alignX:"right"});
b.addListener("scroll",
this._onScrollY,
this);
this._add(b,
{row:1,
column:1});
break;
}return b||arguments.callee.base.call(this,
a);
},
_applyHorizontalScrollBarVisible:function(a,
b){this._horScrollBar.setVisibility(a?"visible":"excluded");
if(!a){this.setScrollY(0,
true);
}},
_applyVerticalScrollBarVisible:function(a,
b){this._verScrollBar.setVisibility(a?"visible":"excluded");
if(!a){this.setScrollX(0);
}},
_applyTablePaneModel:function(a,
b){if(b!=null){b.removeListener("modelChanged",
this._onPaneModelChanged,
this);
}a.addListener("modelChanged",
this._onPaneModelChanged,
this);
},
_applyShowCellFocusIndicator:function(a,
b){if(a){this._updateFocusIndicator();
}else{if(this._focusIndicator){this._focusIndicator.hide();
}}},
getScrollY:function(){return this._verScrollBar.getPosition();
},
setScrollY:function(a,
b){this._ignoreScrollYEvent=b;
this._verScrollBar.scrollTo(a);
if(b){this._updateContent();
}this._ignoreScrollYEvent=false;
},
getScrollX:function(){return this._horScrollBar.getPosition();
},
setScrollX:function(a){this._horScrollBar.scrollTo(a);
},
getTable:function(){return this._table;
},
onColVisibilityChanged:function(){this.updateHorScrollBarMaximum();
this._updateFocusIndicator();
},
setColumnWidth:function(a,
b){this._header.setColumnWidth(a,
b);
this._tablePane.setColumnWidth(a,
b);
var c=this.getTablePaneModel();
var d=c.getX(a);
if(d!=-1){this.updateHorScrollBarMaximum();
this._updateFocusIndicator();
}},
onColOrderChanged:function(){this._header.onColOrderChanged();
this._tablePane.onColOrderChanged();
this.updateHorScrollBarMaximum();
},
onTableModelDataChanged:function(a,
b,
c,
d){this._tablePane.onTableModelDataChanged(a,
b,
c,
d);
var e=this.getTable().getTableModel().getRowCount();
if(e!=this._lastRowCount){this.updateVerScrollBarMaximum();
if(this.getFocusedRow()>=e){if(e==0){this.setFocusedCell(null,
null);
}else{this.setFocusedCell(this.getFocusedColumn(),
e-1);
}}this._lastRowCount=e;
}},
onSelectionChanged:function(){this._tablePane.onSelectionChanged();
},
onFocusChanged:function(){this._tablePane.onFocusChanged();
},
onTableModelMetaDataChanged:function(){this._header.onTableModelMetaDataChanged();
this._tablePane.onTableModelMetaDataChanged();
},
_onPaneModelChanged:function(){this._header.onPaneModelChanged();
this._tablePane.onPaneModelChanged();
},
_onResizePane:function(){this.updateHorScrollBarMaximum();
this.updateVerScrollBarMaximum();
this._updateContent();
this._header._updateContent();
},
updateHorScrollBarMaximum:function(){var a=this._paneClipper.getInnerSize();
if(!a){return ;
}var b=this.getTablePaneModel().getTotalWidth();
var c=this._horScrollBar;
if(a.height<b){var d=Math.max(0,
b-a.width);
c.setMaximum(d);
c.setKnobFactor(a.width/b);
var e=c.getPosition();
c.setPosition(Math.min(e,
d));
}else{c.setMaximum(0);
c.setKnobFactor(1);
c.setPosition(0);
}},
updateVerScrollBarMaximum:function(){var a=this._paneClipper.getInnerSize();
if(!a){return ;
}var b=this.getTable().getTableModel().getRowCount();
if(this.getTable().getKeepFirstVisibleRowComplete()){b+=1;
}var c=this.getTable().getRowHeight();
var d=b*c;
var e=this._verScrollBar;
if(a.height<d){var f=Math.max(0,
d-a.height);
e.setMaximum(f);
e.setKnobFactor(a.height/d);
var g=e.getPosition();
e.setPosition(Math.min(g,
f));
}else{e.setMaximum(0);
e.setKnobFactor(1);
e.setPosition(0);
}},
onKeepFirstVisibleRowCompleteChanged:function(){this.updateVerScrollBarMaximum();
this._updateContent();
},
_onAppear:function(){this._startInterval(this.getScrollTimeout());
},
_onDisappear:function(){this._stopInterval();
},
_onScrollX:function(a){var b=a.getData();
this.fireDataEvent("changeScrollX",
b,
a.getOldData());
this._headerClipper.scrollToX(b);
this._paneClipper.scrollToX(b);
},
_onScrollY:function(a){this.fireDataEvent("changeScrollY",
a.getData(),
a.getOldData());
this._postponedUpdateContent();
},
_onMousewheel:function(a){var b=this.getTable();
if(!b.getEnabled()){return;
}this._verScrollBar.scrollTo(this._verScrollBar.getPosition()+((a.getWheelDelta()*3)*b.getRowHeight()));
if(this._lastMousePageX&&this.getFocusCellOnMouseMove()){this._focusCellAtPagePos(this._lastMousePageX,
this._lastMousePageY);
}},
__gn:function(a){var b=this.getTable();
var c=this._header.getHeaderWidgetAtColumn(this._resizeColumn);
var d=c.getSizeHint().minWidth;
var e=Math.max(d,
this._lastResizeWidth+a-this._lastResizeMousePageX);
if(this.getLiveResize()){var f=b.getTableColumnModel();
f.setColumnWidth(this._resizeColumn,
e);
}else{this._header.setColumnWidth(this._resizeColumn,
e);
var g=this.getTablePaneModel();
this._showResizeLine(g.getColumnLeft(this._resizeColumn)+e);
}this._lastResizeMousePageX+=e-this._lastResizeWidth;
this._lastResizeWidth=e;
},
__go:function(a){var b=qx.ui.table.pane.Scroller.CLICK_TOLERANCE;
if(this._header.isShowingColumnMoveFeedback()||a>this._lastMoveMousePageX+b||a<this._lastMoveMousePageX-b){this._lastMoveColPos+=a-this._lastMoveMousePageX;
this._header.showColumnMoveFeedback(this._moveColumn,
this._lastMoveColPos);
var c=this._table.getTablePaneScrollerAtPageX(a);
if(this._lastMoveTargetScroller&&this._lastMoveTargetScroller!=c){this._lastMoveTargetScroller.hideColumnMoveFeedback();
}
if(c!=null){this._lastMoveTargetX=c.showColumnMoveFeedback(a);
}else{this._lastMoveTargetX=null;
}this._lastMoveTargetScroller=c;
this._lastMoveMousePageX=a;
}},
_onMousemoveHeader:function(a){var b=this.getTable();
if(!b.getEnabled()){return;
}var c=false;
var d=null;
var f=a.getDocumentLeft();
var g=a.getDocumentTop();
this._lastMousePageX=f;
this._lastMousePageY=g;
if(this._resizeColumn!=null){this.__gn(f);
c=true;
}else if(this._moveColumn!=null){this.__go(f);
}else{var h=this._getResizeColumnForPageX(f);
if(h!=-1){c=true;
}else{var i=b.getTableModel();
var j=this._getColumnForPageX(f);
if(j!=null&&i.isColumnSortable(j)){d=j;
}}}var k=c?"ew-resize":null;
this.getApplicationRoot().setGlobalCursor(k);
this.setCursor(k);
this._header.setMouseOverColumn(d);
},
_onMousemovePane:function(a){var b=this.getTable();
if(!b.getEnabled()){return;
}var c=a.getDocumentLeft();
var d=a.getDocumentTop();
this._lastMousePageX=c;
this._lastMousePageY=d;
var f=this._getRowForPagePos(c,
d);
if(f!=null&&this._getColumnForPageX(c)!=null){if(this.getFocusCellOnMouseMove()){this._focusCellAtPagePos(c,
d);
}}this._header.setMouseOverColumn(null);
},
_onMousedownHeader:function(a){if(!this.getTable().getEnabled()){return;
}var b=a.getDocumentLeft();
var c=this._getResizeColumnForPageX(b);
if(c!=-1){this._startResizeHeader(c,
b);
}else{var d=this._getColumnForPageX(b);
if(d!=null){this._startMoveHeader(d,
b);
}}},
_startResizeHeader:function(a,
b){var c=this.getTable().getTableColumnModel();
this._resizeColumn=a;
this._lastResizeMousePageX=b;
this._lastResizeWidth=c.getColumnWidth(this._resizeColumn);
this._headerClipper.capture();
},
_startMoveHeader:function(a,
b){this._moveColumn=a;
this._lastMoveMousePageX=b;
this._lastMoveColPos=this.getTablePaneModel().getColumnLeft(a);
this._headerClipper.capture();
},
_onMousedownPane:function(a){var b=this.getTable();
if(!b.getEnabled()){return;
}
if(this.isEditing()){this.stopEditing();
}var c=a.getDocumentLeft();
var d=a.getDocumentTop();
var f=this._getRowForPagePos(c,
d);
var g=this._getColumnForPageX(c);
if(f!==null&&g!==null){this._lastMouseDownCell={row:f,
col:g};
var h=this.getSelectBeforeFocus();
if(h){b.getSelectionManager().handleMouseDown(f,
a);
}if(!this.getFocusCellOnMouseMove()){this._focusCellAtPagePos(c,
d);
}
if(!h){b.getSelectionManager().handleMouseDown(f,
a);
}}},
_onMouseupFocusIndicator:function(a){if(this._lastMouseDownCell&&this._focusIndicator.getRow()==this._lastMouseDownCell.row&&this._focusIndicator.getColumn()==this._lastMouseDownCell.col){this._lastMouseDownCell={};
this.fireEvent("cellClick",
qx.ui.table.pane.CellEvent,
[this,
a,
this._lastMouseDownCell.row,
this._lastMouseDownCell.col],
true);
}},
_onChangeCaptureHeader:function(a){if(this._resizeColumn!=null&&a.getData()==false){this._stopResizeHeader();
}
if(this._moveColumn!=null&&a.getData()==false){this._stopMoveHeader();
}},
_stopResizeHeader:function(){var a=this.getTable().getTableColumnModel();
if(!this.getLiveResize()){this._hideResizeLine();
a.setColumnWidth(this._resizeColumn,
this._lastResizeWidth);
}this._resizeColumn=null;
this._headerClipper.releaseCapture();
this.getApplicationRoot().setGlobalCursor(null);
this.setCursor(null);
},
_stopMoveHeader:function(){var a=this.getTable().getTableColumnModel();
var b=this.getTablePaneModel();
this._header.hideColumnMoveFeedback();
if(this._lastMoveTargetScroller){this._lastMoveTargetScroller.hideColumnMoveFeedback();
}
if(this._lastMoveTargetX!=null){var c=b.getFirstColumnX()+b.getX(this._moveColumn);
var d=this._lastMoveTargetX;
if(d!=c&&d!=c+1){var e=a.getVisibleColumnAtX(c);
var f=a.getVisibleColumnAtX(d);
var g=a.getOverallX(e);
var h=(f!=null)?a.getOverallX(f):a.getOverallColumnCount();
if(h>g){h--;
}a.moveColumn(g,
h);
}}this._moveColumn=null;
this._lastMoveTargetX=null;
this._headerClipper.releaseCapture();
},
_onMouseupPane:function(a){var b=this.getTable();
if(!b.getEnabled()){return;
}var c=this._getRowForPagePos(a.getDocumentLeft(),
a.getDocumentTop());
if(c!=-1&&c!=null&&this._getColumnForPageX(a.getDocumentLeft())!=null){b.getSelectionManager().handleMouseUp(c,
a);
}},
_onMouseupHeader:function(a){var b=this.getTable();
if(!b.getEnabled()){return;
}
if(this._resizeColumn!=null){this._stopResizeHeader();
this.__ignoreClick=true;
}else if(this._moveColumn!=null){this._stopMoveHeader();
}},
_onClickHeader:function(a){if(this.__ignoreClick){this.__ignoreClick=false;
return;
}var b=this.getTable();
if(!b.getEnabled()){return;
}var c=b.getTableModel();
var d=a.getDocumentLeft();
var f=this._getResizeColumnForPageX(d);
if(f==-1){var g=this._getColumnForPageX(d);
if(g!=null&&c.isColumnSortable(g)){var h=c.getSortColumnIndex();
var i=(g!=h)?true:!c.isSortAscending();
c.sortByColumn(g,
i);
b.getSelectionModel().clearSelection();
}}},
_onClickPane:function(a){var b=this.getTable();
if(!b.getEnabled()){return;
}var c=a.getDocumentLeft();
var d=a.getDocumentTop();
var f=this._getRowForPagePos(c,
d);
var g=this._getColumnForPageX(c);
if(f!=null&&g!=null){b.getSelectionManager().handleClick(f,
a);
if(this._lastMouseDownCell&&f==this._lastMouseDownCell.row&&g==this._lastMouseDownCell.col){this._lastMouseDownCell={};
this.fireEvent("cellClick",
qx.ui.table.pane.CellEvent,
[this,
a,
f,
g],
true);
}}},
_onContextMenu:function(a){var b=a.getDocumentLeft();
var c=a.getDocumentTop();
var d=this._getRowForPagePos(b,
c);
var f=this._getColumnForPageX(b);
if(this._lastMouseDownCell&&d==this._lastMouseDownCell.row&&f==this._lastMouseDownCell.col){this._lastMouseDownCell={};
this.fireEvent("cellContextmenu",
qx.ui.table.pane.CellEvent,
[this,
a,
d,
f],
true);
}},
_onDblclickPane:function(a){var b=a.getDocumentLeft();
var c=a.getDocumentTop();
this._focusCellAtPagePos(b,
c);
this.startEditing();
var d=this._getRowForPagePos(b,
c);
if(d!=-1&&d!=null){this.fireEvent("cellDblclick",
qx.ui.table.pane.CellEvent,
[this,
a,
d],
true);
}},
_onMouseout:function(a){var b=this.getTable();
if(!b.getEnabled()){return;
}if(this._resizeColumn==null){this.setCursor(null);
this.getApplicationRoot().setGlobalCursor(null);
}this._header.setMouseOverColumn(null);
},
_showResizeLine:function(a){var b=this._showChildControl("resize-line");
var c=b.getWidth();
var d=this._paneClipper.getBounds();
b.setUserBounds(a-Math.round(c/2),
0,
c,
d.height);
},
_hideResizeLine:function(){this._excludeChildControl("resize-line");
},
showColumnMoveFeedback:function(a){var b=this.getTablePaneModel();
var c=this.getTable().getTableColumnModel();
var d=this._tablePane.getContainerLocation().left;
var e=this._tablePane.getBounds().width;
var f=b.getColumnCount();
var g=0;
var h=0;
var i=d;
for(var j=0;j<f;j++){var k=b.getColumnAtX(j);
var l=c.getColumnWidth(k);
if(a<i+l/2){break;
}i+=l;
g=j+1;
h=i-d;
}var m=this._paneClipper.getContainerLocation().left;
var n=this._paneClipper.getBounds().width;
var o=m-d;
h=qx.lang.Number.limit(h,
o+2,
o+n-1);
this._showResizeLine(h);
return b.getFirstColumnX()+g;
},
hideColumnMoveFeedback:function(){this._hideResizeLine();
},
_focusCellAtPagePos:function(a,
b){var c=this._getRowForPagePos(a,
b);
if(c!=-1&&c!=null){var d=this._getColumnForPageX(a);
if(d!=null){this._table.setFocusedCell(d,
c);
}}},
setFocusedCell:function(a,
b){if(!this.isEditing()){this._tablePane.setFocusedCell(a,
b,
this._updateContentPlanned);
this._focusedCol=a;
this._focusedRow=b;
this._updateFocusIndicator();
}},
getFocusedColumn:function(){return this._focusedCol;
},
getFocusedRow:function(){return this._focusedRow;
},
scrollCellVisible:function(a,
b){var c=this.getTablePaneModel();
var d=c.getX(a);
if(d!=-1){var e=this._paneClipper.getInnerSize();
if(!e){return;
}var f=this.getTable().getTableColumnModel();
var g=c.getColumnLeft(a);
var h=f.getColumnWidth(a);
var i=this.getTable().getRowHeight();
var j=b*i;
var k=this.getScrollX();
var l=this.getScrollY();
var m=Math.min(g,
g+h-e.width);
var n=g;
this.setScrollX(Math.max(m,
Math.min(n,
k)));
var o=j+i-e.height;
if(this.getTable().getKeepFirstVisibleRowComplete()){o+=i;
}var p=j;
this.setScrollY(Math.max(o,
Math.min(p,
l)),
true);
}},
isEditing:function(){return this._cellEditor!=null;
},
startEditing:function(){var a=this.getTable();
var b=a.getTableModel();
var c=this._focusedCol;
if(!this.isEditing()&&(c!=null)&&b.isColumnEditable(c)){var d=this._focusedRow;
var g=this.getTablePaneModel().getX(c);
var h=b.getValue(c,
d);
this._cellEditorFactory=a.getTableColumnModel().getCellEditorFactory(c);
var i={col:c,
row:d,
xPos:g,
value:h,
table:a};
this._cellEditor=this._cellEditorFactory.createCellEditor(i);
if(this._cellEditor===null){return false;
}else if(this._cellEditor instanceof qx.ui.window.Window){this._cellEditor.setModal(true);
this._cellEditor.setShowClose(false);
this._cellEditor.addListener("close",
this._onCellEditorModalWindowClose,
this);
var j=a.getModalCellEditorPreOpenFunction();
if(j!=null){j(this._cellEditor,
i);
}this._cellEditor.open();
}else{var k=this._focusIndicator.getInnerSize();
this._cellEditor.setUserBounds(0,
0,
k.width,
k.height);
this._focusIndicator.addListener("mousedown",
function(l){l.stopPropagation();
});
this._focusIndicator.add(this._cellEditor);
this._focusIndicator.addState("editing");
this._cellEditor.focus();
}return true;
}return false;
},
stopEditing:function(){this.flushEditor();
this.cancelEditing();
},
flushEditor:function(){if(this.isEditing()){var a=this._cellEditorFactory.getCellEditorValue(this._cellEditor);
this.getTable().getTableModel().setValue(this._focusedCol,
this._focusedRow,
a);
this._table.focus();
}},
cancelEditing:function(){if(this.isEditing()&&!this._cellEditor.pendingDispose){if(this._cellEditorIsModalWindow){this._cellEditor.destroy();
this._cellEditor=null;
this._cellEditorFactory=null;
this._cellEditor.pendingDispose=true;
}else{this._focusIndicator.removeState("editing");
this._cellEditor.destroy();
this._cellEditor=null;
this._cellEditorFactory=null;
}}},
_onCellEditorModalWindowClose:function(a){this.stopEditing();
},
_getColumnForPageX:function(a){var b=this.getTable().getTableColumnModel();
var c=this.getTablePaneModel();
var d=c.getColumnCount();
var e=this._header.getContainerLocation().left;
for(var f=0;f<d;f++){var g=c.getColumnAtX(f);
var h=b.getColumnWidth(g);
e+=h;
if(a<e){return g;
}}return null;
},
_getResizeColumnForPageX:function(a){var b=this.getTable().getTableColumnModel();
var c=this.getTablePaneModel();
var d=c.getColumnCount();
var e=this._header.getContainerLocation().left;
var f=qx.ui.table.pane.Scroller.RESIZE_REGION_RADIUS;
for(var g=0;g<d;g++){var h=c.getColumnAtX(g);
var i=b.getColumnWidth(h);
e+=i;
if(a>=(e-f)&&a<=(e+f)){return h;
}}return -1;
},
_getRowForPagePos:function(a,
b){var c=this._tablePane.getContentLocation();
if(a<c.left||a>c.right){return null;
}
if(b>=c.top&&b<=c.bottom){var d=this.getTable().getRowHeight();
var e=this._verScrollBar.getPosition();
if(this.getTable().getKeepFirstVisibleRowComplete()){e=Math.floor(e/d)*d;
}var f=e+b-c.top;
var g=Math.floor(f/d);
var h=this.getTable().getTableModel().getRowCount();
return (g<h)?g:null;
}var i=this._header.getContainerLocation();
if(b>=i.top&&b<=i.bottom&&a<=i.right){return -1;
}return null;
},
setTopRightWidget:function(a){var b=this._topRightWidget;
if(b!=null){this._remove(b);
}
if(a!=null){this._add(a,
{row:0,
column:1});
}this._topRightWidget=a;
},
getHeader:function(){return this._header;
},
getTablePane:function(){return this._tablePane;
},
getNeededScrollBars:function(a,
b){var c=this._verScrollBar.getSizeHint().width;
var d=this._paneClipper.getInnerSize();
var e=d.width;
if(this.getVerticalScrollBarVisible()){e+=c;
}var f=d.height;
if(this.getHorizontalScrollBarVisible()){f+=c;
}var g=this.getTablePaneModel().getTotalWidth();
var h=this.getTable().getRowHeight()*this.getTable().getTableModel().getRowCount();
var i=false;
var j=false;
if(g>e){i=true;
if(h>f-c){j=true;
}}else if(h>f){j=true;
if(!b&&(g>e-c)){i=true;
}}var k=qx.ui.table.pane.Scroller.HORIZONTAL_SCROLLBAR;
var l=qx.ui.table.pane.Scroller.VERTICAL_SCROLLBAR;
return ((a||i)?k:0)|((b||!j)?0:l);
},
_applyScrollTimeout:function(a,
b){this._startInterval(a);
},
_startInterval:function(a){this._stopInterval();
if(a){this._updateInterval=window.setInterval(this._onintervalWrapper,
a);
}},
_stopInterval:function(){if(this._updateInterval){window.clearInterval(this._updateInterval);
this._updateInterval=null;
}},
_postponedUpdateContent:function(){this._updateContent();
},
_oninterval:function(){if(this._updateContentPlanned&&!this._tablePane._layoutPending){this._updateContentPlanned=false;
this._updateContent();
}},
_updateContent:function(){var a=this._paneClipper.getInnerSize();
if(!a){return;
}var b=a.height;
var c=this._horScrollBar.getPosition();
var d=this._verScrollBar.getPosition();
var e=this.getTable().getRowHeight();
var f=Math.floor(d/e);
var g=this._tablePane.getFirstVisibleRow();
this._tablePane.setFirstVisibleRow(f);
var h=Math.ceil(b/e);
var i=0;
var j=this.getTable().getKeepFirstVisibleRowComplete();
if(!j){h++;
i=d%e;
}this._tablePane.setVisibleRowCount(h);
if(f!=g){this._updateFocusIndicator();
}this._paneClipper.scrollToX(c);
if(!j){this._paneClipper.scrollToY(i);
}},
_updateFocusIndicator:function(){if(!this.getShowCellFocusIndicator()){return;
}var a=this.getTable();
if(!a.getEnabled()){return;
}this._focusIndicator.moveToCell(this._focusedCol,
this._focusedRow);
}},
destruct:function(){this._stopInterval();
var a=this.getTablePaneModel();
if(a){a.dispose();
}this._disposeFields("_lastMouseDownCell");
}});
qx.Class.define("qx.ui.table.cellrenderer.Dynamic",
{extend:qx.ui.table.cellrenderer.Default,
construct:function(a){arguments.callee.base.call(this);
if(a){this.setCellRendererFactoryFunction(a);
}},
properties:{cellRendererFactoryFunction:{check:"Function",
nullable:true,
init:null}},
members:{createDataCellHtml:function(a,
b){var c=this.getCellRendererFactoryFunction();
if(!c){this.error("No function provided! Aborting.");
}var d=c(a);
return d.createDataCellHtml(a,
b);
}}});
qx.Class.define("qx.ui.groupbox.CheckGroupBox",
{extend:qx.ui.groupbox.GroupBox,
properties:{appearance:{refine:true,
init:"check-groupbox"}},
events:{"changeChecked":"qx.event.type.Data",
"changeName":"qx.event.type.Data",
"changeValue":"qx.event.type.Data"},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "legend":b=new qx.ui.form.CheckBox;
b.setChecked(true);
b.addListener("changeChecked",
this._onRadioChangeChecked,
this);
b.addListener("changeName",
this._onRadioChangeName,
this);
b.addListener("changeValue",
this._onRadioChangeValue,
this);
this._add(b);
}return b||arguments.callee.base.call(this,
a);
},
_onRadioChangeChecked:function(a){var b=a.getData();
this.getChildrenContainer().setEnabled(b);
this.fireDataEvent("changeChecked",
b);
},
_onRadioChangeName:function(a){this.fireDataEvent("changeName",
a.getData());
},
_onRadioChangeValue:function(a){this.fireDataEvent("changeValue",
a.getData());
},
getName:function(){return this._getChildControl("legend").getName();
},
setName:function(a){var b=this._getChildControl("legend");
return a?b.setName(a):b.resetName();
},
getValue:function(){return this._getChildControl("legend").getValue();
},
setValue:function(a){var b=this._getChildControl("legend");
return a?b.setValue(a):b.resetValue();
},
getChecked:function(){return this._getChildControl("legend").getChecked();
},
setChecked:function(a){var b=this._getChildControl("legend");
return a?b.setChecked(a):b.resetChecked();
}}});
qx.Class.define("qx.dev.ObjectSummary",
{statics:{getInfo:function(){var c={};
var d=0;
var e;
var f=qx.core.ObjectRegistry.getRegistry();
for(var g in f){e=f[g];
if(e&&e.isDisposed()===false){if(c[e.classname]==null){c[e.classname]=1;
}else{c[e.classname]++;
}d++;
}}var h=[];
for(var j in c){h.push({classname:j,
number:c[j]});
}h.sort(function(k,
l){return l.number-k.number;
});
var m="Summary: ("+d+" Objects)\n\n";
for(var n=0;n<h.length;n++){m+=h[n].number+": "+h[n].classname+"\n";
}return m;
},
getNewObjects:function(){var c={};
var d=0;
var e;
var f=qx.core.ObjectRegistry.getRegistry();
var g={};
var h;
for(var j in f){e=f[j];
if(e&&e.__disposed===false){var k=e.classname;
if(c[k]==null){c[k]=1;
}else{c[k]++;
}h=g[k];
if(h==null){h=g[k]=new Array();
}h[h.length]=e.toHashCode();
d++;
}}
if(!this._m_dObjectList){this._m_dObjectList={};
}var l={};
for(var k in c){if(!(k in this._m_dObjectList)){this._m_dObjectList[k]=0;
}
if(this._m_dObjectList[k]>=0&&this._m_dObjectList[k]<c[k]){l[k]=c[k]-this._m_dObjectList[k];
}}this._m_dObjectList=c;
var m=[];
for(var n in l){m.push({classname:n,
number:l[n],
aHashCode:g[n]});
}m.sort(function(o,
p){return p.number-o.number;
});
var q="Summary: ("+d+" Objects)\r\n\r\n";
for(var r=0;r<m.length;r++){q+=m[r].number+": "+m[r].classname+" ("+m[r].aHashCode.join(", ")+")\r\n";
}return q;
}}});
qx.Class.define("qx.dev.unit.JsUnitTestResult",
{extend:qx.dev.unit.TestResult,
construct:function(){arguments.callee.base.call(this);
this._testFunctionNames=[];
},
members:{run:function(a,
b){var c="$test_"+a.getFullName().replace(/\W/g,
"_");
this._testFunctionNames.push(c);
window[c]=b;
},
exportToJsUnit:function(){var a=this;
window.exposeTestFunctionNames=function(){return a._testFunctionNames;
};
window.isTestPageLoaded=true;
}}});
qx.Class.define("qx.ui.form.TextArea",
{extend:qx.ui.form.AbstractField,
construct:function(a){arguments.callee.base.call(this,
a);
this.initWrap();
},
properties:{wrap:{check:"Boolean",
init:true,
apply:"_applyWrap"},
appearance:{refine:true,
init:"textarea"}},
members:{_createInputElement:function(){var a=new qx.html.Input("textarea");
a.setStyle("overflow",
"hidden");
return a;
},
_applyWrap:function(a,
b){this._contentElement.setWrap(a);
},
_getContentHint:function(){var a=arguments.callee.base.call(this);
a.height=a.height*4;
a.width=this._textSize.width*20;
return a;
}}});
qx.Class.define("qx.ui.table.pane.Model",
{extend:qx.core.Object,
construct:function(a){arguments.callee.base.call(this);
a.addListener("visibilityChangedPre",
this._onColVisibilityChanged,
this);
this._tableColumnModel=a;
},
events:{"modelChanged":"qx.event.type.Event"},
statics:{EVENT_TYPE_MODEL_CHANGED:"modelChanged"},
properties:{firstColumnX:{check:"Integer",
init:0,
apply:"_applyFirstColumnX"},
maxColumnCount:{check:"Number",
init:-1,
apply:"_applyMaxColumnCount"}},
members:{_applyFirstColumnX:function(a,
b){this._columnCount=null;
this.fireEvent(qx.ui.table.pane.Model.EVENT_TYPE_MODEL_CHANGED);
},
_applyMaxColumnCount:function(a,
b){this._columnCount=null;
this.fireEvent(qx.ui.table.pane.Model.EVENT_TYPE_MODEL_CHANGED);
},
setTableColumnModel:function(a){this._tableColumnModel=a;
},
_onColVisibilityChanged:function(a){this._columnCount=null;
this.fireEvent(qx.ui.table.pane.Model.EVENT_TYPE_MODEL_CHANGED);
},
getColumnCount:function(){if(this._columnCount==null){var a=this.getFirstColumnX();
var b=this.getMaxColumnCount();
var c=this._tableColumnModel.getVisibleColumnCount();
if(b==-1||(a+b)>c){this._columnCount=c-a;
}else{this._columnCount=b;
}}return this._columnCount;
},
getColumnAtX:function(a){var b=this.getFirstColumnX();
return this._tableColumnModel.getVisibleColumnAtX(b+a);
},
getX:function(a){var b=this.getFirstColumnX();
var c=this.getMaxColumnCount();
var d=this._tableColumnModel.getVisibleX(a)-b;
if(d>=0&&(c==-1||d<c)){return d;
}else{return -1;
}},
getColumnLeft:function(a){var b=0;
var c=this.getColumnCount();
for(var d=0;d<c;d++){var e=this.getColumnAtX(d);
if(e==a){return b;
}b+=this._tableColumnModel.getColumnWidth(e);
}return -1;
},
getTotalWidth:function(){var a=0;
var b=this.getColumnCount();
for(var c=0;c<b;c++){var d=this.getColumnAtX(c);
a+=this._tableColumnModel.getColumnWidth(d);
}return a;
}},
destruct:function(){this._disposeObjects("_tableColumnModel");
}});
qx.Bootstrap.define("qx.bom.client.Flash",
{statics:{AVAILABLE:false,
FULLVERSION:"0.0.0",
VERSION:0.0,
EXPRESSINSTALL:false,
supportsVersion:function(a){var a=a.split(".");
var b=this.FULLVERSION.split(".");
return (b[0]>a[0]||(b[0]==a[0]&&b[1]>a[1])||(b[0]==a[0]&&b[1]==a[1]&&b[2]>=a[2]))?true:false;
},
__gp:qx.core.Variant.select("qx.client",
{"mshtml":function(){if(window.ActiveXObject){return;
}var a=[0,
0,
0];
var b=false;
try{var c=new ActiveXObject("ShockwaveFlash.ShockwaveFlash.7");
}catch(e){try{var c=new ActiveXObject("ShockwaveFlash.ShockwaveFlash.6");
a=[6,
0,
21];
c.AllowScriptAccess="always";
}catch(e){if(a[0]==6){b=true;
}}
if(!b){try{c=new ActiveXObject("ShockwaveFlash.ShockwaveFlash");
}catch(e){}}}
if(!b&&typeof c=="object"){var d=c.GetVariable("$version");
if(typeof d!="undefined"){d=d.split(" ")[1].split(",");
a[0]=parseInt(d[0],
10);
a[1]=parseInt(d[1],
10);
a[2]=parseInt(d[2],
10);
}}this.__gq(a);
},
"default":function(){if(!navigator.plugins||typeof navigator.plugins["Shockwave Flash"]!=="object"){return;
}var a=[0,
0,
0];
var b=navigator.plugins["Shockwave Flash"].description;
if(typeof b!="undefined"){b=b.replace(/^.*\s+(\S+\s+\S+$)/,
"$1");
a[0]=parseInt(b.replace(/^(.*)\..*$/,
"$1"),
10);
a[1]=parseInt(b.replace(/^.*\.(.*)\s.*$/,
"$1"),
10);
a[2]=/r/.test(b)?parseInt(b.replace(/^.*r(.*)$/,
"$1"),
10):0;
}this.__gq(a);
}}),
__gq:function(a){this.FULLVERSION=a.join(".");
this.VERSION=parseFloat(a);
this.AVAILABLE=this.VERSION>0;
var b=qx.bom.client.Platform;
this.EXPRESSINSTALL=(b.WIN||b.MAC)&&this.supportsVersion("6.0.65");
}},
defer:function(a){a.__gp();
}});
qx.Class.define("qx.ui.menu.CheckBox",
{extend:qx.ui.menu.AbstractButton,
implement:qx.ui.form.IFormElement,
construct:function(a,
b){arguments.callee.base.call(this);
if(a!=null){this.setLabel(a);
}
if(b!=null){this.setMenu(b);
}},
properties:{appearance:{refine:true,
init:"menu-checkbox"},
value:{check:"String",
nullable:true,
event:"changeValue"},
name:{check:"String",
nullable:true,
event:"changeName"},
checked:{check:"Boolean",
init:false,
apply:"_applyChecked",
event:"changeChecked"}},
members:{_applyChecked:function(a,
b){a?this.addState("checked"):this.removeState("checked");
},
_onMouseUp:function(a){if(a.isLeftPressed()){this.toggleChecked();
}},
_onKeyPress:function(a){this.toggleChecked();
}}});
qx.Class.define("qx.dev.unit.TestLoader",
{extend:qx.application.Native,
statics:{getInstance:function(){return this.instance;
}},
properties:{suite:{check:"qx.dev.unit.TestSuite",
nullable:true}},
members:{main:function(){arguments.callee.base.call(this);
this.setTestNamespace(this.__gr());
if(window.top.jsUnitTestSuite){this.runJsUnit();
return;
}
if(window==window.top){this.runStandAlone();
return;
}},
__gr:function(){var a=window.location.search;
var b=a.match(/[\?&]testclass=([A-Za-z0-9_\.]+)/);
if(b){b=b[1];
}else{b="__unknown_class__";
}return b;
},
setTestNamespace:function(a){var b=new qx.dev.unit.TestSuite();
b.add(a);
this.setSuite(b);
},
runJsUnit:function(){var a=new qx.dev.unit.JsUnitTestResult();
this.getSuite().run(a);
a.exportToJsUnit();
},
runStandAlone:function(){this.warn(this.getTestDescriptions());
var a=new qx.dev.unit.TestResult();
a.addListener("failure",
function(b){var c=b.getData().exception;
var d=b.getData().test;
this.error("Test '"+d.getFullName()+"' failed: "+c.getMessage()+" - "+c.getComment());
this.error("Stack trace: "+c.getStackTrace().join("\n"));
});
a.addListener("error",
function(b){var c=b.getData().exception;
this.error("The test '"+b.getData().test.getFullName()+"' had an error: "+c,
c);
});
this.getSuite().run(a);
},
getTestDescriptions:function(){var a=[];
var b=this.getSuite().getTestClasses();
for(var c=0;c<b.length;c++){var d=b[c];
var e={};
e.classname=d.getName();
e.tests=[];
var f=d.getTestMethods();
for(var g=0;g<f.length;g++){e.tests.push(f[g].getName());
}a.push(e);
}return qx.util.Json.stringify(a);
},
runTests:function(a,
b,
c){var d=this.getSuite().getTestClasses();
for(var e=0;e<d.length;e++){if(b==d[e].getName()){var f=d[e].getTestMethods();
for(var g=0;g<f.length;g++){if(c&&f[g].getName()!=c){continue;
}f[g].run(a);
}return;
}}},
runTestsFromNamespace:function(a,
b){var c=this.getSuite().getTestClasses();
for(var d=0;d<c.length;d++){if(c[d].getName().indexOf(b)==0){c[d].run(a);
}}}}});
qx.Class.define("qx.ui.table.celleditor.Dynamic",
{extend:qx.core.Object,
implement:qx.ui.table.ICellEditorFactory,
construct:function(a){arguments.callee.base.call(this);
if(a){this.setCellEditorFactoryFunction(a);
}},
properties:{cellEditorFactoryFunction:{check:"Function",
nullable:true,
init:null}},
members:{createCellEditor:function(a){var b=this.getCellEditorFactoryFunction();
{this.assertFunction(b,
"No function provided! Aborting.");
};
this._cellEditorFactory=b(a);
var c=this._cellEditorFactory.createCellEditor(a);
return c;
},
getCellEditorValue:function(a){var b=this.getCellEditorFactoryFunction();
{this.assertFunction(b,
"No function provided! Aborting.");
};
var c=this._cellEditorFactory.getCellEditorValue(a);
return c;
}}});
qx.Class.define("qx.ui.tree.TreeFolder",
{extend:qx.ui.tree.AbstractTreeItem,
construct:function(a){arguments.callee.base.call(this);
if(a){this.setLabel(a);
}},
properties:{appearance:{refine:true,
init:"tree-folder"}},
members:{_addWidgets:function(){this.addSpacer();
this.addOpenButton();
this.addIcon();
this.addLabel();
}}});
qx.Class.define("qx.bom.Flash",
{statics:{create:function(a,
b,
c,
d){var e={data:a,
width:"100%",
height:"100%"};
var c=c?qx.lang.Object.copy(c):{};
if(b){for(var f in b){if(typeof c.flashvars!="undefined"){c.flashvars+="&"+f+"="+b[f];
}else{c.flashvars=f+"="+b[f];
}}}var g=this.__gt(e,
c,
d);
var h=qx.bom.Element.create("div",
d);
h.appendChild(g);
return h;
},
__gs:function(){window.__flash_unloadHandler=function(){};
window.__flash_savedUnloadHandler=function(){};
window.detachEvent("onbeforeunload",
qx.bom.Flash.__gs);
},
__gt:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b,
c){b.movie=a.data;
delete a.data;
delete a.classid;
var d="";
for(g in b){d+='<param name="'+g+'" value="'+b[g]+'" />';
}var e=qx.bom.Element.create("div",
null,
c);
e.innerHTML='<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000">'+d+'</object>';
var f=e.firstChild;
delete a.classid;
for(var g in a){f.setAttribute(g,
a[g]);
}return f;
},
"default":function(a,
b,
c){var d=qx.bom.Element.create("object",
a,
c);
d.setAttribute("type",
"application/x-shockwave-flash");
delete a.classid;
delete b.movie;
for(var e in a){d.setAttribute(e,
a[e]);
}var f;
for(var e in b){f=document.createElement("param");
f.setAttribute("name",
e);
f.setAttribute("value",
b[e]);
d.appendChild(f);
}return d;
}})},
defer:function(a){if(qx.core.Variant.isSet("qx.client",
"mshtml")){window.attachEvent("onbeforeunload",
a.__gs);
}}});
qx.Class.define("qx.ui.table.pane.Header",
{extend:qx.ui.core.Widget,
construct:function(a){arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.HBox());
this._paneScroller=a;
},
members:{getPaneScroller:function(){return this._paneScroller;
},
getTable:function(){return this._paneScroller.getTable();
},
onColOrderChanged:function(){this._updateContent(true);
},
onPaneModelChanged:function(){this._updateContent(true);
},
onTableModelMetaDataChanged:function(){this._updateContent();
},
setColumnWidth:function(a,
b){var c=this.getHeaderWidgetAtColumn(a);
if(c!=null){c.setWidth(b);
}},
setMouseOverColumn:function(a){if(a!=this._lastMouseOverColumn){if(this._lastMouseOverColumn!=null){var b=this.getHeaderWidgetAtColumn(this._lastMouseOverColumn);
if(b!=null){b.removeState("hovered");
}}
if(a!=null){this.getHeaderWidgetAtColumn(a).addState("hovered");
}this._lastMouseOverColumn=a;
}},
getHeaderWidgetAtColumn:function(a){var b=this.getPaneScroller().getTablePaneModel().getX(a);
return this._getChildren()[b];
},
showColumnMoveFeedback:function(a,
b){var c=this.getContainerLocation();
if(this._moveFeedback==null){var d=this.getPaneScroller().getTablePaneModel().getX(a);
var e=this._getChildren()[d];
var f=this.getTable().getTableModel();
var g=this.getTable().getTableColumnModel();
var h={xPos:d,
col:a,
name:f.getColumnName(a)};
var i=g.getHeaderCellRenderer(a);
var j=i.createHeaderCell(h);
var k=e.getBounds();
j.setWidth(k.width);
j.setHeight(k.height);
j.setZIndex(1000000);
j.setOpacity(0.8);
j.setLayoutProperties({top:c.top});
this.getApplicationRoot().add(j);
this._moveFeedback=j;
}this._moveFeedback.setLayoutProperties({left:c.left+b});
this._moveFeedback.show();
},
hideColumnMoveFeedback:function(){if(this._moveFeedback!=null){this._moveFeedback.getLayoutParent().remove(this._moveFeedback);
this._moveFeedback.dispose();
this._moveFeedback=null;
}},
isShowingColumnMoveFeedback:function(){return this._moveFeedback!=null;
},
_updateContent:function(a){var b=this.getTable().getTableModel();
var c=this.getTable().getTableColumnModel();
var d=this.getPaneScroller().getTablePaneModel();
var e=this._getChildren();
var f=d.getColumnCount();
var g=b.getSortColumnIndex();
if(a){this._cleanUpCells();
}var h={};
h.sortedAscending=b.isSortAscending();
for(var i=0;i<f;i++){var j=d.getColumnAtX(i);
var k=c.getColumnWidth(j);
var l=c.getHeaderCellRenderer(j);
h.xPos=i;
h.col=j;
h.name=b.getColumnName(j);
h.editable=b.isColumnEditable(j);
h.sorted=(j==g);
var m=e[i];
if(m==null){m=l.createHeaderCell(h);
m.set({width:k});
this._add(m);
}else{l.updateHeaderCell(h,
m);
}}},
_cleanUpCells:function(){var a=this._getChildren();
for(var b=a.length-1;b>=0;b--){var c=a[b];
this._remove(c);
c.dispose();
}}},
destruct:function(){this._disposeObjects("_paneScroller");
}});
qx.Class.define("qx.ui.tree.TreeFile",
{extend:qx.ui.tree.AbstractTreeItem,
construct:function(a){arguments.callee.base.call(this);
if(a){this.setLabel(a);
}},
properties:{appearance:{refine:true,
init:"tree-file"}},
members:{_addWidgets:function(){this.addSpacer();
this.addIcon();
this.addLabel();
}}});
qx.Class.define("qx.ui.window.Desktop",
{extend:qx.ui.core.Widget,
include:[qx.ui.core.MChildrenHandling,
qx.ui.window.MDesktop,
qx.ui.core.MBlocker],
implement:qx.ui.window.IDesktop,
construct:function(a){arguments.callee.base.call(this);
this._setLayout(new qx.ui.layout.Canvas());
this.setWindowManager(a);
}});
qx.Class.define("qx.ui.table.Table",
{extend:qx.ui.core.Widget,
construct:function(a,
b){arguments.callee.base.call(this);
if(!b){b={};
}
if(b.selectionManager){this.setNewSelectionManager(b.selectionManager);
}
if(b.selectionModel){this.setNewSelectionModel(b.selectionModel);
}
if(b.tableColumnModel){this.setNewTableColumnModel(b.tableColumnModel);
}
if(b.tablePane){this.setNewTablePane(b.tablePane);
}
if(b.tablePaneHeader){this.setNewTablePaneHeader(b.tablePaneHeader);
}
if(b.tablePaneScroller){this.setNewTablePaneScroller(b.tablePaneScroller);
}
if(b.tablePaneModel){this.setNewTablePaneModel(b.tablePaneModel);
}this._setLayout(new qx.ui.layout.VBox());
this._scrollerParent=new qx.ui.container.Composite(new qx.ui.layout.HBox());
this._statusBar=this._getChildControl("statusbar");
this._add(this._scrollerParent,
{flex:1});
this._add(this._statusBar);
this._columnVisibilityBt=this._getChildControl("column-button");
this.setDataRowRenderer(new qx.ui.table.rowrenderer.Default(this));
this._selectionManager=this.getNewSelectionManager()(this);
this.setSelectionModel(this.getNewSelectionModel()(this));
this.setTableColumnModel(this.getNewTableColumnModel()(this));
if(a!=null){this.setTableModel(a);
}this.setMetaColumnCounts([-1]);
this.setTabIndex(1);
this.addListener("keydown",
this._onkeydown);
this.addListener("keypress",
this._onkeypress);
this.addListener("focus",
this._onFocusChanged);
this.addListener("blur",
this._onFocusChanged);
var c=new qx.ui.core.Widget().set({height:0});
this._add(c);
c.addListener("resize",
this._onResize,
this);
this._focusedCol=null;
this._focusedRow=null;
qx.locale.Manager.getInstance().addListener("changeLocale",
this._onChangeLocale,
this);
},
events:{"columnVisibilityMenuCreateStart":"qx.event.type.DataEvent",
"columnVisibilityMenuCreateEnd":"qx.event.type.DataEvent",
"tableWidthChanged":"qx.event.type.Event",
"verticalScrollBarChanged":"qx.event.type.DataEvent",
"cellClick":"qx.ui.table.pane.CellEvent",
"cellDblclick":"qx.ui.table.pane.CellEvent",
"cellContextmenu":"qx.ui.table.pane.CellEvent"},
statics:{__gu:{cellClick:1,
cellDblclick:1,
cellContextmenu:1}},
properties:{appearance:{refine:true,
init:"table"},
focusable:{refine:true,
init:true},
selectionModel:{check:"qx.ui.table.selection.Model",
apply:"_applySelectionModel",
event:"changeSelectionModel"},
tableModel:{check:"qx.ui.table.ITableModel",
apply:"_applyTableModel",
event:"changeTableModel",
nullable:true},
tableColumnModel:{check:"qx.ui.table.columnmodel.Basic",
apply:"_applyTableColumnModel",
event:"changeTableColumnModel"},
rowHeight:{check:"Number",
init:20,
apply:"_applyRowHeight",
event:"changeRowHeight"},
forceLineHeight:{check:"Boolean",
init:true},
headerCellHeight:{check:"Integer",
init:16,
apply:"_applyHeaderCellHeight",
event:"changeHeaderCellHeight"},
statusBarVisible:{check:"Boolean",
init:true,
apply:"_applyStatusBarVisible"},
additionalStatusBarText:{nullable:true,
init:null,
apply:"_applyAdditionalStatusBarText"},
columnVisibilityButtonVisible:{check:"Boolean",
init:true,
apply:"_applyColumnVisibilityButtonVisible"},
metaColumnCounts:{check:"Object",
apply:"_applyMetaColumnCounts"},
focusCellOnMouseMove:{check:"Boolean",
init:false,
apply:"_applyFocusCellOnMouseMove"},
showCellFocusIndicator:{check:"Boolean",
init:true,
apply:"_applyShowCellFocusIndicator"},
keepFirstVisibleRowComplete:{check:"Boolean",
init:true,
apply:"_applyKeepFirstVisibleRowComplete"},
alwaysUpdateCells:{check:"Boolean",
init:false},
dataRowRenderer:{check:"qx.ui.table.IRowRenderer",
init:null,
nullable:true,
event:"changeDataRowRenderer"},
modalCellEditorPreOpenFunction:{check:"Function",
init:null,
nullable:true},
newSelectionManager:{check:"Function",
init:function(a){return new qx.ui.table.selection.Manager(a);
}},
newSelectionModel:{check:"Function",
init:function(a){return new qx.ui.table.selection.Model(a);
}},
newTableColumnModel:{check:"Function",
init:function(a){return new qx.ui.table.columnmodel.Basic(a);
}},
newTablePane:{check:"Function",
init:function(a){return new qx.ui.table.pane.Pane(a);
}},
newTablePaneHeader:{check:"Function",
init:function(a){return new qx.ui.table.pane.Header(a);
}},
newTablePaneScroller:{check:"Function",
init:function(a){return new qx.ui.table.pane.Scroller(a);
}},
newTablePaneModel:{check:"Function",
init:function(a){return new qx.ui.table.pane.Model(a);
}}},
members:{_createChildControlImpl:function(a){var b;
switch(a){case "statusbar":b=new qx.ui.basic.Label().set({allowGrowX:true});
break;
case "column-button":b=new qx.ui.form.MenuButton().set({focusable:false});
break;
}return b||arguments.callee.base.call(this,
a);
},
_applySelectionModel:function(a,
b){this._selectionManager.setSelectionModel(a);
if(b!=null){b.removeListener("changeSelection",
this._onSelectionChanged,
this);
}a.addListener("changeSelection",
this._onSelectionChanged,
this);
},
_applyRowHeight:function(a,
b){if(!this.getTableModel()){return;
}var c=this._getPaneScrollerArr();
for(var d=0;d<c.length;d++){c[d].updateVerScrollBarMaximum();
}},
_applyHeaderCellHeight:function(a,
b){var c=this._getPaneScrollerArr();
for(var d=0;d<c.length;d++){c[d].getHeader().setHeight(a);
}},
_applyTableModel:function(a,
b){this.getTableColumnModel().init(a.getColumnCount(),
this);
if(b!=null){b.removeListener(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED,
this._onTableModelMetaDataChanged,
this);
b.removeListener(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
this._onTableModelDataChanged,
this);
}a.addListener(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED,
this._onTableModelMetaDataChanged,
this);
a.addListener(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
this._onTableModelDataChanged,
this);
this._updateStatusBar();
this._initColumnMenu();
},
_applyTableColumnModel:function(a,
b){if(b!=null){throw new Error("The table column model can only be set once per table.");
}a.addListener("visibilityChanged",
this._onColVisibilityChanged,
this);
a.addListener("widthChanged",
this._onColWidthChanged,
this);
a.addListener("orderChanged",
this._onColOrderChanged,
this);
var c=this.getTableModel();
if(c){a.init(c.getColumnCount(),
this);
}var d=this._getPaneScrollerArr();
for(var e=0;e<d.length;e++){var f=d[e];
var g=f.getTablePaneModel();
g.setTableColumnModel(a);
}},
_applyStatusBarVisible:function(a,
b){this._statusBar.setVisibility(a?"visible":"excluded");
if(a){this._updateStatusBar();
}},
_applyAdditionalStatusBarText:function(a,
b){this._additionalStatusBarText=a;
if(a){this._updateStatusBar();
}},
_applyColumnVisibilityButtonVisible:function(a,
b){this._columnVisibilityBt.setVisibility(a?"visible":"excluded");
},
_applyMetaColumnCounts:function(a,
b){var c=a;
var d=this._getPaneScrollerArr();
this._cleanUpMetaColumns(c.length);
var e=0;
for(var f=0;f<d.length;f++){var g=d[f];
var h=g.getTablePaneModel();
h.setFirstColumnX(e);
h.setMaxColumnCount(c[f]);
e+=c[f];
}if(c.length>d.length){var j=this.getTableColumnModel();
for(var f=d.length;f<c.length;f++){var h=this.getNewTablePaneModel()(j);
h.setFirstColumnX(e);
h.setMaxColumnCount(c[f]);
e+=c[f];
var g=this.getNewTablePaneScroller()(this);
g.setTablePaneModel(h);
g.addListener("changeScrollY",
this._onScrollY,
this);
this._scrollerParent.add(g);
}}for(var f=0;f<d.length;f++){var g=d[f];
var k=(f==(d.length-1));
g.getHeader().setHeight(this.getHeaderCellHeight());
g.setTopRightWidget(k?this._columnVisibilityBt:null);
}this._updateScrollerWidths();
this._updateScrollBarVisibility();
},
_applyFocusCellOnMouseMove:function(a,
b){var c=this._getPaneScrollerArr();
for(var d=0;d<c.length;d++){c[d].setFocusCellOnMouseMove(a);
}},
_applyShowCellFocusIndicator:function(a,
b){var c=this._getPaneScrollerArr();
for(var d=0;d<c.length;d++){c[d].setShowCellFocusIndicator(a);
}},
_applyKeepFirstVisibleRowComplete:function(a,
b){var c=this._getPaneScrollerArr();
for(var d=0;d<c.length;d++){c[d].onKeepFirstVisibleRowCompleteChanged();
}},
getSelectionManager:function(){return this._selectionManager;
},
_getPaneScrollerArr:function(){return this._scrollerParent.getChildren();
},
getPaneScroller:function(a){return this._getPaneScrollerArr()[a];
},
_cleanUpMetaColumns:function(a){var b=this._getPaneScrollerArr();
if(b!=null){for(var c=b.length-1;c>=a;c--){b[c].dispose();
}}},
_onChangeLocale:function(a){this.updateContent();
this._updateStatusBar();
},
_onSelectionChanged:function(a){var b=this._getPaneScrollerArr();
for(var c=0;c<b.length;c++){b[c].onSelectionChanged();
}this._updateStatusBar();
},
_onTableModelMetaDataChanged:function(a){var b=this._getPaneScrollerArr();
for(var c=0;c<b.length;c++){b[c].onTableModelMetaDataChanged();
}this._updateStatusBar();
},
_onTableModelDataChanged:function(a){var b=this._getPaneScrollerArr();
var c=a.getData();
for(var d=0;d<b.length;d++){b[d].onTableModelDataChanged(c.firstRow,
c.lastRow,
c.firstColumn,
c.lastColumn);
}var e=this.getTableModel().getRowCount();
if(e!=this._lastRowCount){this._lastRowCount=e;
this._updateScrollBarVisibility();
this._updateStatusBar();
}},
_onScrollY:function(a){if(!this._internalChange){this._internalChange=true;
var b=this._getPaneScrollerArr();
for(var c=0;c<b.length;c++){b[c].setScrollY(a.getData());
}this._internalChange=false;
}},
_onkeydown:function(a){if(!this.getEnabled()){return;
}var b=a.getKeyIdentifier();
var c=false;
var d=this._focusedRow;
if(this.isEditing()){if(a.getModifiers()==0){c=true;
switch(b){case "Enter":this.stopEditing();
var d=this._focusedRow;
this.moveFocusedCell(0,
1);
if(this._focusedRow!=d){c=this.startEditing();
}break;
case "Escape":this.cancelEditing();
this.focus();
break;
default:c=false;
break;
}}}else{c=true;
switch(b){case "Home":this.setFocusedCell(this._focusedCol,
0,
true);
break;
case "End":var e=this.getTableModel().getRowCount();
this.setFocusedCell(this._focusedCol,
e-1,
true);
break;
default:c=false;
break;
}if(a.getModifiers()==0){c=true;
switch(b){case "F2":case "Enter":c=this.startEditing();
break;
default:c=false;
break;
}}else if(a.isCtrlPressed()){c=true;
switch(b){case "A":var e=this.getTableModel().getRowCount();
if(e>0){this.getSelectionModel().setSelectionInterval(0,
e-1);
}break;
default:c=false;
break;
}}}
if(d!=this._focusedRow){this._selectionManager.handleMoveKeyDown(this._focusedRow,
a);
}
if(c){a.preventDefault();
a.stopPropagation();
}},
_onkeypress:function(a){if(!this.getEnabled()){return;
}
if(this.isEditing()){return;
}var b=this._focusedRow;
var c=true;
var d=a.getKeyIdentifier();
switch(d){case "Space":this._selectionManager.handleSelectKeyDown(this._focusedRow,
a);
break;
case "Left":this.moveFocusedCell(-1,
0);
break;
case "Right":this.moveFocusedCell(1,
0);
break;
case "Up":this.moveFocusedCell(0,
-1);
break;
case "Down":this.moveFocusedCell(0,
1);
break;
case "PageUp":case "PageDown":var e=this.getPaneScroller(0);
var f=e.getTablePane();
var g=f.getVisibleRowCount()-1;
var h=this.getRowHeight();
var i=(d=="PageUp")?-1:1;
e.setScrollY(e.getScrollY()+i*g*h);
this.moveFocusedCell(0,
i*g);
break;
default:c=false;
}
if(b!=this._focusedRow){this._selectionManager.handleMoveKeyDown(this._focusedRow,
a);
}
if(c){a.preventDefault();
a.stopPropagation();
}},
_onFocusChanged:function(a){var b=this._getPaneScrollerArr();
for(var c=0;c<b.length;c++){b[c].onFocusChanged();
}},
_onColVisibilityChanged:function(a){var b=this._getPaneScrollerArr();
for(var c=0;c<b.length;c++){b[c].onColVisibilityChanged();
}this._updateScrollerWidths();
this._updateScrollBarVisibility();
},
_onColWidthChanged:function(a){var b=this._getPaneScrollerArr();
for(var c=0;c<b.length;c++){var d=a.getData();
b[c].setColumnWidth(d.col,
d.newWidth);
}this._updateScrollerWidths();
this._updateScrollBarVisibility();
},
_onColOrderChanged:function(a){var b=this._getPaneScrollerArr();
for(var c=0;c<b.length;c++){b[c].onColOrderChanged();
}this._updateScrollerWidths();
this._updateScrollBarVisibility();
},
getTablePaneScrollerAtPageX:function(a){var b=this._getMetaColumnAtPageX(a);
return (b!=-1)?this.getPaneScroller(b):null;
},
setFocusedCell:function(a,
b,
c){if(!this.isEditing()&&(a!=this._focusedCol||b!=this._focusedRow)){this._focusedCol=a;
this._focusedRow=b;
var d=this._getPaneScrollerArr();
for(var e=0;e<d.length;e++){d[e].setFocusedCell(a,
b);
}
if(c){this.scrollCellVisible(a,
b);
}}},
getFocusedColumn:function(){return this._focusedCol;
},
getFocusedRow:function(){return this._focusedRow;
},
moveFocusedCell:function(a,
b){var c=this._focusedCol;
var d=this._focusedRow;
if(c===null||d===null){return;
}
if(a!=0){var e=this.getTableColumnModel();
var f=e.getVisibleX(c);
var g=e.getVisibleColumnCount();
f=qx.lang.Number.limit(f+a,
0,
g-1);
c=e.getVisibleColumnAtX(f);
}
if(b!=0){var h=this.getTableModel();
d=qx.lang.Number.limit(d+b,
0,
h.getRowCount()-1);
}this.setFocusedCell(c,
d,
true);
},
scrollCellVisible:function(a,
b){var c=this.getTableColumnModel();
var d=c.getVisibleX(a);
var e=this._getMetaColumnAtColumnX(d);
if(e!=-1){this.getPaneScroller(e).scrollCellVisible(a,
b);
}},
isEditing:function(){if(this._focusedCol!=null){var a=this.getTableColumnModel().getVisibleX(this._focusedCol);
var b=this._getMetaColumnAtColumnX(a);
return this.getPaneScroller(b).isEditing();
}return false;
},
startEditing:function(){if(this._focusedCol!=null){var a=this.getTableColumnModel().getVisibleX(this._focusedCol);
var b=this._getMetaColumnAtColumnX(a);
return this.getPaneScroller(b).startEditing();
}return false;
},
stopEditing:function(){if(this._focusedCol!=null){var a=this.getTableColumnModel().getVisibleX(this._focusedCol);
var b=this._getMetaColumnAtColumnX(a);
this.getPaneScroller(b).stopEditing();
}},
cancelEditing:function(){if(this._focusedCol!=null){var a=this.getTableColumnModel().getVisibleX(this._focusedCol);
var b=this._getMetaColumnAtColumnX(a);
this.getPaneScroller(b).cancelEditing();
}},
updateContent:function(){var a=this._getPaneScrollerArr();
for(var b=0;b<a.length;b++){a[b]._tablePane._updateContent();
}},
_getMetaColumnAtPageX:function(a){var b=this._getPaneScrollerArr();
for(var c=0;c<b.length;c++){var d=b[c].getContainerLocation();
if(a>=d.left&&a<=d.right){return c;
}}return -1;
},
_getMetaColumnAtColumnX:function(a){var b=this.getMetaColumnCounts();
var c=0;
for(var d=0;d<b.length;d++){var e=b[d];
c+=e;
if(e==-1||a<c){return d;
}}return -1;
},
_updateStatusBar:function(){if(this.getStatusBarVisible()){var a=this.getSelectionModel().getSelectedCount();
var b=this.getTableModel().getRowCount();
var c;
if(b>0){if(a==0){c=this.trn("one row",
"%1 rows",
b,
b);
}else{c=this.trn("one of one row",
"%1 of %2 rows",
b,
a,
b);
}}
if(this._additionalStatusBarText){if(c){c+=this._additionalStatusBarText;
}else{c=this._additionalStatusBarText;
}}
if(c){this._statusBar.setContent(c);
}}},
_updateScrollerWidths:function(){var a=this._getPaneScrollerArr();
for(var b=0;b<a.length;b++){var c=(b==(a.length-1));
var d=a[b].getTablePaneModel().getTotalWidth();
a[b].setWidth(d);
var e=c?1:0;
a[b].setLayoutProperties({flex:e});
}},
_updateScrollBarVisibility:function(){if(!this.getBounds()){return;
}var a=qx.ui.table.pane.Scroller.HORIZONTAL_SCROLLBAR;
var b=qx.ui.table.pane.Scroller.VERTICAL_SCROLLBAR;
var c=this._getPaneScrollerArr();
var d=false;
var e=false;
for(var f=0;f<c.length;f++){var g=(f==(c.length-1));
var h=c[f].getNeededScrollBars(d,
!g);
if(h&a){d=true;
}
if(g&&(h&b)){e=true;
}}for(var f=0;f<c.length;f++){var g=(f==(c.length-1));
var j;
c[f].setHorizontalScrollBarVisible(d);
if(g){j=c[f].getVerticalScrollBarVisible();
}c[f].setVerticalScrollBarVisible(g&&e);
if(g&&e!=j){this.fireDataEvent("verticalScrollBarChanged",
e);
}}},
_initColumnMenu:function(){var a=this.getTableModel();
var b=this.getTableColumnModel();
var c=this._columnVisibilityBt.getMenu();
if(c){var d=c.getChildren();
for(var e=0,
f=d.length;e<f;e++){d[e].destroy();
}}else{var c=new qx.ui.menu.Menu();
this._columnVisibilityBt.setMenu(c);
}var g={table:this,
menu:c};
this.fireDataEvent("columnVisibilityMenuCreateStart",
g);
for(var h=0,
f=a.getColumnCount();h<f;h++){var j=new qx.ui.menu.CheckBox(a.getColumnName(h));
j.setChecked(b.isColumnVisible(h));
j.addListener("changeChecked",
this._createColumnVisibilityCheckBoxHandler(h),
this);
c.add(j);
}var g={table:this,
menu:c};
this.fireDataEvent("columnVisibilityMenuCreateEnd",
g);
},
_createColumnVisibilityCheckBoxHandler:function(a){return function(b){var c=this.getTableColumnModel();
c.setColumnVisible(a,
b.getData());
};
},
setColumnWidth:function(a,
b){this.getTableColumnModel().setColumnWidth(a,
b);
},
_onResize:function(){this.fireEvent("tableWidthChanged");
this._updateScrollerWidths();
this._updateScrollBarVisibility();
},
addListener:function(a,
b,
c,
d){if(arguments.callee.self.__gu[a]){for(var e=0,
f=this._getPaneScrollerArr();e<f.length;e++){f[e].addListener.apply(f[e],
arguments);
}}else{arguments.callee.base.call(this,
a,
b,
c,
d);
}},
removeListener:function(a,
b,
c,
d){if(arguments.callee.self.__gu[a]){for(var e=0,
f=this._getPaneScrollerArr();e<f.length;e++){f[e].removeListener.apply(f[e],
arguments);
}}else{arguments.callee.base.call(this,
a,
b,
c,
d);
}}},
destruct:function(){qx.locale.Manager.getInstance().removeListener("changeLocale",
this._onChangeLocale,
this);
var a=this.getSelectionModel();
if(a){a.dispose();
}var b=this.getDataRowRenderer();
if(b){b.dispose();
}this._cleanUpMetaColumns(0);
this._disposeObjects("_selectionManager",
"_columnVisibilityMenu",
"_tableModel",
"_columnVisibilityBt",
"_scrollerParent",
"_statusBar");
}});
qx.Class.define("qx.ui.table.rowrenderer.Default",
{extend:qx.core.Object,
implement:qx.ui.table.IRowRenderer,
construct:function(a){arguments.callee.base.call(this);
this._fontStyleString="";
this._fontStyleString={};
this._colors={};
this._table=a;
this._renderFont(qx.theme.manager.Font.getInstance().resolve("default"));
var b=qx.theme.manager.Color.getInstance();
this._colors.bgcolFocusedSelected=b.resolve("table-row-background-focused-selected");
this._colors.bgcolFocused=b.resolve("table-row-background-focused");
this._colors.bgcolSelected=b.resolve("table-row-background-selected");
this._colors.bgcolEven=b.resolve("table-row-background-even");
this._colors.bgcolOdd=b.resolve("table-row-background-odd");
this._colors.colSelected=b.resolve("table-row-selected");
this._colors.colNormal=b.resolve("table-row");
},
properties:{highlightFocusRow:{check:"Boolean",
init:true}},
members:{_renderFont:function(a){if(a){this._fontStyle=a.getStyles();
this._fontStyleString=qx.bom.element.Style.compile(this._fontStyle);
this._fontStyleString=this._fontStyleString.replace(/"/g,
"'");
}else{this._fontStyleString="";
this._fontStyle=qx.bom.Font.getDefaultStyles();
}this._postponedUpdateTableContent();
},
updateDataRowElement:function(a,
b){var c=this._fontStyle;
var d=b.style;
qx.bom.element.Style.setStyles(b,
c);
if(a.focusedRow&&this.getHighlightFocusRow()){d.backgroundColor=a.selected?this._colors.bgcolFocusedSelected:this._colors.bgcolFocused;
}else{if(a.selected){d.backgroundColor=this._colors.bgcolSelected;
}else{d.backgroundColor=(a.row%2==0)?this._colors.bgcolEven:this._colors.bgcolOdd;
}}d.color=a.selected?this._colors.colSelected:this._colors.colNormal;
},
createRowStyle:function(a){var b=[];
b.push(";");
b.push(this._fontStyleString);
b.push("background-color:");
if(a.focusedRow&&this.getHighlightFocusRow()){b.push(a.selected?this._colors.bgcolFocusedSelected:this._colors.bgcolFocused);
}else{if(a.selected){b.push(this._colors.bgcolSelected);
}else{b.push((a.row%2==0)?this._colors.bgcolEven:this._colors.bgcolOdd);
}}b.push(';color:');
b.push(a.selected?this._colors.colSelected:this._colors.colNormal);
return b.join("");
},
getRowClass:function(a){return "";
},
_postponedUpdateTableContent:function(){if(!this._updateContentPlanned){qx.event.Timer.once(function(){if(this.isDisposed()){return;
}this._updateTableContent();
this._updateContentPlanned=false;
},
this,
0);
this._updateContentPlanned=true;
}},
_updateTableContent:function(){if(this._table){this._table.updateContent();
}}},
destruct:function(){this._disposeFields("_colors",
"_fontStyle",
"__font",
"_table");
}});
qx.Class.define("qx.dev.Tokenizer",
{extend:qx.core.Object,
statics:{tokenizeJavaScript:function(b){var c={"break":1,
"case":1,
"catch":1,
"continue":1,
"default":1,
"delete":1,
"do":1,
"else":1,
"finally":1,
"for":1,
"function":1,
"if":1,
"in":1,
"instanceof":1,
"new":1,
"return":1,
"switch":1,
"throw":1,
"try":1,
"typeof":1,
"var":1,
"while":1,
"with":1};
var d={"void":1,
"null":1,
"true":1,
"false":1,
"NaN":1,
"Infinity":1,
"this":1};
var e={"statics":1,
"members":1,
"construct":1,
"destruct":1,
"events":1,
"properties":1,
"extend":1,
"implement":1};
var f=/^\/\/.*[\n\r$]$/;
var g=/^\/\*(?:.|[\n\r])*?\*\/$/;
var h=/^[a-zA-Z_][a-zA-Z0-9_]*\b$/;
var j=/^[+-]?\d+$/;
var k=/^[+-]?\d+(([.]\d+)*([eE][+-]?\d+))?$/;
var l=/^["][^"]*["]$/;
var m=/^['][^']*[']$/;
var n=/^\t$/;
var o=/^\r\n|\r|\n$/;
var p=/^\s$/;
var q=/^\/(?:\\.|[^\/])+\/[gimy]*$/;
var r=/\/\/.*?[\n\r$]|\/\*(?:.|\n|\r)*?\*\/|\/(?:\\.|[^\/])+\/[gimy]*|\w+\b|[+-]?\d+(([.]\d+)*([eE][+-]?\d+))?|["][^"]*["]|['][^']*[']|\n|\r|./g;
var s=[];
var t=b.match(r);
for(var u=0;u<t.length;u++){var v=t[u];
if(v.match(f)){s.push({type:"linecomment",
value:v});
}else if(v.match(g)){s.push({type:"fullcomment",
value:v});
}else if(v.match(q)){s.push({type:"regexp",
value:v});
}else if(v.match(m)){s.push({type:"qstr",
value:v});
}else if(v.match(l)){s.push({type:"qqstr",
value:v});
}else if(c[v]){s.push({type:"keyword",
value:v});
}else if(d[v]){s.push({type:"atom",
value:v});
}else if(e[v]){s.push({type:"qxkey",
value:v});
}else if(v.match(h)){s.push({type:"ident",
value:v});
}else if(v.match(k)){s.push({type:"real",
value:v});
}else if(v.match(j)){s.push({type:"int",
value:v});
}else if(v.match(o)){s.push({type:"nl",
value:v});
}else if(v.match(p)){s.push({type:"ws",
value:v});
}else if(v.match(n)){s.push({type:"tab",
value:v});
}else if(v==">"){s.push({type:"sym",
value:">"});
}else if(v=="<"){s.push({type:"sym",
value:"<"});
}else if(v=="&"){s.push({type:"sym",
value:"&"});
}else{s.push({type:"sym",
value:v});
}}return s;
},
javaScriptToHtml:function(a){var b=qx.dev.Tokenizer.tokenizeJavaScript(a);
var c=new qx.util.StringBuilder();
for(var d=0;d<b.length;d++){var e=b[d];
var f=qx.bom.String.escape(e.value);
switch(e.type){case "regexp":c.add("<span class='regexp'>",
f,
"</span>");
break;
case "ident":c.add("<span class='ident'>",
f,
"</span>");
break;
case "linecomment":case "fullcomment":c.add("<span class='comment'>",
f,
"</span>");
break;
case "qstr":case "qqstr":c.add("<span class='string'>",
f,
"</span>");
break;
case "keyword":case "atom":case "qxkey":c.add("<span class='",
e.type,
"'>",
f,
"</span>");
break;
case "nl":c.add("\n");
break;
default:c.add(f);
}}return c.get();
}}});
qx.Class.define("qx.util.Base64",
{statics:{__gv:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
encode:function(a){var b=this.__gv;
var c="";
var d,
e,
f;
var g,
h,
j,
k;
var l=0;
do{d=a.charCodeAt(l++);
e=a.charCodeAt(l++);
f=a.charCodeAt(l++);
g=d>>2;
h=((d&3)<<4)|(e>>4);
j=((e&15)<<2)|(f>>6);
k=f&63;
if(isNaN(e)){j=k=64;
}else if(isNaN(f)){k=64;
}c+=b.charAt(g)+b.charAt(h)+b.charAt(j)+b.charAt(k);
}while(l<a.length);
return c;
}}});
qx.Class.define("qx.event.handler.DomReady",
{extend:qx.core.Object,
implement:qx.event.IEventHandler,
construct:function(a){arguments.callee.base.call(this);
this._window=a.getWindow();
this._initWindowObserver();
},
statics:{PRIORITY:qx.event.Registration.PRIORITY_NORMAL,
SUPPORTED_TYPES:{domready:true},
TARGET_CHECK:qx.event.IEventHandler.TARGET_WINDOW,
IGNORE_CAN_HANDLE:true},
members:{canHandleEvent:function(a,
b){},
registerEvent:function(a,
b,
c){},
unregisterEvent:function(a,
b,
c){},
_initWindowObserver:function(){var a=this._window;
var b=this._onNativeWrapper=qx.lang.Function.listener(this._onNative,
this);
if(qx.core.Variant.isSet("qx.client",
"gecko|opera")){qx.bom.Event.addNativeListener(a,
"DOMContentLoaded",
b);
}else if(qx.core.Variant.isSet("qx.client",
"webkit|mshtml")){var c=function(){try{if(qx.bom.client.Engine.MSHTML||document.readyState!="loaded"&&document.readyState!="complete"){document.documentElement.doScroll("left");
}b();
}catch(error){setTimeout(c,
100);
}};
c();
}qx.bom.Event.addNativeListener(this._window,
"load",
b);
},
_stopWindowObserver:function(){var a=this._window;
if(qx.core.Variant.isSet("qx.client",
"gecko|opera")){qx.bom.Event.removeNativeListener(a,
"DOMContentLoaded",
this._onNativeWrapper);
}qx.bom.Event.removeNativeListener(this._window,
"load",
this._onNativeWrapper);
},
_onNative:function(){if(!this._fired){qx.event.Registration.fireEvent(this._window,
"domready");
this._fired=true;
}}},
destruct:function(){this._stopWindowObserver();
this._disposeFields("_window");
},
defer:function(a){qx.event.Registration.addHandler(a);
}});
qx.Bootstrap.define("qx.log.appender.Native",
{statics:{process:qx.core.Variant.select("qx.client",
{"gecko":function(a){if(window.console&&console.firebug){console[a.level].apply(console,
this.__gw(a));
}},
"webkit":function(a){var b=a.level;
if(b=="debug"){b="log";
}var c=this.__gw(a).join(" ");
if(window.console&&console[b]){console[b](c);
}},
"opera":function(a){},
"default":function(a){}}),
__gw:qx.core.Variant.select("qx.client",
{"gecko|webkit":function(a){var b=[];
b.push(a.offset+"ms");
if(a.object){var c=qx.core.ObjectRegistry.fromHashCode(a.object);
if(c){b.push(c.classname+"["+c.$$hash+"]:");
}}else if(a.clazz){b.push(a.clazz.classname+":");
}var d=a.items;
var e,
f;
for(var g=0,
h=d.length;g<h;g++){e=d[g];
f=e.text;
if(f instanceof Array){var k=[];
for(var l=0,
m=f.length;l<m;l++){k.push(f[l].text);
}
if(e.type==="map"){b.push("{",
k.join(", "),
"}");
}else{b.push("[",
k.join(", "),
"]");
}}else{b.push(f);
}}return b;
},
"default":null})},
defer:function(a){qx.log.Logger.register(a);
}});
qx.Class.define("qx.ui.table.celleditor.PasswordField",
{extend:qx.core.Object,
implement:qx.ui.table.ICellEditorFactory,
construct:function(){arguments.callee.base.call(this);
},
properties:{validationFunction:{check:"Function",
nullable:true,
init:null}},
members:{createCellEditor:function(a){var b=new qx.ui.form.PasswordField();
b.setAppearance("table-editor-textfield");
b.originalValue=a.value;
if(a.value===null){a.value="";
}b.setValue(""+a.value);
b.addListener("appear",
function(){b.selectAll();
});
return b;
},
getCellEditorValue:function(a){var b=a.getValue();
var c=this.getValidationFunction();
if(!this._done&&c){b=c(b,
a.originalValue);
this._done=true;
}
if(typeof a.originalValue=="number"){b=parseFloat(b);
}return b;
}}});
qx.Class.define("qx.ui.form.PasswordField",
{extend:qx.ui.form.TextField,
members:{_createInputElement:function(){return new qx.html.Input("password");
}}});
qx.Class.define("qx.xml.Element",
{statics:{serialize:function(a){if(qx.dom.Node.isDocument(a)){a=a.documentElement;
}
if(window.XMLSerializer){return (new XMLSerializer()).serializeToString(a);
}else{return a.xml||a.outerHTML;
}},
selectSingleNode:qx.core.Variant.select("qx.client",
{"mshtml|opera":function(a,
b){return a.selectSingleNode(b);
},
"default":function(a,
b){if(!this.__xpe){this.__xpe=new XPathEvaluator();
}var c=this.__xpe;
try{return c.evaluate(b,
a,
c.createNSResolver(a),
XPathResult.FIRST_ORDERED_NODE_TYPE,
null).singleNodeValue;
}catch(err){throw new Error("selectSingleNode: query: "+b+", element: "+a+", error: "+err);
}}}),
selectNodes:qx.core.Variant.select("qx.client",
{"mshtml|opera":function(a,
b){return a.selectNodes(b);
},
"default":function(a,
b){var c=this.__xpe;
if(!c){this.__xpe=c=new XPathEvaluator();
}
try{var d=c.evaluate(b,
a,
c.createNSResolver(a),
XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
null);
}catch(err){throw new Error("selectNodes: query: "+b+", element: "+a+", error: "+err);
}var e=[];
for(var f=0;f<d.snapshotLength;f++){e[f]=d.snapshotItem(f);
}return e;
}}),
getElementsByTagNameNS:qx.core.Variant.select("qx.client",
{"mshtml":function(a,
b,
c){var d=a.ownerDocument||a;
d.setProperty("SelectionLanguage",
"XPath");
d.setProperty("SelectionNamespaces",
"xmlns:ns='"+b+"'");
return qx.xml.Element.selectNodes(a,
'descendant-or-self::ns:'+c);
},
"default":function(a,
b,
c){return a.getElementsByTagNameNS(b,
c);
}}),
getSingleNodeText:function(a,
b){var c=this.selectSingleNode(a,
b);
return qx.dom.Node.getText(c);
}}});
qx.Class.define("qx.dom.Element",
{statics:{hasChild:function(a,
b){return b.parentNode===a;
},
hasChildren:function(a){return !!a.firstChild;
},
hasChildElements:function(a){a=a.firstChild;
while(a){if(a.nodeType===1){return true;
}a=a.nextSibling;
}return false;
},
insertAt:function(a,
b,
c){var d=b.childNodes[c];
if(d){b.insertBefore(a,
d);
}else{b.appendChild(a);
}return true;
},
insertBegin:function(a,
b){if(b.firstChild){this.insertBefore(a,
b.firstChild);
}else{b.appendChild(a);
}},
insertEnd:function(a,
b){b.appendChild(a);
},
insertBefore:function(a,
b){b.parentNode.insertBefore(a,
b);
return true;
},
insertAfter:function(a,
b){var c=b.parentNode;
if(b==c.lastChild){c.appendChild(a);
}else{return this.insertBefore(a,
b.nextSibling);
}return true;
},
remove:function(a){if(!a.parentNode){return false;
}a.parentNode.removeChild(a);
return true;
},
removeChild:function(a,
b){if(a.parentNode!==b){return false;
}b.removeChild(a);
return true;
},
removeChildAt:function(a,
b){var c=b.childNodes[a];
if(!c){return false;
}b.removeChild(c);
return true;
},
replaceChild:function(a,
b){if(!b.parentNode){return false;
}b.parentNode.replaceChild(a,
b);
return true;
},
replaceAt:function(a,
b,
c){var d=c.childNodes[b];
if(!d){return false;
}c.replaceChild(a,
d);
return true;
}}});
qx.Bootstrap.define("qx.io2.JsonpRequest",
{statics:{}});
qx.Class.define("qx.ui.table.cellrenderer.Password",
{extend:qx.ui.table.cellrenderer.Default,
members:{_getContentHtml:function(a){var b=a.value;
if(b===null){b="";
}a.value=b.replace(/./g,
"*");
return qx.bom.String.escape(this._formatValue(a));
}}});
qx.Class.define("qx.io2.HttpRequest",
{extend:qx.core.Object,
construct:function(a){arguments.callee.base.call(this);
this.__headers={};
if(a!=null){this.setUrl(a);
}},
statics:{__gx:{}},
events:{"change":"qx.event.type.Data",
"timeout":"qx.event.type.Event",
"load":"qx.event.type.Event",
"error":"qx.event.type.Event",
"abort":"qx.event.type.Event"},
properties:{refresh:{check:"Boolean",
init:false},
data:{nullable:true},
method:{check:["GET",
"POST",
"PUT",
"HEAD",
"DELETE",
"OPTIONS"],
init:"GET"},
async:{check:"Boolean",
init:true},
mime:{check:["text/plain",
"text/javascript",
"application/json",
"application/xml",
"text/html"],
init:"text/plain"},
url:{check:"String",
init:""},
username:{check:"String",
nullable:true},
password:{check:"String",
nullable:true},
auth:{check:["http",
"basic"],
init:"http"},
timeout:{check:"Integer",
nullable:true},
cache:{check:"Boolean",
init:false}},
members:{setRequestHeader:function(a,
b){this.__headers[a]=b;
},
removeRequestHeader:function(a){delete this.__headers[a];
},
getRequestHeader:function(a){var b=this.__headers[a];
if(b===undefined){b=null;
}return b;
},
getResponseText:function(){var a=this.__req;
if(a){return a.responseText;
}},
getResponseXml:function(){var a=this.__req;
if(a){return a.responseXML;
}},
getResponseHeader:function(a){var b=this.__req;
if(b){return b.getResponseHeader(a);
}},
getAllResponseHeaders:function(){var a=this.__req;
if(a){return a.getAllResponseHeaders();
}},
isNotModified:function(){var a=this.__req;
if(!a){return false;
}var b=a.getResponseHeader("Last-Modified");
return a.status===304||qx.io2.HttpRequest.__gx[this.getUrl()]===b;
},
isSuccessful:function(){var a=this.__req;
return !a||a.isSuccessful();
},
getStatusCode:function(){var a=this.__req;
if(a){return a.status;
}},
getStatusText:function(){var a=this.__req;
if(a){return a.statusText;
}},
getReadyState:function(){var a=this.__req;
if(a){return a.readyState;
}},
send:function(){if(this.__req){if(this.getReadyState()!==4){throw new Error("Request is still pending at ready state: "+this.getReadyState());
}this.__req.dispose();
}var a=this.__req=new qx.bom.Request;
a.onreadystatechange=qx.lang.Function.bind(this.__gy,
this);
a.ontimeout=qx.lang.Function.bind(this.__gz,
this);
a.onload=qx.lang.Function.bind(this.__gA,
this);
a.onerror=qx.lang.Function.bind(this.__gB,
this);
a.onabort=qx.lang.Function.bind(this.__gC,
this);
var b=this.getUsername();
var c=this.getPassword();
if(this.getAuth()=="basic"){a.setRequestHeader('Authorization',
'Basic '+qx.util.Base64.encode(b+':'+c));
b=c=null;
}var d=this.getUrl();
a.open(this.getMethod(),
d,
this.getAsync(),
b,
c);
a.timeout=this.getTimeout();
if(!this.getCache()){a.setRequestHeader("Cache-Control",
"no-cache");
}if(this.getRefresh()){a.setRequestHeader("If-Modified-Since",
qx.io2.HttpRequest.__gx[d]||"Thu, 01 Jan 1970 00:00:00 GMT");
}a.setRequestHeader("X-Requested-With",
"XMLHttpRequest");
if(this.getMethod()==="POST"){a.setRequestHeader("Content-Type",
"application/x-www-form-urlencoded");
}a.setRequestHeader("Accept",
this.getMime());
var e=this.__headers;
for(var f in e){a.setRequestHeader(f,
e[f]);
}a.send(this.getData());
},
abort:function(){if(this.__req){this.__req.abort();
}},
__gy:function(){this.fireDataEvent("change",
this.getReadyState());
if(this.getRefresh()&&this.getReadyState()===4&&this.isSuccessful()){var a=this.getResponseHeader("Last-Modified");
if(a){qx.io2.HttpRequest.__gx[this.getUrl()]=a;
}}},
__gz:function(){if(this.hasListener("timeout")){this.fireEvent("timeout");
}},
__gA:function(){if(this.hasListener("load")){this.fireEvent("load");
}},
__gB:function(){if(this.hasListener("error")){this.fireEvent("error");
}},
__gC:function(){if(this.hasListener("abort")){this.fireEvent("abort");
}}},
destruct:function(){this._disposeObjects("_req");
this._disposeFields("__headers");
}});
qx.Class.define("qx.ui.embed.HtmlEmbed",
{extend:qx.ui.core.Widget,
include:[qx.ui.core.MNativeOverflow],
construct:function(a){arguments.callee.base.call(this);
if(a!=null){this.setHtml(a);
}},
properties:{html:{check:"String",
apply:"_applyHtml",
event:"changeHtml",
nullable:true},
cssClass:{check:"String",
init:"",
apply:"_applyCssClass"},
font:{refine:true,
init:null},
textColor:{refine:true,
init:null},
selectable:{refine:true,
init:true}},
members:{_applyHtml:function(a,
b){var c=this.getContentElement();
c.setAttribute("html",
a||"");
c.setStyle("padding",
"0px");
c.setStyle("border",
"none");
},
_applyCssClass:function(a,
b){this.getContentElement().setAttribute("class",
a);
},
_applyFont:function(a,
b){var c=a?qx.theme.manager.Font.getInstance().resolve(a).getStyles():qx.bom.Font.getDefaultStyles();
this._contentElement.setStyles(c);
},
_applyTextColor:function(a,
b){if(a){this.getContentElement().setStyle("color",
qx.theme.manager.Color.getInstance().resolve(a));
}else{this.getContentElement().removeStyle("color");
}}}});
qx.Class.define("qx.ui.table.celleditor.CheckBox",
{extend:qx.core.Object,
implement:qx.ui.table.ICellEditorFactory,
construct:function(){arguments.callee.base.call(this);
},
members:{createCellEditor:function(a){var b=new qx.ui.container.Composite(new qx.ui.layout.HBox().set({alignX:"center",
alignY:"middle"})).set({focusable:true});
var c=new qx.ui.form.CheckBox().set({checked:a.value});
b.add(c);
b.addListener("focus",
function(){c.focus();
});
b.addListener("activate",
function(){c.activate();
});
c.addListener("keydown",
function(d){if(d.getKeyIdentifier()=="Enter"){var f=qx.event.Pool.getInstance().getObject(qx.event.type.KeySequence);
var g=b.getContainerElement().getDomElement();
f.init(d.getNativeEvent(),
g,
d.getKeyIdentifier());
f.setType("keydown");
qx.event.Registration.dispatchEvent(g,
f);
}},
this);
return b;
},
getCellEditorValue:function(a){return a.getChildren()[0].getChecked();
}}});
qx.Bootstrap.define("qx.bom.client.Multimedia",
{statics:{__gD:{quicktime:{plugin:"QuickTime",
control:"QuickTimeCheckObject.QuickTimeCheck.1"},
wmv:{plugin:"Windows Media",
control:"WMPlayer.OCX.7"},
divx:{plugin:"DivX Web Player",
control:"npdivx.DivXBrowserPlugin.1"},
silverlight:{plugin:"Silverlight",
control:"AgControl.AgControl"}},
has:function(a,
b){},
__gE:qx.core.Variant.select("qx.client",
{"mshtml":function(){var a=window.ActiveXObject;
if(!a){return;
}var b=this.__gD;
var c,
d;
for(var e in b){c=b[e];
try{d=new ActiveXObject(c.control);
}catch(ex){continue;
}switch(e){case "quicktime":break;
case "wmv":break;
case "divx":break;
case "silverlight":break;
}c.installed=true;
}},
"default":function(){var a=navigator.plugins;
if(!a){return;
}var b=this.__gD;
var c=/([0-9]\.[0-9])/g;
var d,
e,
f;
for(var g=0,
h=a.length;g<h;g++){d=a[g];
e=d.name;
for(var j in b){f=b[j];
if(!f.installed&&e.indexOf(f.plugin)!==-1){f.installed=true;
if(c.test(d.name)||c.test(d.description)){f.version=parseFloat(RegExp.$1,
10);
}else{f.version=0;
}break;
}}}}})},
defer:function(a){a.__gE();
}});
qx.Class.define("qx.ui.progressive.renderer.FunctionCaller",
{extend:qx.ui.progressive.renderer.Abstract,
members:{render:function(a,
b){b.data(a.getUserData());
}}});
qx.Class.define("qx.ui.table.celleditor.SelectBox",
{extend:qx.core.Object,
implement:qx.ui.table.ICellEditorFactory,
construct:function(){arguments.callee.base.call(this);
},
properties:{validationFunction:{check:"Function",
nullable:true,
init:null},
listData:{check:"Array",
init:null,
nullable:true}},
members:{createCellEditor:function(a){var b=new qx.ui.form.SelectBox().set({appearance:"table-editor-selectbox"});
var c=a.value;
b.originalValue=c;
var d=a.table.getTableColumnModel().getDataCellRenderer(a.col);
var e=d._getContentHtml(a);
if(c!=e){c=e;
}if(c===null){c="";
}var f=this.getListData();
if(f){var g;
for(var h=0,
j=f.length;h<j;h++){var k=f[h];
if(k instanceof Array){g=new qx.ui.form.ListItem(k[0],
k[1],
k[2]);
}else{g=new qx.ui.form.ListItem(k,
null,
k);
}b.add(g);
}}b.setValue(""+c);
b.addListener("appear",
function(){b.open();
});
return b;
},
getCellEditorValue:function(a){var b=a.getValue()||"";
var c=this.getValidationFunction();
if(!this._done&&c){b=c(b,
a.originalValue);
this._done=true;
}
if(typeof a.originalValue=="number"){b=parseFloat(b);
}return b;
}}});
qx.Class.define("qx.ui.progressive.renderer.table.Widths",
{extend:qx.core.Object,
construct:function(a){arguments.callee.base.call(this);
this._columnData=[];
for(var b=0;b<a;b++){this._columnData[b]=new qx.ui.table.columnmodel.resizebehavior.ColumnData();
}},
members:{getData:function(){return this._columnData;
},
set:function(a,
b){for(var c in b){switch(c){case "width":this.setWidth(a,
b[c]);
break;
case "minWidth":this.setMinWidth(a,
b[c]);
break;
case "maxWidth":this.setMaxWidth(a,
b[c]);
break;
default:throw new Error("Unrecognized key: "+c);
}}},
setWidth:function(a,
b){if(a>this._columnData.length-1||a<0){throw new Error("Column number out of range");
}this._columnData[a].setWidth(b);
},
setMinWidth:function(a,
b){if(a>this._columnData.length-1||a<0){throw new Error("Column number out of range");
}this._columnData[a].setMinWidth(b);
},
setMaxWidth:function(a,
b){if(a>this._columnData.length-1||a<0){throw new Error("Column number out of range");
}this._columnData[a].setMaxWidth(b);
}}});
qx.Class.define("qx.dev.Debug",
{statics:{debugObject:function(a,
b,
c){if(!c){c=10;
}var d="";
var e=function(a,
f,
c){var g="";
for(var h=0;h<f;h++){g+="  ";
}if(f>c){d+=g+"*** TOO MUCH RECURSION: not displaying ***\n";
return;
}if(typeof (a)!="object"){d+=g+a+"\n";
return;
}for(var j in a){if(typeof (a[j])=="object"){if(a[j] instanceof Array){d+=g+j+": "+"Array"+"\n";
}else{d+=g+j+": "+"Object"+"\n";
}e(a[j],
f+1,
c);
}else{d+=g+j+": "+a[j]+"\n";
}}};
if(b){d+=b+"\n";
}
if(a instanceof Array){d+="Array, length="+a.length+":\n";
}else if(typeof (a)=="object"){var k=0;
for(var j in a){k++;
}d+="Object, count="+k+":\n";
}d+="------------------------------------------------------------\n";
try{e(a,
0,
c);
}catch(ex){d+="*** EXCEPTION ("+ex+") ***\n";
}d+="============================================================\n";
qx.log.Logger.debug(this,
d);
},
getFunctionName:function(a,
b){var c=a.self;
if(!c){return null;
}while(a.wrapper){a=a.wrapper;
}
switch(b){case "construct":return a==c?"construct":null;
case "members":return qx.lang.Object.getKeyFromValue(c,
a);
case "statics":return qx.lang.Object.getKeyFromValue(c.prototype,
a);
default:if(a==c){return "construct";
}return (qx.lang.Object.getKeyFromValue(c.prototype,
a)||qx.lang.Object.getKeyFromValue(c,
a)||null);
}}}});
